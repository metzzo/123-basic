if (typeof preInitFuncs == 'undefined') preInitFuncs = [];
preInitFuncs.push(function() {
	if (viewMode == 'console' && (typeof inEditorPreview == 'undefined')) {
		if (document) {
			window.onload=function( e ){
				var e = document.createElement('textarea');
				e.style.width = '100%';
				e.style.height = '480px';
				e.id = "OTTCONSOLE";
				
				document.body.appendChild(e);
				
				updateConsole();
			}
		} else {
			//egal, rufe updateconsole auf
			updateConsole();
		}
	}
});

var startTime = new Date().getTime();

/**
* @constructor
*/
function OTTException(text, file, line) {
	this.text = text;
	this.line = line;
	this.file = file;
}

/**
* @constructor
*/
function OTTExitException() {
	//exit
}

OTTExitException.prototype.toString = function() {
	return "OTT Exit";
}

OTTException.prototype.toString = function() {
	return "Unhandled exception '"+text+"' in file '"+this.file+"' in line'"+this.line+"'";
}

OTTException.prototype.getText = function() {
	return this.text;
}

OTTException.prototype.toString = function() {
	return "Uncought 123Basic Exception '"+this.text+"' stacktrace: "+STACKTRACE_Str();
}

//alert = function() {}

//------------------------------------------------------------
//Funny variables
//------------------------------------------------------------

var waitload			= 0; //auf wieviel wird gewartet (gibts auch in 2d.js) 
var exec 				= false;
var tmpPositionCache 	= -1; 
var arrargs				= new Array(64); //Die Parameter (in umgeandelter form), 64 maximal
var consoleOutput;
var consoleSize 		= 10000;
var currentDir;
var mainCall			= false;

//------------------------------------------------------------
//Output
//------------------------------------------------------------

function STDOUT(text) {
	if (consoleOutput == undefined) {
		consoleOutput = document ? document.getElementById("OTTCONSOLE") : null;
	}
	
	if (consoleOutput) {
		consoleOutput.value = consoleOutput.value + text;
		consoleOutput.scrollTop = consoleOutput.scrollHeight;
	} else {
		console.log(text);
	}
}


function STDERR(text) {
	STDOUT("Error: "+text);
}

function STDCOLOR(back, fore) {
	//ignore :)
}

function DEBUG(text) {
	console.log(text);
}

function END() {
	window.onbeforeunload();
	throw new OTTExitException();
}


//------------------------------------------------------------
//Info Stuff
//------------------------------------------------------------
var $time = Date.now || function() {
  return +new Date;
};
function GETTIMERALL() {
	return $time() - startTime;
}

function PLATFORMINFO_Str(info) {
	switch(info) {
		case "":
			return "HTML5";
		case "DOCUMENTS":
		case "APPDATA":
		case "TEMP":
			return "/";
		case "ID":
			return ""+uniqueId;
		case "DEVICE":
			//TODO: Andere Devices berücksichtigen
			return "DESKTOP";
		case "BATTERY":
			var bat = navigator.battery || window.navigator.battery || navigator.battery || navigator.mozBattery || navigator.webkitBattery;
			return bat ? bat.level*100 : 100;
		case "TIME":
			var d = new Date();
			var f = function(val) {
				val = CAST2STRING(val);
				if (val.length == 1) val = "0" + val;
				return val;
			}
			return f(d.getFullYear())+"-"+f(d.getMonth())+"-"+f(d.getDate())+" "+f(d.getHours())+":"+f(d.getMinutes())+":"+f(d.getSeconds());
		case "COMPILED":
			return rot13(compileTime);
		case "VERSION":
			return rot13(userDefVersion);
		case "HOSTID":
			return rot13(hostId);
		case "LOCALE":
			return navigator.language || window.navigator.userLanguage || window.navigator.language;
		default:
			if (info.length > "GLEXT:".length && MID_Str(info, 0, "GLEXT:".length) == "GLEXT:") {
				return "0"; //vorerst nichts
			} else {
				return "";
			}
	}
}


function GETLASTERROR_Str() {
	return "0 Successfull";
}

//wait und show wird ignoriert
function SHELLCMD(cmd, wait, show, rv) {
	try {
		rv[0] = CAST2FLOAT(eval(cmd));
	} catch(ex) {
		rv[0] = 0
		rv[0] = 0
		throwError("SHELLCMD raised ab error.");
	}
}

function SHELLEND(cmd) {
	try {
		eval(cmd);
	} catch(ex) {
		throwError("SHELLEND raised an error");
	}
	END();
}

function CALLBYNAME(name) {
	if (!!window[name]) {
		window[name]();
		return 1;
	} else {
		return 0;
	}
}

//------------------------------------------------------------
//Runtime stuff
//------------------------------------------------------------

var callStack = []
/**
* @constructor
*/
function StackFrame(name, info, dbg) {
	this.apply(name, info, dbg);
}
StackFrame.prototype.apply = function(name, info, dbg) {
	this.name = name;
	this.info = info;
	this.dbg  = dbg;
}

function stackPush(name, info) {
	if (!!callStack[callStack.length]) {
		callStack[callStack.length].apply(name, info, __debugInfo);
		callStack.length++;
	} else {
		callStack.push(new StackFrame(name, info, __debugInfo));
	}
}

function stackPop() {
	__debugInfo = callStack[callStack.length];
	callStack.length--; 
	//var obj = callStack.pop();
	//__debugInfo = obj.dbg;
}

function stackTrace() {
	var output = "";
	for (var i = callStack.length-1; i >= 0 ; i--) {
		output += "\tin '"+callStack[i].name+"' in file '"+MID_Str(callStack[i].info, INSTR(callStack[i].info, ":")+1)+"' in line '"+MID_Str(callStack[i].info, 0, INSTR(callStack[i].info, ":"))+"'\n";
	}
	
	return output;
}

function throwError(msg) {
	throw msg;
}

function formatError(msg) {
	msg = msg.message ? msg.message : msg.toString();
	if (msg.indexOf("OTTERR") == 0) msg = msg.substring("OTTERR".length);
	if (debugMode) {
		msg = "Error:\n '"+msg+"' ";
		var info = __debugInfo;
		//debug modus
		msg += "\nAppeared in line '"+MID_Str(info, 0, INSTR(info, ":"))+"' in file '"+MID_Str(info, INSTR(info, ":")+1)+"' "
		
		msg += "\n\n"+stackTrace();
	}
	return msg;
}

function dumpArray(arr) {
	var acc = "";
	var start = false;
	for (var i = 0; i < arr.length; i++) {
		if (start) acc += ", "
		acc += "'"+arr[i]+"'";
		start = true;
	}
	return "["+acc+"]";
}

function toCheck(cur, to, step) {
	if (step > 0) {
		return cur <= to;
	} else if(step < 0) {
		return cur >= to;
	} else {
		return cur != to;
	}
	//return (step > 0) ? (cur <= to) : ((step > 0) ? (cur >= to) : true);
}

function untilCheck(cur, to, step) {
	if (step > 0) {
		return cur < to;
	} else if(step < 0) {
		return cur > to;
	} else {
		return true;
	}
}

function isKnownException(ex) {
	return ex instanceof OTTExitException || ex instanceof OTTException;
}

//versucht zu dereferenzieren falls notwendig
function unref(v) {
	if (v instanceof Array) {
		//damn i have to unref it
		return v[0];
	} else {
		//nothing to do here bro...
		return v;
	}
}

//versucht zu referenzieren falls notwendig
function ref(v) {
	if (v instanceof Array) {
		return v;
	} else {
		return [v];
	}
}


function tryClone(o) {
	switch (typeof o) {
		case 'undefined':
		case 'function':
		case 'string':
		case 'boolean':
		case 'number':
			break;
		default:
			if (o instanceof Array) {
				return [tryClone(o[0])];
			} else {
				return o.clone();
			}
	}
	return o;
	//return (o instanceof Array) ? ([tryClone(o[0])]) : (o.clone ? o.clone() : o);
}

function updateConsole() {
	try {
		if (!mainCall) {
			main();
			mainCall = true;
		}
		
		if (!waitload && !exec) {
			exec = true;

			if (typeof(GLB_ON_INIT) == 'function') GLB_ON_INIT(); //call the 123basic defined initialization function
		} else {
			window.requestAnimFrame(updateConsole, 100);
		}
	} catch(ex) {
		if (ex instanceof OTTExitException) throw(formatError(ex));
	}
}

function castobj(obj, target) {
	if (obj instanceof Array) {
		if (obj[0] instanceof target)
			return obj;
		else
			return [eval("new "+target+"()")];
	} else {
		if (obj instanceof target)
			return obj;
		else
			return eval("new "+target+"()");
	}
	
}


//------------------------------------------------------------
//DATA
//------------------------------------------------------------


var dataLabel, dataPosition;
function RESTORE(label) {
	dataLabel = label;
	dataPosition = 0;
}

function READ() {
	var d = dataLabel[dataPosition];
	dataPosition++;
	return d;
}



//Castet die gegebene Value in eine Ganzzahl (falls NaN kommt => 0 returnen)
function CAST2INT(value) {
	if (value instanceof Array) { //not sure about this
		return [CAST2INT(value[0])];
	} else {
		switch (typeof value) {
			case 'function':
				return 1;
			case 'undefined':
				throwError("Cannot cast 'undefined'");
			case 'number':
				return ~~value; //experimental
				//if (value < 0) return Math.ceil(value); else if (value > 0) return Math.floor(value); else return 0;
			case 'string':
				if (isNaN(value) || value == '') 
					return 0; //Falls keine Nummer => 0
				else
					return parseInt(value, 10);
			case 'boolean':
				return value ? 1 : 0;
			case 'object':
				return CAST2INT(value.toString());
			default:
				throwError("Unknown type!");
		}
	}
}

function INT2STR(value) {
	if (isNaN(value) || value == '') 
		return 0; //Falls keine Nummer => 0
	else
		return parseInt(value, 10);
}

function INTEGER(value) {
	return CAST2INT(value);
}

//Castet die gegebene Value in eine Gleitkommazahl (falls NaN kommt => 0 returnen)
function CAST2FLOAT(value) {
	if (value instanceof Array) { //not sure about this
		return [CAST2FLOAT(value[0])];
	} else {
		switch (typeof value) {
			case 'function':
				return 1.0;
			case 'undefined':
				throwError("Cannot cast 'undefined'");
			case 'number':
				return value;
			case 'string':
				if (isNaN(value) || value == '') 
					return 0.0; //Falls keine Nummer => nummer machen
				else //Ist eine Nummer
					return parseFloat(value);
			case 'boolean':
				return value ? 1.0 : 0.0;
			case 'object':
				return CAST2FLOAT(value.toString());
			default:
				throwError("Unknown type!");
		}
	}
}

function FLOAT2STR(value) {
	if (isNaN(value) || value == '') 
		return 0.0; //Falls keine Nummer => nummer machen
	else //Ist eine Nummer
		return parseFloat(value);
}

function STACKTRACE_Str() {
	return stackTrace();
}


//Castet die gegebene Value in eine Zeichenkette
function CAST2STRING(value) {
	if (value instanceof Array) { //not sure about this
		return [CAST2STRING(value[0])];
	} else {
		switch (typeof value) {
			case 'function':
				return "1";
			case 'undefined':
				throwError("Cannot cast undefined to string");
			case 'boolean':
				return value ? "1" : "0";
			case 'number':
				return ""+value;
			case 'string':
				return value;
			case 'object':
				return value.toString();
			default:
				throwError("Unknown type");
		}
	}
}



function PUTENV(name, value) {
	localStorage.setItem(("env_"+name).toLowerCase(), value);
}

function GETENV_Str(name) {
	return localStorage.getItem(("env_"+name).toLowerCase());
}


function SLEEP(time) {
	var start = GETTIMERALL();
	while ((GETTIMERALL() - start)<time) {} //übler hack :/
}




//-----------------------------------------------------------
//LocalStorage wrapper to cookies (if there is no localStorage) Found on the MDN
//-----------------------------------------------------------

if (!window.localStorage) {
  Object.defineProperty(window, "localStorage", new (function () {
    var aKeys = [], oStorage = {};
    Object.defineProperty(oStorage, "getItem", {
      value: function (sKey) { return sKey ? this[sKey] : null; },
      writable: false,
      configurable: false,
      enumerable: false
    });
    Object.defineProperty(oStorage, "key", {
      value: function (nKeyId) { return aKeys[nKeyId]; },
      writable: false,
      configurable: false,
      enumerable: false
    });
    Object.defineProperty(oStorage, "setItem", {
      value: function (sKey, sValue) {
        if(!sKey) { return; }
        document.cookie = escape(sKey) + "=" + escape(sValue) + "; path=/";
      },
      writable: false,
      configurable: false,
      enumerable: false
    });
    Object.defineProperty(oStorage, "length", {
      get: function () { return aKeys.length; },
      configurable: false,
      enumerable: false
    });
    Object.defineProperty(oStorage, "removeItem", {
      value: function (sKey) {
        if(!sKey) { return; }
        var sExpDate = new Date();
        sExpDate.setDate(sExpDate.getDate() - 1);
        document.cookie = escape(sKey) + "=; expires=" + sExpDate.toGMTString() + "; path=/";
      },
      writable: false,
      configurable: false,
      enumerable: false
    });
    this.get = function () {
      var iThisIndx;
      for (var sKey in oStorage) {
        iThisIndx = aKeys.indexOf(sKey);
        if (iThisIndx === -1) { oStorage.setItem(sKey, oStorage[sKey]); }
        else { aKeys.splice(iThisIndx, 1); }
        delete oStorage[sKey];
      }
      for (/*aKeys*/; aKeys.length > 0; aKeys.splice(0, 1)) { 
		oStorage.removeItem(aKeys[0]);
	  }
      for (var iCouple, iKey, iCouplId = 0, aCouples = document.cookie.split(/\s*;\s*/); iCouplId < aCouples.length; iCouplId++) {
        iCouple = aCouples[iCouplId].split(/\s*=\s*/);
        if (iCouple.length > 1) {
          oStorage[iKey = unescape(iCouple[0])] = unescape(iCouple[1]);
          aKeys.push(iKey);
        }
      }
      return oStorage;
    };
    this.configurable = false;
    this.enumerable = true;
  })());
}

//-----------------------------------------------------------
//Misc
//-----------------------------------------------------------

function NETWEBEND(url) {
	window.location.href = url;
	END();
}


window.requestAnimFrame = (function() {
  return window.requestAnimationFrame ||
         window.webkitRequestAnimationFrame ||
         window.mozRequestAnimationFrame ||
         window.oRequestAnimationFrame ||
         window.msRequestAnimationFrame ||
         function(/* function FrameRequestCallback */ callback, /* DOMElement Element */ element) {
           window.setTimeout(callback, 1000/60);
         };
})();

function checkBrowserName(name){  
	var agent = navigator.userAgent.toLowerCase();  
	if (agent.indexOf(name.toLowerCase())>-1) {  
		return true;  
	}  
	return false;  
}  

window.onbeforeunload = function (e) {
	e = e || window.event;
	
	//rufe noch GLB_ON_QUIT auf
	CALLBYNAME("GLB_ON_QUIT");
	
	//versuche nun das filesystem zu speichern
	saveFileSystem();
};

function saveFileSystem() {
	if (localStorage) {
		localStorage.setItem("filesystem", fileSystem.save());
	}
}


//------------------------------------------------------------
//ARRAY FUN
//------------------------------------------------------------


/**
* Ein OTTArray ist ein Array, welches versucht die OTTArrays unter GLBasic so gut wie m�glich zu simulieren.
* @constructor
*/
function OTTArray(def) {
	this.values = [];
	this.dimensions = [0];
	this.defval = !!def ? def : 0;
	return this;
}

//Klonen!
OTTArray.prototype.clone = function() {
	var other = new OTTArray();
	
	other.dimensions = this.dimensions.slice(0);
	other.defval = this.defval;
	
	//Klonen die drinnen sind!
	switch (typeof this.defval) {
		case 'number':
		case 'string':
		case 'boolean':
		case 'function':
			other.values = this.values.slice(0);
			break;
		default:
			//es muss geklont werden
			if (this.values != undefined && this.dimensions != undefined) {
				for (var i = 0; i < this.values.length; i++) {
					other.values[i] = tryClone(this.values[i]);
				}
			} else {
				other.values = [];
			}
	}
	
	return other;
};

//Zugriff!
OTTArray.prototype.arrAccess = function() {
	tmpPositionCache = 0;
	
	for (var i = arguments.length-1; i >= 0 ; i--) {
		if (i >= this.dimensions.length) throwError("Wrong dimension count '"+(arguments.length-1)+"' expected '"+this.dimensions.length+"'");
		
		var position = arguments[i]; //CAST2INT( normalerweise sollten access automatisch nach INT gecastet worden sein!
		
		if (position < 0)
			position = (this.dimensions[i] + position);
		
		if (position < 0 || position >= this.dimensions[i]) throwError("Array index out of bounds access, position: "+dumpArray(arguments));
		
		arrargs[i] = position;
	}
	
	
	switch (arguments.length) {
		case 1:
			tmpPositionCache = arrargs[0];
			break;
		case 2:
			tmpPositionCache = arrargs[0] + arrargs[1]*this.dimensions[0];
			break;
		case 3:
			tmpPositionCache = arrargs[0] + arrargs[1]*this.dimensions[0] + arrargs[2]*this.dimensions[0]*this.dimensions[1] 
			break;
		case 4:
			tmpPositionCache = arrargs[0] + arrargs[1]*this.dimensions[0] + arrargs[2]*this.dimensions[0]*this.dimensions[1] + arrargs[3]*this.dimensions[0]*this.dimensions[1]*this.dimensions[2];
			break;
		default:
			var mul = this.values.length/this.dimensions[arguments.length-1];
			for (var i = arguments.length-1; i >= 0 ; i--) {
				tmpPositionCache += arrargs[i]*mul;
				mul /= this.dimensions[i-1];
			}
	}
	
	return this;
}

function realArrSize(dims) {
	var realSize = 1;
	for(d in dims) {
		dims[d] = CAST2INT(dims[d]);
		realSize *= dims[d];
	}
	return realSize;
}

//Dimensioniert das gegebene Array
function DIM(vari, dims, value) {
	vari.values = new Array(realArrSize(dims)); //[];//vari.values.length = realArrSize(dims);
	vari.dimensions = dims;
	vari.defval = value;
	
	
	for(var i = 0; i < vari.values.length; i++) {
		vari.values[i] = tryClone(value);
	}
	
	
	return vari;
}
//Redimensioniert das gegebene Array.
function REDIM(vari, dims, value) {
	var oldLength = vari.values.length;
	var doDim = false, action;
	vari.dimensions = dims;
	if (vari.defval !== value) {
		doDim = true;
		if (value instanceof Array && !(vari.defval instanceof Array)) {
			//Es muss ein Array sein
			action = 1
		} else if (!(value instanceof Array) && vari.defval instanceof Array) {
			//Es darf kein Array sein
			action = 2
		} else {
			action = 0 //nichts
		}
	}
	vari.defval = value;
	
	
	//OBACHT k�nnte bei mehrdimensionalen arrys unerwartete ergebnisse liefern, wenn man elemente rausl�scht
	vari.values.length = realArrSize(dims);
	var start = oldLength;
	if (doDim) start = 0;
	for(i = start; i < vari.values.length; i++) {
		if (vari.values[i]) {
			if (action == 1) {
				//Es muss ein Array sein
				vari.values[i] = [vari.values[i]];
			} else if (action == 2) {
				//Es darf kein Array sein
				vari.values[i] = vari.values[i][0];
			}
		} else {
			//default wert geben
			vari.values[i] = tryClone(vari.defval);
		}
	}
	
	return vari;
}

function BOUNDS(array, dimension) {
	return array.dimensions[dimension];
}

function DIMPUSH(array, value) {
	//OBACHT bei Mehrdimensionalen Arrays
	REDIM(array, [array.values.length+1], array.defval);
	array.values[array.values.length-1] = tryClone(value);
}

function DIMDEL(array, position) {
	//OBACHT k�nnte bei mehrdimensionalen arrys unerwartete ergebnisse liefern, wenn man elemente rausl�scht
	array.values.splice(position, 1);
	array.dimensions[0]--;
}

function DIMDATA(array, values) {
	array.values = values;
	array.dimensions = [values.length];
}


//------------------------------------------------------------
//MATH
//------------------------------------------------------------

function SEEDRND(seed) {
	randomseed = seed;
}


function RND(range) {
    if (range == 0) return 0;
	if (range < 0) range = -range;
    //return MAX((Math.random()+.1)*range, range);
	return ~~((range+1) * random());
}

function MIN(a,b) {
	if (a < b) return a; else return b;
}

function MAX(a, b) {
	if (a > b) return a; else return b;
}

function ABS(a) {
	return Math.abs(a);
}

function SGN(a) {
	return a > 0 ? 1 : (a < 0 ? -1 : 0);
}

function SIN(a) {
	return Math.sin(deg2rad(a));
}

function COS(a) {
	return Math.cos(deg2rad(a));
}

function TAN(a) {
	return Math.tan(deg2rad(a));
}

function ACOS(a) {
	return Math.acos(deg2rad(a));
}

function ASIN(a) {
	return Math.asin(deg2rad(a));
}

function ASL(num, shift) {
	return num << shift;
}

function ASR(num, shift) {
	return num >> shift;
}

function ATAN(dy, dx) {
	return rad2deg(Math.atan2(dy, dx));
}

function bAND(a, b) {
	return a & b;
}

function bOR(a, b) {
	return a | b;
}

function bXOR(a, b) {
	return a ^ b;
}

function bNOT(a) {
	return ~a;
}

function MOD(a, b) {
	return CAST2INT(a%b);
}

function FMOD(num, div) {
	return num%div;
}

function FINDPATH(map, result, heu, startx, starty, endx, endy) {
	alert("TODO: findpath");
}

function LOGN(a) {
	return Math.log(a);
}

function POW(a, b) {
	return Math.pow(a, b);
}

function SQR(a) {
	return Math.sqrt(a);
}

function SWAP(a, b) {
	var tmp = a;
	a[0] = b[0];
	b[0] = tmp[0];
}

function SORTARRAY(array, cmp) {
	var cmpFunc;
	if (cmp == 0) {
		cmpFunc = function(a, b) {
			a = unref(a);
			b = unref(b);
			switch (typeof o) {
				case 'undefined':
				case 'function':
				case 'string':
				case 'boolean':
				case 'number':
					return a < b ? -1 : (a > b ? 1 : 0)
				default:
					throwError("TODO: Default sortarray with types!");
					return;
			}
		}
	} else {
		cmpFunc = function(a, b) {
			return cmp([a], [b]);
		}
	}
	array.values.sort(cmpFunc);
}

function deg2rad(val) {
	return (val*(Math.PI/180));
}

function rad2deg(val) {
	return (val*(180/Math.PI));
}

var randomseed = new Date().getTime();
function random() {
	randomseed = (randomseed*9301+49297) % 233280;
	return randomseed/(233280.0);
}

//------------------------------------------------------------
//String:
//------------------------------------------------------------

function strcmp(a, b) {
	return ( a < b ? -1 : ( a > b ? 1 : 0)); 
}

function FORMAT_Str(numLetter, numKommas, Number) {
	var str = CAST2STRING(Number);
	var l = INSTR(str, ".");
	var r = REVINSTR(str, ".");
	
	//wenn l�nger als erwartet
	for(var i = l; i < numLetter; i++) {
		str = " " + str;
	}
	for(var i = r; i < numKommas; i++) {
		str = str + "0";
	}
	
	//wenn k�rzer als erwartet
	for (var i = numLetter; i < l; i++) {
		str = MID_Str(str, 1);
	}
	for (var i = numKommas; i < r; i++) {
		str = MID_Str(str, 0, str.length-1);
	}
	
	return str;
}

function ENCRYPT_Str(code, text) {
	var add = 0;
	for (i = 0; i < code.length; i++) {
		add += ASC(code, i);
	}
	add = add %  16;
	
	var newText = "";
	for (i = 0; i < text.length; i++) {
		newText = newText + CHR_Str(ASC(text, i)+add);
	}
	return newText;
}

function DECRYPT_Str(code, text) {
	var add = 0;
	for (i = 0; i < code.length; i++) {
		add += ASC(code, i);
	}
	add = add % 16;
	
	var newText = "";
	for (i = 0; i < text.length; i++) {
		newText = newText + CHR_Str(ASC(text, i)-add);
	}
	return newText;
}

function LCASE_Str(str) {
	return str.toLowerCase();
}

function UCASE_Str(str) {
	return str.toUpperCase();
}

function MID_Str(str, start, count) {
	try {
		if (count == 1) {
			return str.charAt(start);
		} else {
			if (count == -1)
				return str.substr(start);
			else
				return str.substr(start, count);
		}
	} catch (ex) {
		throwError("string error (MID$): '"+str+"' start: '"+start+"' count: '"+count+"'");
	}
}

function LEFT_Str(str, count) {
	try {
		return str.substr(0, count);
	} catch(ex) {
		throwError("string error (LEFT$): '"+str+"' count: '"+count+"'");
	}
}

function RIGHT_Str(str, count) {
	try {
		return str.substr(str.length - count, count);
	} catch (ex) {
		throwError("string error (RIGHT$): '"+str+"' count: '"+count+"'");
	}
}



function INSTR(str, text, start) {
	if (start == -1) {
		return str.indexOf(text);
	} else {
		return str.indexOf(text, start);
	}
}
function REVINSTR(str, text, start) {
	if (start == -1) {
		return str.lastIndexOf(text);
	} else {
		return str.lastIndexOf(text, start);
	}
}

function CHR_Str(character) {
	return String.fromCharCode(character);
}

function REPLACE_Str(text, from, to) {
	var i=0;
	for(;;){
		i=text.indexOf( from,i );
		if( i==-1 ) return text;
		text=text.substring( 0,i )+to+text.substring( i+from.length );
		i+=to.length;
	}
	return text;
	//return text.replace(from, to);
}

function TRIM_Str(text, repl) {
	return LTRIM_Str(RTRIM_Str(text, repl), repl);
}

function LTRIM_Str(text, repl) {
	for (i =0; i < text.length; i++) {
		var c = text.charAt(i);
		if (repl.indexOf(c) == -1) {
			return text.substr(i);
		}
	}
	return "";
}

function RTRIM_Str(text, repl) {
	for (i =text.length-1; i >= 0 ; i--) {
		var c = text.charAt(i);
		if (repl.indexOf(c) == -1) {
			return text.substr(0,i+1);
		}
	}
	return "";
}

function ASC(text, index) {
	try {
		return text.charCodeAt(index);
	} catch(ex) {
		throwError("string error (ASC): '"+text+"' index: '"+index+"'");
	}
}


function SPLITSTR(text, array, split, dropEmpty) {
	try {
		var last = 0;
		REDIM(array, [0], array.defval);
		for (var i = 0; i <=text.length; i++) {
			var c = text.charAt(i);
			if (split.indexOf(c) != -1 || i == (text.length)) {
				var t = MID_Str(text, last, i - last);
				if (t != "" || !dropEmpty) {
					if (array.defval instanceof Array) {
						DIMPUSH(array, [t]); //wenns ein ref dings ist, in ref packen!
					} else {
						DIMPUSH(array, t);
					}
				}
				last = i+1;
			}
		}
		
		return BOUNDS(array, 0);
	} catch(ex) {
		throwError("string error (SPLITSTR): '"+str+"' split: '"+split+"' dropEmpty: "+dropEmpty);
	}
}

function URLENCODE_Str(url) {
	return encodeURI(url);
}

function URLDECODE_Str(url) {
	return decodeURI(url);
}
//------------------------------------------------------------
//FILE:
//------------------------------------------------------------
function createXMLHttpRequest() {
	try { return new XMLHttpRequest(); } catch(e) {}
	try { return new ActiveXObject("Msxml2.XMLHTTP"); } catch (e) {}
	throwError("XMLHttpRequest not supported");
	return null;
}

function loadText(text) {
	var load = createXMLHttpRequest();
	if (text.charAt(0) == '/') text = text.substring(1); // slash am ans
	load.open("get", text, false);
	load.requestType = 'text';
	load.send(null);
	
	return load.responseText;
}
//FileSystem und variablen laden!
var fileSystem = new VirtualFileSystem(localStorage ? localStorage.getItem("filesystem") : "");; //dynamisch (= kann ver�ndert werden)
var staticFileSystem = new VirtualFileSystem(); //statisch (= tempor�r)

var text = loadText("DIR_STRUCTURE");
if (text == null) {
	throwError("Cannot load dir structure!");
} else {
	var lines = text.split("\n");
	for (var pos = 0; pos < lines.length; pos++) {
		var line = lines[pos];
		if (line.indexOf(":") != -1) {
			// es gibt ein .
			var command = line.substring(0, line.indexOf(":"));
			var param = line.substring(line.indexOf(":")+1);
			
			switch(command) {
				case 'var':
					if (param.indexOf("=") != -1) {
						var name = param.substring(0, param.indexOf("="));
						var value = param.substring(param.indexOf("=")+1);
						if (typeof isInWebWorker == 'undefined') {
							window[name] = value; //setzen \o/
						} else {
							eval(name+" = '"+value+"'");
						}
						
					} else {
						throwError("Expecting '='");
					}
					break;
				case 'folder':
					fileSystem.createDir(param);
					staticFileSystem.createDir(param);
					break;
				case 'static':
					staticFileSystem.createFile(param, []); //unlesbar aber da!
					break;
				case 'editable':
					//TODO!
					staticFileSystem.createFile(param, function(file) {
						var text = loadText(file.path+".123SCRIPT_DATA");
						file.data = text.split(",");
						return file.data;
					});
					break;
				default:
					throwError("Unknown command '"+command+"'");
			}
		}
	}
}



var channels 	= []
function GENFILE() {
	for (var i = 0; i < channels.length; i++) {
		if (!channels[i]) return i;
	}
	return channels.length;
}

//converts the given path "/lol/hallo/wtf.txt" to the result dir and filename
function rawpath(path, dir) {
	path = (TRIM_Str(dir.getFileSystem().getCurrentDir()," ") + TRIM_Str(path," ")).toLowerCase();
	var last = 0;
	var curDir = dir;
	
	for (var i = 0; i < path.length; i++) {
		switch(path.charAt(i)) {
			case '/':
				if (i > 0) {
					//oha ein / also einen tab h�her
					var name = path.substr(last, i - last);
					curDir = curDir.getSubDir(name);
					last = i+1;
				} else {
					last = 1;
				}
				break;
			case '.':
				//schauen was danach kommt
				var nextSymbol = function() {
					i++;
					return i < path.length;
				}
				if (!nextSymbol()) break;
				if (path.charAt(i) == '.') {
					curDir = curDir.getParent();
					if (!nextSymbol()) break; //nun muss ein / sein
					if (path.charAt(i) != '/') throwError("Expecting '/'");
					last = i+1;
				} else if (path.charAt(i) == '/') {
					//wenn ein / ist, ignorieren
					last = i+1;
				}
				
				break;
		}
	}
	
	return new FilePointer(path.substr(last, path.length - last), curDir);
}

/**
* @constructor
*/
function FilePointer(name, dir) {
	this.name = name;
	this.dir = dir;
}

/**
* @constructor
*/
function VirtualFileSystem(text) {
	this.mainDir = new VirtualDirectory("", null, this);
	this.curDir = "";
	
	
	this.copyFile = function(from, to) {
		if (this.doesFileExist(form)) {
			var data = this.getFile(from).getData();
			this.createFile(to, data);
		}
	}
	
	this.getCurrentDir = function() {
		return this.curDir;
	}	
	
	this.setCurrentDir = function(dir) {
		if (RIGHT_Str(dir, 1) != "/") dir += "/" //muss mit / enden!
		this.curDir = dir;
	}
	
	this.getFile = function(file) {
		var d = rawpath(file, this.mainDir);
		return d.dir.getFile(d.name);
	}
	
	this.getDir = function(dir) {
		var d = rawpath(dir, this.mainDir);
		return d.dir;
		//return d.dir.getDir(d.name);
	}
	
	this.doesFileExist = function(file) {
		try {
			var d = rawpath(file, this.mainDir);
			return d.dir.doesFileExist(d.name);
		} catch (ex) {}
		return false;
	}
	
	this.doesDirExist = function(dir) {
		try {
			var d = rawpath(dir, this.mainDir);
			return d.dir.doesDirExist(d.name);
		} catch (ex) {}
		return false;
	}
	
	this.removeFile = function(file) {
		var d= rawpath(file, this.mainDir);
		d.dir.removeFile(d.name);
	}
	
	this.removeDir = function(path) {
		var d = rawpath(path, this.mainDir);
		d.dir.removePath(d.name);
	}
	
	this.createFile = function(file, data) {
		//if (!file || !file.name || file.name.length == 0) return;
		if (!this.doesFileExist(file)) {
			var d = rawpath(file, this.mainDir);
			return d.dir.createFile(file, d.name, data);
		} else {
			var f = this.getFile(file);
			f.data = data;
			return f;
		}
	}
	
	this.createDir = function(dir) {
		//if (!dir || !dir.name || dir.name.length == 0) return;
		if (!this.doesDirExist(dir)) {
			var d = rawpath(dir, this.mainDir);
			return d.dir.createDir(d.name);
		} else return this.getDir(dir);
	}
	
	this["cD"] = this.createDir;
	this["cF"] = this.createFile;
	
	this.getMainDir = function() {
		return this.mainDir; //this.mainDir.charAt(this.mainDir.length - 1) != '/' : this.mainDir+"/" : this.mainDir;
	}
	
	this.save = function() {
		return this.mainDir.save();
	}
	
	if (text != undefined) {
		//tempor�r die k�rzel erstellen
		window["filesystem"] = this;
		eval(REPLACE_Str(text, "t.", "window.filesystem."));
	}
}


/**
* @constructor
*/
function VirtualDirectory(name, parent, system) {
	this.name = name;
	this.parent = parent;
	this.subDirs = [];
	this.files = [];
	this.fileSystem = system;
	
	this.getList = function() {
		return this.subDirs.concat(this.files);
	}
	
	this.getFileSystem = function() {
		return this.fileSystem;
	}
	
	this.doesDirExist = function(dir) {
		for (var i = 0; i < this.subDirs.length; i++) {
			if (this.subDirs[i].name == dir) {
				return true;
			}
		}
		return false;
	}
	
	this.doesFileExist = function(file) {
		for (var i = 0; i < this.files.length; i++) {
			if (this.files[i].name == file) {
				return true;
			}
		}
		return false;
	}
	
	this.removeFile = function(file) {
		for (var i = 0; i < this.files.length; i++) {
			if (this.files[i].name == file) {
				this.files.splice(i, 1);
				return;
			}
		}
		throwError("FileNotFound "+file);
	}
	
	this.removeDir = function(file) {
		for (var i = 0; i < this.subDirs.length; i++) {
			if (this.subDirs[i].name == file) {
				this.subDirs.splice(i, 1);
				return;
			}
		}
		throwError("DirNotFound "+file);
	}
	
	this.createDir = function(name) {
		var d = new VirtualDirectory(name, this,this.fileSystem);
		this.subDirs.push(d);
		return d;
	}
	
	this.createFile = function(path, name, data) {
		var f = new VirtualFile(this, name, data, path);
		this.files.push(f);
		
		return f;
	}
	
	this.getFile = function(name) {
		for (var i = 0; i < this.files.length; i++) {
			if (this.files[i].name == name) {
				return this.files[i];
			}
		}
		throwError("file not found");
	}
	
	this.getDir = function(name) {
		for (var i = 0; i < this.subDirs.length; i++) {
			if (this.subDirs[i].name == name) {
				return this.subDirs[i];
			}
		}
		throwError("Dir not found");
	}
	
	this.getSubDir = function(name) {
		for (var i = 0; i < this.subDirs.length; i++) {
			if (this.subDirs[i].name == name) {
				return this.subDirs[i];
			}
		}
		throwError("Dir not found: "+name);
	}
	
	this.getParent = function() {
		return this.parent;
	}
	
	this.getPath = function() {
		return ((!!this.getParent()) ? this.getParent().getPath()+"/" : "")+this.name;
	}
	
	this.save = function() {
		var text = "";
		if (this.getParent() != null ) text = "t.cD(\""+this.getPath()+"\");\n";
		for (var i = 0; i < this.files.length; i++) {
			text += this.files[i].save();
		}
		for (var i = 0; i < this.subDirs.length; i++) {
			text += this.subDirs[i].save();
		}
		return text;
	}
}

/**
* @constructor
*/
function VirtualFile(dir, name, data, path) {
	this.name = name;
	this.data = data;
	this.dir = dir;
	this.path = path;
	
	this.getName = function() {
		return this.name;
	}
	
	this.getData = function() {
		if (typeof this.data == 'function') {
			return this.data(this);
		} else {
			return this.data;
		}
	}
	
	this.save = function() {
		return "t.cF(\""+this.dir.getPath()+"/"+this.name+"\", "+JSON.stringify(this.getData())+");\n";
	}
}

/**
* @constructor
*/
function Channel(channel, file, mode) {
	this.channel = channel;
	this.mode = mode;
	this.ptr = 0;
	file = file.toLowerCase();
	
	//existiert das file auf der platte?
	if (fileSystem.doesFileExist(file)) {
		//yep ist schon da!
		this.file = fileSystem.getFile(file);
	} else {
		//schauen obs im statischen filesystem liegt
		if (staticFileSystem.doesFileExist(file)) {
			//yey!
			if (mode == 1) { //ist nur lesen, da muss das file nicht ins andere filesystem kopiert werden
				this.file = staticFileSystem.getFile(file);
			} else { //muss ins dynamische hinkopiert werden
				var tmp = staticFileSystem.getFile(file);
				this.file = fileSystem.createFile(file, tmp.getData());
			}
		} else {
			// :( nope... erstelle es im normalen, sofern es gerade nicht im lesemodus ist
			if (mode != 1) {
				try {
					this.file = fileSystem.createFile(file, []);
				} catch (ex) {
					throwError("cannot create file: "+file);
				}
			} else {
				throwError("file not found: "+file);
			}
		}
	}
	
	if (mode == -1) {
		//ptr
		this.ptr = this.file.getData().length;
	}
	
	this.updateSize = function() {
		if (this.ptr > this.file.getData().length) this.file.getData().length = this.ptr;
	}
	
	this.checkPosition = function() {
		if (this.ptr > this.file.getData().length) throwError("Reached end of file: '"+this.ptr+"' filesize: '"+this.file.getData().length+"'");
	}
	
	this.ENDOFFILE = function() {
		return this.ptr >= this.file.getData().length || this.ptr < 0; //TODO: not sure about >= !!111
	}
	this.FILESEEK = function(bytes, dir) {
		var old = this.ptr;
		switch(dir) {
			case -1:
				this.ptr = this.file.getData().length - bytes;
				break;
			case 0:
				this.ptr = bytes;
				break;
			case 1:
				this.ptr += bytes;
				break;
		}
		if (this.ENDOFFILE()) this.ptr = this.file.getData().length; //throwError("Seeked out of file..."); //wenn au�erhalb, dann zur�cksetzen
	}
	
	//reads:
	this.READLINE = function() {
		var line = ""
		var character = "";
		while((character = String.fromCharCode(this.file.getData()[this.ptr])) != "\n" && (this.ptr < this.file.getData().length)) {
			line = line + character;
			this.ptr++;
		}
		this.checkPosition();
		this.ptr++;
		//das \r am ende weg
		if (line.substr(line.length-1,1)=="\r") {
			line = line.substr(0, line.length-1);
		}
		
		return line;
	}
	this.READBYTE = function() {
		this.ptr++;
		var tmp = new Int8Array(1);
		tmp[0] = this.file.getData()[this.ptr-1]; //in ein byte converten
		this.checkPosition();
		return tmp[0];
	}
	this.READUBYTE = function() {
		this.ptr++;
		var tmp = new Uint8Array(1);
		tmp[0] = this.file.getData()[this.ptr-1]; //in ein ubyte casten
		this.checkPosition();
		return tmp[0];
	}
	this.READWORD = function() {
		this.ptr+=2;
		var buf = new ArrayBuffer(2);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-2];
		view8[1] = this.file.getData()[this.ptr-1];
		var tmp = new Int16Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READUWORD = function() {
		this.ptr+=2;
		var buf = new ArrayBuffer(2);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-2];
		view8[1] = this.file.getData()[this.ptr-1];
		var tmp = new Uint16Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READLONG = function() {
		this.ptr+=4;
		var buf = new ArrayBuffer(4);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-4];
		view8[1] = this.file.getData()[this.ptr-3];
		view8[2] = this.file.getData()[this.ptr-2];
		view8[3] = this.file.getData()[this.ptr-1];
		var tmp = new Int32Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READULONG = function() {
		this.ptr+=4;
		var buf = new ArrayBuffer(4);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-4];
		view8[1] = this.file.getData()[this.ptr-3];
		view8[2] = this.file.getData()[this.ptr-2];
		view8[3] = this.file.getData()[this.ptr-1];
		var tmp = new Uint32Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READIEEE = function() {
		this.ptr+=8;
		var buf = new ArrayBuffer(8);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-8];
		view8[1] = this.file.getData()[this.ptr-7];
		view8[2] = this.file.getData()[this.ptr-6];
		view8[3] = this.file.getData()[this.ptr-5];
		view8[4] = this.file.getData()[this.ptr-4];
		view8[5] = this.file.getData()[this.ptr-3];
		view8[6] = this.file.getData()[this.ptr-2];
		view8[7] = this.file.getData()[this.ptr-1];
		var tmp = new Float64Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READSHORTIEEE = function() {
		this.ptr+=4;
		var buf = new ArrayBuffer(4);
		var view8 = new Uint8Array(buf);
		view8[0] = this.file.getData()[this.ptr-4];
		view8[1] = this.file.getData()[this.ptr-3];
		view8[2] = this.file.getData()[this.ptr-2];
		view8[3] = this.file.getData()[this.ptr-1];
		var tmp = new Float32Array(buf);
		this.checkPosition();
		return tmp[0];
	}
	this.READSTR = function(count) {
		var text = "";
		for (var i = 0; i < count; i++) {
			text += CHR_Str(this.READUBYTE());
		}
		return text;
	}
	
	//writes:
	this.WRITEBYTE = function(data) {
		var tmp = new Int8Array(1);
		tmp[0] = data;
		this.file.getData()[this.ptr] = tmp[0];
		
		this.ptr++;
		this.updateSize();
	}
	this.WRITEUBYTE = function(data) {
		var tmp = new Uint8Array(1);
		tmp[0] = data;
		this.file.getData()[this.ptr] = tmp[0];
		
		this.ptr++;
		this.updateSize();
	}
	this.WRITEWORD = function(data) {
		var buffer = new ArrayBuffer(2);
		var wordView = new Int16Array(buffer);
		wordView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITEUWORD = function(data) {
		var buffer = new ArrayBuffer(2);
		var wordView = new Uint16Array(buffer);
		wordView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITELONG = function(data) {
		var buffer = new ArrayBuffer(4);
		var longView = new Int32Array(buffer);
		longView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITEULONG = function(data) {
		var buffer = new ArrayBuffer(4);
		var longView = new Uint32Array(buffer);
		longView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITEIEEE = function(data) {
		var buffer = new ArrayBuffer(8);
		var floatView = new Float64Array(buffer);
		floatView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITESHORTIEEE = function(data) {
		var buffer = new ArrayBuffer(4);
		var floatView = new Float32Array(buffer);
		floatView[0] = data;
		var byteView = new Uint8Array(buffer);
		for (var i = 0; i < byteView.length; i++) {
			this.WRITEUBYTE(byteView[i]);
		}
		this.updateSize();
	}
	this.WRITESTR = function(data) {
		for (var i = 0; i <data.length; i++) {
			this.WRITEUBYTE(ASC(data, i));
			//this.file.getData()[this.ptr] = ASC(data, i);
			//this.ptr++;
		}
		this.updateSize();
	}
	this.WRITELINE = function(data) {
		this.WRITESTR(data+"\r\n");
	}
}

function OPENFILE(channel, file, mode) {
	try {
		channels[channel] = new Channel(channel, file, mode);
		if (channel >= channels.length) channels.length = channel + 1;
		return 1;
	} catch(ex) {
		return 0;
	}
}

function getChannel(chn) {
	if (!channels[chn]) throwError("Cannot find channel: "+chn);
	return channels[chn];
}

function ENDOFFILE(channel) {
	return getChannel(channel).ENDOFFILE() ? 1 : 0;
}

function FILEPOSITION(channel) {
	return getChannel(channel).ptr;
}

function FILESEEK(channel, bytes, dir) {
	getChannel(channel).FILESEEK(bytes, dir);
}

function KILLFILE(file) {
	try {
		if (fileSystem.doesDirExist(file)) {
			fileSystem.removeDir(file);
		} else if (fileSystem.doesFileExist(file)) {
			fileSystem.removeFile(file);
		}
	} catch (ex) {}
	
	try {
		if (staticFileSystem.doesDirExist(file)) {
			staticFileSystem.removeDir(file);
		} else if (staticFileSystem.doesFileExist(file)) {
			staticFileSystem.removeFile(file);
		}
	} catch (ex) {}
}

function CLOSEFILE(channel) {
	channels[channel] = null;
	saveFileSystem(); //fs abspeichern
}

//READ Wrapper
function READUBYTE(channel, b) {
	b[0] = getChannel(channel).READUBYTE();
}

function READBYTE(channel, b) {
	b[0] = getChannel(channel).READBYTE();
}

function READWORD(channel, b) {
	b[0] = getChannel(channel).READWORD();
}

function READUWORD(channel, b) {
	b[0] = getChannel(channel).READUWORD();
}

function READLONG(channel, b) {
	b[0] = getChannel(channel).READLONG();
}

function READULONG(channel, b) {
	b[0] = getChannel(channel).READULONG();
}

function READSHORTIEEE(channel, b) {
	b[0] = getChannel(channel).READSHORTIEEE();
}

function READIEEE(channel, b) {
	b[0] = getChannel(channel).READIEEE();
}

function READLINE(channel, line) {
	line[0] = getChannel(channel).READLINE();
}

function READSTR(channel, str, count) {
	str[0] = getChannel(channel).READSTR(count);
}

//WRITE Wrapper
function WRITEUBYTE(channel, data) {
	getChannel(channel).WRITEUBYTE(data);
}

function WRITEBYTE(channel, data) {
	getChannel(channel).WRITEBYTE(data);
}

function WRITEWORD(channel, data) {
	getChannel(channel).WRITEWORD(data);
}

function WRITEUWORD(channel, data) {
	getChannel(channel).WRITEUWORD(data);
}

function WRITELONG(channel, data) {
	getChannel(channel).WRITELONG(data);
}

function WRITEULONG(channel, data) {
	getChannel(channel).WRITEULONG(data);
}

function WRITESHORTIEEE(channel, data) {
	getChannel(channel).WRITESHORTIEEE(data);
}

function WRITEIEEE(channel, data) {
	getChannel(channel).WRITEIEEE(data);
}
function WRITELINE(channel, data) {
	getChannel(channel).WRITELINE(data);
}

function WRITESTR(channel, data) {
	getChannel(channel).WRITESTR(data);
}

function SETSHOEBOX(data, media) {
	//ignore!
}

function GETCOMMANDLINE_Str() {
	var c = window.location.href;
	var l = INSTR(c, "?");
	if (l == -1) return "";
	return REPLACE_Str(MID_Str(c, l+1), "&", " ");
}

function GETCURRENTDIR_Str() {
	return fileSystem.getCurrentDir();
}

function SETCURRENTDIR(dir) {
	if (dir == '') return;
	
	var tmpDir = rawpath(dir, fileSystem.getMainDir());
	dir = tmpDir.dir.getPath()+dir;
	
	var fs1 = false, fs2 = false;
	try {
		fileSystem.setCurrentDir(dir);
		fs1 = true;
	} catch (ex) {}
	try {
		staticFileSystem.setCurrentDir(dir);
		fs2 = true;
	} catch (ex) {}
	return (fs1 && fs2) ? 1 : 0;
}

function DOESFILEEXIST(file) {
	return (fileSystem.doesFileExist(file) || staticFileSystem.doesFileExist(file)) ? 1 : 0;
}

function DOESDIREXIST(dir) {
	return (fileSystem.doesDirExist(dir) || staticFileSystem.doesDirExist(dir)) ? 1 : 0;
}

function GETFILESIZE(file) {
	try {
		var f = null;
		if (fileSystem.doesFileExist(file)) {
			f = fileSystem.getFile(file);
		} else if (staticFileSystem.doesFileExist(file)) {
			f = staticFileSystem.getFile(file);
		} else {
			throwError("Cannot find file: "+file);
		}
		if (!!f) return f.getData().length;
	} catch(ex) {}
	return 0;
}

function GETFILELIST(find, files) {
	try {
		REDIM(files, [0], files.defval);
		var doesMatch = function(name) {
			var i = 0, j = 0;
			for (var j = 0; j <= find.length; j++) {
				var c = find.charAt(j);
				switch(c) {
					case '*':
						//beliebig lang
						j++;
						var endTok = find.charAt(j);
						j--;
						while(name.charAt(i) != endTok && i < name.length) i++; //bis es wieder zu einem spezialzeichen kommt, wiederholen
						break;
					case '?':
						//ignoriere!
						i++;
						break;
					default:
						if (c != name.charAt(i)) return false;
						i++;
				}
			}
			
			return true;
		}
		
		var data = fileSystem.getDir("").getList().concat(staticFileSystem.getDir("").getList());
		
		var numDir = 0, numFile = 0;
		
		var output = [];
		output.push(".");
		output.push("..");
		for (var i = 0; i <data.length; i++) {
			var o = data[i];
			
			if (doesMatch(o.name)) {
				if (o instanceof VirtualDirectory) {
					numDir++;
				} else if (o instanceof VirtualFile) {
					numFile++;
				} else {
					throwError("Unknown file type");
				}
				
				output.push(o.name);
			}
		}
		
		//output array in das echte array rein
		for (var i = 0; i < output.length; i++) {
			if (files.defval instanceof Array) {
				DIMPUSH(files, [output[i]]);
			} else {
				DIMPUSH(files, output[i]);
			}
		}
		
		//fertig
		return numDir*0x1000+numFile;
	} catch (ex) {
		throwError("GETFILELIST error: find: '"+find+"'");
	}
}

function COPYFILE(source, dest) {
	fileSystem.copyFile(source, dest);
	staticFileSystem.copyFile(source, dest);
}

function CREATEDIR(dir) {
	try {
		fileSystem.createDir(dir);
		staticFileSystem.createDir(dir);
		return 1;
	} catch(ex) {}
	return 0;
}

//-----------------------------------------------------------
//INI
//-----------------------------------------------------------

/**
* @constructor
*/
function INI(file) {
	this.parse = function(text) {
		try {
			var lines = text.replace("\r").split("\n");
			var cat = "";
			for (var i = 0; i < lines.length; i++) {
				var l = lines[i];
				if (INSTR(l, ";") != -1) {
					l = MID_Str(l, 0, INSTR(l, ";"));
				}
				if (MID_Str(l, 0, 1) == '[') {
					//kategorie
					cat = MID_Str(l, 1, REVINSTR(l, ']')-1);
				} else if (INSTR(l, "=") != -1) {
					var k = MID_Str(l, 0, INSTR(l,"="));
					var v = MID_Str(l, INSTR(l,"=")+1);
					INIPUT(cat, k, v);
				}
			}
		} catch(ex) {
			throwError("INI parse error: '"+text*"'");
		}
	}
	
	
	this.put = function(cat, key, value) {
		try {
			cat = cat.toLowerCase();
			var c;
			for (var i = 0;i < this.cats.length; i++) {
				if (this.cats[i].name == cat) {
					c = this.cats[i];
					if (key == "" && value == "") {
						//l�schen
						this.cats.splice(i, 1);
						return;
					}
					break;
				}
			}
			if (!c) {
				c = new INICat(cat);
				this.cats.push(c);
			}
			c.put(key, value);
		} catch(ex) {
			throwError("INIPUT error cat: '"+cat+"' key: '"+key+"' value: '"+value+"'");
		}
	}
	
	
	this.get = function(cat, key) {
		try {
			cat = cat.toLowerCase();
			var c;
			for (var i = 0;i < this.cats.length; i++) {
				if (this.cats[i].name == cat) {
					c = this.cats[i];
					break;
				}
			}
			if (!c) {
				c = new INICat(cat);
			}
			return c.get(key);
		} catch(ex) {
			throwError("INIGET error cat: '"+cat+"' key: '"+key+"'");
		}
	}
	
	this.save = function() {
		var text = "";
		for (var i = 0;i < this.cats.length; i++) {
			text += "["+this.cats[i].name+"]\n"
			text += this.cats[i].save();
		}
		return text;
	}
	
	this.cats = [];	
	this.channel = 1337*2;
	
	try {
		OPENFILE(this.channel, file, 0)
		var size = GETFILESIZE(file);
		if (size > 0) {
			var text = [""];
			READSTR(this.channel, text, size);
			var o = curIni;
			curIni = this;
			this.parse(text[0]);
			curIni = o;
		}
	} catch(ex) {
		throwError("INI load error: '"+file+"'");
	}
	
}

/**
* @constructor
*/
function INICat(name) {
	this.name = name;
	this.keys = [];
	
	this.put = function(key, value) {
		key = key.toLowerCase();
		var kv;
		for (var i = 0;i < this.keys.length; i++) {
			if (this.keys[i].key == key) {
				kv = this.keys[i];
				if (value == "") {
					this.keys.splice(i, 1);
					return;
				}
				break;
			}
		}
		if (!kv) {
			kv = new INIKeyValue(key, value);
			this.keys.push(kv);
		}
	}
	
	this.get = function(key) {
		key = key.toLowerCase();
		var kv;
		for (var i = 0;i < this.keys.length; i++) {
			if (this.keys[i].key == key) {
				kv = this.keys[i];
				break;
			}
		}
		
		if (!kv) {
			return "NO_DATA"
		} else {
			return kv.value;
		}
	}
	
	this.save = function() {
		var text = "";
		for(var i = 0; i < this.keys.length; i++) {
			text += this.keys[i].key+"="+this.keys[i].value+"\n";
		}
		return text;
	}
}

/**
* @constructor
*/
function INIKeyValue(key, value) {
	this.key = key;
	this.value = value;
}

var curIni = null;

function INIOPEN(file) {
	if (!!curIni) {
		//speichern
		var text = curIni.save();
		WRITESTR(curIni.channel, text);
		CLOSEFILE(curIni.channel);
	}
	if (file == "") {
		curIni = null;
	} else {
		curIni = new INI(file);
	}
}

function INIPUT(cat, name, key) {
	if (!!curIni) {
		curIni.put(cat, name, key);
	}
}

function INIGET_Str(cat, name) {
	if (!!curIni) {
		return curIni.get(cat, name);
	}
}
//------------------------------------------------------------
//Variables
//------------------------------------------------------------
if (typeof preInitFuncs == 'undefined') preInitFuncs = [];
preInitFuncs.push(function() {
	if (viewMode == '2d' || (typeof inEditorPreview != 'undefined')) {
		if (typeof window == 'undefined') window = {};
		window.onload=function( e ) {
			if (typeof GFX_WIDTH 	== 'undefined')
				window["GFX_WIDTH"] = 640;
				
			if (typeof GFX_HEIGHT 	== 'undefined')
				window["GFX_HEIGHT"] = 480;
			
			var c = document.createElement('canvas');
			c.width = GFX_WIDTH;
			c.height = GFX_HEIGHT
			c.id = "OTTCANVAS";
			
			document.body.appendChild(c);
			
			init2D('OTTCANVAS');
		}
	}
});


var waitload	= 0; 		//Auf wieviele Sachen muss noch gewartet werden
var curScreen	= null;		//Der aktuell ausgew�hlte Screen
var context		= null; 	//Der JavaScript Kontext
var canvas		= null;		//Das Canvas auf das gezeichnet wird
var clrColor	= RGB(0,0,0); //Die Hintergrundfarbe
var keyInput 	= [];		//Das Inputarray
var fontbuffer	= null;		//der frontbuffer
var backbuffer	= null;		//Der hintergrundbuffer
var initCalled	= false;	//wurde init aufgerufen?
var lastShwscrn	= 0;		//Wann wurde das letzte showscreen gemacht?
var showFPS		= -1; 		//wieviele fps?
var framePrev	= 0;		//welche ms gabs davor?
var frameDelay	= 0;		//wie lange soll gewarten werden?
var canvasWidth, canvasHeight; //Die breite/h�he
var	background	= null;		//Das Hintergrundbg (USEASBMP oder LOADBMP)
var loopFunc 	= null; //Aktueller LOOP
var loops 	 	= [];		//Der Loopstack
var usedSoundformat = 'ogg';	//Das benutzte Soundformat
var hibernate	= false;	//SOlls warten
var transCol	= null;		//Die durchsichtige farbe
var setBmp 		= null;		//die funktion die den hintergrund setzen soll
var lastKey		= ""; //der zuletzt gedr�ckte Buchstabe (ist f�r INKEY)
var inFullscreen= false;
var canvasOffsetLeft = 0;
var canvasOffsetTop = 0;

var waitForFont = false;

var sub_loadingName = "GLB_ON_LOADING";
var sub_loopName = "GLB_ON_LOOP";

//------------------------------------------------------------
// Basic 2D stuff
//------------------------------------------------------------

var doCurrentFunction = function() {
	if (!waitload) {
		loopFunc(); //mainloop
	} else if (!!window[sub_loadingName]) {
		window[sub_loadingName]();
	}
	
	//Nun wieder auf normal
	ALPHAMODE(0);
	if (inPoly) {
		ENDPOLY();
	}
	if (inViewport) {
		context.restore();
		inViewport = false;
	}
}

function update2D() {
	try {
		if (!initCalled) {
			if (waitForFont) {
				if (!waitload) {
					waitForFont = false;
				}
			} else {
				//Erst wenn Font fertig geladen ist
				initCalled = true;
				
				main();
			}
		} else {
			if (setBmp) {
				setBmp();
				setBmp = null;
			}
			
			updateTouches();
			
			if (hibernate) {
				if (ANYMOUSE() || ANYKEY() || globalSpeedX || globalSpeedY) {
					hibernate = false;
				}
			} else {
				canvasWidth = canvas.width; 
				canvasHeight = canvas.height;
				canvasOffsetLeft = getOffsetLeft(canvas);
				canvasOffsetTop = getOffsetTop(canvas);
				
				
				if (showFPS == -1) {
					doCurrentFunction();
				} else {
					var frameStart = GETTIMERALL();
					var frameDelta = frameStart - framePrev;
					
					if (frameDelta >= frameDelay) {
						doCurrentFunction();
							
						frameDelay = showFPS;
						if (frameDelta > frameDelay) {
							frameDelay = frameDelay - (frameDelta - frameDelay);
						}
						framePrev = frameStart;
					}
				}
				
			}
			
			anyKeyPress = false;
		}
		window.requestAnimFrame(update2D, frontbuffer.canvas);
	} catch(ex) {
		if (!(ex instanceof OTTExitException)) throw(formatError(ex));
	}
}

function domExceptionError(ex) {
	if (ex instanceof DOMException) {
		if (ex.code == 18) {
			throwError("Cannot access to ressource (maybe pixel data?). If you use Chrome, please run in localhost or use another browser!");
		} else {
			throwError("Unknown DOM error :(");
		}
	} else throw ex;
}

function PUSHLOOP(loop) {
	var f = eval("window['"+loop+"']");
	if (f == undefined) {
		loopFunc = function() {
			throwError("Call to undefined loop!");
		}
		throwError("Cannot push undefined loop: '"+loop+"'");
	}
	loopFunc = f;
	
	loops.push([f, loop]);
}

function POPLOOP() {
	loops.pop();
	
	if (loops.length == 0) {
		throwError("Cannot pop loop, because loop stack is empty!");
	}
	
	var f = loops[loops.length-1];
	loopFunc = f[0];
}

function GETCURRENTLOOP_Str() {
	var f = loops[loops.length-1];
	return f[1];
}

function RETURNTOLOOP(loop) {
	var f = eval("window."+loop);
	if (f == undefined) {
		throwError("Cannot return to undefined loop: '"+loop+"'");
	}
	while(GETCURRENTLOOP_Str() != loop) {
		POPLOOP();
	}
}

function X_MAKE2D() {
	//noch nichts tun, erst wenn 3D da ist
}

function SHOWSCREEN() {
	
	lastShwscrn = GETTIMERALL();
	if (initCalled) {
		USESCREEN(-2);
		CLEARSCREEN(clrColor);
		USESCREEN(-1);
		frontbuffer.context.drawImage(backbuffer.canvas,0, 0);
		CLEARSCREEN(clrColor);
		//nun noch falls vorhanden den bg zeichnen
		if (!!background) {
			backbuffer.context.drawImage(background, 0, 0);
		}
	}
}


function init2D(canvasName) {
	var myAudio = document.createElement('audio'); 
    var canPlayMp3 = false, canPlayOgg = false;
    if (myAudio.canPlayType) {
		canPlayMp3 = !!myAudio.canPlayType && "" != myAudio.canPlayType('audio/mpeg');
		if (canPlayMp3 == "maybe" || canPlayMp3 == "probably" || canPlayMp3 == true) canPlayMp3 = true; else canPlayMp3 = false;
		canPlayOgg = !!myAudio.canPlayType && "" != myAudio.canPlayType('audio/ogg; codecs="vorbis"');
		if (canPlayOgg == "maybe" || canPlayOgg == "probably" || canPlayOgg == true) canPlayOgg = true; else canPlayOgg = false;
	}
	if (!canPlayOgg && !canPlayMp3) {
		noSound = true; //throwError("Your browser is not able to play sound... please use a newer browser.");
		console.log("No sound playback possible!");
	}
	
	if (canPlayOgg) {
		usedSoundFormat = 'ogg';
	} else {
		usedSoundFormat = 'mp3';
	}
	
	frontbuffer = new Screen(document.getElementById(canvasName), -2);
	register(frontbuffer);
	
	var cnvs = document.createElement('canvas');
	cnvs.width = frontbuffer.canvas.width
	cnvs.height = frontbuffer.canvas.height
	backbuffer = new Screen(cnvs, -1);
	register(backbuffer);
	
	if (typeof window[sub_loadingName] == 'undefined') window[sub_loadingName] = null;
	
	USESCREEN(-2);
    if (!context) {
		throwError("Canvas unsupported, please use a newer browser.");
		END();
	}
	
	function finishEvent(e){
		if(e.stopPropagation){
			e.stopPropagation();
			e.preventDefault();
		} else {
			e.cancelBubble=true;
			e.returnValue=false;
		}
	}
	
	canvas.oncontextmenu = function() {
		return false;
	}
	
	touches.push(new Touch()); //Einen Touch gibts immer!
	
	canvasOffsetLeft = getOffsetLeft(canvas);
	canvasOffsetTop = getOffsetTop(canvas);
	
	//mouse listener
	if (!touchable) {
		canvas.onmousemove = function(ev) {
			if(!ev) ev = window.event();
			
			touches[0].x = ev.pageX - canvasOffsetLeft;
			touches[0].y = ev.pageY - canvasOffsetTop;
		}
		canvas.onmousedown=function( e ) {
			if(!e) e = window.event();
			
			switch( e.button ){
				case 0: touches[0].left 	= true; break;
				case 1: touches[0].middle 	= true; break;
				case 2: touches[0].right 	= true; break;
			}
			
			finishEvent(e);
		}
		
		canvas.onmouseup=function( e ) {
			if(!e) e = window.event();
			
			switch( e.button ){
				case 0: touches[0].left 	= false; break;
				case 1: touches[0].middle 	= false; break;
				case 2: touches[0].right 	= false; break;
			}
			finishEvent(e);
		}
		
		canvas.onmouseout=function( e ){
			if(!e) e = window.event();
			
			touches[0].left 	= false;
			touches[0].right	= false;
			touches[0].middle 	= false;
			finishEvent(e);
		}
		
		wheel = function(ev) {
			var delta = 0;
			if (!ev) ev = window.event;
			if (ev.wheelDelta){
				delta = ev.wheelDelta/120;
				if (window.opera) delta = -delta;
			} else if(ev.detail){
				delta = -ev.detail/3;
			}
			
			touches[0].wheel = (delta > 0) ? 1 : ((delta < 0) ? -1 : 0);
			if(ev.preventDefault) ev.preventDefault();
			ev.returnValue = false;
			
			finishEvent(ev);
		}
		
		if(window.addEventListener) window.addEventListener("DOMMouseScroll", wheel, false);
		window.onmousewheel = document.onmousewheel = wheel;
	} else {
		canvas.addEventListener('touchmove', function(event) {
			updateTouches(event.changedTouches, 'move');
			
			finishEvent(event);
		}, false);
		
		
		canvas.addEventListener('touchstart', function(event) {
			//Beginn...
			updateTouches(event.changedTouches, 'start');
			finishEvent(event);
		}, false);
		
		canvas.addEventListener('touchend', function(event) {
			//Ende...
			updateTouches(event.changedTouches, 'end');
			finishEvent(event);
		}, false);
	}
	//key listener
	document.onkeydown = canvas.onkeydown = function(ev) {
		if(!ev) ev = window.event();
		keyInput[ev.keyCode] = true;
		anyKeyPress = true;
		
		finishEvent(ev);
	}
	document.onkeyup = canvas.onkeyup = function(ev) {
		if(!ev) ev = window.event();
		keyInput[ev.keyCode] = false;
		
		finishEvent(ev);
	}
	// press listener (for INKEY$)
	document.onkeypress = canvas.onkeypress = function(ev) {
		if (!ev) ev = window.event();
		if (ev.keyCode == 8) 
			lastKey = "\b";
		else if (ev.keyCode == 13)
			lastKey = "\n";
		else
			lastKey = CHR_Str(ev.which);
	}
	
	// gamepad listener
	gamepads = navigator.getGamepads || navigator.webkitGetGamepads || navigator.webkitGamepads || navigator.gamepads || navigator.mozGetGamepads || navigator.mozGamepads;
	
	USESCREEN(-1);
	CLEARSCREEN(RGB(0,0,0)); //black background color
	SHOWSCREEN();
	
	if (!!window[sub_loopName]) {
		PUSHLOOP(sub_loopName);
	}
	
	SYSTEMPOINTER(0);
	
	var possibleDirs = ["Media/smalfont.png", "smalfont.png", "smallfont.png", "Media/smallfont.png", "Media/smalfont.bmp", "smalfont.bmp", "smallfont.bmp", "Media/smallfont.bmp"];
	var f = null;
	for (var i = 0; i < possibleDirs.length; i++) {
		if (DOESFILEEXIST(possibleDirs[i])) {
			f = possibleDirs[i];
			break;
		}
	}
	
	if (f != null) {
		LOADFONT(f, 0);
		SETFONT(0);
		waitForFont = true;
	}
	
    update2D(); //call the render function
}

function deInit2D() {
	canvas = null;
	context = null;
    sprites = [];
    screens = [];
    waitload = 0;
    curScreen = null;
    clrColor = RGB(0, 0, 0);
    keyInput = [];
    fontbuffer = null;
    backbuffer = null;
	initCalled = false;
}

function register(obj) {
	if (obj instanceof Sprite) {
		sprites[obj.num] = obj;
		if (obj.num >= sprites.length) sprites.length = obj.num + 1;
	} else if (obj instanceof Screen) {
		screens[obj.num] = obj;
		if (obj.num>=screens.length) screens.length = obj.num + 1; //vllt +3
	} else if (obj instanceof Sound) {
		sounds[obj.num] = obj;
		if (obj.num >= sounds.length) sounds.length = obj.num + 1;
	} else if (obj instanceof SoundChannel) {
		soundChannels[obj.num] = obj;
		if (obj.num >= soundChannels.length) soundChannels.length = obj.num + 1;
	} else if (obj instanceof Font) {
		fonts[obj.num] = obj;
		if (obj.num >= fonts.length) fonts.length = obj.num+1;
	} else {
		throwError("Cannot register unknown object: "+obj.constructor);
	}
	
	return obj.num;
}



//------------------------------------------------------------
//Misc
//------------------------------------------------------------

function FOCEFEEDBACK(joy, dur, x, y) {
	var f = navigator.vibrate || navigator.mozVibrate;
	if (f) f(dur);
}

function GETTIMER() {
	return GETTIMERALL() - lastShwscrn;
}

function ALPHAMODE(mode) {
	var val;
	if (mode < 0) {
		context.globalCompositeOperation = 'source-atop'; // TODO: Implement properly
		val = 1 - (1 + mode);
	} else if (mode > 0) {
		context.globalCompositeOperation = 'source-atop';
		val = mode;
	} else {
		context.globalCompositeOperation = 'source-over'; 
		val = 1;
	}
	
	context.globalAlpha = val;
}

function SETPIXEL(x, y, col) {
	DRAWRECT(x,y,1,1,col);
}

function LIMITFPS(fps) {
	showFPS = fps;
}

function RGB(r, g, b) {
	r = r%256; g = g%256; b = b%256
	return r*0x10000 + g*0x100 + b;
}

var whiteRGB = RGB(255,255,255);

function SETTRANSPARENCY(rgb) {
	transCol = rgb;
	transFontCol = rgb;
}

function SMOOTHSHADING(mode) {
	if (typeof context.imageSmoothingEnabled != 'undefined')
		context.imageSmoothingEnabled = mode ? true : false;
		
	if (typeof context.mozImageSmoothingEnabled != 'undefined')
		context.mozImageSmoothingEnabled = mode ? true : false;
		
	if (typeof context.oImageSmoothingEnabled != 'undefined')
		context.oImageSmoothingEnabled = mode ? true : false;
		
	if (typeof context.webkitImageSmoothingEnabled != 'undefined')
		context.webkitImageSmoothingEnabled = mode ? true : false;
		
	if (typeof context.msImageSmoothingEnabled != 'undefined')
		context.msImageSmoothingEnabled = mode ? true : false;
}

// unused: because fullscreen has to be triggered by the user
function toggleFullScreen() {
  if (!document.fullscreenElement &&    // alternative standard method
      !document.mozFullScreenElement && !document.webkitFullscreenElement) {  // current working methods
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen();
    } else if (document.documentElement.mozRequestFullScreen) {
      document.documentElement.mozRequestFullScreen();
    } else if (document.documentElement.webkitRequestFullscreen) {
      document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
    }
  } else {
    if (document.cancelFullScreen) {
      document.cancelFullScreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitCancelFullScreen) {
      document.webkitCancelFullScreen();
    }
  }
}

function SETSCREEN(width, height, fullscreen) {
	if (fullscreen && !inFullscreen) {
		width = window.innerWidth;
		height = window.innerHeight;
		inFullscreen = true;
	} else if (!fullscreen && inFullscreen) {
		
		inFullscreen = false;
	}
	var set = function(cvs) {
		cvs.width = width
		cvs.height = height;
		cvs.style.width = width+"px";
		cvs.style.height = height+"px";
	}
	
	set(frontbuffer.canvas);
	set(backbuffer.canvas);
	set(canvas);
	
	
	canvasWidth = width
	canvasHeight = height
	
	USESCREEN(-1);
	CLEARSCREEN(RGB(0,0,0)); //black background color
	SHOWSCREEN();
	
	canvasOffsetLeft = getOffsetLeft(canvas);
	canvasOffsetTop = getOffsetTop(canvas);
}

var inViewport = false;
function VIEWPORT(x, y, width, height) {
	if (inViewport) {
		context.restore();
		inViewport = false;
	}
	
	if (x != 0 || y != 0 || width != 0 || height != 0) {
		//clipping \o/
		context.save();
		
		context.beginPath();
		context.rect( x,y,width,height );
		context.clip();
		
		context.translate(x, y);
		inViewport = true;
	}
}

function ALLOWESCAPE(allow) {
	throwError("TODO: allowescape");
}

function AUTOPAUSE(mode) {
	throwError("TODO: autopause");
}

function HIBERNATE() {
	hibernate = true;
}

//------------------------------------------------------------
//get functions
//------------------------------------------------------------

function GETSCREENSIZE(width, height) {
	width[0] = canvas.width
	height[0] = canvas.height;
}

function GETSPRITESIZE(num, width, height) {
	width[0] = 0;
	height[0] = 0;
	
	if (sprites[num] && sprites[num].loaded) {
		width[0] = sprites[num].img.width;
		height[0] = sprites[num].img.height;
	}
}

function GETDESKTOPSIZE(width, height) {
	width[0] = window.innerWidth;
	height[0] = window.innerHeight;
}

function ISFULLSCREEN() {
	return 0;
}

function GETPIXEL(x, y) {
	var data = context.getImageData(x, y, 1, 1);
	return RGB(data[0], data[1], data[2]);
}


function removeTransparency(image, col) {
	if (typeof col == 'undefined') {
		col = transCol
	}
	//Weird hack...
	var width = image.width, height = image.height;
	var buf = document.createElement('canvas');
	buf.width = width;
	buf.height = height;
	
	var scrn = new Screen(buf, -42);
	scrn.context.drawImage(image, 0, 0);
	
	//data modifizieren
	var imageData = scrn.context.getImageData(0, 0, width, height);
	
	for (var y = 0; y < height; y++) {
		inpos = y * width * 4; // *4 for 4 ints per pixel
		outpos = inpos;
		for (var x = 0; x < width; x++) {
			var r = imageData.data[inpos++];
			var g = imageData.data[inpos++];
			var b = imageData.data[inpos++];
			var a = imageData.data[inpos++];
			
			var rgb = RGB(r, g, b);
			if (rgb == col) {
				//Transparent machen!
				a = 0;
			}
			
			imageData.data[outpos++] = r;
			imageData.data[outpos++] = g;
			imageData.data[outpos++] = b;
			imageData.data[outpos++] = a;
		}
	}
	
	scrn.context.putImageData(imageData, 0, 0);
	
	return buf;
}


//------------------------------------------------------------
//save functions
//------------------------------------------------------------
function SAVEBMP(file) {
	throwError("TODO: savebmp");
}

function SAVESPRITE(file, num) {
	throwError("TODO: savesprite");
}

//------------------------------------------------------------
//shape functions
//------------------------------------------------------------
function DRAWLINE(x1, y1, x2, y2, col) {
	context.save();
	context.strokeStyle	= formatColor(col);
	context.beginPath();
	context.moveTo(CAST2INT(x1), CAST2INT(y1));
	context.lineTo(CAST2INT(x2), CAST2INT(y2));
	context.stroke();
	context.restore();
}
function DRAWRECT(x,y,w,h,col) {
	if (col == transCol) {
		// delete this from the canvas
		context.clearRect(x,y,w,h);
	} else {
		context.save();
		context.fillStyle	= formatColor(col);
		context.fillRect(CAST2INT(x), CAST2INT(y), CAST2INT(w), CAST2INT(h));
		context.restore();
	}
}

function formatColor(col) {
	col = col.toString(16);
	while(col.length<6) {
		col = "00"+col;
	}
	return '#'+col;
}


//------------------------------------------------------------
//movie
//------------------------------------------------------------
function LOOPMOVIE(movie) {
	throwError("TODO: loopmovie");
}

function PLAYMOVIE(movie) {
	throwError("TODO:playmovie");
}



function loadAsset(path) {
	var oldpath = path;
	path = path.toLowerCase();
	
	if (!!window.assets) {
		for (var i = 0; i < window.assets.length; i++) {
			if (window.assets[i].name.toLowerCase() == path) {
				return window.assets[i].path;
			}
		}
	}
	return oldpath;
}



function getOffsetLeft(elem) {
    var offsetLeft = 0;
    do {
      if (!isNaN( elem.offsetLeft )) {
          offsetLeft += elem.offsetLeft;
      }
    } while(elem = elem.offsetParent);
    return offsetLeft;
}
function getOffsetTop(elem) {
    var offsetTop = 0;
    do {
      if (!isNaN( elem.offsetTop )) {
          offsetTop += elem.offsetTop;
      }
    } while(elem = elem.offsetParent);
    return offsetTop;
}
//------------------------------------------------------------
//text
//------------------------------------------------------------

var transFontCol = null;
var fonts = [];
var currentFont = -1;

/**
 * @constructor
 */
function Font(path, num, img) {
	this.loaded = false;
	this.path = path;
	this.num = num;
	this.charwidth = 0;
	this.charheight = 0;
	this.chars = new Array(256);
	this.img = img;
	this.oimg = img;
}


function LOADFONT(path, num) {
	if (!transFontCol) {
		transFontCol = RGB(0,0,0);
	}
	var image = new Image();
	var font = new Font(path, num, image);
	
	
	//existiert das bild im filesystem?
	image.onerror = function() {
		if (fonts[num]) {
			waitload--;
			fonts[num] = null;
			if (path != "" && path != "0") {
				throwError("Font '"+num+"' '"+path+"' not found!");
			}
		} //else => es wurde schon gel�scht
	};
	//nein, also lade es von der hdd
	image.onload = function () { 
		if (!font.loaded) {
			waitload--;
			font.loaded = true;
			
			try {
				var width = image.width, height = image.height;
				var buf = document.createElement('canvas');
				buf.width = width;
				buf.height = height;
				
				var scrn = new Screen(buf, -42);
				scrn.context.drawImage(image, 0, 0);
				
				//data modifizieren
				var imageData = scrn.context.getImageData(0, 0, width, height);
				
				var data = imageData.data;
				var fx = 0, fy = 0;
				var sizing = true;
				
				var i = 0;
				
				var getCol = function(x, y) {
					return RGB(data[(y*width + x)*4], data[(y*width + x)*4 + 1], data[(y*width + x)*4 + 2]);
				}
				var trans = function(x,y) {
					return data[(y*width + x)*4 + 3];
				}
				
				var charwidth = null, charheight = null;
				var is256 = height > width;
				charwidth = INTEGER(width/16);
				charheight = INTEGER(height/(is256 ? 16 : 8));
				
				
				font.charwidth = charwidth;
				font.charheight = charheight;
				
				for (var y = fy; y < height; y += charheight) {
					for (var x = fx; x < width; x += charwidth) {
						var realwidth = charwidth;
						
						var startx = null, endx = null;
						
						//DO KERNING STUFF \o/
						for (var leftx = x; leftx < x + charwidth; leftx++) {
							var pixel = false;
							for (var tmpy = y; tmpy < y + charheight; tmpy++) {
								if (getCol(leftx, tmpy) != transFontCol) {
									pixel = true;
									break;
								}
							}
							if (pixel) {
								startx = leftx;
								break;
							}
						}
						
						for (var rightx = x + charwidth - 1; rightx > x; rightx--) {
							var pixel = false;
							for (var tmpy = y; tmpy < y + charheight; tmpy++) {
								if (getCol(rightx, tmpy) != transFontCol) {
									pixel = true;
									break;
								}
							}
							if (pixel) {
								endx = rightx;
								break;
							}
						}
						
						if (typeof startx != 'undefined' && typeof endx != 'undefined' && endx > startx) {
							realwidth = (endx - startx)+1;
						} else {
							realwidth = INTEGER(charwidth/3) - 1;
							startx = x;
						}
						
						font.chars[i] = {
							x: x, y: y,
							//kerning data
							kernx: startx, kernwidth: realwidth,
							width: realwidth+1
						};
						
						i++;
					}
				}
				
				
				
				font.img = removeTransparency(font.img, transFontCol);
			}  catch(ex) {
				//kann keine imagedata holen
				domExceptionError(ex);
			}
		}
	}
	image.src = loadAsset(fileSystem.getCurrentDir() + path);
	
	register(font);
	
	waitload++;
}



function PRINT(text, x, y, kerning) {
	if (currentFont == -1 || !fonts[currentFont].loaded) {
		context.save();
		context.font = "12pt Consolas";
		context.fillStyle	= '#ffffff';
		context.fillText(text, ~~(x+.5), ~~(y+.5)+12);
		context.restore();
	} else {
		context.save();
		x = ~~(x+.5);
		y = ~~(y+.5);
		
		var curposx = 0;
		
		var font = fonts[currentFont];
		for (var i = 0; i < text.length; i++) {
			var pos = text.charCodeAt(i);
			
			if (pos >= font.chars.length) {
				throwError("Unicode unsupported! "+pos);
			}
			var c = font.chars[pos];
			if (!!c && pos > 26) {
				var pos, tex, w;
				if (kerning) {
					pos = x; //-~~(font.charwidth/2+.5)+~~(c.width/2+.5);
					tex = c.kernx;
					w = c.kernwidth;
				} else {
					pos = x;
					tex = c.x;
					w = font.charwidth;
				}
				
				context.drawImage(font.img, tex, c.y, w, font.charheight, pos, y, w, font.charheight);
				
				
				if (kerning) {
					x += c.width;
				} else {
					x += font.charwidth;
				}
			} else {
				x += font.charwidth;
			}
		}
		context.restore();
	}
}

function SETFONT(num) {
	currentFont = num;
}

function KERNLEN(text, len) {
	if (currentFont == -1 || !fonts[currentFont].loaded) {
		throwError("Font not yet loaded - unable to determine length!");
	} else {
		var font = fonts[currentFont];
		var w = 0;
		for (var i = 0; i < text.length; i++) {
			var pos = text.charCodeAt(i);
		
			if (pos >= font.chars.length) {
				throwError("Unicode unsupported! "+pos);
			}
			var c = font.chars[pos];
			
			if (!!c) {
				if (len) {
					w+=c.width;
				} else {
					w+=font.charwidth;
				}
			}
		}
		return w;
	}
}

function GETFONTSIZE(width, height) {
	if (currentFont == -1 || !fonts[currentFont].loaded) {
		throwError("Font not yet loaded - unable to determine length!");
	} else {
		width[0] =  fonts[currentFont].charwidth;
		height[0] = fonts[currentFont].charheight;
	}
}

//------------------------------------------------------------
//sound
//------------------------------------------------------------
var engines = {
	// this engine is way more flexible, but is not supported by a lot of browsers
	WEBAUDIO: {
		play: function(sound, pan, volume) {
			var curChn = sound.getNextFreeChannel();
			if (!curChn) {
				curChn = sound.buffers[0];
				soundEngine.newSource(curChn);
			}
			
			if (sound.loop) {
				curChn.source.loop = true;
			}
			// clear timeout if exists
			if (!!curChn.timeout) {
				clearTimeout(curChn.timeout);
				curChn.timeout = null;
			}
			
			
			curChn.playing = true;
			var startPos = 0;
			if (!!curChn.pauseTime) {
				curChn.startTime = GETTIMERALL() - curChn.pauseTime;
				curChn.source.start(0, startPos = (curChn.pauseTime / 1000));
			} else {
				curChn.startTime = GETTIMERALL();
				curChn.source.start(0);
			}
			
			curChn.panner.setPosition(pan*5, 0, 0);
			curChn.gainNode.gain.value = volume;
			
			curChn.timeout = setTimeout(function() {
				soundEngine.stop(curChn);
			}, (curChn.sound.data.duration+1)*1000 - startPos*1000);
		},
		setVolume: function(channel, volume) {
			channel.gainNode.gain.value = volume;
		},
		stop: function(channel) {
			if (channel.playing) {
				channel.pauseTime = null;
				channel.startTime = null;
				channel.source.stop(0);
				channel.playing = false;
				
				// clear timeout if exists
				if (!!channel.timeout) {
					clearTimeout(channel.timeout);
					channel.timeout = null;
				}
				
				// new
				soundEngine.newSource(channel);
			}
		},
		pause: function(channel) {
			if (channel.playing) {
				channel.pauseTime = GETTIMERALL() - channel.startTime;
				channel.source.stop(0);
				channel.playing = false;
				
				// clear timeout if exists
				if (!!channel.timeout) {
					clearTimeout(channel.timeout);
					channel.timeout = null;
				}
			}
		},
		newSource: function(channel) {
			channel.gainNode = audioContext.createGain();
			channel.panner = audioContext.createPanner();
			channel.source = audioContext.createBufferSource();
			
			if (!channel.source.start) channel.source.start = channel.source.noteOn;
			if (!channel.source.stop) channel.source.stop = channel.source.noteOff;
			
			channel.source.buffer = channel.sound.data;
			// channel.source.connect(audioContext.destination);
			
			channel.startTime = null; // used when pausing
			channel.pauseTime = null; // used when pausing
			
			channel.source.connect(channel.gainNode);
			channel.gainNode.connect(channel.panner);
			channel.panner.connect(audioContext.destination);
		},
		load: function(sound) {
			var request = new XMLHttpRequest();
			request.open('GET', sound.file, true);
			request.responseType = 'arraybuffer';

			request.onload = function() {
				audioContext.decodeAudioData(request.response, function(buffer) {
					waitload--;
					sound.loaded = true;
					sound.data = buffer;
					// sound sourcen erstellen
					for (var i = 0; i < sound.buffers.length; i++) {
						(function() {
							var channel = new SoundChannel(sound);
							soundEngine.newSource(channel);
							sound.buffers[i] = channel;
							channel.timeout = null; // when audio is finished
							channel.finishedLoading();
						})();
					}
				}, function() {
					waitload--;
					throwError("Could not load WebAudio file.");
				});
			}
			request.send();
		}
	},
	
	// this is more or less the fallback, because it is widely supported
	AUDIO: {
		play: function(sound, pan, volume) {
			var curChn = sound.getNextFreeChannel();
			if (!curChn) {
				curChn = sound.buffers[0];
				soundEngine.stop(curChn);
			}
			if (!volume) volume = curChn.audio.volume;
			if (!pan) pan = 0;
			
			if (curChn.playing) sound.stop(curChn);
			
			curChn.playing = true;
			curChn.audio.volume = volume;
			curChn.audio.pan = pan;
			curChn.audio.play();
			return curChn.num;
		},
		setVolume: function(channel, volume) {
			channel.audio.volume = volume;
		},
		stop: function(channel) {
			if (channel.playing) {
				channel.audio.pause();
				channel.audio.currentTime = 0;
				channel.playing = false;
			}
		},
		pause: function(channel) {
			if (channel.playing) {
				channel.audio.pause();
				channel.playing = false;
			}
		},
		load: function(sound) {
			sound.audio =  new Audio(sound.file);
			sound.audio.autoplay = false;
			sound.audio.load();
			document.body.appendChild( sound.audio );
			
			sound.audio.addEventListener("onerror", function() {
				waitload--;
				if (sound.file != "" && sound.file != "0") {
					throwError("Sound '"+sound.num+"' '"+sound.file+"' not found!");
				}
			}, false);
			sound.audio.addEventListener("canplaythrough", function() {
				if (!sound.loaded) {
					sound.loaded = true;
					waitload--;
					
					//buffer erstellen
					for (var i = 0; i < sound.buffers.length; i++) { 
						(function() {
							var channel = new SoundChannel(sound);
							channel.audio = sound.audio.cloneNode(true);
							channel.audio.load();
							
							channel.audio.addEventListener( 'canplaythrough', function() {
								channel.finishedLoading();
							}, false );
							channel.audio.addEventListener("ended", function() {
								channel.finishedPlaying();
							}, false);
							
							sound.buffers[i] = channel;
						})();
					}
					
					
				}
			}, false);
		}
	}
};

window.AudioContext = window.AudioContext||window.webkitAudioContext||window.mozAudioContext||window.msAudioContext||window.oAudioContext;
var audioContext;
if (!!window.AudioContext) {
	try {
		audioContext = new AudioContext();
		if (!audioContext.createGain) audioContext.createGain = audioContext.createGainNode
		
		audioContext.listener.setPosition(0,0,0);
	} catch(e) {
		audioContext = null;
	}
}

var soundEngine =  !!audioContext ? engines.WEBAUDIO : engines.AUDIO; // which sound engine is currently being used
var sounds = [];
var soundChannels = [ ];
var music = null, musicVolume = 1;

/**
* @constructor
*/
function Sound(file, num, buffer) {
	this.file = file;
	this.num = num;
	this.buffer = buffer;
	this.music = false;
	this.loop = false;
	this.loaded = false;
	this.buffers = [ ];
	this.buffers.length = this.buffer;
	
	soundEngine.load(this);
	waitload++;
}
Sound.prototype.getNextFreeChannel = function() {
	var curChn = null;
	for (var i = 0; i < this.buffers.length; i++) {
		if (!this.buffers[i].playing) {
			curChn = this.buffers[i];
			break;
		}
	}
	return curChn;
}


/**
* @constructor
*/
function SoundChannel(sound) {
	this.sound = sound;
	this.playing = false;
	this.loaded = false;
	
	this.id = null;
	// find next free channel ID
	for (var i = 0; i < soundChannels.length; i++) {
		if (!soundChannels[i]) {
			this.id = i;
			break;
		}
	}
	if (!this.id) {
		this.id = soundChannels.length;
		soundChannels.length++;
	}
	
	soundChannels[this.id] = this;
}

SoundChannel.prototype.finishedLoading = function() {
	if (!this.loaded) {
		this.loaded = true;
		if (this.sound.music) {
			soundEngine.setVolume(this, musicVolume);
			
			var that = this;
			setTimeout(function() {
				 soundEngine.play(that.sound, 0, musicVolume);
			}, 0);
		}
	}
}
SoundChannel.prototype.finishedPlaying = function() {
	this.playing = false;
	if (this.sound.loop) {
		var that = this;
		setTimeout(function() {
			soundEngine.play(that.sound, 0, musicVolume);
		}, 0);
	}
}

function LOADSOUND(file, num, buffer) {
	if (file == "") {
		// TODO: free up
	} else {
		var ass = loadAsset(file);
		
		if (ass == file) {
			var fileName = REPLACE_Str(MID_Str(file, MAX(0, file.lastIndexOf('/')), -1),"/","");
			file = REPLACE_Str(file, fileName, ".html5_convertedsounds_"+fileName)+"/";
			
			if (usedSoundFormat == 'ogg') {
				file +="sound.ogg";
			} else { //mp3
				file +="sound.mp3";
			}
			file = "./"+file;
		} else {
			file = ass;
		}
		if (buffer <= 0) throwError("LOADSOUND buffer size must not be 0");
		
		var sound = new Sound(file, num, buffer);
		register(sound);
	}
}

function PLAYSOUND(num, pan, volume) {
	var s = sounds[num];
	if (!!s) {
		if (s.loaded) {
			return soundEngine.play(s, pan, volume);
		} else {
			return -1;
		}
	} else {
		throwError("Attempt to play unavailable sound '"+num+"'");
	}
}

function HUSH() {
	for (var i = 0; i < soundChannels.length; i++) {
		if (!!soundChannels[i]&& soundChannels[i].playing) soundChannels[i].stop();
	}
}

function SOUNDPLAYING(chn) {
	return (!!soundChannels[chn] && soundChannels[chn].playing ) ? 0 : 1;
}

function PLAYMUSIC(file, loop) {
	if (file == "") {
		// TODO: free up
	} else {
		var ass = loadAsset(file);
		if (ass == file) {
			var fileName = REPLACE_Str(MID_Str(file, MAX(0, file.lastIndexOf('/')), -1),"/","");
			file = REPLACE_Str(file, fileName, ".html5_convertedsounds_"+fileName)+"/";
			
			if (usedSoundFormat == 'ogg') {
				file +="sound.ogg";
			} else { //mp3
				file +="sound.mp3";
			}
			file = "./"+file;
		} else {
			file = ass;
		}
		
		music = new Sound(file, -42, 1);
		
		music.loop = loop;
		music.music = true;
	}
	
}

function STOPMUSIC() {
	soundEngine.stop(music.buffers[0]);
}

function ISMUSICPLAYING() {
	return music.buffers[0].playing ? 1 : 0;
}

function PAUSEMUSIC(pause) {
	soundEngine.stop(music.buffers[0]);
}

function MUSICVOLUME(vol) {
	musicVolume = vol;
	if (!!music.loaded) {
		soundEngine.setVolume(music.buffers[0], vol);
	}
}



//------------------------------------------------------------
//input
//------------------------------------------------------------

var currentMouse= 0;


//Mouse/Touch Input
var anyKeyPress = false;	//Wurde eine Taste gedr�ckt?
var anyMousePress = false;	//Wurde eine Mouse gedr�ckt?

var globalSpeedX, globalSpeedY; //f�r HIBERNATE
var touches		= [];
var touchable	= document ? ('createTouch' in document) : false;

var gamepads;

/**
* @constructor
*/
function Touch() {
	this.lastx 	= 0;
	this.lasty 	= 0;
	this.speedx = 0;
	this.speedy = 0;
	
	this.x = 0;
	this.y = 0;
	
	this.left	= false;
	this.right 	= false;
	this.middle = false;
	this.wheel 	= 0;
	this.reallywheel = 0;
	
	this.identifier = null; // used by touch API
}
Touch.prototype.applyTouch = function(touch) {
	this.left = true;
	this.identifier = touch.identifier;
	this.x = touch.pageX - canvasOffsetLeft;
	this.y = touch.pageY - canvasOffsetTop;
}

function findTouchIndexByIdentifier(identifier) {
	for (var i = 0; i < touches.length; i++) {
		if (touches[i].identifier == identifier) {
			return i;
		}
	}
	return -1;
}

function updateTouches(t, state) {
	anyMousePress = false;
	if (t) {
		switch(state) {
			case 'start':
				//falls neue tasten => draufhauen
				for (var i = 0; i < t.length; i++) {
					var tmp = t[i];
					var touch = tmp.identifier != 0 ? new Touch() : touches[0];
					touch.applyTouch(tmp);
					if (tmp.identifier != 0) touches.push(touch);
				}
				break;
			case 'end':
				//Alle Tasten zur�cksetzen
				for (var i = 0; i < t.length; i++) {
					var tmp = t[i];
					var touchid = findTouchIndexByIdentifier(tmp.identifier);
					if (tmp.identifier != 0) {
						if (touchid >= 0) {
							touches.splice(touchid, 1);
						}
					} else {
						touches[0].left = false;
					}
				}
				break;
			case 'move':
				//Nun die gedr�ckten Tasten setzen
				for (var i = 0; i < t.length; i++) {
					var tmp = t[i];
					var touchid = findTouchIndexByIdentifier(tmp.identifier);
					if (touchid >= 0) {
						touches[touchid].applyTouch(tmp);
					}
				}
				break;
		}
	} else {
		globalSpeedX = 0;
		globalSpeedY = 0;
		
		for (var i = 0; i <touches.length;i++) {
			var touch = touches[i];
			if (!!touch) {
				touch.reallywheel = touch.wheel
				touch.wheel = 0;
				
				touch.speedx = (touch.x - touch.lastx);
				touch.speedy = (touch.y - touch.lasty);
				
				globalSpeedX += touch.speedx;
				globalSpeedY += touch.speedy;
				
				touch.lastX = touch.x;
				touch.lastY = touch.y;
				
				if (touch.left || touch.right || touch.middle) {
					anyMousePress = true;
				}
			}
		}
	}
}

// GAMEPAD
function GETNUMJOYSTICKS() {
	if (!!gamepads) {
		return gamepads.length;
	} else return 0;
}

function GETJOYNAME_Str(n) {
	return gamepads[n].id;
}

function GETJOYX(n) {
	return gamepads[n].axes[0];
}

function GETJOYY(n) {
	return gamepads[n].axes[1];
}

function GETJOYZ(n) {
	return 0; // umimplemented
}

function GETJOYRX(n) {
	return gamepads[n].axes[2];
}

function GETJOYRY(n) {
	return gamepads[n].axes[3];
}

function GETJOYRZ(n) {
	return 0;
}

function GETJOYBUTTON(n, m) {
	return gamepads[n].buttons[m];
}

function GETDIGIX(n) {
	return gamepads[n].buttons[15]-gamepads[n].buttons[14];
}

function GETDIGIY(n) {
	return gamepads[n].buttons[13]-gamepads[n].buttons[12];
}

// stuff
function MOUSEAXIS(info) {
	if (currentMouse >= 0 && currentMouse < touches.length) {} else {
		return;
	}
	var t = touches[currentMouse];
	switch(info) {
		case 0:
			return t.speedx;
		case 1:
			return t.speedy;
		case 2:
			return t.reallywheel;
		case 3:
			return t.left ? 1 : 0;
		case 4:
			return t.right ? 1 : 0;
		case 5:
			return t.middle ? 1 : 0;
	}
}

function SETACTIVEMOUSE(mouse) {
	currentMouse = mouse;
	if (mouse < 0 || mouse >= touches.length) throwError("Invalid mouse index '"+mouse+"' max: '"+touches.length+"'");
}

function GETMOUSECOUNT() {
	return touches.length;
}

function MOUSESTATE(x, y, ml, mr) {
	if (currentMouse >= 0 && currentMouse < touches.length) {} else {
		return;
	}
	var t = touches[currentMouse];
	x[0] 	= t.x
	y[0] 	= t.y;
	ml[0]	= t.left ? 1 : 0;
	mr[0]	= t.right ? 1 : 0;
}

function SYSTEMPOINTER(show) {
	if (show) {
		canvas.style.cursor = '';
	} else {
		canvas.style.cursor = 'none';
	}
}

function KEY(key) {
	key = ott2jsKeyCode(key);
	return keyInput[key] ? 1 : 0;
}

function ott2jsKeyCode(key) {
	switch(key) {
		case 14:
			return 8;
		case 15:
			return 9;
		case 28:
			return 13;
		case 42:
			return 16;
		case 29:
		case 157:
			return 17;
		case 56:
		case 29: //ALT GR
		case 184: //ALT GR
			return 18;
		case 197:
			return 19;
		case 58:
			return 20;
		case 1:
			return 27;
		case 201:
			return 33;
		case 57:
			return 32;
		case 209:
			return 34;
		case 207:
			return 35;
		case 178:
			return 36;
		case 203:
			return 37;
		case 200:
			return 38;
		case 205:
			return 39;
		case 208:
			return 40;
		case 183:
			return 44;
		case 210:
			return 45;
		case 211:
			return 46;
		case 11:
			return 48;
		case 2:
			return 49;
		case 3:
			return 50;
		case 4:
			return 51;
		case 5:
			return 52;
		case 6:
			return 53;
		case 7:
			return 54;
		case 8:
			return 55;
		case 9:
			return 56;
		case 10:
			return 57;
		case 30:
			return 65;
		case 48:
			return 66;
		case 46:
			return 67;
		case 32:
			return 68;
		case 18:
			return 69;
		case 33:
			return 70;
		case 34:
			return 71;
		case 35:
			return 72;
		case 23:
			return 73;
		case 36:
			return 74;
		case 37:
			return 75;
		case 38:
			return 76;
		case 50:
			return 77;
		case 49:
			return 78;
		case 24:
			return 79;
		case 25:
			return 80;
		case 16:
			return 81;
		case 19:
			return 82;
		case 31:
			return 83;
		case 20:
			return 84;
		case 22:
			return 85;
		case 47:
			return 86;
		case 17:
			return 87;
		case 45:
			return 88;
		case 44:
			return 89;
		case 21:
			return 90;
		case 219:
			return 91;
		case 220:
			return 92;
		//case KEY_SELECT = 93:
		//	return 93;
		case 82:
			return 96;
		case 79:
			return 97;
		case 80:
			return 98;
		case 81:
			return 99;
		case 75:
			return 100;
		case 76:
			return 101;
		case 77:
			return 102;
		case 71:
			return 103;
		case 72:
			return 104;
		case 73:
			return 105;
		case 55:
			return 106;
		case 78:
			return 107;
		case 74:
			return 109;
		case 83:
			return 110;
		case 181:
			return 111;
		case 59:
			return 112;
		case 60:
			return 113;
		case 61:
			return 114;
		case 62:
			return 115;
		case 63:
			return 116;
		case 64:
			return 117;
		case 65:
			return 118;
		case 66:
			return 119;
		case 67:
			return 120;
		case 68:
			return 121;
		case 87:
			return 122;
		case 88:
			return 123;
		case 69:
			return 144;
		case KEY_SCROLLLOCK= 145:
			return 70;
	}
}

function INKEY_Str() {
	var k = lastKey;
	lastKey = "";
	return k;
}

function ANYKEY() {
	return anyKeyPress ? 1 : 0;
}

function ANYMOUSE() {
	return anyMousePress ? 1 : 0;
}
//------------------------------------------------------------
//Basic classes (Sprite, Screen, etc)
//------------------------------------------------------------

var sprites		= []; 		//Alle Sprites im Array

/**
* @constructor
*/
function Sprite(img, num) {
	this.img = img;
	this.oimg = img;
	this.num = num;
	this.data = null;
	this.loaded = false;
	this.tint = null; //Hat es das tinting?
	
	this.frames = null;
	this.frameWidth = -1;
	this.frameHeight = -1;
}

function getSprite(num, notstrict) {
	if (!!sprites[num]) {
		if (!sprites[num].loaded) throwError("Image not yet loaded '"+num+"'");
		return sprites[num];
	} else {
		if (!notstrict) {
			throwError("Image not available '"+num+"'");
		} else {
			return null;
		}
	}
}


//------------------------------------------------------------
// sprite loading
//------------------------------------------------------------

function LOADSPRITE(path, num) {
	var image = new Image();
	var spr = new Sprite(image, num);
	//existiert das bild im filesystem?

	image.onerror = function() {
		if (sprites[num]) {
			waitload--;
			sprites[num] = null;
			if (path != "" && path != "0") {
				throwError("Image '"+num+"' '"+path+"' not found!");
			}
		} //else => es wurde schon gel�scht
	};
	//nein, also lade es von der hdd
	image.onload = function () { 
		if (!spr.loaded) {
			waitload--;
			spr.loaded = true;
			
			updateFrames(num);
			
			//transparency rausl�schen
			try {
				if (typeof transCol != 'undefined' && !!transCol) {
					spr.img = removeTransparency(spr.oimg);
				}
			}  catch(ex) {
				//kann keine imagedata holen
				domExceptionError(ex);
			}
			//on sprite loaded rufen
			
		}
	}
	image.src = loadAsset(fileSystem.getCurrentDir() + path);
	
	register(spr);
	
	waitload++;
}


function SETSPRITEANIM(num, frmw, frmh) {
	var spr = sprites[num];
	if (!spr) throwError("Cannot SETSPRITEANIM to unloaded sprite '"+num+"'");
	spr.frames = null;
	if (frmw && frmh) {
		//animation!
		spr.frameWidth = frmw;
		spr.frameHeight = frmh;
	} else {
		spr.frameWidth = -1;
		spr.frameHeight = -1;
	}
	
	if (spr.loaded) {
		//direkt updaten!
		updateFrames(num);
	}
}

function updateFrames(num) {
	//nun die frames in das sprite
	var spr = getSprite(num);
	if (spr.frameWidth != -1 && spr.frameHeight != -1) {
		spr.frameWidth = MAX(MIN(spr.frameWidth, spr.img.width), 0);
		spr.frameHeight = MAX(MIN(spr.frameHeight, spr.img.height), 0);
		
		spr.frames = [];
		var i = 0;
		for (var y = 0; y < spr.img.height; y+= spr.frameHeight) {
			for (var x = 0; x < spr.img.width; x += spr.frameWidth) {
				spr.frames.push({posx: x, posy: y});
			}
		}
	}
}

function LOADANIM(path,num, width, height) {
	LOADSPRITE(path, num, width, height);
	SETSPRITEANIM(num, width, height);
}


function MEM2SPRITE(pixels, num, width, height) {
	var buf = document.createElement('canvas');
	buf.width = width;
	buf.height = height;
	var spr = new Sprite(buf, num);
	register(spr);
	spr.loaded = true;
	var scrn = new Screen(buf, -42);
	try {
		var isref = pixels.deval instanceof Array;
		var imageData = scrn.context.getImageData(0,0,width, height);
		var data = imageData.data;
		for (var x = 0; x < width; x++) {
			for (var y = 0; y < height; y++) {
				var pos = x + y*width;
				var p = pixels.arrAccess(pos).values[tmpPositionCache];
				if (isref) p = p[0]; // Dereferenzieren, falls notwendig
				
				var a = (p & 0xFF000000)/0x1000000;
				var b = (p & 0xFF0000)/0x10000;
				var g = (p & 0xFF00)/0x100;
				var r =  p & 0xFF;
				
				if (a == -1) a = 255;
				
				pos *= 4;
				data[pos]   = r; 
				data[pos+1] = g;
				data[pos+2] = b;
				data[pos+3] = a;
			}
		}
		scrn.context.putImageData(imageData, 0, 0);
	} catch(ex) {
		//kann keine imagedata holen
		return 0;
	}
	return 1;
}

function SPRITE2MEM(pixels, num) {
	var isref = pixels.deval instanceof Array;
	
	var spr = getSprite(num);
	if (isref)
		DIM(pixels, [spr.img.width*spr.img.height], [0]);
	else
		DIM(pixels, [spr.img.width*spr.img.height], 0);
	
	var width = spr.img.width, height = spr.img.height;
	var buf = document.createElement('canvas');
	buf.width = width;
	buf.height = height;
	
	var scrn = new Screen(buf, -42);
	scrn.context.drawImage(spr.img, 0, 0);
	
	//data modifizieren
	try {
		var imageData = scrn.context.getImageData(0, 0, width, height);
	
		for (var y = 0; y < height; y++) {
			var inpos = y * width * 4; // *4 for 4 ints per pixel
			for (var x = 0; x < width; x++) {
				var r = imageData.data[inpos++];
				var g = imageData.data[inpos++];
				var b = imageData.data[inpos++];
				var a = imageData.data[inpos++];
				var v = a*0x1000000 + b*0x10000 + g*0x100 + r;
				if (isref)
					v = [v];
				pixels.arrAccess(x + y*width).values[tmpPositionCache] = v
			}
		}
	}  catch(ex) {
		//kann keine imagedata holen
		return 0;
	}
	
	return 1;
}

function LOADSPRITEMEM(file, w, h, pixels) {
	throwError("TODO: loadspritemem");
}


//------------------------------------------------------------
// poly functions
//------------------------------------------------------------

var inPoly = false;
var num, mode;
var polyStack = [];
var tmpPolyStack = new Array(3);

function ENDPOLY() {
	if (!inPoly) throwError("ENDPOLY has to be in STARTPOLY - ENDPOLY ");
	if (polyStack.length > 0) {
		//schlie�en!
		if (polyStack.length == 4) {
			POLYNEWSTRIP();
		} else {
			context.save();
			//Zeichnen
			if (mode == 1) {
				if ((polyStack.length % 3) != 0) throwError("Polyvector cannot draw non power of 3 triangles");
				var spr = getSprite(num, true);
				for (var i = 0; i < polyStack.length; i+=3) {
					if (!spr) {
						context.beginPath();
						context.moveTo(polyStack[i].x, polyStack[i].y);
						context.lineTo(polyStack[i+1].x, polyStack[i+1].y);
						context.lineTo(polyStack[i+2].x, polyStack[i+2].y);
						context.closePath();
						context.fillStyle	= formatColor(polyStack[0].col);
						context.fill();
					} else {
						tmpPolyStack[0] = polyStack[i];
						tmpPolyStack[1] = polyStack[i+1];
						tmpPolyStack[2] = polyStack[i+2];
						
						drawPolygon(false, simpletris, tmpPolyStack, spr); //TODO: plzTint Parameter
					}
				}
			} else if (mode == 0) {
				if ((polyStack.length % 3) != 0) throwError("Polyvector cannot draw non power of 3 triangles");
				var spr = getSprite(num, true);
				for (var i = 0; i < polyStack.length-1; i++) {
					if (!spr) {
						context.beginPath();
						context.moveTo(polyStack[0].x, polyStack[0].y);
						context.lineTo(polyStack[i].x, polyStack[i].y);
						context.lineTo(polyStack[i+1].x, polyStack[i+1].y);
						context.closePath();
						context.fillStyle	= formatColor(polyStack[0].col);
						context.fill();
					} else {
						tmpPolyStack[0] = polyStack[0];
						tmpPolyStack[1] = polyStack[i];
						tmpPolyStack[2] = polyStack[i+1];
						drawPolygon(false, simpletris, tmpPolyStack, spr); //TODO: plzTint Parameter
					}
				}
			} else if (mode == 2) {
				throwError("Unimplemented ENDPOLY drawing mode: 2");
			} else {
				throwError("Unknown draw mode.");
			}
			context.restore();
		}
		polyStack.length = 0;
	}
	
	inPoly = false;
	
	context.restore();
}

var simpletris = [[0, 1, 2]];
var tris2 = [[0, 1, 2], [2, 3, 1]];
var tris1 = [[0, 1, 2], [2, 3, 0]];

function POLYNEWSTRIP() {
	if (!inPoly) throwError("POLYNEWSTRIP has to be in STARTPOLY - ENDPOLY ");
		
	context.save();
	if (num == -1) {
		//use pure html5!
		context.fillStyle = formatColor(polyStack[0].col);
		context.beginPath();
		context.moveTo(0, 0);
		for (var i = 0; i <polyStack.length; i++) {
			context.lineTo(~~(polyStack[i].x+.5), ~~(polyStack[i].y+.5));
		}
		context.closePath();
		context.fill();
		polyStack.length=0;
	} else {
		//use the texture!
		//got code from: http://stackoverflow.com/questions/4774172/image-manipulation-and-texture-mapping-using-html5-canvas Thanks, you saved my life!!
		var tris
		if (mode == 2) {
			tris = tris2;
		} else if (mode == 1) {
			tris =  tris1;
		} else if (mode == 0){
			tris = tris1 //TODO;
		}else {
			throwError("Invalid drawing mode!")
		}
		
		var spr = getSprite(num);
		
		//muss das sprite gef�rbt werden?
		var plzTint;
		if (polyStack[0].col != whiteRGB && polyStack[1].col != whiteRGB && polyStack[2].col != whiteRGB  && polyStack[2].col != whiteRGB) {
			plzTint = true;
		} else {
			plzTint = false;
		}
		
		
		drawPolygon(plzTint, tris, polyStack, spr);
	}
	
	context.restore();
	
	polyStack.length = 0; //anstatt = []
}

function drawPolygon(plzTint, tris, polyStack, spr) {
	if (plzTint) {
		var tmpAlpha = context.globalAlpha;
		var tmpOperation = context.globalCompositeOperation;
	}
	
	var pts = polyStack
	for (var t=0; t<tris.length; t++) {
		var pp = tris[t];
		var x0 = pts[pp[0]].x, x1 = pts[pp[1]].x, x2 = pts[pp[2]].x;
		var y0 = pts[pp[0]].y, y1 = pts[pp[1]].y, y2 = pts[pp[2]].y;
		var u0 = pts[pp[0]].u, u1 = pts[pp[1]].u, u2 = pts[pp[2]].u;
		var v0 = pts[pp[0]].v, v1 = pts[pp[1]].v, v2 = pts[pp[2]].v;

		// Set clipping area so that only pixels inside the triangle will
		// be affected by the image drawing operation
		context.save(); context.beginPath(); context.moveTo(x0, y0); context.lineTo(x1, y1);
		context.lineTo(x2, y2); context.closePath(); context.clip();

		// Compute matrix transform
		var delta = u0*v1 + v0*u2 + u1*v2 - v1*u2 - v0*u1 - u0*v2;
		var delta_a = x0*v1 + v0*x2 + x1*v2 - v1*x2 - v0*x1 - x0*v2;
		var delta_b = u0*x1 + x0*u2 + u1*x2 - x1*u2 - x0*u1 - u0*x2;
		var delta_c = u0*v1*x2 + v0*x1*u2 + x0*u1*v2 - x0*v1*u2
					  - v0*u1*x2 - u0*x1*v2;
		var delta_d = y0*v1 + v0*y2 + y1*v2 - v1*y2 - v0*y1 - y0*v2;
		var delta_e = u0*y1 + y0*u2 + u1*y2 - y1*u2 - y0*u1 - u0*y2;
		var delta_f = u0*v1*y2 + v0*y1*u2 + y0*u1*v2 - y0*v1*u2
					  - v0*u1*y2 - u0*y1*v2;

		// Draw the transformed image
		context.transform(delta_a/delta, delta_d/delta,
					  delta_b/delta, delta_e/delta,
					  delta_c/delta, delta_f/delta);
		
		if (plzTint) {
			//schauen ob alle gleiche Farbe haben
			if (polyStack[0].col == polyStack[1].col && polyStack[1].col == polyStack[2].col && (polyStack.length > 2 && polyStack[2].col == polyStack[3].col)) {
				if (!spr.tint) {
				//Hat noch nicht die Tinting Farbchannel
					try {
						//farbkan�le holen!
						spr.tint = generateRGBKs(spr.img);
					} catch (ex) {
						domExceptionError(ex);
					}
				}
				if (spr.tint) {
					//selbe farbe \o/
					
					var red = (polyStack[t].col & 0xFF0000)/0x10000 
					var green = (polyStack[t].col & 0xFF00)/0x100 
					var blue = polyStack[t].col & 0xFF 
					
					context.globalAlpha = 1;
					context.globalCompositeOperation = 'copy';
					context.drawImage( spr.tint[3], 0, 0 );

					context.globalCompositeOperation = 'lighter';
					if ( red > 0 ) {
						context.globalAlpha = red   / 255.0;
						context.drawImage( spr.tint[0], 0, 0 );
					}
					if ( green > 0 ) {
						context.globalAlpha = green / 255.0;
						context.drawImage( spr.tint[1], 0, 0 );
					}
					if ( blue > 0 ) {
						context.globalAlpha = blue  / 255.0;
						context.drawImage( spr.tint[2], 0, 0 );
					}
					
					
				} else {
					//Kann nicht tinten...
				}
			} else {
				//Die Farbe ist ein Farbverlauf!
				//Das kann ich noch nicht...
			}
		} else {
			context.drawImage(spr.img, 0, 0);
		}
		context.restore();
	}
	if (plzTint) {
		context.globalAlpha = tmpAlpha;
		context.globalCompositeOperation = tmpOperation;
	}
}

function POLYVECTOR(posx, posy, tx, ty, color) {
	if (!inPoly) throwError("POLYVECTOR has to be in STARTPOLY - ENDPODRAWANIMLY ");
	
	if (polyStack[polyStack.length]) {
		//existiert bereits!
		polyStack[polyStack.length].x = posx;
		polyStack[polyStack.length].y = posy;
		polyStack[polyStack.length].u = tx;
		polyStack[polyStack.length].v = ty;
		polyStack[polyStack.length].col = color;
		polyStack.length++;
	} else {
		//existiert noch nicht!
		polyStack.push({
			x: posx, y: posy, u: tx, v: ty, col: color
		});
	}
}

function STARTPOLY(n, m) {
	if (inPoly) throwError("STARTPOLY has not to be in STARTPOLY - ENDPOLY ");
	inPoly = true;
	polyStack.length = 0;
	num = n;
	mode = m;
	
	context.save();
}

//------------------------------------------------------------
//Sprite Rendering
//------------------------------------------------------------

function GENSPRITE() {
	for (var i = 0; i < sprites.length; i++) {
		if (!sprites[i]) return i;
	}
	return sprites.length;
}

function DRAWSPRITE(num, x, y) {
	var spr = getSprite(num);
	context.drawImage(spr.img, ~~(x+.5), ~~(y+.5));
}

function ROTOSPRITE(num, x, y, phi) {
	if ((phi%360) == 0) {
		DRAWSPRITE(num, x, y);
	} else {
		context.save();
		var spr = getSprite(num);
		context.translate(x+spr.img.width/2, y+spr.img.height/2);
		context.rotate(phi * Math.PI / 180); //convert into RAD
		DRAWSPRITE(num, -spr.img.width/2, -spr.img.height/2);
		context.restore();
	}
}

function ZOOMSPRITE(num, x, y, sx, sy) {
	if (sx == 0 || sy == 0) return;
	
	if (sx == 1 && sy == 1) {
		DRAWSPRITE(num, x, y);
	} else if (sx != 0 && sy != 0){
		context.save();
		var spr = getSprite(num);
		var dx = 0, dy = 0
		if (sx < 0) dx = spr.img.width*sx;
		if (sy < 0) dy = spr.img.height*sy;
		
		if (sx > 0) dx = spr.img.width/sx;
		if (sy > 0) dy = spr.img.height/sy;
		
		
		context.translate(x-dx,y-dy);
		context.scale(sx, sy);
		DRAWSPRITE(num, 0, 0);
		context.restore();
	}
}

function STRETCHSPRITE(num,  x, y, width, height) {
	var spr = getSprite(num);
	if (width != 0 && height != 0) {
		context.save();
		var sx = width/spr.img.width, sy = height/spr.img.height;
		context.translate(x, y);
		context.scale(sx, sy);
		DRAWSPRITE(num, 0, 0);
		context.restore();
	}
}

function ROTOZOOMSPRITE(num, x, y,phi, scale) {
	context.save();
	var spr = getSprite(num);
	context.translate(x+spr.img.width*scale, y+spr.img.height*scale)
	context.scale(scale, scale);
	ROTOSPRITE(num, 0, 0, phi);
	context.restore();
}

function DRAWANIM(num, frame, x, y) {
	var spr = getSprite(num);
	if (spr.frames == null) throwError("DRAWANIM can only draw an animation!");
	frame = frame % spr.frames.length;
	if (frame < 0) throwError("Invalid frame '"+frame+"'");
	context.drawImage(spr.img, ~~(spr.frames[frame].posx+.5), ~~(spr.frames[frame].posy+.5), spr.frameWidth, spr.frameHeight, CAST2INT(x), CAST2INT(y), spr.frameWidth, spr.frameHeight);
}

function ROTOZOOMANIM(num, frame, x, y,phi, scale) {
	context.save();
	context.translate(x, y)
	context.scale(scale, scale);
	ROTOANIM(num, frame, 0, 0, phi);
	context.restore();
}

function ROTOANIM(num, frame, x, y, phi) {
	if ((phi%360) == 0) {
		DRAWANIM(num, frame, x, y);
	} else {
		context.save();
		context.translate(x, y);
		context.rotate(phi * Math.PI / 180); //convert into RAD
		DRAWSPRITE(num, -spr.img.width/2, -spr.img.height/2);
		context.restore();
	}
}

function ZOOMANIM(num,frame, x, y, sx, sy) {
	if (sx == 1 && sy == 1) {
		DRAWANIM(num,frame, x, y);
	} else if (sx != 0 && sy != 0){
		context.save();
		context.translate(x, y);
		context.scale(sx, sy);
		DRAWANIM(num,frame, 0, 0);
		context.restore();
	}
}

function STRETCHANIM(num,frame,  x, y, width, height) {
	var spr = getSprite(num);
	if (width != 0 && height != 0) {
		context.save();
		var sx = width/spr.img.frameWidth, sy = height/spr.img.frameHeight;
		context.translate(x, y);
		context.scale(sx, sy);
		DRAWANIM(num,frame, 0, 0);
		context.restore();
	}
}

function GRABSPRITE(num, x, y, width, height) {
	if (width < 1 || height < 1) throwError("Invalid width/height!");
	try {
		var data = context.getImageData(x, y, width, height);
		
		var canvas = document.createElement('canvas');
		canvas.width = width;
		canvas.height = height;
		var ctxt = canvas.getContext("2d");
		ctxt.putImageData(data, 0, 0);
		
		var spr = new Sprite(canvas, num);
		spr.loaded = true;
		register(spr);
	}  catch(ex) {
		//kann keine imagedata holen
		domExceptionError(ex);
	}
}
//------------------------------------------------------------
//collision
//------------------------------------------------------------

function SPRCOLL(spr1, x1, y1, spr2, x2, y2) {
	//throwError("TODO: sprcoll");
	var s1, s2;
	s1 = getSprite(spr1);
	s2 = getSprite(spr2);
	
	
	if (!s1.data || !s2.data) {
		var getMyData = function(s) {
			//oha get the data!
			try {
				var canvas = document.createElement('canvas');
				canvas.width = s.img.width;
				canvas.height = s.img.height;
				var context = canvas.getContext("2d");
				
				context.drawImage(s.img, 0, 0);
				s.data = context.getImageData(0, 0, canvas.width, canvas.height);
			} catch (ex) {
				domExceptionError(ex);
			}
		}
		
		if (s1.data == null) {
			getMyData(s1);
		}
		if (s2.data == null) {
			getMyData(s2);
		}
	}
	
	return isPixelCollision(s1.data, x1, y1, s2.data, x2, y2) ? 1 : 0;
}

function ANIMCOLL(ani1, tile, x1, y1, ani2, time2, x2, y2) {
	throwError("TODO: animcoll");
}

//Thanks Joseph for these two useful functions!
/**
 * @author Joseph Lenton - PlayMyCode.com
 *
 * @param first An ImageData object from the first image we are colliding with.
 * @param x The x location of 'first'.
 * @param y The y location of 'first'.
 * @param other An ImageData object from the second image involved in the collision check.
 * @param x2 The x location of 'other'.
 * @param y2 The y location of 'other'.
 * @param isCentred True if the locations refer to the centre of 'first' and 'other', false to specify the top left corner.
 */
function isPixelCollision( first, x, y, other, x2, y2 ) {
	var isCentred = false;
	
    // we need to avoid using floats, as were doing array lookups
    x  = Math.round( x );
    y  = Math.round( y );
    x2 = Math.round( x2 );
    y2 = Math.round( y2 );

    var w  = first.width,
        h  = first.height,
        w2 = other.width,
        h2 = other.height ;

    // deal with the image being centred
    if ( isCentred ) {
        // fast rounding, but positive only
        x  -= ( w/2 + 0.5) << 0
        y  -= ( h/2 + 0.5) << 0
        x2 -= (w2/2 + 0.5) << 0
        y2 -= (h2/2 + 0.5) << 0
    }

    // find the top left and bottom right corners of overlapping area
    var xMin = Math.max( x, x2 ),
        yMin = Math.max( y, y2 ),
        xMax = Math.min( x+w, x2+w2 ),
        yMax = Math.min( y+h, y2+h2 );

    // Sanity collision check, we ensure that the top-left corner is both
    // above and to the left of the bottom-right corner.
    if ( xMin >= xMax || yMin >= yMax ) {
        return false;
    }

    var xDiff = xMax - xMin,
        yDiff = yMax - yMin;

    // get the pixels out from the images
    var pixels  = first.data,
        pixels2 = other.data;

    // if the area is really small,
    // then just perform a normal image collision check
    if ( xDiff < 4 && yDiff < 4 ) {
        for ( var pixelX = xMin; pixelX < xMax; pixelX++ ) {
            for ( var pixelY = yMin; pixelY < yMax; pixelY++ ) {
                if (
                        ( pixels [ ((pixelX-x ) + (pixelY-y )*w )*4 + 3 ] !== 0 ) &&
                        ( pixels2[ ((pixelX-x2) + (pixelY-y2)*w2)*4 + 3 ] !== 0 )
                ) {
                    return true;
                }
            }
        }
    } else {
        var incX = xDiff / 3.0,
            incY = yDiff / 3.0;
        incX = (~~incX === incX) ? incX : (incX+1 | 0);
        incY = (~~incY === incY) ? incY : (incY+1 | 0);

        for ( var offsetY = 0; offsetY < incY; offsetY++ ) {
            for ( var offsetX = 0; offsetX < incX; offsetX++ ) {
                for ( var pixelY = yMin+offsetY; pixelY < yMax; pixelY += incY ) {
                    for ( var pixelX = xMin+offsetX; pixelX < xMax; pixelX += incX ) {
                        if (
                                ( pixels [ ((pixelX-x ) + (pixelY-y )*w )*4 + 3 ] !== 0 ) &&
                                ( pixels2[ ((pixelX-x2) + (pixelY-y2)*w2)*4 + 3 ] !== 0 )
                        ) {
                            return true;
                        }
                    }
                }
            }
        }
    }

    return false;
}

/**
 * @author Joseph Lenton - PlayMyCode.com
 *
 * @param img the image with tinting
 */
function generateRGBKs( img ) {
	var w = img.width;
	var h = img.height;
	var rgbks = [];

	var canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;

	var ctx = canvas.getContext("2d");
	ctx.drawImage( img, 0, 0 );

	var pixels = ctx.getImageData( 0, 0, w, h ).data;

	// 4 is used to ask for 3 images: red, green, blue and
	// black in that order.
	for ( var rgbI = 0; rgbI < 4; rgbI++ ) {
		var canvas = document.createElement("canvas");
		canvas.width  = w;
		canvas.height = h;

		var ctx = canvas.getContext('2d');
		ctx.drawImage( img, 0, 0 );
		var to = ctx.getImageData( 0, 0, w, h );
		var toData = to.data;

		for (
				var i = 0, len = pixels.length;
				i < len;
				i += 4
		) {
			toData[i  ] = (rgbI === 0) ? pixels[i  ] : 0;
			toData[i+1] = (rgbI === 1) ? pixels[i+1] : 0;
			toData[i+2] = (rgbI === 2) ? pixels[i+2] : 0;
			toData[i+3] =                pixels[i+3]    ;
		}

		ctx.putImageData( to, 0, 0 );

		// image is _slightly_ faster then canvas for this, so convert
		var imgComp = new Image();
		imgComp.src = canvas.toDataURL();

		rgbks.push( imgComp );
	}

	return rgbks;
}

function BOXCOLL(x1,y1,breite1,hoehe1,x2,y2,breite2,hoehe2) {
	if (breite1 < 0) {
		breite1 = -breite1;
		x1 -= breite1;
	}
	if (hoehe1 < 0) {
		hoehe1 = -hoehe1;
		y1 -= hoehe1;
	}
	if (breite2 < 0) {
		breite2 = -breite2;
		x2 -= breite2;
	}
	if (hoehe2 < 0) {
		hoehe2 = -hoehe2;
		y2 -= hoehe2;
	}
    if (x1<=(x2+breite2) && y1<=y2+hoehe2 && (x1+breite1) >=x2 && (y1+hoehe1)>= y2) return 1; else return 0; 
}
//------------------------------------------------------------
// Screens
//------------------------------------------------------------


var screens		= [];		//Alle Screens

/**
 * @constructor
 */
function Screen(buffer, num, sprid) {
	this.canvas = buffer;
	this.context = buffer.getContext('2d');
	this.realwidth = this.canvas.width;
	this.realheight = this.canvas.height;
	this.realx = this.canvas.offsetLeft;
	this.realy = this.canvas.offsetRight;
	this.num = num + 2;
	this.spr = sprid;
	
	if (this.context == null) throwError("Given buffer does not support '2d'");
}

function CREATESCREEN(scrid, sprid, width, height) {
	var buffer = document.createElement('canvas');
    buffer.width = width;
    buffer.height = height;
	
	register(new Screen(buffer, scrid, sprid));
	var spr = new Sprite(buffer, sprid);
	register(spr);
	spr.loaded = true; //es ist bereits geladen...
}

function USESCREEN(id) {
	var oScreen = curScreen;
	if (oScreen && oScreen.spr) {
		//die pixel und tint daten raushauen
		getSprite(oScreen.spr).data = null;
		getSprite(oScreen.spr).tint = null;
	}
	curScreen = screens[id + 2];
	if (!curScreen) {
		curScreen = oScreen;
	} else {
		context = curScreen.context;
		canvas = curScreen.canvas;
	}
}

function BLENDSCREEN(file, duration) {
	throwError("TODO: blendscreen");
}

function CLEARSCREEN(col) {
	var tmpAlpha = context.globalAlpha;
	var tmpOperation = context.globalCompositeOperation;
	
	context.globalCompositeOperation = '';
	context.globalAlpha = 1;
	
	context.save();
	context.fillStyle = formatColor(col);
	context.fillRect(0,0,canvas.width, canvas.height);
	clrColor = col;
	context.restore();
	
	context.globalAlpha = tmpAlpha;
	context.globalCompositeOperation = tmpOperation;
}

function BLACKSCREEN() {
	CLEARSCREEN(RGB(0,0,0));
}

function USEASBMP() {
	background = backbuffer.canvas;
	var buffer = document.createElement('canvas');
    buffer.width = canvasWidth;
    buffer.height = canvasHeight;
	backbuffer = new Screen(buffer, -1);
	register(backbuffer);
	USESCREEN(-1);
}

function LOADBMP(path) {
	var image = new Image();
	
	image.onload = function () {
		background = image;
	}
	image.onerror = function() {
		//fehler
		throwError("BMP '"+path+"' not found!");
	}
	image.src = loadAsset(fileSystem.getCurrentDir() + path);
	
}
var static12_Factor_DIMASEXPRErr = 0;
var static12_Keyword_SelectHelper = 0.0, static7_Keyword_GOTOErr = 0;
var __debugInfo = "";
var debugMode = true;
window['main'] = function(){
	stackPush("main", __debugInfo);
	try {
		var local1_G_1771 = new type10_TGenerator();
		__debugInfo = "39:\123basic.gbas";
		DIM(global10_Generators, [0], new type10_TGenerator());
		__debugInfo = "42:\123basic.gbas";
		local1_G_1771.attr8_Name_Str = "JS";
		__debugInfo = "43:\123basic.gbas";
		local1_G_1771.attr8_genProto = func16_JS_Generator_Str;
		__debugInfo = "44:\123basic.gbas";
		DIMPUSH(global10_Generators, local1_G_1771);
		__debugInfo = "67:\123basic.gbas";
		global12_GbapPath_Str = "./";
		__debugInfo = "157:\123basic.gbas";
		global7_CONSOLE = 0;
		__debugInfo = "45:\src\Compiler.gbas";
		global10_LastExprID = 0;
		__debugInfo = "600:\src\Compiler.gbas";
		global13_SettingIn_Str = "";
		__debugInfo = "600:\src\Compiler.gbas";
		global13_SettingIn_Str = "";
		__debugInfo = "862:\src\Compiler.gbas";
		MaxPasses = 6;
		__debugInfo = "6:\src\Utils\GBAPReader.gbas";
		global9_GFX_WIDTH = 640;
		__debugInfo = "7:\src\Utils\GBAPReader.gbas";
		global10_GFX_HEIGHT = 480;
		__debugInfo = "8:\src\Utils\GBAPReader.gbas";
		global10_FULLSCREEN = 0;
		__debugInfo = "9:\src\Utils\GBAPReader.gbas";
		global9_FRAMERATE = 60;
		__debugInfo = "11:\src\Utils\GBAPReader.gbas";
		global11_APPNAME_Str = "123basic Program";
		__debugInfo = "12:\src\Utils\GBAPReader.gbas";
		global9_DEBUGMODE = 1;
		__debugInfo = "13:\src\Utils\GBAPReader.gbas";
		global7_CONSOLE = 1;
		__debugInfo = "14:\src\Utils\GBAPReader.gbas";
		global6_STRICT = 1;
		__debugInfo = "15:\src\Utils\GBAPReader.gbas";
		global15_USRDEF_VERS_Str = "0.00001";
		__debugInfo = "39:\src\Utils\GBAPReader.gbas";
		global6_Ignore = 0;
		__debugInfo = "11:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global13_OptimizeLevel = 1;
		__debugInfo = "13:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global12_CurrentScope = -(1);
		__debugInfo = "15:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global11_CurrentFunc = -(1);
		__debugInfo = "17:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global8_IsInGoto = 0;
		__debugInfo = "18:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global11_LoopBreakID = 0;
		__debugInfo = "19:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global14_LoopContinueID = 0;
		__debugInfo = "21:\src\CompilerPasses\Generator\JSGenerator.gbas";
		global14_StaticText_Str = "";
		__debugInfo = "31:\src\Target.gbas";
		global10_Target_Str = "";
		__debugInfo = "34:\src\Target.gbas";
		global8_Lang_Str = "";
		__debugInfo = "36:\src\Target.gbas";
		global5_NoRun = 0;
		__debugInfo = "39:\123basic.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
}
main = window['main'];
window['GetIdentifierByPart'] = function(param8_Text_Str) {
	stackPush("function: GetIdentifierByPart_Str", __debugInfo);
	try {
		var local10_Result_Str_1773 = "", local11_tmpCompiler_1774 = new type9_TCompiler();
		__debugInfo = "168:\123basic.gbas";
		local10_Result_Str_1773 = "";
		__debugInfo = "171:\123basic.gbas";
		local11_tmpCompiler_1774 = global8_Compiler.clone(/* In Assign */);
		__debugInfo = "173:\123basic.gbas";
		global8_Compiler.attr8_Code_Str = ((param8_Text_Str) + ("\n"));
		__debugInfo = "175:\123basic.gbas";
		func5_Lexer();
		__debugInfo = "177:\123basic.gbas";
		func8_Analyser();
		__debugInfo = "179:\123basic.gbas";
		global8_Compiler.attr8_GetIdent = 1;
		__debugInfo = "181:\123basic.gbas";
		func6_Parser();
		__debugInfo = "183:\123basic.gbas";
		global8_Compiler = local11_tmpCompiler_1774.clone(/* In Assign */);
		__debugInfo = "185:\123basic.gbas";
		return tryClone(local10_Result_Str_1773);
		__debugInfo = "186:\123basic.gbas";
		return "";
		__debugInfo = "168:\123basic.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
GetIdentifierByPart = window['GetIdentifierByPart'];
window['func8_Analyser'] = function() {
	stackPush("function: Analyser", __debugInfo);
	try {
		var local6_CurTyp_1780 = 0;
		__debugInfo = "11:\src\CompilerPasses\Analyser.gbas";
		func5_Start();
		__debugInfo = "64:\src\CompilerPasses\Analyser.gbas";
		while (func8_EOFParse()) {
			__debugInfo = "61:\src\CompilerPasses\Analyser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "63:\src\CompilerPasses\Analyser.gbas";
				try {
					__debugInfo = "15:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper1__1775 = "";
						__debugInfo = "15:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper1__1775 = func14_GetCurrent_Str();
						__debugInfo = "59:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper1__1775) == ("TYPE")) ? 1 : 0)) {
							var local3_typ_ref_1776 = [new type14_IdentifierType()];
							__debugInfo = "17:\src\CompilerPasses\Analyser.gbas";
							func5_Match("TYPE", 16, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "19:\src\CompilerPasses\Analyser.gbas";
							local3_typ_ref_1776[0].attr8_Name_Str = func14_GetCurrent_Str();
							__debugInfo = "20:\src\CompilerPasses\Analyser.gbas";
							local3_typ_ref_1776[0].attr12_RealName_Str = local3_typ_ref_1776[0].attr8_Name_Str;
							__debugInfo = "21:\src\CompilerPasses\Analyser.gbas";
							local3_typ_ref_1776[0].attr2_ID = BOUNDS(global8_Compiler.attr5_Types_ref[0], 0);
							__debugInfo = "22:\src\CompilerPasses\Analyser.gbas";
							DIMPUSH(global8_Compiler.attr5_Types_ref[0], local3_typ_ref_1776);
							__debugInfo = "24:\src\CompilerPasses\Analyser.gbas";
							func7_GetNext();
							__debugInfo = "17:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper1__1775) == ("PROTOTYPE")) ? 1 : 0)) {
							var local4_func_1777 = new type14_IdentifierFunc();
							__debugInfo = "26:\src\CompilerPasses\Analyser.gbas";
							func5_Match("PROTOTYPE", 25, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "28:\src\CompilerPasses\Analyser.gbas";
							local4_func_1777.attr8_Name_Str = func14_GetCurrent_Str();
							__debugInfo = "29:\src\CompilerPasses\Analyser.gbas";
							local4_func_1777.attr3_Typ = ~~(4);
							__debugInfo = "30:\src\CompilerPasses\Analyser.gbas";
							func11_AddFunction(local4_func_1777);
							__debugInfo = "32:\src\CompilerPasses\Analyser.gbas";
							func7_GetNext();
							__debugInfo = "26:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper1__1775) == ("CONSTANT")) ? 1 : 0)) {
							__debugInfo = "55:\src\CompilerPasses\Analyser.gbas";
							do {
								var local4_Vari_1778 = new type14_IdentifierVari();
								__debugInfo = "48:\src\CompilerPasses\Analyser.gbas";
								if (func7_IsToken("CONSTANT")) {
									__debugInfo = "45:\src\CompilerPasses\Analyser.gbas";
									func5_Match("CONSTANT", 44, "src\CompilerPasses\Analyser.gbas");
									__debugInfo = "45:\src\CompilerPasses\Analyser.gbas";
								} else {
									__debugInfo = "47:\src\CompilerPasses\Analyser.gbas";
									func5_Match(",", 46, "src\CompilerPasses\Analyser.gbas");
									__debugInfo = "47:\src\CompilerPasses\Analyser.gbas";
								};
								__debugInfo = "51:\src\CompilerPasses\Analyser.gbas";
								local4_Vari_1778 = func7_VariDef(0).clone(/* In Assign */);
								__debugInfo = "52:\src\CompilerPasses\Analyser.gbas";
								local4_Vari_1778.attr3_Typ = ~~(6);
								__debugInfo = "53:\src\CompilerPasses\Analyser.gbas";
								func11_AddVariable(local4_Vari_1778, 0);
								__debugInfo = "54:\src\CompilerPasses\Analyser.gbas";
								DIMPUSH(global8_Compiler.attr7_Globals, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
								__debugInfo = "48:\src\CompilerPasses\Analyser.gbas";
							} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
							__debugInfo = "55:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "15:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "60:\src\CompilerPasses\Analyser.gbas";
					func7_GetNext();
					__debugInfo = "15:\src\CompilerPasses\Analyser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "62:\src\CompilerPasses\Analyser.gbas";
						func8_FixError();
						__debugInfo = "62:\src\CompilerPasses\Analyser.gbas";
					}
				};
				__debugInfo = "63:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "61:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "66:\src\CompilerPasses\Analyser.gbas";
		local6_CurTyp_1780 = -(1);
		__debugInfo = "67:\src\CompilerPasses\Analyser.gbas";
		func5_Start();
		__debugInfo = "146:\src\CompilerPasses\Analyser.gbas";
		while (func8_EOFParse()) {
			__debugInfo = "143:\src\CompilerPasses\Analyser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "145:\src\CompilerPasses\Analyser.gbas";
				try {
					var local10_IsCallback_1781 = 0, local8_IsNative_1782 = 0, local10_IsAbstract_1783 = 0;
					__debugInfo = "70:\src\CompilerPasses\Analyser.gbas";
					local10_IsCallback_1781 = 0;
					__debugInfo = "70:\src\CompilerPasses\Analyser.gbas";
					local8_IsNative_1782 = 0;
					__debugInfo = "71:\src\CompilerPasses\Analyser.gbas";
					local10_IsAbstract_1783 = 0;
					__debugInfo = "76:\src\CompilerPasses\Analyser.gbas";
					if (func7_IsToken("CALLBACK")) {
						__debugInfo = "73:\src\CompilerPasses\Analyser.gbas";
						func5_Match("CALLBACK", 72, "src\CompilerPasses\Analyser.gbas");
						__debugInfo = "74:\src\CompilerPasses\Analyser.gbas";
						local10_IsCallback_1781 = 1;
						__debugInfo = "75:\src\CompilerPasses\Analyser.gbas";
						if ((((func7_IsToken("FUNCTION")) == (0)) ? 1 : 0)) {
							__debugInfo = "75:\src\CompilerPasses\Analyser.gbas";
							func5_Match("FUNCTION", 74, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "75:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "73:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "81:\src\CompilerPasses\Analyser.gbas";
					if (func7_IsToken("NATIVE")) {
						__debugInfo = "78:\src\CompilerPasses\Analyser.gbas";
						func5_Match("NATIVE", 77, "src\CompilerPasses\Analyser.gbas");
						__debugInfo = "79:\src\CompilerPasses\Analyser.gbas";
						local8_IsNative_1782 = 1;
						__debugInfo = "80:\src\CompilerPasses\Analyser.gbas";
						if ((((func7_IsToken("FUNCTION")) == (0)) ? 1 : 0)) {
							__debugInfo = "80:\src\CompilerPasses\Analyser.gbas";
							func5_Match("FUNCTION", 79, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "80:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "78:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "86:\src\CompilerPasses\Analyser.gbas";
					if (func7_IsToken("ABSTRACT")) {
						__debugInfo = "83:\src\CompilerPasses\Analyser.gbas";
						func5_Match("ABSTRACT", 82, "src\CompilerPasses\Analyser.gbas");
						__debugInfo = "84:\src\CompilerPasses\Analyser.gbas";
						local10_IsAbstract_1783 = 1;
						__debugInfo = "85:\src\CompilerPasses\Analyser.gbas";
						if ((((func7_IsToken("FUNCTION")) == (0)) ? 1 : 0)) {
							__debugInfo = "85:\src\CompilerPasses\Analyser.gbas";
							func5_Match("FUNCTION", 84, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "85:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "83:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "88:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper2__1784 = "";
						__debugInfo = "88:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper2__1784 = func14_GetCurrent_Str();
						__debugInfo = "139:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper2__1784) == ("PROTOTYPE")) ? 1 : 0)) {
							var local3_var_1785 = new type14_IdentifierVari(), local5_Found_1786 = 0;
							__debugInfo = "90:\src\CompilerPasses\Analyser.gbas";
							func5_Match("PROTOTYPE", 89, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "92:\src\CompilerPasses\Analyser.gbas";
							local3_var_1785 = func7_VariDef(0).clone(/* In Assign */);
							__debugInfo = "93:\src\CompilerPasses\Analyser.gbas";
							local5_Found_1786 = 0;
							__debugInfo = "100:\src\CompilerPasses\Analyser.gbas";
							var forEachSaver2409 = global8_Compiler.attr5_Funcs_ref[0];
							for(var forEachCounter2409 = 0 ; forEachCounter2409 < forEachSaver2409.values.length ; forEachCounter2409++) {
								var local4_func_ref_1787 = forEachSaver2409.values[forEachCounter2409];
							{
									__debugInfo = "99:\src\CompilerPasses\Analyser.gbas";
									if ((((local4_func_ref_1787[0].attr8_Name_Str) == (local3_var_1785.attr8_Name_Str)) ? 1 : 0)) {
										__debugInfo = "96:\src\CompilerPasses\Analyser.gbas";
										local4_func_ref_1787[0].attr8_datatype = local3_var_1785.attr8_datatype.clone(/* In Assign */);
										__debugInfo = "97:\src\CompilerPasses\Analyser.gbas";
										local5_Found_1786 = 1;
										__debugInfo = "98:\src\CompilerPasses\Analyser.gbas";
										break;
										__debugInfo = "96:\src\CompilerPasses\Analyser.gbas";
									};
									__debugInfo = "99:\src\CompilerPasses\Analyser.gbas";
								}
								forEachSaver2409.values[forEachCounter2409] = local4_func_ref_1787;
							
							};
							__debugInfo = "101:\src\CompilerPasses\Analyser.gbas";
							if ((((local5_Found_1786) == (0)) ? 1 : 0)) {
								__debugInfo = "101:\src\CompilerPasses\Analyser.gbas";
								func5_Error((("Internal error (prototype not found: ") + (local3_var_1785.attr8_Name_Str)), 100, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "101:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "102:\src\CompilerPasses\Analyser.gbas";
							if ((((local6_CurTyp_1780) != (-(1))) ? 1 : 0)) {
								__debugInfo = "102:\src\CompilerPasses\Analyser.gbas";
								func5_Error("PROTOTYPE definition not in Type allowed.", 101, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "102:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "90:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper2__1784) == ("FUNCTION")) ? 1 : 0)) {
							var local3_var_1788 = new type14_IdentifierVari(), local4_func_1789 = new type14_IdentifierFunc();
							__debugInfo = "104:\src\CompilerPasses\Analyser.gbas";
							func5_Match("FUNCTION", 103, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "106:\src\CompilerPasses\Analyser.gbas";
							local3_var_1788 = func7_VariDef(0).clone(/* In Assign */);
							__debugInfo = "109:\src\CompilerPasses\Analyser.gbas";
							local4_func_1789.attr8_Name_Str = local3_var_1788.attr8_Name_Str;
							__debugInfo = "110:\src\CompilerPasses\Analyser.gbas";
							local4_func_1789.attr8_datatype = local3_var_1788.attr8_datatype.clone(/* In Assign */);
							__debugInfo = "111:\src\CompilerPasses\Analyser.gbas";
							local4_func_1789.attr10_IsCallback = local10_IsCallback_1781;
							__debugInfo = "112:\src\CompilerPasses\Analyser.gbas";
							local4_func_1789.attr10_IsAbstract = local10_IsAbstract_1783;
							__debugInfo = "120:\src\CompilerPasses\Analyser.gbas";
							if ((((local6_CurTyp_1780) != (-(1))) ? 1 : 0)) {
								__debugInfo = "115:\src\CompilerPasses\Analyser.gbas";
								local4_func_1789.attr3_Typ = ~~(3);
								__debugInfo = "116:\src\CompilerPasses\Analyser.gbas";
								DIMPUSH(global8_Compiler.attr5_Types_ref[0].arrAccess(local6_CurTyp_1780).values[tmpPositionCache][0].attr7_Methods, BOUNDS(global8_Compiler.attr5_Funcs_ref[0], 0));
								__debugInfo = "117:\src\CompilerPasses\Analyser.gbas";
								local4_func_1789.attr6_MyType = local6_CurTyp_1780;
								__debugInfo = "115:\src\CompilerPasses\Analyser.gbas";
							} else {
								__debugInfo = "119:\src\CompilerPasses\Analyser.gbas";
								local4_func_1789.attr3_Typ = ~~(1);
								__debugInfo = "119:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "122:\src\CompilerPasses\Analyser.gbas";
							func11_AddFunction(local4_func_1789);
							__debugInfo = "124:\src\CompilerPasses\Analyser.gbas";
							if (((((((local8_IsNative_1782) == (0)) ? 1 : 0)) && ((((local10_IsAbstract_1783) == (0)) ? 1 : 0))) ? 1 : 0)) {
								__debugInfo = "124:\src\CompilerPasses\Analyser.gbas";
								func10_SkipTokens("FUNCTION", "ENDFUNCTION", local4_func_1789.attr8_Name_Str);
								__debugInfo = "124:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "104:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper2__1784) == ("SUB")) ? 1 : 0)) {
							var local4_func_1790 = new type14_IdentifierFunc();
							__debugInfo = "126:\src\CompilerPasses\Analyser.gbas";
							func5_Match("SUB", 125, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "128:\src\CompilerPasses\Analyser.gbas";
							local4_func_1790.attr8_Name_Str = func14_GetCurrent_Str();
							__debugInfo = "129:\src\CompilerPasses\Analyser.gbas";
							local4_func_1790.attr8_datatype = global12_voidDatatype.clone(/* In Assign */);
							__debugInfo = "130:\src\CompilerPasses\Analyser.gbas";
							local4_func_1790.attr3_Typ = ~~(2);
							__debugInfo = "131:\src\CompilerPasses\Analyser.gbas";
							func11_AddFunction(local4_func_1790);
							__debugInfo = "132:\src\CompilerPasses\Analyser.gbas";
							func10_SkipTokens("SUB", "ENDSUB", local4_func_1790.attr8_Name_Str);
							__debugInfo = "126:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper2__1784) == ("TYPE")) ? 1 : 0)) {
							__debugInfo = "134:\src\CompilerPasses\Analyser.gbas";
							func5_Match("TYPE", 133, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "135:\src\CompilerPasses\Analyser.gbas";
							if ((((func6_IsType("")) == (0)) ? 1 : 0)) {
								__debugInfo = "135:\src\CompilerPasses\Analyser.gbas";
								func5_Error((((("Internal error (unrecognized type: ") + (func14_GetCurrent_Str()))) + (")")), 134, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "135:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "136:\src\CompilerPasses\Analyser.gbas";
							local6_CurTyp_1780 = global8_LastType.attr2_ID;
							__debugInfo = "134:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper2__1784) == ("ENDTYPE")) ? 1 : 0)) {
							__debugInfo = "138:\src\CompilerPasses\Analyser.gbas";
							local6_CurTyp_1780 = -(1);
							__debugInfo = "138:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "88:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "142:\src\CompilerPasses\Analyser.gbas";
					func7_GetNext();
					__debugInfo = "70:\src\CompilerPasses\Analyser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "144:\src\CompilerPasses\Analyser.gbas";
						func8_FixError();
						__debugInfo = "144:\src\CompilerPasses\Analyser.gbas";
					}
				};
				__debugInfo = "145:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "143:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "148:\src\CompilerPasses\Analyser.gbas";
		if ((((local6_CurTyp_1780) != (-(1))) ? 1 : 0)) {
			__debugInfo = "148:\src\CompilerPasses\Analyser.gbas";
			func5_Error((((("Type '") + (global8_Compiler.attr5_Types_ref[0].arrAccess(local6_CurTyp_1780).values[tmpPositionCache][0].attr8_Name_Str))) + (" not closed with 'ENDTYPE'")), 147, "src\CompilerPasses\Analyser.gbas");
			__debugInfo = "148:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "149:\src\CompilerPasses\Analyser.gbas";
		local6_CurTyp_1780 = -(1);
		__debugInfo = "166:\src\CompilerPasses\Analyser.gbas";
		var forEachSaver2692 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter2692 = 0 ; forEachCounter2692 < forEachSaver2692.values.length ; forEachCounter2692++) {
			var local1_F_ref_1792 = forEachSaver2692.values[forEachCounter2692];
		{
				__debugInfo = "165:\src\CompilerPasses\Analyser.gbas";
				if (local1_F_ref_1792[0].attr10_IsCallback) {
					var local12_alreadyExist_1793 = 0;
					__debugInfo = "154:\src\CompilerPasses\Analyser.gbas";
					local12_alreadyExist_1793 = 0;
					__debugInfo = "160:\src\CompilerPasses\Analyser.gbas";
					var forEachSaver2677 = global8_Compiler.attr5_Funcs_ref[0];
					for(var forEachCounter2677 = 0 ; forEachCounter2677 < forEachSaver2677.values.length ; forEachCounter2677++) {
						var local2_F2_ref_1794 = forEachSaver2677.values[forEachCounter2677];
					{
							__debugInfo = "159:\src\CompilerPasses\Analyser.gbas";
							if (((((((local2_F2_ref_1794[0].attr8_Name_Str) == (local1_F_ref_1792[0].attr8_Name_Str)) ? 1 : 0)) && ((((local2_F2_ref_1794[0].attr10_IsCallback) == (0)) ? 1 : 0))) ? 1 : 0)) {
								__debugInfo = "157:\src\CompilerPasses\Analyser.gbas";
								local12_alreadyExist_1793 = 1;
								__debugInfo = "158:\src\CompilerPasses\Analyser.gbas";
								break;
								__debugInfo = "157:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "159:\src\CompilerPasses\Analyser.gbas";
						}
						forEachSaver2677.values[forEachCounter2677] = local2_F2_ref_1794;
					
					};
					__debugInfo = "164:\src\CompilerPasses\Analyser.gbas";
					if (local12_alreadyExist_1793) {
						__debugInfo = "163:\src\CompilerPasses\Analyser.gbas";
						local1_F_ref_1792[0].attr8_Name_Str = (("Overwritten Callback method (screw them!): ") + (local1_F_ref_1792[0].attr8_Name_Str));
						__debugInfo = "163:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "154:\src\CompilerPasses\Analyser.gbas";
				};
				__debugInfo = "165:\src\CompilerPasses\Analyser.gbas";
			}
			forEachSaver2692.values[forEachCounter2692] = local1_F_ref_1792;
		
		};
		__debugInfo = "173:\src\CompilerPasses\Analyser.gbas";
		var forEachSaver2731 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter2731 = 0 ; forEachCounter2731 < forEachSaver2731.values.length ; forEachCounter2731++) {
			var local1_F_ref_1795 = forEachSaver2731.values[forEachCounter2731];
		{
				__debugInfo = "172:\src\CompilerPasses\Analyser.gbas";
				if ((((((((((local1_F_ref_1795[0].attr3_Typ) != (3)) ? 1 : 0)) && ((((local1_F_ref_1795[0].attr3_Typ) != (2)) ? 1 : 0))) ? 1 : 0)) && (((local1_F_ref_1795[0].attr10_IsCallback) ? 0 : 1))) ? 1 : 0)) {
					__debugInfo = "171:\src\CompilerPasses\Analyser.gbas";
					(global8_Compiler.attr11_GlobalFuncs).Put(local1_F_ref_1795[0].attr8_Name_Str, local1_F_ref_1795[0].attr2_ID);
					__debugInfo = "171:\src\CompilerPasses\Analyser.gbas";
				};
				__debugInfo = "172:\src\CompilerPasses\Analyser.gbas";
			}
			forEachSaver2731.values[forEachCounter2731] = local1_F_ref_1795;
		
		};
		__debugInfo = "186:\src\CompilerPasses\Analyser.gbas";
		func5_Start();
		__debugInfo = "210:\src\CompilerPasses\Analyser.gbas";
		while (func8_EOFParse()) {
			__debugInfo = "207:\src\CompilerPasses\Analyser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "209:\src\CompilerPasses\Analyser.gbas";
				try {
					__debugInfo = "190:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper3__1796 = "";
						__debugInfo = "190:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper3__1796 = func14_GetCurrent_Str();
						__debugInfo = "204:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper3__1796) == ("GLOBAL")) ? 1 : 0)) {
							__debugInfo = "203:\src\CompilerPasses\Analyser.gbas";
							do {
								var local4_Vari_1797 = new type14_IdentifierVari();
								__debugInfo = "197:\src\CompilerPasses\Analyser.gbas";
								if (func7_IsToken("GLOBAL")) {
									__debugInfo = "194:\src\CompilerPasses\Analyser.gbas";
									func5_Match("GLOBAL", 193, "src\CompilerPasses\Analyser.gbas");
									__debugInfo = "194:\src\CompilerPasses\Analyser.gbas";
								} else {
									__debugInfo = "196:\src\CompilerPasses\Analyser.gbas";
									func5_Match(",", 195, "src\CompilerPasses\Analyser.gbas");
									__debugInfo = "196:\src\CompilerPasses\Analyser.gbas";
								};
								__debugInfo = "199:\src\CompilerPasses\Analyser.gbas";
								local4_Vari_1797 = func7_VariDef(0).clone(/* In Assign */);
								__debugInfo = "200:\src\CompilerPasses\Analyser.gbas";
								local4_Vari_1797.attr3_Typ = ~~(2);
								__debugInfo = "201:\src\CompilerPasses\Analyser.gbas";
								func11_AddVariable(local4_Vari_1797, 1);
								__debugInfo = "202:\src\CompilerPasses\Analyser.gbas";
								DIMPUSH(global8_Compiler.attr7_Globals, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
								__debugInfo = "197:\src\CompilerPasses\Analyser.gbas";
							} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
							__debugInfo = "203:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "190:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "206:\src\CompilerPasses\Analyser.gbas";
					func7_GetNext();
					__debugInfo = "190:\src\CompilerPasses\Analyser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "208:\src\CompilerPasses\Analyser.gbas";
						func8_FixError();
						__debugInfo = "208:\src\CompilerPasses\Analyser.gbas";
					}
				};
				__debugInfo = "209:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "207:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "213:\src\CompilerPasses\Analyser.gbas";
		func5_Start();
		__debugInfo = "225:\src\CompilerPasses\Analyser.gbas";
		while (func8_EOFParse()) {
			__debugInfo = "222:\src\CompilerPasses\Analyser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "224:\src\CompilerPasses\Analyser.gbas";
				try {
					__debugInfo = "216:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper4__1799 = "";
						__debugInfo = "216:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper4__1799 = func14_GetCurrent_Str();
						__debugInfo = "219:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper4__1799) == ("TYPE")) ? 1 : 0)) {
							__debugInfo = "218:\src\CompilerPasses\Analyser.gbas";
							func8_TypeDefi();
							__debugInfo = "218:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "216:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "221:\src\CompilerPasses\Analyser.gbas";
					func7_GetNext();
					__debugInfo = "216:\src\CompilerPasses\Analyser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "223:\src\CompilerPasses\Analyser.gbas";
						func8_FixError();
						__debugInfo = "223:\src\CompilerPasses\Analyser.gbas";
					}
				};
				__debugInfo = "224:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "222:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "226:\src\CompilerPasses\Analyser.gbas";
		local6_CurTyp_1780 = -(1);
		__debugInfo = "231:\src\CompilerPasses\Analyser.gbas";
		var forEachSaver2832 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter2832 = 0 ; forEachCounter2832 < forEachSaver2832.values.length ; forEachCounter2832++) {
			var local3_typ_ref_1801 = forEachSaver2832.values[forEachCounter2832];
		{
				__debugInfo = "230:\src\CompilerPasses\Analyser.gbas";
				func10_ExtendType(unref(local3_typ_ref_1801[0]));
				__debugInfo = "230:\src\CompilerPasses\Analyser.gbas";
			}
			forEachSaver2832.values[forEachCounter2832] = local3_typ_ref_1801;
		
		};
		__debugInfo = "236:\src\CompilerPasses\Analyser.gbas";
		var forEachSaver2845 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter2845 = 0 ; forEachCounter2845 < forEachSaver2845.values.length ; forEachCounter2845++) {
			var local3_typ_ref_1802 = forEachSaver2845.values[forEachCounter2845];
		{
				__debugInfo = "235:\src\CompilerPasses\Analyser.gbas";
				func11_CheckCyclic(local3_typ_ref_1802[0].attr8_Name_Str, unref(local3_typ_ref_1802[0]));
				__debugInfo = "235:\src\CompilerPasses\Analyser.gbas";
			}
			forEachSaver2845.values[forEachCounter2845] = local3_typ_ref_1802;
		
		};
		__debugInfo = "238:\src\CompilerPasses\Analyser.gbas";
		func5_Start();
		__debugInfo = "314:\src\CompilerPasses\Analyser.gbas";
		while (func8_EOFParse()) {
			__debugInfo = "311:\src\CompilerPasses\Analyser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "313:\src\CompilerPasses\Analyser.gbas";
				try {
					var local8_isNative_1803 = 0, local10_isCallBack_1804 = 0;
					__debugInfo = "242:\src\CompilerPasses\Analyser.gbas";
					local8_isNative_1803 = 0;
					__debugInfo = "243:\src\CompilerPasses\Analyser.gbas";
					local10_isCallBack_1804 = 0;
					__debugInfo = "244:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper5__1805 = "";
						__debugInfo = "244:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper5__1805 = func14_GetCurrent_Str();
						__debugInfo = "253:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper5__1805) == ("NATIVE")) ? 1 : 0)) {
							__debugInfo = "246:\src\CompilerPasses\Analyser.gbas";
							local8_isNative_1803 = 1;
							__debugInfo = "247:\src\CompilerPasses\Analyser.gbas";
							func7_GetNext();
							__debugInfo = "246:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper5__1805) == ("CALLBACK")) ? 1 : 0)) {
							__debugInfo = "249:\src\CompilerPasses\Analyser.gbas";
							local10_isCallBack_1804 = 1;
							__debugInfo = "250:\src\CompilerPasses\Analyser.gbas";
							func7_GetNext();
							__debugInfo = "249:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper5__1805) == ("ABSTRACT")) ? 1 : 0)) {
							__debugInfo = "252:\src\CompilerPasses\Analyser.gbas";
							func7_GetNext();
							__debugInfo = "252:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "244:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "255:\src\CompilerPasses\Analyser.gbas";
					{
						var local16___SelectHelper6__1806 = "";
						__debugInfo = "255:\src\CompilerPasses\Analyser.gbas";
						local16___SelectHelper6__1806 = func14_GetCurrent_Str();
						__debugInfo = "308:\src\CompilerPasses\Analyser.gbas";
						if ((((local16___SelectHelper6__1806) == ("FUNCTION")) ? 1 : 0)) {
							var local3_Typ_1807 = 0.0;
							__debugInfo = "262:\src\CompilerPasses\Analyser.gbas";
							if ((((local6_CurTyp_1780) == (-(1))) ? 1 : 0)) {
								__debugInfo = "259:\src\CompilerPasses\Analyser.gbas";
								local3_Typ_1807 = 1;
								__debugInfo = "259:\src\CompilerPasses\Analyser.gbas";
							} else {
								__debugInfo = "261:\src\CompilerPasses\Analyser.gbas";
								local3_Typ_1807 = 3;
								__debugInfo = "261:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "263:\src\CompilerPasses\Analyser.gbas";
							func7_FuncDef(local8_isNative_1803, local10_isCallBack_1804, ~~(local3_Typ_1807), local6_CurTyp_1780);
							__debugInfo = "262:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper6__1806) == ("PROTOTYPE")) ? 1 : 0)) {
							__debugInfo = "265:\src\CompilerPasses\Analyser.gbas";
							func7_FuncDef(0, 0, ~~(4), -(1));
							__debugInfo = "265:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper6__1806) == ("SUB")) ? 1 : 0)) {
							__debugInfo = "267:\src\CompilerPasses\Analyser.gbas";
							func6_SubDef();
							__debugInfo = "267:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper6__1806) == ("TYPE")) ? 1 : 0)) {
							__debugInfo = "269:\src\CompilerPasses\Analyser.gbas";
							func5_Match("TYPE", 268, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "270:\src\CompilerPasses\Analyser.gbas";
							if ((((func6_IsType("")) == (0)) ? 1 : 0)) {
								__debugInfo = "270:\src\CompilerPasses\Analyser.gbas";
								func5_Error((((("Internal error (unrecognized type: ") + (func14_GetCurrent_Str()))) + (")")), 269, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "270:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "271:\src\CompilerPasses\Analyser.gbas";
							local6_CurTyp_1780 = global8_LastType.attr2_ID;
							__debugInfo = "269:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper6__1806) == ("ENDTYPE")) ? 1 : 0)) {
							__debugInfo = "273:\src\CompilerPasses\Analyser.gbas";
							local6_CurTyp_1780 = -(1);
							__debugInfo = "273:\src\CompilerPasses\Analyser.gbas";
						} else if ((((local16___SelectHelper6__1806) == ("STARTDATA")) ? 1 : 0)) {
							var local8_Name_Str_1808 = "", local5_Datas_1809 = new OTTArray(0), local5_dataB_1813 = new type9_DataBlock();
							__debugInfo = "275:\src\CompilerPasses\Analyser.gbas";
							func5_Match("STARTDATA", 274, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "276:\src\CompilerPasses\Analyser.gbas";
							local8_Name_Str_1808 = func14_GetCurrent_Str();
							__debugInfo = "277:\src\CompilerPasses\Analyser.gbas";
							if ((((func14_IsValidVarName()) == (0)) ? 1 : 0)) {
								__debugInfo = "277:\src\CompilerPasses\Analyser.gbas";
								func5_Error("Invalid DATA name", 276, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "277:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "278:\src\CompilerPasses\Analyser.gbas";
							func5_Match(local8_Name_Str_1808, 277, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "279:\src\CompilerPasses\Analyser.gbas";
							func5_Match(":", 278, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "280:\src\CompilerPasses\Analyser.gbas";
							func5_Match("\n", 279, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "300:\src\CompilerPasses\Analyser.gbas";
							while (func7_IsToken("DATA")) {
								var local4_Done_1810 = 0;
								__debugInfo = "283:\src\CompilerPasses\Analyser.gbas";
								func5_Match("DATA", 282, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "284:\src\CompilerPasses\Analyser.gbas";
								local4_Done_1810 = 0;
								__debugInfo = "298:\src\CompilerPasses\Analyser.gbas";
								while ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
									var local1_e_1811 = 0.0, local7_tmpData_1812 = new type8_Datatype();
									__debugInfo = "286:\src\CompilerPasses\Analyser.gbas";
									if ((((local4_Done_1810) == (1)) ? 1 : 0)) {
										__debugInfo = "286:\src\CompilerPasses\Analyser.gbas";
										func5_Match(",", 285, "src\CompilerPasses\Analyser.gbas");
										__debugInfo = "286:\src\CompilerPasses\Analyser.gbas";
									};
									__debugInfo = "287:\src\CompilerPasses\Analyser.gbas";
									local1_e_1811 = func10_Expression(0);
									__debugInfo = "289:\src\CompilerPasses\Analyser.gbas";
									local7_tmpData_1812 = global5_Exprs_ref[0].arrAccess(~~(local1_e_1811)).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
									__debugInfo = "290:\src\CompilerPasses\Analyser.gbas";
									local7_tmpData_1812.attr7_IsArray_ref[0] = 0;
									__debugInfo = "291:\src\CompilerPasses\Analyser.gbas";
									func14_EnsureDatatype(~~(local1_e_1811), local7_tmpData_1812, 0, 0);
									__debugInfo = "295:\src\CompilerPasses\Analyser.gbas";
									if ((((((((((global5_Exprs_ref[0].arrAccess(~~(local1_e_1811)).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(~~(local1_e_1811)).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(~~(local1_e_1811)).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
										
									} else {
										__debugInfo = "294:\src\CompilerPasses\Analyser.gbas";
										func5_Error((((("Must be primitive datatype (int, float or string), got '") + (global5_Exprs_ref[0].arrAccess(~~(local1_e_1811)).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + ("'")), 293, "src\CompilerPasses\Analyser.gbas");
										__debugInfo = "294:\src\CompilerPasses\Analyser.gbas";
									};
									__debugInfo = "296:\src\CompilerPasses\Analyser.gbas";
									DIMPUSH(local5_Datas_1809, ~~(local1_e_1811));
									__debugInfo = "297:\src\CompilerPasses\Analyser.gbas";
									local4_Done_1810 = 1;
									__debugInfo = "286:\src\CompilerPasses\Analyser.gbas";
								};
								__debugInfo = "299:\src\CompilerPasses\Analyser.gbas";
								func5_Match("\n", 298, "src\CompilerPasses\Analyser.gbas");
								__debugInfo = "283:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "301:\src\CompilerPasses\Analyser.gbas";
							func5_Match("ENDDATA", 300, "src\CompilerPasses\Analyser.gbas");
							__debugInfo = "303:\src\CompilerPasses\Analyser.gbas";
							local5_dataB_1813.attr8_Name_Str = local8_Name_Str_1808;
							__debugInfo = "304:\src\CompilerPasses\Analyser.gbas";
							local5_dataB_1813.attr5_Datas = local5_Datas_1809.clone(/* In Assign */);
							__debugInfo = "307:\src\CompilerPasses\Analyser.gbas";
							DIMPUSH(global8_Compiler.attr10_DataBlocks, local5_dataB_1813);
							__debugInfo = "275:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "255:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "310:\src\CompilerPasses\Analyser.gbas";
					func7_GetNext();
					__debugInfo = "242:\src\CompilerPasses\Analyser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "312:\src\CompilerPasses\Analyser.gbas";
						func8_FixError();
						__debugInfo = "312:\src\CompilerPasses\Analyser.gbas";
					}
				};
				__debugInfo = "313:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "311:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "315:\src\CompilerPasses\Analyser.gbas";
		return 0;
		__debugInfo = "11:\src\CompilerPasses\Analyser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_Analyser = window['func8_Analyser'];
window['func11_CheckCyclic'] = function(param8_Name_Str, param3_typ) {
	stackPush("function: CheckCyclic", __debugInfo);
	try {
		__debugInfo = "328:\src\CompilerPasses\Analyser.gbas";
		var forEachSaver3199 = param3_typ.attr10_Attributes;
		for(var forEachCounter3199 = 0 ; forEachCounter3199 < forEachSaver3199.values.length ; forEachCounter3199++) {
			var local1_t_1817 = forEachSaver3199.values[forEachCounter3199];
		{
				__debugInfo = "327:\src\CompilerPasses\Analyser.gbas";
				if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_t_1817).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == (param8_Name_Str)) ? 1 : 0)) {
					__debugInfo = "321:\src\CompilerPasses\Analyser.gbas";
					func5_Error((((((((("Cyclic reference '") + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_t_1817).values[tmpPositionCache][0].attr8_Name_Str))) + ("' to type '"))) + (param8_Name_Str))) + ("'")), 320, "src\CompilerPasses\Analyser.gbas");
					__debugInfo = "321:\src\CompilerPasses\Analyser.gbas";
				} else if (func6_IsType(unref(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_t_1817).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) {
					__debugInfo = "324:\src\CompilerPasses\Analyser.gbas";
					func11_CheckCyclic(param8_Name_Str, global8_LastType);
					__debugInfo = "324:\src\CompilerPasses\Analyser.gbas";
				} else {
					
				};
				__debugInfo = "327:\src\CompilerPasses\Analyser.gbas";
			}
			forEachSaver3199.values[forEachCounter3199] = local1_t_1817;
		
		};
		__debugInfo = "329:\src\CompilerPasses\Analyser.gbas";
		return 0;
		__debugInfo = "328:\src\CompilerPasses\Analyser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_CheckCyclic = window['func11_CheckCyclic'];
window['func10_ExtendType'] = function(param3_typ) {
	stackPush("function: ExtendType", __debugInfo);
	try {
		__debugInfo = "413:\src\CompilerPasses\Analyser.gbas";
		if ((((param3_typ.attr9_Extending) != (-(1))) ? 1 : 0)) {
			var alias6_ExtTyp_ref_1819 = [new type14_IdentifierType()], local6_tmpTyp_1820 = 0, local9_Abstracts_1821 = new OTTArray(0);
			__debugInfo = "334:\src\CompilerPasses\Analyser.gbas";
			func10_ExtendType(unref(global8_Compiler.attr5_Types_ref[0].arrAccess(param3_typ.attr9_Extending).values[tmpPositionCache][0]));
			__debugInfo = "337:\src\CompilerPasses\Analyser.gbas";
			alias6_ExtTyp_ref_1819 = global8_Compiler.attr5_Types_ref[0].arrAccess(param3_typ.attr9_Extending).values[tmpPositionCache] /* ALIAS */;
			__debugInfo = "364:\src\CompilerPasses\Analyser.gbas";
			local6_tmpTyp_1820 = alias6_ExtTyp_ref_1819[0].attr2_ID;
			__debugInfo = "374:\src\CompilerPasses\Analyser.gbas";
			while ((((local6_tmpTyp_1820) != (-(1))) ? 1 : 0)) {
				__debugInfo = "371:\src\CompilerPasses\Analyser.gbas";
				var forEachSaver3267 = global8_Compiler.attr5_Types_ref[0].arrAccess(local6_tmpTyp_1820).values[tmpPositionCache][0].attr7_Methods;
				for(var forEachCounter3267 = 0 ; forEachCounter3267 < forEachSaver3267.values.length ; forEachCounter3267++) {
					var local1_M_1822 = forEachSaver3267.values[forEachCounter3267];
				{
						__debugInfo = "370:\src\CompilerPasses\Analyser.gbas";
						if (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_1822).values[tmpPositionCache][0].attr10_IsAbstract) {
							__debugInfo = "369:\src\CompilerPasses\Analyser.gbas";
							DIMPUSH(local9_Abstracts_1821, local1_M_1822);
							__debugInfo = "369:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "370:\src\CompilerPasses\Analyser.gbas";
					}
					forEachSaver3267.values[forEachCounter3267] = local1_M_1822;
				
				};
				__debugInfo = "373:\src\CompilerPasses\Analyser.gbas";
				local6_tmpTyp_1820 = global8_Compiler.attr5_Types_ref[0].arrAccess(local6_tmpTyp_1820).values[tmpPositionCache][0].attr9_Extending;
				__debugInfo = "371:\src\CompilerPasses\Analyser.gbas";
			};
			__debugInfo = "395:\src\CompilerPasses\Analyser.gbas";
			var forEachSaver3371 = local9_Abstracts_1821;
			for(var forEachCounter3371 = 0 ; forEachCounter3371 < forEachSaver3371.values.length ; forEachCounter3371++) {
				var local2_Ab_1823 = forEachSaver3371.values[forEachCounter3371];
			{
					var local5_Found_1824 = 0;
					__debugInfo = "379:\src\CompilerPasses\Analyser.gbas";
					local5_Found_1824 = 0;
					__debugInfo = "380:\src\CompilerPasses\Analyser.gbas";
					local6_tmpTyp_1820 = alias6_ExtTyp_ref_1819[0].attr2_ID;
					__debugInfo = "390:\src\CompilerPasses\Analyser.gbas";
					while ((((local6_tmpTyp_1820) != (-(1))) ? 1 : 0)) {
						__debugInfo = "387:\src\CompilerPasses\Analyser.gbas";
						var forEachSaver3344 = global8_Compiler.attr5_Types_ref[0].arrAccess(local6_tmpTyp_1820).values[tmpPositionCache][0].attr7_Methods;
						for(var forEachCounter3344 = 0 ; forEachCounter3344 < forEachSaver3344.values.length ; forEachCounter3344++) {
							var local1_M_1825 = forEachSaver3344.values[forEachCounter3344];
						{
								__debugInfo = "386:\src\CompilerPasses\Analyser.gbas";
								if (((((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_1825).values[tmpPositionCache][0].attr8_Name_Str) == (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local2_Ab_1823).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0)) && (((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_1825).values[tmpPositionCache][0].attr10_IsAbstract) ? 0 : 1))) ? 1 : 0)) {
									__debugInfo = "384:\src\CompilerPasses\Analyser.gbas";
									local5_Found_1824 = 1;
									__debugInfo = "385:\src\CompilerPasses\Analyser.gbas";
									break;
									__debugInfo = "384:\src\CompilerPasses\Analyser.gbas";
								};
								__debugInfo = "386:\src\CompilerPasses\Analyser.gbas";
							}
							forEachSaver3344.values[forEachCounter3344] = local1_M_1825;
						
						};
						__debugInfo = "388:\src\CompilerPasses\Analyser.gbas";
						if (local5_Found_1824) {
							__debugInfo = "388:\src\CompilerPasses\Analyser.gbas";
							break;
							__debugInfo = "388:\src\CompilerPasses\Analyser.gbas";
						};
						__debugInfo = "389:\src\CompilerPasses\Analyser.gbas";
						local6_tmpTyp_1820 = global8_Compiler.attr5_Types_ref[0].arrAccess(local6_tmpTyp_1820).values[tmpPositionCache][0].attr9_Extending;
						__debugInfo = "387:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "394:\src\CompilerPasses\Analyser.gbas";
					if (((local5_Found_1824) ? 0 : 1)) {
						__debugInfo = "392:\src\CompilerPasses\Analyser.gbas";
						alias6_ExtTyp_ref_1819[0].attr10_Createable = 0;
						__debugInfo = "392:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "379:\src\CompilerPasses\Analyser.gbas";
				}
				forEachSaver3371.values[forEachCounter3371] = local2_Ab_1823;
			
			};
			__debugInfo = "412:\src\CompilerPasses\Analyser.gbas";
			var forEachSaver3429 = alias6_ExtTyp_ref_1819[0].attr10_Attributes;
			for(var forEachCounter3429 = 0 ; forEachCounter3429 < forEachSaver3429.values.length ; forEachCounter3429++) {
				var local1_A_1826 = forEachSaver3429.values[forEachCounter3429];
			{
					var alias3_Att_ref_1827 = [new type14_IdentifierVari()], local6_Exists_1828 = 0;
					__debugInfo = "399:\src\CompilerPasses\Analyser.gbas";
					alias3_Att_ref_1827 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_A_1826).values[tmpPositionCache] /* ALIAS */;
					__debugInfo = "400:\src\CompilerPasses\Analyser.gbas";
					local6_Exists_1828 = 0;
					__debugInfo = "407:\src\CompilerPasses\Analyser.gbas";
					var forEachSaver3417 = param3_typ.attr10_Attributes;
					for(var forEachCounter3417 = 0 ; forEachCounter3417 < forEachSaver3417.values.length ; forEachCounter3417++) {
						var local2_A2_1829 = forEachSaver3417.values[forEachCounter3417];
					{
							var alias4_Att2_ref_1830 = [new type14_IdentifierVari()];
							__debugInfo = "402:\src\CompilerPasses\Analyser.gbas";
							alias4_Att2_ref_1830 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local2_A2_1829).values[tmpPositionCache] /* ALIAS */;
							__debugInfo = "406:\src\CompilerPasses\Analyser.gbas";
							if ((((alias3_Att_ref_1827[0].attr8_Name_Str) == (alias4_Att2_ref_1830[0].attr8_Name_Str)) ? 1 : 0)) {
								__debugInfo = "404:\src\CompilerPasses\Analyser.gbas";
								local6_Exists_1828 = 1;
								__debugInfo = "405:\src\CompilerPasses\Analyser.gbas";
								break;
								__debugInfo = "404:\src\CompilerPasses\Analyser.gbas";
							};
							__debugInfo = "402:\src\CompilerPasses\Analyser.gbas";
						}
						forEachSaver3417.values[forEachCounter3417] = local2_A2_1829;
					
					};
					__debugInfo = "411:\src\CompilerPasses\Analyser.gbas";
					if (((local6_Exists_1828) ? 0 : 1)) {
						__debugInfo = "410:\src\CompilerPasses\Analyser.gbas";
						DIMPUSH(param3_typ.attr10_Attributes, local1_A_1826);
						__debugInfo = "410:\src\CompilerPasses\Analyser.gbas";
					};
					__debugInfo = "399:\src\CompilerPasses\Analyser.gbas";
				}
				forEachSaver3429.values[forEachCounter3429] = local1_A_1826;
			
			};
			__debugInfo = "334:\src\CompilerPasses\Analyser.gbas";
		};
		__debugInfo = "414:\src\CompilerPasses\Analyser.gbas";
		return 0;
		__debugInfo = "413:\src\CompilerPasses\Analyser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_ExtendType = window['func10_ExtendType'];
window['method21_type14_IdentifierFunc_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "82:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(1000));
		__debugInfo = "84:\src\Compiler.gbas";
		func11_WriteString(param1_F, param4_self.attr9_OName_Str);
		__debugInfo = "85:\src\Compiler.gbas";
		func11_WriteString(param1_F, param4_self.attr8_Name_Str);
		__debugInfo = "87:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr6_Params, 0));
		__debugInfo = "91:\src\Compiler.gbas";
		var forEachSaver3479 = param4_self.attr6_Params;
		for(var forEachCounter3479 = 0 ; forEachCounter3479 < forEachSaver3479.values.length ; forEachCounter3479++) {
			var local1_P_1834 = forEachSaver3479.values[forEachCounter3479];
		{
				__debugInfo = "89:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1834);
				__debugInfo = "90:\src\Compiler.gbas";
				if ((((local1_P_1834) != (-(1))) ? 1 : 0)) {
					__debugInfo = "90:\src\Compiler.gbas";
					(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1834).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "90:\src\Compiler.gbas";
				};
				__debugInfo = "89:\src\Compiler.gbas";
			}
			forEachSaver3479.values[forEachCounter3479] = local1_P_1834;
		
		};
		__debugInfo = "93:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr10_CopyParams, 0));
		__debugInfo = "97:\src\Compiler.gbas";
		var forEachSaver3513 = param4_self.attr10_CopyParams;
		for(var forEachCounter3513 = 0 ; forEachCounter3513 < forEachSaver3513.values.length ; forEachCounter3513++) {
			var local1_P_1835 = forEachSaver3513.values[forEachCounter3513];
		{
				__debugInfo = "95:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1835);
				__debugInfo = "96:\src\Compiler.gbas";
				if ((((local1_P_1835) != (-(1))) ? 1 : 0)) {
					__debugInfo = "96:\src\Compiler.gbas";
					(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1835).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "96:\src\Compiler.gbas";
				};
				__debugInfo = "95:\src\Compiler.gbas";
			}
			forEachSaver3513.values[forEachCounter3513] = local1_P_1835;
		
		};
		__debugInfo = "99:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr7_Statics, 0));
		__debugInfo = "103:\src\Compiler.gbas";
		var forEachSaver3547 = param4_self.attr7_Statics;
		for(var forEachCounter3547 = 0 ; forEachCounter3547 < forEachSaver3547.values.length ; forEachCounter3547++) {
			var local1_P_1836 = forEachSaver3547.values[forEachCounter3547];
		{
				__debugInfo = "101:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1836);
				__debugInfo = "102:\src\Compiler.gbas";
				if ((((local1_P_1836) != (-(1))) ? 1 : 0)) {
					__debugInfo = "102:\src\Compiler.gbas";
					(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1836).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "102:\src\Compiler.gbas";
				};
				__debugInfo = "101:\src\Compiler.gbas";
			}
			forEachSaver3547.values[forEachCounter3547] = local1_P_1836;
		
		};
		__debugInfo = "106:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr6_Native);
		__debugInfo = "107:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr3_Scp);
		__debugInfo = "108:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr2_ID);
		__debugInfo = "109:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr3_Typ);
		__debugInfo = "110:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr3_Tok);
		__debugInfo = "111:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr10_PlzCompile);
		__debugInfo = "112:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr6_HasRef);
		__debugInfo = "114:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr6_MyType);
		__debugInfo = "115:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr7_SelfVar);
		__debugInfo = "116:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr10_IsAbstract);
		__debugInfo = "118:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr10_IsCallback);
		__debugInfo = "122:\src\Compiler.gbas";
		if ((((param4_self.attr3_Tok) != (-(1))) ? 1 : 0)) {
			__debugInfo = "122:\src\Compiler.gbas";
			(global8_Compiler.attr6_Tokens.arrAccess(param4_self.attr3_Tok).values[tmpPositionCache]).Save(param1_F);
			__debugInfo = "122:\src\Compiler.gbas";
		};
		__debugInfo = "124:\src\Compiler.gbas";
		(param4_self.attr8_datatype).Save(param1_F);
		__debugInfo = "126:\src\Compiler.gbas";
		if ((((param4_self.attr6_MyType) != (-(1))) ? 1 : 0)) {
			__debugInfo = "126:\src\Compiler.gbas";
			(global8_Compiler.attr5_Types_ref[0].arrAccess(param4_self.attr6_MyType).values[tmpPositionCache][0]).Save(param1_F);
			__debugInfo = "126:\src\Compiler.gbas";
		};
		__debugInfo = "128:\src\Compiler.gbas";
		if ((((param4_self.attr3_Scp) != (-(1))) ? 1 : 0)) {
			__debugInfo = "128:\src\Compiler.gbas";
			(global5_Exprs_ref[0].arrAccess(param4_self.attr3_Scp).values[tmpPositionCache][0]).Save(param1_F);
			__debugInfo = "128:\src\Compiler.gbas";
		};
		__debugInfo = "130:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(1000));
		__debugInfo = "131:\src\Compiler.gbas";
		return 0;
		__debugInfo = "82:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierFunc_4_Save = window['method21_type14_IdentifierFunc_4_Save'];
window['method21_type14_IdentifierFunc_4_Load'] = function(param1_F, param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		__debugInfo = "135:\src\Compiler.gbas";
		return 0;
		__debugInfo = "135:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierFunc_4_Load = window['method21_type14_IdentifierFunc_4_Load'];
window['method21_type14_IdentifierVari_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "164:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(2000));
		__debugInfo = "165:\src\Compiler.gbas";
		func11_WriteString(param1_F, param4_self.attr8_Name_Str);
		__debugInfo = "166:\src\Compiler.gbas";
		(param4_self.attr8_datatype).Save(param1_F);
		__debugInfo = "167:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr3_Typ);
		__debugInfo = "168:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr2_ID);
		__debugInfo = "169:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr6_PreDef);
		__debugInfo = "170:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr3_ref);
		__debugInfo = "171:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr9_OwnerVari);
		__debugInfo = "172:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr4_func);
		__debugInfo = "174:\src\Compiler.gbas";
		if (param4_self.attr4_func) {
			__debugInfo = "174:\src\Compiler.gbas";
			(global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_self.attr4_func).values[tmpPositionCache][0]).Save(param1_F);
			__debugInfo = "174:\src\Compiler.gbas";
		};
		__debugInfo = "175:\src\Compiler.gbas";
		if (param4_self.attr9_OwnerVari) {
			__debugInfo = "175:\src\Compiler.gbas";
			(global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_self.attr9_OwnerVari).values[tmpPositionCache][0]).Save(param1_F);
			__debugInfo = "175:\src\Compiler.gbas";
		};
		__debugInfo = "176:\src\Compiler.gbas";
		if ((((param4_self.attr6_PreDef) == (-(1))) ? 1 : 0)) {
			__debugInfo = "176:\src\Compiler.gbas";
			(global5_Exprs_ref[0].arrAccess(param4_self.attr6_PreDef).values[tmpPositionCache][0]).Save(param1_F);
			__debugInfo = "176:\src\Compiler.gbas";
		};
		__debugInfo = "179:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(2000));
		__debugInfo = "180:\src\Compiler.gbas";
		return 0;
		__debugInfo = "164:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierVari_4_Save = window['method21_type14_IdentifierVari_4_Save'];
window['method21_type14_IdentifierVari_4_Load'] = function(param1_F, param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		__debugInfo = "184:\src\Compiler.gbas";
		return 0;
		__debugInfo = "184:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierVari_4_Load = window['method21_type14_IdentifierVari_4_Load'];
window['method21_type14_IdentifierType_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "203:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(3000));
		__debugInfo = "204:\src\Compiler.gbas";
		func11_WriteString(param1_F, param4_self.attr8_Name_Str);
		__debugInfo = "205:\src\Compiler.gbas";
		func11_WriteString(param1_F, param4_self.attr12_RealName_Str);
		__debugInfo = "209:\src\Compiler.gbas";
		WRITEUWORD(param1_F, param4_self.attr2_ID);
		__debugInfo = "210:\src\Compiler.gbas";
		WRITELONG(param1_F, param4_self.attr9_Extending);
		__debugInfo = "213:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr10_Attributes, 0));
		__debugInfo = "217:\src\Compiler.gbas";
		var forEachSaver3823 = param4_self.attr10_Attributes;
		for(var forEachCounter3823 = 0 ; forEachCounter3823 < forEachSaver3823.values.length ; forEachCounter3823++) {
			var local1_P_1849 = forEachSaver3823.values[forEachCounter3823];
		{
				__debugInfo = "215:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1849);
				__debugInfo = "216:\src\Compiler.gbas";
				if ((((local1_P_1849) != (-(1))) ? 1 : 0)) {
					__debugInfo = "216:\src\Compiler.gbas";
					(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1849).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "216:\src\Compiler.gbas";
				};
				__debugInfo = "215:\src\Compiler.gbas";
			}
			forEachSaver3823.values[forEachCounter3823] = local1_P_1849;
		
		};
		__debugInfo = "219:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr7_Methods, 0));
		__debugInfo = "223:\src\Compiler.gbas";
		var forEachSaver3857 = param4_self.attr7_Methods;
		for(var forEachCounter3857 = 0 ; forEachCounter3857 < forEachSaver3857.values.length ; forEachCounter3857++) {
			var local1_P_1850 = forEachSaver3857.values[forEachCounter3857];
		{
				__debugInfo = "221:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1850);
				__debugInfo = "222:\src\Compiler.gbas";
				if ((((local1_P_1850) != (-(1))) ? 1 : 0)) {
					__debugInfo = "222:\src\Compiler.gbas";
					(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_P_1850).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "222:\src\Compiler.gbas";
				};
				__debugInfo = "221:\src\Compiler.gbas";
			}
			forEachSaver3857.values[forEachCounter3857] = local1_P_1850;
		
		};
		__debugInfo = "225:\src\Compiler.gbas";
		WRITEUWORD(param1_F, BOUNDS(param4_self.attr7_PreSize, 0));
		__debugInfo = "229:\src\Compiler.gbas";
		var forEachSaver3889 = param4_self.attr7_PreSize;
		for(var forEachCounter3889 = 0 ; forEachCounter3889 < forEachSaver3889.values.length ; forEachCounter3889++) {
			var local1_P_1851 = forEachSaver3889.values[forEachCounter3889];
		{
				__debugInfo = "227:\src\Compiler.gbas";
				WRITELONG(param1_F, local1_P_1851);
				__debugInfo = "228:\src\Compiler.gbas";
				if ((((local1_P_1851) != (-(1))) ? 1 : 0)) {
					__debugInfo = "228:\src\Compiler.gbas";
					(global5_Exprs_ref[0].arrAccess(local1_P_1851).values[tmpPositionCache][0]).Save(param1_F);
					__debugInfo = "228:\src\Compiler.gbas";
				};
				__debugInfo = "227:\src\Compiler.gbas";
			}
			forEachSaver3889.values[forEachCounter3889] = local1_P_1851;
		
		};
		__debugInfo = "232:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(3000));
		__debugInfo = "233:\src\Compiler.gbas";
		return 0;
		__debugInfo = "203:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierType_4_Save = window['method21_type14_IdentifierType_4_Save'];
window['method21_type14_IdentifierType_4_Load'] = function(param1_F, param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		var local3_tmp_ref_1855 = [0];
		__debugInfo = "237:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1855);
		__debugInfo = "238:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1855[0]) != (3000)) ? 1 : 0)) {
			__debugInfo = "238:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "238:\src\Compiler.gbas";
		};
		__debugInfo = "243:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1855);
		__debugInfo = "244:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1855[0]) != (3000)) ? 1 : 0)) {
			__debugInfo = "244:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "244:\src\Compiler.gbas";
		};
		__debugInfo = "246:\src\Compiler.gbas";
		return tryClone(0);
		__debugInfo = "247:\src\Compiler.gbas";
		return 0;
		__debugInfo = "237:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method21_type14_IdentifierType_4_Load = window['method21_type14_IdentifierType_4_Load'];
window['method14_type8_Datatype_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "257:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(4000));
		__debugInfo = "258:\src\Compiler.gbas";
		func11_WriteString(param1_F, unref(param4_self.attr8_Name_Str_ref[0]));
		__debugInfo = "259:\src\Compiler.gbas";
		WRITELONG(param1_F, unref(param4_self.attr7_IsArray_ref[0]));
		__debugInfo = "260:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(4000));
		__debugInfo = "261:\src\Compiler.gbas";
		return 0;
		__debugInfo = "257:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method14_type8_Datatype_4_Save = window['method14_type8_Datatype_4_Save'];
window['method14_type8_Datatype_4_Load'] = function(param1_F, param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		var local3_tmp_ref_1862 = [0];
		__debugInfo = "265:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1862);
		__debugInfo = "266:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1862[0]) != (4000)) ? 1 : 0)) {
			__debugInfo = "266:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "266:\src\Compiler.gbas";
		};
		__debugInfo = "268:\src\Compiler.gbas";
		func10_ReadString(param1_F, param4_self.attr8_Name_Str_ref);
		__debugInfo = "269:\src\Compiler.gbas";
		READLONG(param1_F, param4_self.attr7_IsArray_ref);
		__debugInfo = "271:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1862);
		__debugInfo = "272:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1862[0]) != (4000)) ? 1 : 0)) {
			__debugInfo = "272:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "272:\src\Compiler.gbas";
		};
		__debugInfo = "273:\src\Compiler.gbas";
		return 1;
		__debugInfo = "274:\src\Compiler.gbas";
		return 0;
		__debugInfo = "265:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method14_type8_Datatype_4_Load = window['method14_type8_Datatype_4_Load'];
window['method11_type5_Token_4_Load'] = function(param1_F, param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		var local3_tmp_ref_1866 = [0];
		__debugInfo = "308:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1866);
		__debugInfo = "309:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1866[0]) != (5000)) ? 1 : 0)) {
			__debugInfo = "309:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "309:\src\Compiler.gbas";
		};
		__debugInfo = "311:\src\Compiler.gbas";
		READLONG(param1_F, param4_self.attr4_Line_ref);
		__debugInfo = "312:\src\Compiler.gbas";
		READLONG(param1_F, param4_self.attr9_Character_ref);
		__debugInfo = "314:\src\Compiler.gbas";
		func10_ReadString(param1_F, param4_self.attr15_LineContent_Str_ref);
		__debugInfo = "315:\src\Compiler.gbas";
		func10_ReadString(param1_F, param4_self.attr8_Path_Str_ref);
		__debugInfo = "316:\src\Compiler.gbas";
		func10_ReadString(param1_F, param4_self.attr8_Text_Str_ref);
		__debugInfo = "318:\src\Compiler.gbas";
		READUWORD(param1_F, local3_tmp_ref_1866);
		__debugInfo = "319:\src\Compiler.gbas";
		if ((((local3_tmp_ref_1866[0]) != (5000)) ? 1 : 0)) {
			__debugInfo = "319:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "319:\src\Compiler.gbas";
		};
		__debugInfo = "320:\src\Compiler.gbas";
		return 1;
		__debugInfo = "321:\src\Compiler.gbas";
		return 0;
		__debugInfo = "308:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method11_type5_Token_4_Load = window['method11_type5_Token_4_Load'];
window['method11_type5_Token_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "324:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(5000));
		__debugInfo = "326:\src\Compiler.gbas";
		WRITELONG(param1_F, unref(param4_self.attr4_Line_ref[0]));
		__debugInfo = "327:\src\Compiler.gbas";
		WRITELONG(param1_F, unref(param4_self.attr9_Character_ref[0]));
		__debugInfo = "329:\src\Compiler.gbas";
		func11_WriteString(param1_F, unref(param4_self.attr15_LineContent_Str_ref[0]));
		__debugInfo = "330:\src\Compiler.gbas";
		func11_WriteString(param1_F, unref(param4_self.attr8_Path_Str_ref[0]));
		__debugInfo = "331:\src\Compiler.gbas";
		func11_WriteString(param1_F, unref(param4_self.attr8_Text_Str_ref[0]));
		__debugInfo = "333:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(5000));
		__debugInfo = "334:\src\Compiler.gbas";
		return 0;
		__debugInfo = "324:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method11_type5_Token_4_Save = window['method11_type5_Token_4_Save'];
window['method10_type4_Expr_4_Load'] = function(param4_self) {
	stackPush("method: Load", __debugInfo);
	try {
		__debugInfo = "500:\src\Compiler.gbas";
		return 0;
		__debugInfo = "500:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method10_type4_Expr_4_Load = window['method10_type4_Expr_4_Load'];
window['method10_type4_Expr_4_Save'] = function(param1_F, param4_self) {
	stackPush("method: Save", __debugInfo);
	try {
		__debugInfo = "560:\src\Compiler.gbas";
		WRITEUWORD(param1_F, ~~(1));
		__debugInfo = "561:\src\Compiler.gbas";
		return 0;
		__debugInfo = "560:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method10_type4_Expr_4_Save = window['method10_type4_Expr_4_Save'];
window['func12_LoadFile_Str'] = function(param8_Path_Str) {
	stackPush("function: LoadFile_Str", __debugInfo);
	try {
		var local8_Text_Str_2576 = "", local4_File_2577 = 0;
		__debugInfo = "609:\src\Compiler.gbas";
		local4_File_2577 = GENFILE();
		__debugInfo = "619:\src\Compiler.gbas";
		if (OPENFILE(local4_File_2577, param8_Path_Str, 1)) {
			__debugInfo = "615:\src\Compiler.gbas";
			while ((((ENDOFFILE(local4_File_2577)) == (0)) ? 1 : 0)) {
				var local8_Line_Str_ref_2578 = [""];
				__debugInfo = "613:\src\Compiler.gbas";
				READLINE(local4_File_2577, local8_Line_Str_ref_2578);
				__debugInfo = "614:\src\Compiler.gbas";
				local8_Text_Str_2576 = ((((local8_Text_Str_2576) + (local8_Line_Str_ref_2578[0]))) + ("\n"));
				__debugInfo = "613:\src\Compiler.gbas";
			};
			__debugInfo = "616:\src\Compiler.gbas";
			CLOSEFILE(local4_File_2577);
			__debugInfo = "615:\src\Compiler.gbas";
		} else {
			__debugInfo = "618:\src\Compiler.gbas";
			func5_Error((("Cannot find file: ") + (param8_Path_Str)), 617, "src\Compiler.gbas");
			__debugInfo = "618:\src\Compiler.gbas";
		};
		__debugInfo = "621:\src\Compiler.gbas";
		return tryClone(local8_Text_Str_2576);
		__debugInfo = "622:\src\Compiler.gbas";
		return "";
		__debugInfo = "609:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_LoadFile_Str = window['func12_LoadFile_Str'];
window['func5_Error'] = function(param7_Msg_Str, param4_Line, param8_File_Str) {
	stackPush("function: Error", __debugInfo);
	try {
		var local3_tok_1878 = new type5_Token();
		__debugInfo = "626:\src\Compiler.gbas";
		local3_tok_1878 = func15_GetCurrentToken().clone(/* In Assign */);
		__debugInfo = "628:\src\Compiler.gbas";
		param7_Msg_Str = (((((("Error: '") + (REPLACE_Str(param7_Msg_Str, "\n", "NEWLINE")))) + (global8_Compiler.attr14_errorState_Str))) + ("'\n"));
		__debugInfo = "629:\src\Compiler.gbas";
		param7_Msg_Str = ((((((((((((((param7_Msg_Str) + ("in line '"))) + (CAST2STRING(local3_tok_1878.attr4_Line_ref[0])))) + ("' at character '"))) + (CAST2STRING(local3_tok_1878.attr9_Character_ref[0])))) + ("' near '"))) + (REPLACE_Str(unref(local3_tok_1878.attr8_Text_Str_ref[0]), "\n", "NEWLINE")))) + ("'\n"));
		__debugInfo = "630:\src\Compiler.gbas";
		param7_Msg_Str = ((((((param7_Msg_Str) + ("in file '"))) + (local3_tok_1878.attr8_Path_Str_ref[0]))) + ("'\n"));
		__debugInfo = "636:\src\Compiler.gbas";
		param7_Msg_Str = ((((((param7_Msg_Str) + ("\t '"))) + (local3_tok_1878.attr15_LineContent_Str_ref[0]))) + ("'\n"));
		__debugInfo = "637:\src\Compiler.gbas";
		param7_Msg_Str = ((param7_Msg_Str) + ("-----------------------------------\n"));
		__debugInfo = "637:\src\Compiler.gbas";
		param7_Msg_Str = (("\n-----------------------------------\n") + (param7_Msg_Str));
		__debugInfo = "639:\src\Compiler.gbas";
		STDERR(param7_Msg_Str);
		__debugInfo = "640:\src\Compiler.gbas";
		global8_Compiler.attr8_WasError = 1;
		__debugInfo = "644:\src\Compiler.gbas";
		END();
		__debugInfo = "646:\src\Compiler.gbas";
		throw new OTTException((((("syntaxerror '") + (param7_Msg_Str))) + ("'")), "\src\Compiler.gbas", 646);
		__debugInfo = "647:\src\Compiler.gbas";
		return 0;
		__debugInfo = "626:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_Error = window['func5_Error'];
window['func7_Warning'] = function(param7_Msg_Str) {
	stackPush("function: Warning", __debugInfo);
	try {
		var local3_tok_2580 = new type5_Token();
		__debugInfo = "651:\src\Compiler.gbas";
		local3_tok_2580 = func15_GetCurrentToken().clone(/* In Assign */);
		__debugInfo = "653:\src\Compiler.gbas";
		param7_Msg_Str = (((("Warning: '") + (REPLACE_Str(param7_Msg_Str, "\n", "NEWLINE")))) + ("'\n"));
		__debugInfo = "654:\src\Compiler.gbas";
		param7_Msg_Str = ((((((((((((((param7_Msg_Str) + ("in line '"))) + (CAST2STRING(local3_tok_2580.attr4_Line_ref[0])))) + ("' at character '"))) + (CAST2STRING(local3_tok_2580.attr9_Character_ref[0])))) + ("' near '"))) + (REPLACE_Str(unref(local3_tok_2580.attr8_Text_Str_ref[0]), "\n", "NEWLINE")))) + ("'\n"));
		__debugInfo = "655:\src\Compiler.gbas";
		param7_Msg_Str = ((((((param7_Msg_Str) + ("in file '"))) + (local3_tok_2580.attr8_Path_Str_ref[0]))) + ("'\n"));
		__debugInfo = "656:\src\Compiler.gbas";
		param7_Msg_Str = ((((((param7_Msg_Str) + ("\t '"))) + (local3_tok_2580.attr15_LineContent_Str_ref[0]))) + ("'\n"));
		__debugInfo = "657:\src\Compiler.gbas";
		param7_Msg_Str = ((param7_Msg_Str) + ("-----------------------------------\n"));
		__debugInfo = "657:\src\Compiler.gbas";
		param7_Msg_Str = (("\n-----------------------------------\n") + (param7_Msg_Str));
		__debugInfo = "659:\src\Compiler.gbas";
		STDOUT(param7_Msg_Str);
		__debugInfo = "660:\src\Compiler.gbas";
		return 0;
		__debugInfo = "651:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_Warning = window['func7_Warning'];
window['func11_CreateToken'] = function(param8_Text_Str, param15_LineContent_Str, param4_Line, param9_Character, param8_Path_Str) {
	stackPush("function: CreateToken", __debugInfo);
	try {
		__debugInfo = "691:\src\Compiler.gbas";
		if (((((((((((((param8_Text_Str) != ("\n")) ? 1 : 0)) && ((((TRIM_Str(param8_Text_Str, " \t\r\n\v\f")) == ("")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Text_Str) == ("\t")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Text_Str) == ("\r")) ? 1 : 0))) ? 1 : 0)) {
			
		} else {
			var local6_ascval_2586 = 0, local3_pos_2587 = 0.0;
			__debugInfo = "668:\src\Compiler.gbas";
			local6_ascval_2586 = ASC(param8_Text_Str, 0);
			__debugInfo = "671:\src\Compiler.gbas";
			if ((((((((((local6_ascval_2586) == (8)) ? 1 : 0)) || ((((local6_ascval_2586) == (12)) ? 1 : 0))) ? 1 : 0)) || ((((CAST2STRING(local6_ascval_2586)) == (global11_SHLASHF_Str)) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "670:\src\Compiler.gbas";
				param8_Text_Str = "\n";
				__debugInfo = "670:\src\Compiler.gbas";
			};
			__debugInfo = "675:\src\Compiler.gbas";
			local3_pos_2587 = global8_Compiler.attr11_LastTokenID;
			__debugInfo = "676:\src\Compiler.gbas";
			global8_Compiler.attr11_LastTokenID = ((global8_Compiler.attr11_LastTokenID) + (1));
			__debugInfo = "683:\src\Compiler.gbas";
			if ((((global8_Compiler.attr11_LastTokenID) >= (((BOUNDS(global8_Compiler.attr6_Tokens, 0)) - (10)))) ? 1 : 0)) {
				__debugInfo = "681:\src\Compiler.gbas";
				REDIM(global8_Compiler.attr6_Tokens, [((global8_Compiler.attr11_LastTokenID) + (50))], new type5_Token() );
				__debugInfo = "681:\src\Compiler.gbas";
			};
			__debugInfo = "685:\src\Compiler.gbas";
			global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr4_Line_ref[0] = param4_Line;
			__debugInfo = "686:\src\Compiler.gbas";
			global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr9_Character_ref[0] = param9_Character;
			__debugInfo = "687:\src\Compiler.gbas";
			global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr15_LineContent_Str_ref[0] = param15_LineContent_Str;
			__debugInfo = "688:\src\Compiler.gbas";
			global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr8_Path_Str_ref[0] = param8_Path_Str;
			__debugInfo = "689:\src\Compiler.gbas";
			global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr8_Text_Str_ref[0] = param8_Text_Str;
			__debugInfo = "690:\src\Compiler.gbas";
			if ((((LEFT_Str(unref(global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr8_Text_Str_ref[0]), 1)) == ("@")) ? 1 : 0)) {
				__debugInfo = "690:\src\Compiler.gbas";
				global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr8_Text_Str_ref[0] = MID_Str(unref(global8_Compiler.attr6_Tokens.arrAccess(~~(local3_pos_2587)).values[tmpPositionCache].attr8_Text_Str_ref[0]), 1, -(1));
				__debugInfo = "690:\src\Compiler.gbas";
			};
			__debugInfo = "668:\src\Compiler.gbas";
		};
		__debugInfo = "692:\src\Compiler.gbas";
		return tryClone(unref(new type5_Token()));
		__debugInfo = "691:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_CreateToken = window['func11_CreateToken'];
window['func15_GetCurrentToken'] = function() {
	stackPush("function: GetCurrentToken", __debugInfo);
	try {
		__debugInfo = "700:\src\Compiler.gbas";
		if ((((global8_Compiler.attr11_currentPosi) < (global8_Compiler.attr11_LastTokenID)) ? 1 : 0)) {
			__debugInfo = "696:\src\Compiler.gbas";
			return tryClone(global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache]);
			__debugInfo = "696:\src\Compiler.gbas";
		} else {
			var local1_t_1879 = new type5_Token();
			__debugInfo = "699:\src\Compiler.gbas";
			return tryClone(local1_t_1879);
			__debugInfo = "699:\src\Compiler.gbas";
		};
		__debugInfo = "701:\src\Compiler.gbas";
		return tryClone(unref(new type5_Token()));
		__debugInfo = "700:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func15_GetCurrentToken = window['func15_GetCurrentToken'];
window['func5_Start'] = function() {
	stackPush("function: Start", __debugInfo);
	try {
		__debugInfo = "704:\src\Compiler.gbas";
		global8_Compiler.attr11_currentPosi = 0;
		__debugInfo = "705:\src\Compiler.gbas";
		func7_GetNext();
		__debugInfo = "706:\src\Compiler.gbas";
		return 0;
		__debugInfo = "704:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_Start = window['func5_Start'];
window['func7_HasNext'] = function() {
	stackPush("function: HasNext", __debugInfo);
	try {
		__debugInfo = "713:\src\Compiler.gbas";
		if ((((global8_Compiler.attr11_currentPosi) > (((global8_Compiler.attr11_LastTokenID) - (2)))) ? 1 : 0)) {
			__debugInfo = "710:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "710:\src\Compiler.gbas";
		} else {
			__debugInfo = "712:\src\Compiler.gbas";
			return 1;
			__debugInfo = "712:\src\Compiler.gbas";
		};
		__debugInfo = "714:\src\Compiler.gbas";
		return 0;
		__debugInfo = "713:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_HasNext = window['func7_HasNext'];
window['func7_GetNext'] = function() {
	stackPush("function: GetNext", __debugInfo);
	try {
		__debugInfo = "721:\src\Compiler.gbas";
		do {
			__debugInfo = "717:\src\Compiler.gbas";
			global8_Compiler.attr11_currentPosi+=1;
			__debugInfo = "720:\src\Compiler.gbas";
			if ((((global8_Compiler.attr11_currentPosi) > (((global8_Compiler.attr11_LastTokenID) - (1)))) ? 1 : 0)) {
				__debugInfo = "719:\src\Compiler.gbas";
				func5_Error("Unexpected end of line", 718, "src\Compiler.gbas");
				__debugInfo = "719:\src\Compiler.gbas";
			};
			__debugInfo = "717:\src\Compiler.gbas";
		} while (!(((global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr5_IsDel) ? 0 : 1)));
		__debugInfo = "725:\src\Compiler.gbas";
		return 0;
		__debugInfo = "721:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_GetNext = window['func7_GetNext'];
window['func5_Match'] = function(param8_Text_Str, param4_Line, param8_File_Str) {
	stackPush("function: Match", __debugInfo);
	try {
		__debugInfo = "729:\src\Compiler.gbas";
		if ((((global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr8_Text_Str_ref[0]) != (param8_Text_Str)) ? 1 : 0)) {
			__debugInfo = "728:\src\Compiler.gbas";
			func5_Error((((("Unexpected token, expecting: '") + (param8_Text_Str))) + ("'")), ~~(param4_Line), param8_File_Str);
			__debugInfo = "728:\src\Compiler.gbas";
		};
		__debugInfo = "730:\src\Compiler.gbas";
		func7_GetNext();
		__debugInfo = "731:\src\Compiler.gbas";
		return 0;
		__debugInfo = "729:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_Match = window['func5_Match'];
window['func8_EOFParse'] = function() {
	stackPush("function: EOFParse", __debugInfo);
	try {
		__debugInfo = "734:\src\Compiler.gbas";
		return tryClone((((global8_Compiler.attr11_currentPosi) < (((global8_Compiler.attr11_LastTokenID) - (1)))) ? 1 : 0));
		__debugInfo = "735:\src\Compiler.gbas";
		return 0;
		__debugInfo = "734:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_EOFParse = window['func8_EOFParse'];
window['func14_GetCurrent_Str'] = function() {
	stackPush("function: GetCurrent_Str", __debugInfo);
	try {
		__debugInfo = "738:\src\Compiler.gbas";
		return tryClone(unref(global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr8_Text_Str_ref[0]));
		__debugInfo = "739:\src\Compiler.gbas";
		return "";
		__debugInfo = "738:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_GetCurrent_Str = window['func14_GetCurrent_Str'];
window['func13_RemoveCurrent'] = function() {
	stackPush("function: RemoveCurrent", __debugInfo);
	try {
		__debugInfo = "742:\src\Compiler.gbas";
		global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr5_IsDel = 1;
		__debugInfo = "743:\src\Compiler.gbas";
		global8_Compiler.attr11_currentPosi+=1;
		__debugInfo = "746:\src\Compiler.gbas";
		return 0;
		__debugInfo = "742:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_RemoveCurrent = window['func13_RemoveCurrent'];
window['func14_MatchAndRemove'] = function(param8_Text_Str, param4_Line, param8_File_Str) {
	stackPush("function: MatchAndRemove", __debugInfo);
	try {
		__debugInfo = "751:\src\Compiler.gbas";
		if ((((func14_GetCurrent_Str()) != (param8_Text_Str)) ? 1 : 0)) {
			__debugInfo = "750:\src\Compiler.gbas";
			func5_Error((((("Unexpected token, expecting: '") + (param8_Text_Str))) + ("'")), ~~(param4_Line), param8_File_Str);
			__debugInfo = "750:\src\Compiler.gbas";
		};
		__debugInfo = "752:\src\Compiler.gbas";
		func13_RemoveCurrent();
		__debugInfo = "753:\src\Compiler.gbas";
		return 0;
		__debugInfo = "751:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_MatchAndRemove = window['func14_MatchAndRemove'];
window['func14_CreateDatatype'] = function(param8_Name_Str, param7_IsArray) {
	stackPush("function: CreateDatatype", __debugInfo);
	try {
		var local8_datatype_2593 = new type8_Datatype();
		__debugInfo = "757:\src\Compiler.gbas";
		local8_datatype_2593.attr8_Name_Str_ref[0] = param8_Name_Str;
		__debugInfo = "758:\src\Compiler.gbas";
		local8_datatype_2593.attr7_IsArray_ref[0] = param7_IsArray;
		__debugInfo = "759:\src\Compiler.gbas";
		return tryClone(local8_datatype_2593);
		__debugInfo = "760:\src\Compiler.gbas";
		return tryClone(unref(new type8_Datatype()));
		__debugInfo = "757:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_CreateDatatype = window['func14_CreateDatatype'];
window['func7_IsToken'] = function(param8_Text_Str) {
	stackPush("function: IsToken", __debugInfo);
	try {
		__debugInfo = "767:\src\Compiler.gbas";
		if ((((func14_GetCurrent_Str()) == (param8_Text_Str)) ? 1 : 0)) {
			__debugInfo = "764:\src\Compiler.gbas";
			return 1;
			__debugInfo = "764:\src\Compiler.gbas";
		} else {
			__debugInfo = "766:\src\Compiler.gbas";
			return tryClone(0);
			__debugInfo = "766:\src\Compiler.gbas";
		};
		__debugInfo = "768:\src\Compiler.gbas";
		return 0;
		__debugInfo = "767:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_IsToken = window['func7_IsToken'];
window['func14_CreateOperator'] = function(param8_Name_Str, param7_Sym_Str, param4_Prio, param3_Typ) {
	stackPush("function: CreateOperator", __debugInfo);
	try {
		var local2_Op_ref_2598 = [new type8_Operator()];
		__debugInfo = "772:\src\Compiler.gbas";
		local2_Op_ref_2598[0].attr8_Name_Str = param8_Name_Str;
		__debugInfo = "773:\src\Compiler.gbas";
		local2_Op_ref_2598[0].attr7_Sym_Str = param7_Sym_Str;
		__debugInfo = "774:\src\Compiler.gbas";
		local2_Op_ref_2598[0].attr4_Prio = param4_Prio;
		__debugInfo = "775:\src\Compiler.gbas";
		local2_Op_ref_2598[0].attr3_Typ = param3_Typ;
		__debugInfo = "776:\src\Compiler.gbas";
		local2_Op_ref_2598[0].attr2_ID = BOUNDS(global9_Operators_ref[0], 0);
		__debugInfo = "777:\src\Compiler.gbas";
		DIMPUSH(global9_Operators_ref[0], local2_Op_ref_2598);
		__debugInfo = "778:\src\Compiler.gbas";
		return 0;
		__debugInfo = "772:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_CreateOperator = window['func14_CreateOperator'];
window['func11_WriteString'] = function(param1_F, param8_Text_Str) {
	stackPush("function: WriteString", __debugInfo);
	try {
		__debugInfo = "781:\src\Compiler.gbas";
		WRITEULONG(param1_F, INT2STR(param8_Text_Str));
		__debugInfo = "782:\src\Compiler.gbas";
		WRITESTR(param1_F, param8_Text_Str);
		__debugInfo = "783:\src\Compiler.gbas";
		return 0;
		__debugInfo = "781:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_WriteString = window['func11_WriteString'];
window['func10_ReadString'] = function(param1_F, param8_Text_Str_ref) {
	stackPush("function: ReadString", __debugInfo);
	try {
		var local1_l_ref_1888 = [0];
		__debugInfo = "787:\src\Compiler.gbas";
		READULONG(param1_F, local1_l_ref_1888);
		__debugInfo = "788:\src\Compiler.gbas";
		READSTR(param1_F, param8_Text_Str_ref, unref(local1_l_ref_1888[0]));
		__debugInfo = "789:\src\Compiler.gbas";
		return 0;
		__debugInfo = "787:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_ReadString = window['func10_ReadString'];
window['func11_AddVariable'] = function(param4_Vari, param6_Ignore) {
	stackPush("function: AddVariable", __debugInfo);
	try {
		var local4_Vari_ref_1889 = [param4_Vari]; /* NEWCODEHERE */
		__debugInfo = "792:\src\Compiler.gbas";
		if (((((((param6_Ignore) == (0)) ? 1 : 0)) && (func13_IsVarExisting(local4_Vari_ref_1889[0].attr8_Name_Str))) ? 1 : 0)) {
			__debugInfo = "792:\src\Compiler.gbas";
			func5_Error((((("Variable already exists, is a keyword or a type: '") + (local4_Vari_ref_1889[0].attr8_Name_Str))) + ("'")), 791, "src\Compiler.gbas");
			__debugInfo = "792:\src\Compiler.gbas";
		};
		__debugInfo = "793:\src\Compiler.gbas";
		local4_Vari_ref_1889[0].attr2_ID = BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0);
		__debugInfo = "795:\src\Compiler.gbas";
		DIMPUSH(global8_Compiler.attr5_Varis_ref[0], local4_Vari_ref_1889);
		__debugInfo = "796:\src\Compiler.gbas";
		return 0;
		__debugInfo = "792:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_AddVariable = window['func11_AddVariable'];
window['func11_AddFunction'] = function(param4_Func) {
	stackPush("function: AddFunction", __debugInfo);
	try {
		var local4_Func_ref_1891 = [param4_Func]; /* NEWCODEHERE */
		__debugInfo = "799:\src\Compiler.gbas";
		if (((((((local4_Func_ref_1891[0].attr3_Typ) != (3)) ? 1 : 0)) && (func14_IsFuncExisting(local4_Func_ref_1891[0].attr8_Name_Str, local4_Func_ref_1891[0].attr10_IsCallback))) ? 1 : 0)) {
			__debugInfo = "799:\src\Compiler.gbas";
			func5_Error((((("Function already exists, is a keyword or a type: '") + (local4_Func_ref_1891[0].attr8_Name_Str))) + ("'")), 798, "src\Compiler.gbas");
			__debugInfo = "799:\src\Compiler.gbas";
		};
		__debugInfo = "801:\src\Compiler.gbas";
		local4_Func_ref_1891[0].attr2_ID = BOUNDS(global8_Compiler.attr5_Funcs_ref[0], 0);
		__debugInfo = "802:\src\Compiler.gbas";
		DIMPUSH(global8_Compiler.attr5_Funcs_ref[0], local4_Func_ref_1891);
		__debugInfo = "803:\src\Compiler.gbas";
		return 0;
		__debugInfo = "799:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_AddFunction = window['func11_AddFunction'];
window['InitCompiler'] = function() {
	stackPush("function: InitCompiler", __debugInfo);
	try {
		var local12_Keywords_Str_1892 = new OTTArray("");
		__debugInfo = "806:\src\Compiler.gbas";
		REDIM(global7_Defines, [0], new type7_TDefine() );
		__debugInfo = "807:\src\Compiler.gbas";
		global12_voidDatatype = func14_CreateDatatype("void", 0).clone(/* In Assign */);
		__debugInfo = "808:\src\Compiler.gbas";
		global11_intDatatype = func14_CreateDatatype("int", 0).clone(/* In Assign */);
		__debugInfo = "809:\src\Compiler.gbas";
		global13_floatDatatype = func14_CreateDatatype("float", 0).clone(/* In Assign */);
		__debugInfo = "810:\src\Compiler.gbas";
		global11_strDatatype = func14_CreateDatatype("string", 0).clone(/* In Assign */);
		__debugInfo = "812:\src\Compiler.gbas";
		global11_SHLASHF_Str = CHR_Str(INT2STR("\f"));
		__debugInfo = "814:\src\Compiler.gbas";
		REDIM(unref(global9_Operators_ref[0]), [0], [new type8_Operator()] );
		__debugInfo = "815:\src\Compiler.gbas";
		func14_CreateOperator("add", "+", 4, ~~(2));
		__debugInfo = "816:\src\Compiler.gbas";
		func14_CreateOperator("sub", "-", 4, ~~(2));
		__debugInfo = "817:\src\Compiler.gbas";
		func14_CreateOperator("mul", "*", 5, ~~(2));
		__debugInfo = "818:\src\Compiler.gbas";
		func14_CreateOperator("div", "/", 5, ~~(2));
		__debugInfo = "819:\src\Compiler.gbas";
		func14_CreateOperator("pot", "^", 6, ~~(2));
		__debugInfo = "821:\src\Compiler.gbas";
		func14_CreateOperator("equ", "=", 3, ~~(3));
		__debugInfo = "822:\src\Compiler.gbas";
		func14_CreateOperator("grt", ">", 3, ~~(3));
		__debugInfo = "823:\src\Compiler.gbas";
		func14_CreateOperator("less", "<", 3, ~~(3));
		__debugInfo = "824:\src\Compiler.gbas";
		func14_CreateOperator("lessequ", "<=", 3, ~~(3));
		__debugInfo = "825:\src\Compiler.gbas";
		func14_CreateOperator("grtequ", ">=", 3, ~~(3));
		__debugInfo = "826:\src\Compiler.gbas";
		func14_CreateOperator("unequ", "<>", 3, ~~(3));
		__debugInfo = "828:\src\Compiler.gbas";
		func14_CreateOperator("and", "AND", 2, ~~(3));
		__debugInfo = "829:\src\Compiler.gbas";
		func14_CreateOperator("or", "OR", 2, ~~(3));
		__debugInfo = "832:\src\Compiler.gbas";
		DIMDATA(local12_Keywords_Str_1892, ["CALLBACK", "FUNCTION", "ENDFUNCTION", "SUB", "ENDSUB", "GOSUB", "IF", "ELSE", "ELSEIF", "THEN", "ENDIF", "WHILE", "WEND", "BREAK", "CONTINUE", "FOR", "FOREACH", "IN", "TO", "STEP", "NEXT", "REPEAT", "UNTIL", "TYPE", "ENDTYPE", "RETURN", "NATIVE", "LOCAL", "GLOBAL", "STATIC", "DIM", "REDIM", "INLINE", "ENDINLINE", "PROTOTYPE", "REQUIRE", "BREAK", "CONTINUE", "TRY", "CATCH", "FINALLY", "THROW", "SELECT", "CASE", "DEFAULT", "ENDSELECT", "STARTDATA", "ENDDATA", "DATA", "RESTORE", "READ", "GOTO", "ALIAS", "AS", "CONSTANT", "INC", "DEC", "DIMPUSH", "LEN", "DIMDATA", "DELETE", "DIMDEL", "DEBUG", "ASSERT", "ABSTRACT", "EXPORT"]);
		__debugInfo = "834:\src\Compiler.gbas";
		(global10_KeywordMap).SetSize(((BOUNDS(local12_Keywords_Str_1892, 0)) * (8)));
		__debugInfo = "837:\src\Compiler.gbas";
		var forEachSaver4584 = local12_Keywords_Str_1892;
		for(var forEachCounter4584 = 0 ; forEachCounter4584 < forEachSaver4584.values.length ; forEachCounter4584++) {
			var local7_key_Str_1893 = forEachSaver4584.values[forEachCounter4584];
		{
				__debugInfo = "836:\src\Compiler.gbas";
				(global10_KeywordMap).Put(local7_key_Str_1893, 1);
				__debugInfo = "836:\src\Compiler.gbas";
			}
			forEachSaver4584.values[forEachCounter4584] = local7_key_Str_1893;
		
		};
		__debugInfo = "840:\src\Compiler.gbas";
		RegisterDefine("GLB_VERSION", "1");
		__debugInfo = "841:\src\Compiler.gbas";
		RegisterDefine("oTT_VERSION", "1");
		__debugInfo = "842:\src\Compiler.gbas";
		RegisterDefine("OTTBASIC", CAST2STRING(1));
		__debugInfo = "846:\src\Compiler.gbas";
		RegisterDefine("ADDON_2D", CAST2STRING(1));
		__debugInfo = "847:\src\Compiler.gbas";
		RegisterDefine("ADDON_3D", CAST2STRING(1));
		__debugInfo = "848:\src\Compiler.gbas";
		RegisterDefine("ADDON_NET", CAST2STRING(1));
		__debugInfo = "849:\src\Compiler.gbas";
		RegisterDefine("ADDON_INPUT", CAST2STRING(1));
		__debugInfo = "850:\src\Compiler.gbas";
		RegisterDefine("ADDON_CONSOLE", CAST2STRING(1));
		__debugInfo = "851:\src\Compiler.gbas";
		RegisterDefine("ADDON_SOUND", CAST2STRING(1));
		__debugInfo = "852:\src\Compiler.gbas";
		RegisterDefine("ADDON_NET", CAST2STRING(1));
		__debugInfo = "854:\src\Compiler.gbas";
		func16_ResetExpressions();
		__debugInfo = "857:\src\Compiler.gbas";
		REDIM(global14_Documentations, [0], new type13_Documentation() );
		__debugInfo = "858:\src\Compiler.gbas";
		return 0;
		__debugInfo = "806:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
InitCompiler = window['InitCompiler'];
window['Compile_Str'] = function(param8_Text_Str, param10_Target_Str) {
	stackPush("function: Compile_Str", __debugInfo);
	try {
		var local1_c_1896 = new type9_TCompiler(), local11_tmpPath_Str_1897 = "", local10_Output_Str_1898 = "";
		__debugInfo = "872:\src\Compiler.gbas";
		global8_Compiler = local1_c_1896.clone(/* In Assign */);
		__debugInfo = "875:\src\Compiler.gbas";
		InitCompiler();
		__debugInfo = "877:\src\Compiler.gbas";
		func16_ResetExpressions();
		__debugInfo = "879:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "880:\src\Compiler.gbas";
		param8_Text_Str = ((param8_Text_Str) + ("\n"));
		__debugInfo = "881:\src\Compiler.gbas";
		param8_Text_Str = ((param8_Text_Str) + (func12_LoadFile_Str("Target/Header.gbas")));
		__debugInfo = "885:\src\Compiler.gbas";
		param8_Text_Str = ((param8_Text_Str) + ("\n"));
		__debugInfo = "887:\src\Compiler.gbas";
		func11_SetupTarget(param10_Target_Str);
		__debugInfo = "889:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "891:\src\Compiler.gbas";
		func8_PopTimer("Header load & setup target!");
		__debugInfo = "893:\src\Compiler.gbas";
		global8_Compiler.attr8_Code_Str = ((param8_Text_Str) + ("\n"));
		__debugInfo = "895:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "896:\src\Compiler.gbas";
		func5_Lexer();
		__debugInfo = "897:\src\Compiler.gbas";
		func8_PopTimer("Lexer!");
		__debugInfo = "899:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "900:\src\Compiler.gbas";
		STDOUT("Lexing successful! \n");
		__debugInfo = "902:\src\Compiler.gbas";
		global8_Compiler.attr14_errorState_Str = " (precompiler error)";
		__debugInfo = "903:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "904:\src\Compiler.gbas";
		func11_Precompiler();
		__debugInfo = "905:\src\Compiler.gbas";
		func8_PopTimer("Precompiler");
		__debugInfo = "907:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "908:\src\Compiler.gbas";
		STDOUT("Preprocessing successful! \n");
		__debugInfo = "911:\src\Compiler.gbas";
		global8_Compiler.attr13_LastMaxTokens = global8_Compiler.attr11_LastTokenID;
		__debugInfo = "913:\src\Compiler.gbas";
		func16_ResetExpressions();
		__debugInfo = "915:\src\Compiler.gbas";
		global8_Compiler.attr14_errorState_Str = " (analyse error)";
		__debugInfo = "916:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "917:\src\Compiler.gbas";
		func8_Analyser();
		__debugInfo = "918:\src\Compiler.gbas";
		func8_PopTimer("Analyser");
		__debugInfo = "920:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "926:\src\Compiler.gbas";
		if (global8_Compiler.attr8_WasError) {
			__debugInfo = "922:\src\Compiler.gbas";
			STDOUT("Analysing failed :( \n");
			__debugInfo = "923:\src\Compiler.gbas";
			return "";
			__debugInfo = "922:\src\Compiler.gbas";
		} else {
			__debugInfo = "925:\src\Compiler.gbas";
			STDOUT("Analysing successful! \n");
			__debugInfo = "925:\src\Compiler.gbas";
		};
		__debugInfo = "928:\src\Compiler.gbas";
		local11_tmpPath_Str_1897 = GETCURRENTDIR_Str();
		__debugInfo = "929:\src\Compiler.gbas";
		SETCURRENTDIR(global12_GbapPath_Str);
		__debugInfo = "931:\src\Compiler.gbas";
		global8_Compiler.attr14_errorState_Str = " (parse error)";
		__debugInfo = "932:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "933:\src\Compiler.gbas";
		func6_Parser();
		__debugInfo = "934:\src\Compiler.gbas";
		func8_PopTimer("Parser");
		__debugInfo = "936:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "942:\src\Compiler.gbas";
		if (global8_Compiler.attr8_WasError) {
			__debugInfo = "938:\src\Compiler.gbas";
			STDOUT("Parsing failed :( \n");
			__debugInfo = "939:\src\Compiler.gbas";
			return "";
			__debugInfo = "938:\src\Compiler.gbas";
		} else {
			__debugInfo = "941:\src\Compiler.gbas";
			STDOUT("Parsing successful! \n");
			__debugInfo = "941:\src\Compiler.gbas";
		};
		__debugInfo = "943:\src\Compiler.gbas";
		global8_Compiler.attr14_errorState_Str = " (generate error)";
		__debugInfo = "945:\src\Compiler.gbas";
		SETCURRENTDIR(local11_tmpPath_Str_1897);
		__debugInfo = "948:\src\Compiler.gbas";
		func9_PushTimer();
		__debugInfo = "949:\src\Compiler.gbas";
		local10_Output_Str_1898 = func12_DoTarget_Str(param10_Target_Str);
		__debugInfo = "950:\src\Compiler.gbas";
		func8_PopTimer("Target stuff");
		__debugInfo = "952:\src\Compiler.gbas";
		PassSuccessfull();
		__debugInfo = "958:\src\Compiler.gbas";
		if (global8_Compiler.attr8_WasError) {
			__debugInfo = "954:\src\Compiler.gbas";
			STDOUT("Generating failed :( \n");
			__debugInfo = "955:\src\Compiler.gbas";
			return "";
			__debugInfo = "954:\src\Compiler.gbas";
		} else {
			__debugInfo = "957:\src\Compiler.gbas";
			STDOUT((((("Generating successful to target ") + (param10_Target_Str))) + ("! \n")));
			__debugInfo = "957:\src\Compiler.gbas";
		};
		__debugInfo = "960:\src\Compiler.gbas";
		return tryClone(local10_Output_Str_1898);
		__debugInfo = "961:\src\Compiler.gbas";
		return "";
		__debugInfo = "872:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
Compile_Str = window['Compile_Str'];
window['func16_ResetExpressions'] = function() {
	stackPush("function: ResetExpressions", __debugInfo);
	try {
		__debugInfo = "964:\src\Compiler.gbas";
		DIM(unref(global5_Exprs_ref[0]), [0], [new type4_Expr()]);
		__debugInfo = "965:\src\Compiler.gbas";
		global10_LastExprID = 0;
		__debugInfo = "966:\src\Compiler.gbas";
		func21_CreateDebugExpression();
		__debugInfo = "967:\src\Compiler.gbas";
		return 0;
		__debugInfo = "964:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func16_ResetExpressions = window['func16_ResetExpressions'];
window['func9_PushTimer'] = function() {
	stackPush("function: PushTimer", __debugInfo);
	try {
		__debugInfo = "977:\src\Compiler.gbas";
		return 0;
		__debugInfo = "977:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func9_PushTimer = window['func9_PushTimer'];
window['func8_PopTimer'] = function(param8_Text_Str) {
	stackPush("function: PopTimer", __debugInfo);
	try {
		__debugInfo = "985:\src\Compiler.gbas";
		return 0;
		__debugInfo = "985:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_PopTimer = window['func8_PopTimer'];
window['RegisterDefine'] = function(param7_Key_Str, param9_Value_Str) {
	stackPush("function: RegisterDefine", __debugInfo);
	try {
		var local3_Def_1902 = new type7_TDefine();
		__debugInfo = "990:\src\Compiler.gbas";
		local3_Def_1902.attr7_Key_Str = param7_Key_Str;
		__debugInfo = "991:\src\Compiler.gbas";
		local3_Def_1902.attr9_Value_Str = param9_Value_Str;
		__debugInfo = "992:\src\Compiler.gbas";
		DIMPUSH(global7_Defines, local3_Def_1902);
		__debugInfo = "993:\src\Compiler.gbas";
		return 0;
		__debugInfo = "990:\src\Compiler.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
RegisterDefine = window['RegisterDefine'];
window['func16_CreateExpression'] = function(param3_Typ, param8_datatype) {
	stackPush("function: CreateExpression", __debugInfo);
	try {
		var local4_tmpD_2601 = new type8_Datatype(), local3_pos_2602 = 0.0, local1_d_2603 = new type8_Datatype();
		__debugInfo = "64:\src\Expression.gbas";
		local4_tmpD_2601 = param8_datatype.clone(/* In Assign */);
		__debugInfo = "69:\src\Expression.gbas";
		local3_pos_2602 = global10_LastExprID;
		__debugInfo = "70:\src\Expression.gbas";
		global10_LastExprID = ((global10_LastExprID) + (1));
		__debugInfo = "77:\src\Expression.gbas";
		if ((((global10_LastExprID) >= (((BOUNDS(global5_Exprs_ref[0], 0)) - (10)))) ? 1 : 0)) {
			__debugInfo = "75:\src\Expression.gbas";
			REDIM(unref(global5_Exprs_ref[0]), [~~(((global10_LastExprID) + (50)))], [new type4_Expr()] );
			__debugInfo = "75:\src\Expression.gbas";
		};
		__debugInfo = "78:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(~~(local3_pos_2602)).values[tmpPositionCache][0].attr3_Typ = param3_Typ;
		__debugInfo = "81:\src\Expression.gbas";
		local1_d_2603.attr8_Name_Str_ref[0] = local4_tmpD_2601.attr8_Name_Str_ref[0];
		__debugInfo = "82:\src\Expression.gbas";
		local1_d_2603.attr7_IsArray_ref[0] = local4_tmpD_2601.attr7_IsArray_ref[0];
		__debugInfo = "83:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(~~(local3_pos_2602)).values[tmpPositionCache][0].attr8_datatype = local1_d_2603.clone(/* In Assign */);
		__debugInfo = "84:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(~~(local3_pos_2602)).values[tmpPositionCache][0].attr2_ID = ~~(local3_pos_2602);
		__debugInfo = "85:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(~~(local3_pos_2602)).values[tmpPositionCache][0].attr5_tokID = global8_Compiler.attr11_currentPosi;
		__debugInfo = "86:\src\Expression.gbas";
		return tryClone(~~(local3_pos_2602));
		__debugInfo = "87:\src\Expression.gbas";
		return 0;
		__debugInfo = "64:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func16_CreateExpression = window['func16_CreateExpression'];
window['func24_CreateOperatorExpression'] = function(param2_Op, param4_Left, param5_Right) {
	stackPush("function: CreateOperatorExpression", __debugInfo);
	try {
		var local4_expr_2607 = 0, local8_datatype_2608 = new type8_Datatype();
		var local4_Left_ref_2605 = [param4_Left]; /* NEWCODEHERE */
		var local5_Right_ref_2606 = [param5_Right]; /* NEWCODEHERE */
		__debugInfo = "93:\src\Expression.gbas";
		local8_datatype_2608 = func12_CastDatatype(local4_Left_ref_2605, local5_Right_ref_2606).clone(/* In Assign */);
		__debugInfo = "98:\src\Expression.gbas";
		if ((((param2_Op.attr3_Typ) == (3)) ? 1 : 0)) {
			__debugInfo = "97:\src\Expression.gbas";
			local8_datatype_2608 = global11_intDatatype.clone(/* In Assign */);
			__debugInfo = "97:\src\Expression.gbas";
		};
		__debugInfo = "100:\src\Expression.gbas";
		local4_expr_2607 = func16_CreateExpression(~~(1), local8_datatype_2608);
		__debugInfo = "101:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2607).values[tmpPositionCache][0].attr4_Left = local4_Left_ref_2605[0];
		__debugInfo = "102:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2607).values[tmpPositionCache][0].attr5_Right = local5_Right_ref_2606[0];
		__debugInfo = "103:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2607).values[tmpPositionCache][0].attr2_Op = param2_Op.attr2_ID;
		__debugInfo = "106:\src\Expression.gbas";
		return tryClone(local4_expr_2607);
		__debugInfo = "107:\src\Expression.gbas";
		return 0;
		__debugInfo = "93:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateOperatorExpression = window['func24_CreateOperatorExpression'];
window['func19_CreateIntExpression'] = function(param3_Num) {
	stackPush("function: CreateIntExpression", __debugInfo);
	try {
		var local4_expr_2610 = 0;
		__debugInfo = "112:\src\Expression.gbas";
		local4_expr_2610 = func16_CreateExpression(~~(3), global11_intDatatype);
		__debugInfo = "113:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2610).values[tmpPositionCache][0].attr6_intval = param3_Num;
		__debugInfo = "114:\src\Expression.gbas";
		return tryClone(local4_expr_2610);
		__debugInfo = "115:\src\Expression.gbas";
		return 0;
		__debugInfo = "112:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateIntExpression = window['func19_CreateIntExpression'];
window['func21_CreateFloatExpression'] = function(param3_Num) {
	stackPush("function: CreateFloatExpression", __debugInfo);
	try {
		var local4_expr_2612 = 0;
		__debugInfo = "120:\src\Expression.gbas";
		local4_expr_2612 = func16_CreateExpression(~~(4), global13_floatDatatype);
		__debugInfo = "121:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2612).values[tmpPositionCache][0].attr8_floatval = param3_Num;
		__debugInfo = "122:\src\Expression.gbas";
		return tryClone(local4_expr_2612);
		__debugInfo = "123:\src\Expression.gbas";
		return 0;
		__debugInfo = "120:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateFloatExpression = window['func21_CreateFloatExpression'];
window['func19_CreateStrExpression'] = function(param7_Str_Str) {
	stackPush("function: CreateStrExpression", __debugInfo);
	try {
		var local4_expr_2614 = 0;
		__debugInfo = "127:\src\Expression.gbas";
		local4_expr_2614 = func16_CreateExpression(~~(5), global11_strDatatype);
		__debugInfo = "128:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2614).values[tmpPositionCache][0].attr10_strval_Str = param7_Str_Str;
		__debugInfo = "129:\src\Expression.gbas";
		return tryClone(local4_expr_2614);
		__debugInfo = "130:\src\Expression.gbas";
		return 0;
		__debugInfo = "127:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateStrExpression = window['func19_CreateStrExpression'];
window['func21_CreateScopeExpression'] = function(param6_ScpTyp) {
	stackPush("function: CreateScopeExpression", __debugInfo);
	try {
		var local3_Scp_2616 = 0;
		__debugInfo = "134:\src\Expression.gbas";
		local3_Scp_2616 = func16_CreateExpression(~~(2), global12_voidDatatype);
		__debugInfo = "135:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local3_Scp_2616).values[tmpPositionCache][0].attr10_SuperScope = global8_Compiler.attr12_CurrentScope;
		__debugInfo = "136:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local3_Scp_2616).values[tmpPositionCache][0].attr6_ScpTyp = param6_ScpTyp;
		__debugInfo = "138:\src\Expression.gbas";
		return tryClone(local3_Scp_2616);
		__debugInfo = "139:\src\Expression.gbas";
		return 0;
		__debugInfo = "134:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateScopeExpression = window['func21_CreateScopeExpression'];
window['func24_CreateFuncCallExpression'] = function(param4_func, param6_Params) {
	stackPush("function: CreateFuncCallExpression", __debugInfo);
	try {
		var local4_expr_2619 = 0;
		__debugInfo = "145:\src\Expression.gbas";
		local4_expr_2619 = func16_CreateExpression(~~(6), global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr8_datatype);
		__debugInfo = "146:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2619).values[tmpPositionCache][0].attr6_Params = param6_Params.clone(/* In Assign */);
		__debugInfo = "147:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_expr_2619).values[tmpPositionCache][0].attr4_func = param4_func;
		__debugInfo = "148:\src\Expression.gbas";
		return tryClone(local4_expr_2619);
		__debugInfo = "149:\src\Expression.gbas";
		return 0;
		__debugInfo = "145:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateFuncCallExpression = window['func24_CreateFuncCallExpression'];
window['func21_CreateEmptyExpression'] = function() {
	stackPush("function: CreateEmptyExpression", __debugInfo);
	try {
		__debugInfo = "153:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(7), global12_voidDatatype));
		__debugInfo = "154:\src\Expression.gbas";
		return 0;
		__debugInfo = "153:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateEmptyExpression = window['func21_CreateEmptyExpression'];
window['func21_CreateDebugExpression'] = function() {
	stackPush("function: CreateDebugExpression", __debugInfo);
	try {
		__debugInfo = "158:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(8), global12_voidDatatype));
		__debugInfo = "159:\src\Expression.gbas";
		return 0;
		__debugInfo = "158:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateDebugExpression = window['func21_CreateDebugExpression'];
window['func24_CreateVariableExpression'] = function(param4_vari) {
	stackPush("function: CreateVariableExpression", __debugInfo);
	try {
		__debugInfo = "169:\src\Expression.gbas";
		if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_vari).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0)) {
			__debugInfo = "164:\src\Expression.gbas";
			return tryClone(global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_vari).values[tmpPositionCache][0].attr6_PreDef);
			__debugInfo = "164:\src\Expression.gbas";
		} else {
			var local4_expr_2621 = 0;
			__debugInfo = "166:\src\Expression.gbas";
			local4_expr_2621 = func16_CreateExpression(~~(9), global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_vari).values[tmpPositionCache][0].attr8_datatype);
			__debugInfo = "167:\src\Expression.gbas";
			global5_Exprs_ref[0].arrAccess(local4_expr_2621).values[tmpPositionCache][0].attr4_vari = param4_vari;
			__debugInfo = "168:\src\Expression.gbas";
			return tryClone(local4_expr_2621);
			__debugInfo = "166:\src\Expression.gbas";
		};
		__debugInfo = "170:\src\Expression.gbas";
		return 0;
		__debugInfo = "169:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateVariableExpression = window['func24_CreateVariableExpression'];
window['func22_CreateAssignExpression'] = function(param4_Vari, param5_Right) {
	stackPush("function: CreateAssignExpression", __debugInfo);
	try {
		var local4_Expr_2624 = 0;
		__debugInfo = "174:\src\Expression.gbas";
		local4_Expr_2624 = func16_CreateExpression(~~(10), global12_voidDatatype);
		__debugInfo = "175:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2624).values[tmpPositionCache][0].attr4_vari = param4_Vari;
		__debugInfo = "176:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2624).values[tmpPositionCache][0].attr5_Right = param5_Right;
		__debugInfo = "177:\src\Expression.gbas";
		return tryClone(local4_Expr_2624);
		__debugInfo = "178:\src\Expression.gbas";
		return 0;
		__debugInfo = "174:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateAssignExpression = window['func22_CreateAssignExpression'];
window['func19_CreateDimExpression'] = function(param5_Array, param4_Dims) {
	stackPush("function: CreateDimExpression", __debugInfo);
	try {
		var local4_Expr_2627 = 0;
		__debugInfo = "183:\src\Expression.gbas";
		local4_Expr_2627 = func16_CreateExpression(~~(11), global5_Exprs_ref[0].arrAccess(param5_Array).values[tmpPositionCache][0].attr8_datatype);
		__debugInfo = "184:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2627).values[tmpPositionCache][0].attr5_array = param5_Array;
		__debugInfo = "185:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2627).values[tmpPositionCache][0].attr4_dims = param4_Dims.clone(/* In Assign */);
		__debugInfo = "187:\src\Expression.gbas";
		return tryClone(local4_Expr_2627);
		__debugInfo = "188:\src\Expression.gbas";
		return 0;
		__debugInfo = "183:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateDimExpression = window['func19_CreateDimExpression'];
window['func21_CreateReDimExpression'] = function(param5_Array, param4_Dims) {
	stackPush("function: CreateReDimExpression", __debugInfo);
	try {
		var local4_Expr_2630 = 0;
		__debugInfo = "194:\src\Expression.gbas";
		local4_Expr_2630 = func16_CreateExpression(~~(12), global5_Exprs_ref[0].arrAccess(param5_Array).values[tmpPositionCache][0].attr8_datatype);
		__debugInfo = "195:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2630).values[tmpPositionCache][0].attr5_array = param5_Array;
		__debugInfo = "196:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2630).values[tmpPositionCache][0].attr4_dims = param4_Dims.clone(/* In Assign */);
		__debugInfo = "198:\src\Expression.gbas";
		return tryClone(local4_Expr_2630);
		__debugInfo = "199:\src\Expression.gbas";
		return 0;
		__debugInfo = "194:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateReDimExpression = window['func21_CreateReDimExpression'];
window['func21_CreateArrayExpression'] = function(param5_Array, param4_Dims) {
	stackPush("function: CreateArrayExpression", __debugInfo);
	try {
		var local7_tmpData_2633 = new type8_Datatype(), local4_Expr_2634 = 0;
		__debugInfo = "205:\src\Expression.gbas";
		local7_tmpData_2633 = global5_Exprs_ref[0].arrAccess(param5_Array).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
		__debugInfo = "206:\src\Expression.gbas";
		if (((((((global5_Exprs_ref[0].arrAccess(param5_Array).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) && (global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(param5_Array, 1)).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0])) ? 1 : 0)) && (BOUNDS(param4_Dims, 0))) ? 1 : 0)) {
			__debugInfo = "206:\src\Expression.gbas";
			local7_tmpData_2633.attr7_IsArray_ref[0] = 0;
			__debugInfo = "206:\src\Expression.gbas";
		};
		__debugInfo = "207:\src\Expression.gbas";
		local4_Expr_2634 = func16_CreateExpression(~~(13), local7_tmpData_2633);
		__debugInfo = "208:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2634).values[tmpPositionCache][0].attr5_array = param5_Array;
		__debugInfo = "209:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2634).values[tmpPositionCache][0].attr4_dims = param4_Dims.clone(/* In Assign */);
		__debugInfo = "210:\src\Expression.gbas";
		return tryClone(local4_Expr_2634);
		__debugInfo = "211:\src\Expression.gbas";
		return 0;
		__debugInfo = "205:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateArrayExpression = window['func21_CreateArrayExpression'];
window['func24_CreateCast2IntExpression'] = function(param4_expr) {
	stackPush("function: CreateCast2IntExpression", __debugInfo);
	try {
		var local4_Expr_2636 = 0;
		__debugInfo = "216:\src\Expression.gbas";
		local4_Expr_2636 = func16_CreateExpression(~~(15), global11_intDatatype);
		__debugInfo = "217:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2636).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "218:\src\Expression.gbas";
		return tryClone(local4_Expr_2636);
		__debugInfo = "219:\src\Expression.gbas";
		return 0;
		__debugInfo = "216:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateCast2IntExpression = window['func24_CreateCast2IntExpression'];
window['func26_CreateCast2FloatExpression'] = function(param4_expr) {
	stackPush("function: CreateCast2FloatExpression", __debugInfo);
	try {
		var local4_Expr_2638 = 0;
		__debugInfo = "223:\src\Expression.gbas";
		local4_Expr_2638 = func16_CreateExpression(~~(16), global13_floatDatatype);
		__debugInfo = "224:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2638).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "225:\src\Expression.gbas";
		return tryClone(local4_Expr_2638);
		__debugInfo = "226:\src\Expression.gbas";
		return 0;
		__debugInfo = "223:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func26_CreateCast2FloatExpression = window['func26_CreateCast2FloatExpression'];
window['func27_CreateCast2StringExpression'] = function(param4_expr) {
	stackPush("function: CreateCast2StringExpression", __debugInfo);
	try {
		var local4_Expr_2640 = 0;
		__debugInfo = "230:\src\Expression.gbas";
		local4_Expr_2640 = func16_CreateExpression(~~(17), global11_strDatatype);
		__debugInfo = "231:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2640).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "232:\src\Expression.gbas";
		return tryClone(local4_Expr_2640);
		__debugInfo = "233:\src\Expression.gbas";
		return 0;
		__debugInfo = "230:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func27_CreateCast2StringExpression = window['func27_CreateCast2StringExpression'];
window['func22_CreateAccessExpression'] = function(param4_expr, param8_NextExpr) {
	stackPush("function: CreateAccessExpression", __debugInfo);
	try {
		__debugInfo = "237:\src\Expression.gbas";
		if (((((((param4_expr) == (param8_NextExpr)) ? 1 : 0)) && ((((param4_expr) == (-(1))) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "237:\src\Expression.gbas";
			func5_Error("Internal error (expr and nextexpr = -1)", 236, "src\Expression.gbas");
			__debugInfo = "237:\src\Expression.gbas";
		};
		__debugInfo = "255:\src\Expression.gbas";
		if ((((param4_expr) == (-(1))) ? 1 : 0)) {
			__debugInfo = "239:\src\Expression.gbas";
			return tryClone(param8_NextExpr);
			__debugInfo = "239:\src\Expression.gbas";
		} else if ((((param8_NextExpr) == (-(1))) ? 1 : 0)) {
			__debugInfo = "241:\src\Expression.gbas";
			return tryClone(param4_expr);
			__debugInfo = "241:\src\Expression.gbas";
		} else {
			var local9_ONextExpr_2643 = 0;
			__debugInfo = "243:\src\Expression.gbas";
			local9_ONextExpr_2643 = param8_NextExpr;
			__debugInfo = "244:\src\Expression.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(param8_NextExpr).values[tmpPositionCache][0].attr3_Typ) == (13)) ? 1 : 0)) {
				__debugInfo = "244:\src\Expression.gbas";
				param8_NextExpr = global5_Exprs_ref[0].arrAccess(param8_NextExpr).values[tmpPositionCache][0].attr5_array;
				__debugInfo = "244:\src\Expression.gbas";
			};
			__debugInfo = "254:\src\Expression.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(param8_NextExpr).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0)) {
				__debugInfo = "246:\src\Expression.gbas";
				DIMPUSH(global5_Exprs_ref[0].arrAccess(param8_NextExpr).values[tmpPositionCache][0].attr6_Params, param4_expr);
				__debugInfo = "247:\src\Expression.gbas";
				return tryClone(local9_ONextExpr_2643);
				__debugInfo = "246:\src\Expression.gbas";
			} else {
				var local4_Expr_2644 = 0;
				__debugInfo = "249:\src\Expression.gbas";
				param8_NextExpr = local9_ONextExpr_2643;
				__debugInfo = "250:\src\Expression.gbas";
				local4_Expr_2644 = func16_CreateExpression(~~(18), global5_Exprs_ref[0].arrAccess(param8_NextExpr).values[tmpPositionCache][0].attr8_datatype);
				__debugInfo = "251:\src\Expression.gbas";
				global5_Exprs_ref[0].arrAccess(local4_Expr_2644).values[tmpPositionCache][0].attr4_expr = param4_expr;
				__debugInfo = "252:\src\Expression.gbas";
				global5_Exprs_ref[0].arrAccess(local4_Expr_2644).values[tmpPositionCache][0].attr8_nextExpr = param8_NextExpr;
				__debugInfo = "253:\src\Expression.gbas";
				return tryClone(local4_Expr_2644);
				__debugInfo = "249:\src\Expression.gbas";
			};
			__debugInfo = "243:\src\Expression.gbas";
		};
		__debugInfo = "256:\src\Expression.gbas";
		return 0;
		__debugInfo = "237:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateAccessExpression = window['func22_CreateAccessExpression'];
window['func22_CreateReturnExpression'] = function(param4_expr) {
	stackPush("function: CreateReturnExpression", __debugInfo);
	try {
		var local4_Expr_2646 = 0;
		__debugInfo = "260:\src\Expression.gbas";
		local4_Expr_2646 = func16_CreateExpression(~~(19), global12_voidDatatype);
		__debugInfo = "261:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2646).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "263:\src\Expression.gbas";
		return tryClone(local4_Expr_2646);
		__debugInfo = "264:\src\Expression.gbas";
		return 0;
		__debugInfo = "260:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateReturnExpression = window['func22_CreateReturnExpression'];
window['func20_CreateGotoExpression'] = function(param8_Name_Str) {
	stackPush("function: CreateGotoExpression", __debugInfo);
	try {
		var local4_Expr_2648 = 0;
		__debugInfo = "268:\src\Expression.gbas";
		local4_Expr_2648 = func16_CreateExpression(~~(20), global12_voidDatatype);
		__debugInfo = "269:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2648).values[tmpPositionCache][0].attr8_Name_Str = param8_Name_Str;
		__debugInfo = "270:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2648).values[tmpPositionCache][0].attr3_Scp = global8_Compiler.attr12_CurrentScope;
		__debugInfo = "271:\src\Expression.gbas";
		return tryClone(local4_Expr_2648);
		__debugInfo = "272:\src\Expression.gbas";
		return 0;
		__debugInfo = "268:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func20_CreateGotoExpression = window['func20_CreateGotoExpression'];
window['func21_CreateLabelExpression'] = function(param8_Name_Str) {
	stackPush("function: CreateLabelExpression", __debugInfo);
	try {
		var local4_Expr_2650 = 0;
		__debugInfo = "276:\src\Expression.gbas";
		local4_Expr_2650 = func16_CreateExpression(~~(21), global12_voidDatatype);
		__debugInfo = "277:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2650).values[tmpPositionCache][0].attr8_Name_Str = param8_Name_Str;
		__debugInfo = "278:\src\Expression.gbas";
		return tryClone(local4_Expr_2650);
		__debugInfo = "279:\src\Expression.gbas";
		return 0;
		__debugInfo = "276:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateLabelExpression = window['func21_CreateLabelExpression'];
window['func24_CreateFuncDataExpression'] = function(param1_d) {
	stackPush("function: CreateFuncDataExpression", __debugInfo);
	try {
		__debugInfo = "283:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(22), param1_d));
		__debugInfo = "284:\src\Expression.gbas";
		return 0;
		__debugInfo = "283:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateFuncDataExpression = window['func24_CreateFuncDataExpression'];
window['func25_CreateProtoCallExpression'] = function(param4_expr, param6_Params) {
	stackPush("function: CreateProtoCallExpression", __debugInfo);
	try {
		var local4_Func_2654 = 0, local4_Expr_2655 = 0;
		__debugInfo = "288:\src\Expression.gbas";
		local4_Func_2654 = func14_SearchPrototyp(unref(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]));
		__debugInfo = "289:\src\Expression.gbas";
		if ((((local4_Func_2654) == (-(1))) ? 1 : 0)) {
			__debugInfo = "289:\src\Expression.gbas";
			func5_Error((((("Internal error (could not find prototype: ") + (global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (")")), 288, "src\Expression.gbas");
			__debugInfo = "289:\src\Expression.gbas";
		};
		__debugInfo = "290:\src\Expression.gbas";
		local4_Expr_2655 = func16_CreateExpression(~~(23), global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr8_datatype);
		__debugInfo = "291:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2655).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "292:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2655).values[tmpPositionCache][0].attr6_Params = param6_Params.clone(/* In Assign */);
		__debugInfo = "293:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2655).values[tmpPositionCache][0].attr4_func = local4_Func_2654;
		__debugInfo = "294:\src\Expression.gbas";
		return tryClone(local4_Expr_2655);
		__debugInfo = "295:\src\Expression.gbas";
		return 0;
		__debugInfo = "288:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func25_CreateProtoCallExpression = window['func25_CreateProtoCallExpression'];
window['func18_CreateIfExpression'] = function(param5_Conds, param4_Scps, param7_elseScp) {
	stackPush("function: CreateIfExpression", __debugInfo);
	try {
		var local4_Expr_2659 = 0;
		__debugInfo = "299:\src\Expression.gbas";
		local4_Expr_2659 = func16_CreateExpression(~~(24), global12_voidDatatype);
		__debugInfo = "300:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2659).values[tmpPositionCache][0].attr10_Conditions = param5_Conds.clone(/* In Assign */);
		__debugInfo = "301:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2659).values[tmpPositionCache][0].attr6_Scopes = param4_Scps.clone(/* In Assign */);
		__debugInfo = "302:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2659).values[tmpPositionCache][0].attr9_elseScope = param7_elseScp;
		__debugInfo = "303:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2659).values[tmpPositionCache][0].attr5_dummy = func21_CreateDummyExpression();
		__debugInfo = "304:\src\Expression.gbas";
		return tryClone(local4_Expr_2659);
		__debugInfo = "305:\src\Expression.gbas";
		return 0;
		__debugInfo = "299:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func18_CreateIfExpression = window['func18_CreateIfExpression'];
window['func21_CreateWhileExpression'] = function(param4_expr, param3_Scp) {
	stackPush("function: CreateWhileExpression", __debugInfo);
	try {
		var local4_Expr_2662 = 0;
		__debugInfo = "309:\src\Expression.gbas";
		local4_Expr_2662 = func16_CreateExpression(~~(25), global12_voidDatatype);
		__debugInfo = "310:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2662).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "311:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2662).values[tmpPositionCache][0].attr3_Scp = param3_Scp;
		__debugInfo = "312:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2662).values[tmpPositionCache][0].attr5_dummy = func21_CreateDummyExpression();
		__debugInfo = "313:\src\Expression.gbas";
		return tryClone(local4_Expr_2662);
		__debugInfo = "314:\src\Expression.gbas";
		return 0;
		__debugInfo = "309:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateWhileExpression = window['func21_CreateWhileExpression'];
window['func22_CreateRepeatExpression'] = function(param4_expr, param3_Scp) {
	stackPush("function: CreateRepeatExpression", __debugInfo);
	try {
		var local4_Expr_2665 = 0;
		__debugInfo = "318:\src\Expression.gbas";
		local4_Expr_2665 = func16_CreateExpression(~~(26), global12_voidDatatype);
		__debugInfo = "319:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2665).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "320:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2665).values[tmpPositionCache][0].attr3_Scp = param3_Scp;
		__debugInfo = "321:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2665).values[tmpPositionCache][0].attr5_dummy = func21_CreateDummyExpression();
		__debugInfo = "322:\src\Expression.gbas";
		return tryClone(local4_Expr_2665);
		__debugInfo = "323:\src\Expression.gbas";
		return 0;
		__debugInfo = "318:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateRepeatExpression = window['func22_CreateRepeatExpression'];
window['func19_CreateForExpression'] = function(param7_varExpr, param6_toExpr, param8_stepExpr, param5_hasTo, param3_Scp) {
	stackPush("function: CreateForExpression", __debugInfo);
	try {
		var local4_Expr_2671 = 0;
		__debugInfo = "327:\src\Expression.gbas";
		local4_Expr_2671 = func16_CreateExpression(~~(27), global12_voidDatatype);
		__debugInfo = "328:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr7_varExpr = param7_varExpr;
		__debugInfo = "329:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr6_toExpr = param6_toExpr;
		__debugInfo = "330:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr8_stepExpr = param8_stepExpr;
		__debugInfo = "331:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr3_Scp = param3_Scp;
		__debugInfo = "332:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr5_hasTo = param5_hasTo;
		__debugInfo = "333:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2671).values[tmpPositionCache][0].attr5_dummy = func21_CreateDummyExpression();
		__debugInfo = "334:\src\Expression.gbas";
		return tryClone(local4_Expr_2671);
		__debugInfo = "335:\src\Expression.gbas";
		return 0;
		__debugInfo = "327:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateForExpression = window['func19_CreateForExpression'];
window['func23_CreateForEachExpression'] = function(param7_varExpr, param6_inExpr, param3_Scp) {
	stackPush("function: CreateForEachExpression", __debugInfo);
	try {
		var local4_Expr_2675 = 0;
		__debugInfo = "339:\src\Expression.gbas";
		local4_Expr_2675 = func16_CreateExpression(~~(38), global12_voidDatatype);
		__debugInfo = "340:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2675).values[tmpPositionCache][0].attr7_varExpr = param7_varExpr;
		__debugInfo = "341:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2675).values[tmpPositionCache][0].attr6_inExpr = param6_inExpr;
		__debugInfo = "342:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2675).values[tmpPositionCache][0].attr3_Scp = param3_Scp;
		__debugInfo = "343:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2675).values[tmpPositionCache][0].attr5_dummy = func21_CreateDummyExpression();
		__debugInfo = "345:\src\Expression.gbas";
		return tryClone(local4_Expr_2675);
		__debugInfo = "346:\src\Expression.gbas";
		return 0;
		__debugInfo = "339:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_CreateForEachExpression = window['func23_CreateForEachExpression'];
window['func21_CreateBreakExpression'] = function() {
	stackPush("function: CreateBreakExpression", __debugInfo);
	try {
		__debugInfo = "350:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(29), global12_voidDatatype));
		__debugInfo = "351:\src\Expression.gbas";
		return 0;
		__debugInfo = "350:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateBreakExpression = window['func21_CreateBreakExpression'];
window['func24_CreateContinueExpression'] = function() {
	stackPush("function: CreateContinueExpression", __debugInfo);
	try {
		__debugInfo = "355:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(30), global12_voidDatatype));
		__debugInfo = "356:\src\Expression.gbas";
		return 0;
		__debugInfo = "355:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func24_CreateContinueExpression = window['func24_CreateContinueExpression'];
window['func19_CreateTryExpression'] = function(param6_tryScp, param7_ctchScp, param4_vari) {
	stackPush("function: CreateTryExpression", __debugInfo);
	try {
		var local4_Expr_2679 = 0;
		__debugInfo = "360:\src\Expression.gbas";
		local4_Expr_2679 = func16_CreateExpression(~~(31), global12_voidDatatype);
		__debugInfo = "361:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2679).values[tmpPositionCache][0].attr3_Scp = param6_tryScp;
		__debugInfo = "362:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2679).values[tmpPositionCache][0].attr8_catchScp = param7_ctchScp;
		__debugInfo = "363:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2679).values[tmpPositionCache][0].attr4_vari = param4_vari;
		__debugInfo = "365:\src\Expression.gbas";
		return tryClone(local4_Expr_2679);
		__debugInfo = "366:\src\Expression.gbas";
		return 0;
		__debugInfo = "360:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateTryExpression = window['func19_CreateTryExpression'];
window['func21_CreateThrowExpression'] = function(param5_value) {
	stackPush("function: CreateThrowExpression", __debugInfo);
	try {
		var local4_Expr_2681 = 0;
		__debugInfo = "370:\src\Expression.gbas";
		local4_Expr_2681 = func16_CreateExpression(~~(32), global12_voidDatatype);
		__debugInfo = "371:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2681).values[tmpPositionCache][0].attr4_expr = param5_value;
		__debugInfo = "372:\src\Expression.gbas";
		return tryClone(local4_Expr_2681);
		__debugInfo = "373:\src\Expression.gbas";
		return 0;
		__debugInfo = "370:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateThrowExpression = window['func21_CreateThrowExpression'];
window['func23_CreateRestoreExpression'] = function(param8_Name_Str) {
	stackPush("function: CreateRestoreExpression", __debugInfo);
	try {
		var local4_Expr_2683 = 0;
		__debugInfo = "377:\src\Expression.gbas";
		local4_Expr_2683 = func16_CreateExpression(~~(33), global12_voidDatatype);
		__debugInfo = "378:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2683).values[tmpPositionCache][0].attr8_Name_Str = param8_Name_Str;
		__debugInfo = "379:\src\Expression.gbas";
		return tryClone(local4_Expr_2683);
		__debugInfo = "380:\src\Expression.gbas";
		return 0;
		__debugInfo = "377:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_CreateRestoreExpression = window['func23_CreateRestoreExpression'];
window['func20_CreateReadExpression'] = function(param5_Reads) {
	stackPush("function: CreateReadExpression", __debugInfo);
	try {
		var local4_Expr_2685 = 0;
		__debugInfo = "384:\src\Expression.gbas";
		local4_Expr_2685 = func16_CreateExpression(~~(34), global12_voidDatatype);
		__debugInfo = "385:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2685).values[tmpPositionCache][0].attr5_Reads = param5_Reads.clone(/* In Assign */);
		__debugInfo = "386:\src\Expression.gbas";
		return tryClone(local4_Expr_2685);
		__debugInfo = "387:\src\Expression.gbas";
		return 0;
		__debugInfo = "384:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func20_CreateReadExpression = window['func20_CreateReadExpression'];
window['func28_CreateDefaultValueExpression'] = function(param8_datatype) {
	stackPush("function: CreateDefaultValueExpression", __debugInfo);
	try {
		__debugInfo = "406:\src\Expression.gbas";
		if (param8_datatype.attr7_IsArray_ref[0]) {
			__debugInfo = "392:\src\Expression.gbas";
			return tryClone(func16_CreateExpression(~~(35), param8_datatype));
			__debugInfo = "392:\src\Expression.gbas";
		} else {
			__debugInfo = "394:\src\Expression.gbas";
			{
				var local17___SelectHelper41__2687 = "";
				__debugInfo = "394:\src\Expression.gbas";
				local17___SelectHelper41__2687 = param8_datatype.attr8_Name_Str_ref[0];
				__debugInfo = "405:\src\Expression.gbas";
				if ((((local17___SelectHelper41__2687) == ("int")) ? 1 : 0)) {
					__debugInfo = "396:\src\Expression.gbas";
					return tryClone(func19_CreateIntExpression(0));
					__debugInfo = "396:\src\Expression.gbas";
				} else if ((((local17___SelectHelper41__2687) == ("float")) ? 1 : 0)) {
					__debugInfo = "398:\src\Expression.gbas";
					return tryClone(func21_CreateFloatExpression(0));
					__debugInfo = "398:\src\Expression.gbas";
				} else if ((((local17___SelectHelper41__2687) == ("string")) ? 1 : 0)) {
					__debugInfo = "400:\src\Expression.gbas";
					return tryClone(func19_CreateStrExpression("\"\""));
					__debugInfo = "400:\src\Expression.gbas";
				} else if ((((local17___SelectHelper41__2687) == ("void")) ? 1 : 0)) {
					__debugInfo = "402:\src\Expression.gbas";
					return tryClone(func19_CreateIntExpression(0));
					__debugInfo = "402:\src\Expression.gbas";
				} else {
					__debugInfo = "404:\src\Expression.gbas";
					return tryClone(func16_CreateExpression(~~(35), param8_datatype));
					__debugInfo = "404:\src\Expression.gbas";
				};
				__debugInfo = "394:\src\Expression.gbas";
			};
			__debugInfo = "394:\src\Expression.gbas";
		};
		__debugInfo = "407:\src\Expression.gbas";
		return 0;
		__debugInfo = "406:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func28_CreateDefaultValueExpression = window['func28_CreateDefaultValueExpression'];
window['func25_CreateDimAsExprExpression'] = function(param8_datatype, param4_dims) {
	stackPush("function: CreateDimAsExprExpression", __debugInfo);
	try {
		var local4_Expr_2690 = 0;
		__debugInfo = "411:\src\Expression.gbas";
		local4_Expr_2690 = func16_CreateExpression(~~(36), param8_datatype);
		__debugInfo = "412:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2690).values[tmpPositionCache][0].attr4_dims = param4_dims.clone(/* In Assign */);
		__debugInfo = "414:\src\Expression.gbas";
		return tryClone(local4_Expr_2690);
		__debugInfo = "415:\src\Expression.gbas";
		return 0;
		__debugInfo = "411:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func25_CreateDimAsExprExpression = window['func25_CreateDimAsExprExpression'];
window['func21_CreateAliasExpression'] = function(param4_vari, param4_expr) {
	stackPush("function: CreateAliasExpression", __debugInfo);
	try {
		var local4_Expr_2693 = 0;
		__debugInfo = "419:\src\Expression.gbas";
		local4_Expr_2693 = func16_CreateExpression(~~(37), global12_voidDatatype);
		__debugInfo = "420:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2693).values[tmpPositionCache][0].attr4_vari = param4_vari;
		__debugInfo = "421:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2693).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "423:\src\Expression.gbas";
		return tryClone(local4_Expr_2693);
		__debugInfo = "424:\src\Expression.gbas";
		return 0;
		__debugInfo = "419:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateAliasExpression = window['func21_CreateAliasExpression'];
window['func19_CreateIncExpression'] = function(param4_Vari, param7_AddExpr) {
	stackPush("function: CreateIncExpression", __debugInfo);
	try {
		var local4_Expr_2696 = 0;
		__debugInfo = "428:\src\Expression.gbas";
		local4_Expr_2696 = func16_CreateExpression(~~(39), global12_voidDatatype);
		__debugInfo = "429:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2696).values[tmpPositionCache][0].attr4_vari = param4_Vari;
		__debugInfo = "430:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2696).values[tmpPositionCache][0].attr4_expr = param7_AddExpr;
		__debugInfo = "431:\src\Expression.gbas";
		return tryClone(local4_Expr_2696);
		__debugInfo = "432:\src\Expression.gbas";
		return 0;
		__debugInfo = "428:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateIncExpression = window['func19_CreateIncExpression'];
window['func23_CreateDimpushExpression'] = function(param4_vari, param4_expr) {
	stackPush("function: CreateDimpushExpression", __debugInfo);
	try {
		var local4_Expr_2699 = 0;
		__debugInfo = "437:\src\Expression.gbas";
		local4_Expr_2699 = func16_CreateExpression(~~(40), global12_voidDatatype);
		__debugInfo = "438:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2699).values[tmpPositionCache][0].attr4_vari = param4_vari;
		__debugInfo = "439:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2699).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "440:\src\Expression.gbas";
		return tryClone(local4_Expr_2699);
		__debugInfo = "441:\src\Expression.gbas";
		return 0;
		__debugInfo = "437:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_CreateDimpushExpression = window['func23_CreateDimpushExpression'];
window['func19_CreateLenExpression'] = function(param4_expr, param4_kern) {
	stackPush("function: CreateLenExpression", __debugInfo);
	try {
		var local4_Expr_2702 = 0;
		__debugInfo = "445:\src\Expression.gbas";
		local4_Expr_2702 = func16_CreateExpression(~~(41), global11_intDatatype);
		__debugInfo = "446:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2702).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "447:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2702).values[tmpPositionCache][0].attr4_kern = param4_kern;
		__debugInfo = "448:\src\Expression.gbas";
		return tryClone(local4_Expr_2702);
		__debugInfo = "449:\src\Expression.gbas";
		return 0;
		__debugInfo = "445:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateLenExpression = window['func19_CreateLenExpression'];
window['func23_CreateDimDataExpression'] = function(param5_array, param5_exprs) {
	stackPush("function: CreateDimDataExpression", __debugInfo);
	try {
		var local4_Expr_2705 = 0;
		__debugInfo = "453:\src\Expression.gbas";
		local4_Expr_2705 = func16_CreateExpression(~~(42), global12_voidDatatype);
		__debugInfo = "454:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2705).values[tmpPositionCache][0].attr5_array = param5_array;
		__debugInfo = "455:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2705).values[tmpPositionCache][0].attr5_Exprs = param5_exprs.clone(/* In Assign */);
		__debugInfo = "456:\src\Expression.gbas";
		return tryClone(local4_Expr_2705);
		__debugInfo = "457:\src\Expression.gbas";
		return 0;
		__debugInfo = "453:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_CreateDimDataExpression = window['func23_CreateDimDataExpression'];
window['func22_CreateDeleteExpression'] = function() {
	stackPush("function: CreateDeleteExpression", __debugInfo);
	try {
		__debugInfo = "461:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(43), global12_voidDatatype));
		__debugInfo = "462:\src\Expression.gbas";
		return 0;
		__debugInfo = "461:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateDeleteExpression = window['func22_CreateDeleteExpression'];
window['func22_CreateDimDelExpression'] = function(param5_array, param8_position) {
	stackPush("function: CreateDimDelExpression", __debugInfo);
	try {
		var local4_Expr_2708 = 0;
		__debugInfo = "466:\src\Expression.gbas";
		local4_Expr_2708 = func16_CreateExpression(~~(44), global12_voidDatatype);
		__debugInfo = "467:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2708).values[tmpPositionCache][0].attr5_array = param5_array;
		__debugInfo = "468:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2708).values[tmpPositionCache][0].attr8_position = param8_position;
		__debugInfo = "469:\src\Expression.gbas";
		return tryClone(local4_Expr_2708);
		__debugInfo = "470:\src\Expression.gbas";
		return 0;
		__debugInfo = "466:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateDimDelExpression = window['func22_CreateDimDelExpression'];
window['func21_CreateBoundExpression'] = function(param4_expr, param8_position) {
	stackPush("function: CreateBoundExpression", __debugInfo);
	try {
		var local4_Expr_2711 = 0;
		__debugInfo = "474:\src\Expression.gbas";
		local4_Expr_2711 = func16_CreateExpression(~~(45), global11_intDatatype);
		__debugInfo = "475:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2711).values[tmpPositionCache][0].attr5_array = param4_expr;
		__debugInfo = "476:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2711).values[tmpPositionCache][0].attr8_position = param8_position;
		__debugInfo = "477:\src\Expression.gbas";
		return tryClone(local4_Expr_2711);
		__debugInfo = "478:\src\Expression.gbas";
		return 0;
		__debugInfo = "474:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateBoundExpression = window['func21_CreateBoundExpression'];
window['func19_CreateNotExpression'] = function(param4_expr) {
	stackPush("function: CreateNotExpression", __debugInfo);
	try {
		var local4_Expr_2713 = 0;
		__debugInfo = "482:\src\Expression.gbas";
		local4_Expr_2713 = func16_CreateExpression(~~(46), global13_floatDatatype);
		__debugInfo = "483:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2713).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "484:\src\Expression.gbas";
		return tryClone(local4_Expr_2713);
		__debugInfo = "485:\src\Expression.gbas";
		return 0;
		__debugInfo = "482:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateNotExpression = window['func19_CreateNotExpression'];
window['func21_CreateDummyExpression'] = function() {
	stackPush("function: CreateDummyExpression", __debugInfo);
	try {
		__debugInfo = "490:\src\Expression.gbas";
		return 0;
		__debugInfo = "491:\src\Expression.gbas";
		return 0;
		__debugInfo = "490:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateDummyExpression = window['func21_CreateDummyExpression'];
window['func25_CreateAddressOfExpression'] = function(param4_func) {
	stackPush("function: CreateAddressOfExpression", __debugInfo);
	try {
		var local4_Expr_2715 = 0;
		__debugInfo = "495:\src\Expression.gbas";
		local4_Expr_2715 = func16_CreateExpression(~~(48), global11_intDatatype);
		__debugInfo = "496:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2715).values[tmpPositionCache][0].attr4_func = param4_func;
		__debugInfo = "497:\src\Expression.gbas";
		return tryClone(local4_Expr_2715);
		__debugInfo = "498:\src\Expression.gbas";
		return 0;
		__debugInfo = "495:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func25_CreateAddressOfExpression = window['func25_CreateAddressOfExpression'];
window['func22_CreateAssertExpression'] = function(param4_expr) {
	stackPush("function: CreateAssertExpression", __debugInfo);
	try {
		var local4_Expr_2717 = 0;
		__debugInfo = "503:\src\Expression.gbas";
		local4_Expr_2717 = func16_CreateExpression(~~(49), global12_voidDatatype);
		__debugInfo = "504:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2717).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "505:\src\Expression.gbas";
		return tryClone(local4_Expr_2717);
		__debugInfo = "506:\src\Expression.gbas";
		return 0;
		__debugInfo = "503:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func22_CreateAssertExpression = window['func22_CreateAssertExpression'];
window['func27_CreateDebugOutputExpression'] = function(param4_expr) {
	stackPush("function: CreateDebugOutputExpression", __debugInfo);
	try {
		var local4_Expr_2719 = 0;
		__debugInfo = "511:\src\Expression.gbas";
		local4_Expr_2719 = func16_CreateExpression(~~(50), global12_voidDatatype);
		__debugInfo = "512:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2719).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "513:\src\Expression.gbas";
		return tryClone(local4_Expr_2719);
		__debugInfo = "514:\src\Expression.gbas";
		return 0;
		__debugInfo = "511:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func27_CreateDebugOutputExpression = window['func27_CreateDebugOutputExpression'];
window['func19_CreateIIFExpression'] = function(param4_Cond, param6_onTrue, param7_onFalse) {
	stackPush("function: CreateIIFExpression", __debugInfo);
	try {
		var local4_Expr_2723 = 0;
		__debugInfo = "518:\src\Expression.gbas";
		local4_Expr_2723 = func16_CreateExpression(~~(51), global5_Exprs_ref[0].arrAccess(param6_onTrue).values[tmpPositionCache][0].attr8_datatype);
		__debugInfo = "519:\src\Expression.gbas";
		DIMDATA(global5_Exprs_ref[0].arrAccess(local4_Expr_2723).values[tmpPositionCache][0].attr10_Conditions, [param4_Cond]);
		__debugInfo = "520:\src\Expression.gbas";
		DIMDATA(global5_Exprs_ref[0].arrAccess(local4_Expr_2723).values[tmpPositionCache][0].attr6_Scopes, [param6_onTrue]);
		__debugInfo = "521:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2723).values[tmpPositionCache][0].attr9_elseScope = param7_onFalse;
		__debugInfo = "523:\src\Expression.gbas";
		return tryClone(local4_Expr_2723);
		__debugInfo = "524:\src\Expression.gbas";
		return 0;
		__debugInfo = "518:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_CreateIIFExpression = window['func19_CreateIIFExpression'];
window['func23_CreateRequireExpression'] = function(param8_Path_Str) {
	stackPush("function: CreateRequireExpression", __debugInfo);
	try {
		var local4_Expr_2725 = 0;
		__debugInfo = "527:\src\Expression.gbas";
		local4_Expr_2725 = func16_CreateExpression(~~(52), global12_voidDatatype);
		__debugInfo = "535:\src\Expression.gbas";
		if ((((REVINSTR(param8_Path_Str, ".", -(1))) != (-(1))) ? 1 : 0)) {
			__debugInfo = "530:\src\Expression.gbas";
			{
				var local17___SelectHelper42__2726 = "";
				__debugInfo = "530:\src\Expression.gbas";
				local17___SelectHelper42__2726 = MID_Str(param8_Path_Str, ((REVINSTR(param8_Path_Str, ".", -(1))) + (1)), -(1));
				__debugInfo = "534:\src\Expression.gbas";
				if ((((local17___SelectHelper42__2726) == ("js")) ? 1 : 0)) {
					
				} else {
					__debugInfo = "533:\src\Expression.gbas";
					func5_Error("Cannot not REQUIRE non javascript files...", 532, "src\Expression.gbas");
					__debugInfo = "533:\src\Expression.gbas";
				};
				__debugInfo = "530:\src\Expression.gbas";
			};
			__debugInfo = "530:\src\Expression.gbas";
		};
		__debugInfo = "536:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2725).values[tmpPositionCache][0].attr8_Name_Str = param8_Path_Str;
		__debugInfo = "537:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2725).values[tmpPositionCache][0].attr11_Content_Str = func12_LoadFile_Str(param8_Path_Str);
		__debugInfo = "539:\src\Expression.gbas";
		return tryClone(local4_Expr_2725);
		__debugInfo = "540:\src\Expression.gbas";
		return 0;
		__debugInfo = "527:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_CreateRequireExpression = window['func23_CreateRequireExpression'];
window['func21_CreateSuperExpression'] = function(param3_typ) {
	stackPush("function: CreateSuperExpression", __debugInfo);
	try {
		var local1_d_2728 = new type8_Datatype();
		__debugInfo = "545:\src\Expression.gbas";
		local1_d_2728.attr7_IsArray_ref[0] = 0;
		__debugInfo = "546:\src\Expression.gbas";
		local1_d_2728.attr8_Name_Str_ref[0] = global8_Compiler.attr5_Types_ref[0].arrAccess(param3_typ).values[tmpPositionCache][0].attr8_Name_Str;
		__debugInfo = "547:\src\Expression.gbas";
		return tryClone(func16_CreateExpression(~~(53), local1_d_2728));
		__debugInfo = "548:\src\Expression.gbas";
		return 0;
		__debugInfo = "545:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_CreateSuperExpression = window['func21_CreateSuperExpression'];
window['func14_CreateCast2Obj'] = function(param7_Obj_Str, param4_expr) {
	stackPush("function: CreateCast2Obj", __debugInfo);
	try {
		var local1_d_2731 = new type8_Datatype(), local4_Expr_2732 = 0;
		__debugInfo = "553:\src\Expression.gbas";
		local1_d_2731.attr7_IsArray_ref[0] = 0;
		__debugInfo = "554:\src\Expression.gbas";
		local1_d_2731.attr8_Name_Str_ref[0] = param7_Obj_Str;
		__debugInfo = "555:\src\Expression.gbas";
		local4_Expr_2732 = func16_CreateExpression(~~(54), local1_d_2731);
		__debugInfo = "556:\src\Expression.gbas";
		global5_Exprs_ref[0].arrAccess(local4_Expr_2732).values[tmpPositionCache][0].attr4_expr = param4_expr;
		__debugInfo = "558:\src\Expression.gbas";
		return tryClone(local4_Expr_2732);
		__debugInfo = "559:\src\Expression.gbas";
		return 0;
		__debugInfo = "553:\src\Expression.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_CreateCast2Obj = window['func14_CreateCast2Obj'];
window['method13_type7_HashMap_3_Put'] = function(param7_Key_Str, param5_Value, param4_self) {
	stackPush("method: Put", __debugInfo);
	try {
		var local2_KV_1907 = new type8_KeyValue(), local4_hash_1908 = 0, alias6_Bucket_ref_1909 = [new type6_Bucket()];
		__debugInfo = "28:\src\Utils\Hashmap.gbas";
		if ((((param7_Key_Str) == ("")) ? 1 : 0)) {
			__debugInfo = "28:\src\Utils\Hashmap.gbas";
			func5_Error("Cannot insert empty key you son of a bitch.", 19, "Hashmap.gbas");
			__debugInfo = "28:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "31:\src\Utils\Hashmap.gbas";
		if ((((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) == (0)) ? 1 : 0)) {
			__debugInfo = "30:\src\Utils\Hashmap.gbas";
			(param4_self).SetSize(4096);
			__debugInfo = "30:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "34:\src\Utils\Hashmap.gbas";
		if ((((param4_self).DoesKeyExist(param7_Key_Str)) ? 0 : 1)) {
			__debugInfo = "33:\src\Utils\Hashmap.gbas";
			param4_self.attr8_Elements+=1;
			__debugInfo = "33:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "37:\src\Utils\Hashmap.gbas";
		if ((((param4_self.attr8_Elements) > (((CAST2INT(((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) / (3)))) * (2)))) ? 1 : 0)) {
			__debugInfo = "36:\src\Utils\Hashmap.gbas";
			(param4_self).SetSize(((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) * (4)));
			__debugInfo = "36:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "40:\src\Utils\Hashmap.gbas";
		local2_KV_1907.attr7_Key_Str = param7_Key_Str;
		__debugInfo = "41:\src\Utils\Hashmap.gbas";
		local2_KV_1907.attr5_Value = param5_Value;
		__debugInfo = "43:\src\Utils\Hashmap.gbas";
		local4_hash_1908 = func7_HashStr(param7_Key_Str, ((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) - (1)));
		__debugInfo = "44:\src\Utils\Hashmap.gbas";
		alias6_Bucket_ref_1909 = param4_self.attr7_Buckets_ref[0].arrAccess(local4_hash_1908).values[tmpPositionCache] /* ALIAS */;
		__debugInfo = "55:\src\Utils\Hashmap.gbas";
		if (alias6_Bucket_ref_1909[0].attr3_Set) {
			__debugInfo = "49:\src\Utils\Hashmap.gbas";
			if ((((BOUNDS(alias6_Bucket_ref_1909[0].attr8_Elements, 0)) == (0)) ? 1 : 0)) {
				__debugInfo = "48:\src\Utils\Hashmap.gbas";
				DIMPUSH(alias6_Bucket_ref_1909[0].attr8_Elements, alias6_Bucket_ref_1909[0].attr7_Element);
				__debugInfo = "48:\src\Utils\Hashmap.gbas";
			};
			__debugInfo = "51:\src\Utils\Hashmap.gbas";
			DIMPUSH(alias6_Bucket_ref_1909[0].attr8_Elements, local2_KV_1907);
			__debugInfo = "49:\src\Utils\Hashmap.gbas";
		} else {
			__debugInfo = "53:\src\Utils\Hashmap.gbas";
			alias6_Bucket_ref_1909[0].attr3_Set = 1;
			__debugInfo = "54:\src\Utils\Hashmap.gbas";
			alias6_Bucket_ref_1909[0].attr7_Element = local2_KV_1907.clone(/* In Assign */);
			__debugInfo = "53:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "56:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "28:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_3_Put = window['method13_type7_HashMap_3_Put'];
window['method13_type7_HashMap_12_DoesKeyExist'] = function(param7_Key_Str, param4_self) {
	stackPush("method: DoesKeyExist", __debugInfo);
	try {
		var local5_Value_ref_1913 = [0];
		__debugInfo = "61:\src\Utils\Hashmap.gbas";
		return tryClone((param4_self).GetValue(param7_Key_Str, local5_Value_ref_1913));
		__debugInfo = "62:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "61:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_12_DoesKeyExist = window['method13_type7_HashMap_12_DoesKeyExist'];
window['method13_type7_HashMap_8_GetValue'] = function(param7_Key_Str, param5_Value_ref, param4_self) {
	stackPush("method: GetValue", __debugInfo);
	try {
		var local4_hash_1918 = 0, alias6_Bucket_ref_1919 = [new type6_Bucket()];
		__debugInfo = "66:\src\Utils\Hashmap.gbas";
		local4_hash_1918 = func7_HashStr(param7_Key_Str, ((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) - (1)));
		__debugInfo = "67:\src\Utils\Hashmap.gbas";
		if ((((local4_hash_1918) >= (BOUNDS(param4_self.attr7_Buckets_ref[0], 0))) ? 1 : 0)) {
			__debugInfo = "67:\src\Utils\Hashmap.gbas";
			return tryClone(0);
			__debugInfo = "67:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "68:\src\Utils\Hashmap.gbas";
		alias6_Bucket_ref_1919 = param4_self.attr7_Buckets_ref[0].arrAccess(local4_hash_1918).values[tmpPositionCache] /* ALIAS */;
		__debugInfo = "90:\src\Utils\Hashmap.gbas";
		if (alias6_Bucket_ref_1919[0].attr3_Set) {
			__debugInfo = "87:\src\Utils\Hashmap.gbas";
			if ((((BOUNDS(alias6_Bucket_ref_1919[0].attr8_Elements, 0)) == (0)) ? 1 : 0)) {
				__debugInfo = "77:\src\Utils\Hashmap.gbas";
				if ((((alias6_Bucket_ref_1919[0].attr7_Element.attr7_Key_Str) != (param7_Key_Str)) ? 1 : 0)) {
					__debugInfo = "72:\src\Utils\Hashmap.gbas";
					param5_Value_ref[0] = 0;
					__debugInfo = "73:\src\Utils\Hashmap.gbas";
					return tryClone(0);
					__debugInfo = "72:\src\Utils\Hashmap.gbas";
				} else {
					__debugInfo = "75:\src\Utils\Hashmap.gbas";
					param5_Value_ref[0] = alias6_Bucket_ref_1919[0].attr7_Element.attr5_Value;
					__debugInfo = "76:\src\Utils\Hashmap.gbas";
					return 1;
					__debugInfo = "75:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "77:\src\Utils\Hashmap.gbas";
			} else {
				__debugInfo = "78:\src\Utils\Hashmap.gbas";
				{
					var local1_i_1920 = 0.0;
					__debugInfo = "85:\src\Utils\Hashmap.gbas";
					for (local1_i_1920 = 0;toCheck(local1_i_1920, ((BOUNDS(alias6_Bucket_ref_1919[0].attr8_Elements, 0)) - (1)), 1);local1_i_1920 += 1) {
						__debugInfo = "84:\src\Utils\Hashmap.gbas";
						if ((((alias6_Bucket_ref_1919[0].attr8_Elements.arrAccess(~~(local1_i_1920)).values[tmpPositionCache].attr7_Key_Str) == (param7_Key_Str)) ? 1 : 0)) {
							__debugInfo = "82:\src\Utils\Hashmap.gbas";
							param5_Value_ref[0] = alias6_Bucket_ref_1919[0].attr8_Elements.arrAccess(~~(local1_i_1920)).values[tmpPositionCache].attr5_Value;
							__debugInfo = "83:\src\Utils\Hashmap.gbas";
							return 1;
							__debugInfo = "82:\src\Utils\Hashmap.gbas";
						};
						__debugInfo = "84:\src\Utils\Hashmap.gbas";
					};
					__debugInfo = "85:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "86:\src\Utils\Hashmap.gbas";
				return tryClone(0);
				__debugInfo = "78:\src\Utils\Hashmap.gbas";
			};
			__debugInfo = "87:\src\Utils\Hashmap.gbas";
		} else {
			__debugInfo = "89:\src\Utils\Hashmap.gbas";
			return tryClone(0);
			__debugInfo = "89:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "91:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "66:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_8_GetValue = window['method13_type7_HashMap_8_GetValue'];
window['method13_type7_HashMap_6_Remove'] = function(param7_Key_Str, param4_self) {
	stackPush("method: Remove", __debugInfo);
	try {
		var local4_hash_1924 = 0, alias6_Bucket_ref_1925 = [new type6_Bucket()];
		__debugInfo = "95:\src\Utils\Hashmap.gbas";
		local4_hash_1924 = func7_HashStr(param7_Key_Str, ((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) - (1)));
		__debugInfo = "96:\src\Utils\Hashmap.gbas";
		alias6_Bucket_ref_1925 = param4_self.attr7_Buckets_ref[0].arrAccess(local4_hash_1924).values[tmpPositionCache] /* ALIAS */;
		__debugInfo = "124:\src\Utils\Hashmap.gbas";
		if (alias6_Bucket_ref_1925[0].attr3_Set) {
			__debugInfo = "121:\src\Utils\Hashmap.gbas";
			if ((((alias6_Bucket_ref_1925[0].attr7_Element.attr7_Key_Str) == (param7_Key_Str)) ? 1 : 0)) {
				var local1_e_1926 = new type8_KeyValue();
				__debugInfo = "100:\src\Utils\Hashmap.gbas";
				param4_self.attr8_Elements+=-1;
				__debugInfo = "102:\src\Utils\Hashmap.gbas";
				alias6_Bucket_ref_1925[0].attr7_Element = local1_e_1926.clone(/* In Assign */);
				__debugInfo = "103:\src\Utils\Hashmap.gbas";
				alias6_Bucket_ref_1925[0].attr3_Set = 0;
				__debugInfo = "100:\src\Utils\Hashmap.gbas";
			} else {
				var local4_Find_1927 = 0;
				__debugInfo = "105:\src\Utils\Hashmap.gbas";
				local4_Find_1927 = 0;
				__debugInfo = "105:\src\Utils\Hashmap.gbas";
				{
					var local1_i_1928 = 0.0;
					__debugInfo = "112:\src\Utils\Hashmap.gbas";
					for (local1_i_1928 = 0;toCheck(local1_i_1928, ((BOUNDS(alias6_Bucket_ref_1925[0].attr8_Elements, 0)) - (1)), 1);local1_i_1928 += 1) {
						__debugInfo = "111:\src\Utils\Hashmap.gbas";
						if ((((alias6_Bucket_ref_1925[0].attr8_Elements.arrAccess(~~(local1_i_1928)).values[tmpPositionCache].attr7_Key_Str) == (param7_Key_Str)) ? 1 : 0)) {
							__debugInfo = "108:\src\Utils\Hashmap.gbas";
							local4_Find_1927 = 1;
							__debugInfo = "109:\src\Utils\Hashmap.gbas";
							DIMDEL(alias6_Bucket_ref_1925[0].attr8_Elements, ~~(local1_i_1928));
							__debugInfo = "110:\src\Utils\Hashmap.gbas";
							break;
							__debugInfo = "108:\src\Utils\Hashmap.gbas";
						};
						__debugInfo = "111:\src\Utils\Hashmap.gbas";
					};
					__debugInfo = "112:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "116:\src\Utils\Hashmap.gbas";
				if ((((BOUNDS(alias6_Bucket_ref_1925[0].attr8_Elements, 0)) == (1)) ? 1 : 0)) {
					__debugInfo = "114:\src\Utils\Hashmap.gbas";
					alias6_Bucket_ref_1925[0].attr7_Element = alias6_Bucket_ref_1925[0].attr8_Elements.arrAccess(0).values[tmpPositionCache].clone(/* In Assign */);
					__debugInfo = "115:\src\Utils\Hashmap.gbas";
					DIMDEL(alias6_Bucket_ref_1925[0].attr8_Elements, 0);
					__debugInfo = "114:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "118:\src\Utils\Hashmap.gbas";
				if (local4_Find_1927) {
					__debugInfo = "118:\src\Utils\Hashmap.gbas";
					param4_self.attr8_Elements+=-1;
					__debugInfo = "118:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "120:\src\Utils\Hashmap.gbas";
				return tryClone(local4_Find_1927);
				__debugInfo = "105:\src\Utils\Hashmap.gbas";
			};
			__debugInfo = "121:\src\Utils\Hashmap.gbas";
		} else {
			__debugInfo = "123:\src\Utils\Hashmap.gbas";
			return tryClone(0);
			__debugInfo = "123:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "125:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "95:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_6_Remove = window['method13_type7_HashMap_6_Remove'];
window['method13_type7_HashMap_7_ToArray'] = function(param5_Array, param4_self) {
	stackPush("method: ToArray", __debugInfo);
	try {
		__debugInfo = "130:\src\Utils\Hashmap.gbas";
		DIM(param5_Array, [0], new type8_KeyValue());
		__debugInfo = "130:\src\Utils\Hashmap.gbas";
		{
			var local1_i_1932 = 0.0;
			__debugInfo = "142:\src\Utils\Hashmap.gbas";
			for (local1_i_1932 = 0;toCheck(local1_i_1932, ((BOUNDS(param4_self.attr7_Buckets_ref[0], 0)) - (1)), 1);local1_i_1932 += 1) {
				var alias1_B_ref_1933 = [new type6_Bucket()];
				__debugInfo = "132:\src\Utils\Hashmap.gbas";
				alias1_B_ref_1933 = param4_self.attr7_Buckets_ref[0].arrAccess(~~(local1_i_1932)).values[tmpPositionCache] /* ALIAS */;
				__debugInfo = "141:\src\Utils\Hashmap.gbas";
				if (alias1_B_ref_1933[0].attr3_Set) {
					__debugInfo = "140:\src\Utils\Hashmap.gbas";
					if (BOUNDS(alias1_B_ref_1933[0].attr8_Elements, 0)) {
						__debugInfo = "134:\src\Utils\Hashmap.gbas";
						{
							var local1_j_1934 = 0.0;
							__debugInfo = "137:\src\Utils\Hashmap.gbas";
							for (local1_j_1934 = 0;toCheck(local1_j_1934, ((BOUNDS(alias1_B_ref_1933[0].attr8_Elements, 0)) - (1)), 1);local1_j_1934 += 1) {
								__debugInfo = "136:\src\Utils\Hashmap.gbas";
								DIMPUSH(param5_Array, alias1_B_ref_1933[0].attr8_Elements.arrAccess(~~(local1_j_1934)).values[tmpPositionCache]);
								__debugInfo = "136:\src\Utils\Hashmap.gbas";
							};
							__debugInfo = "137:\src\Utils\Hashmap.gbas";
						};
						__debugInfo = "134:\src\Utils\Hashmap.gbas";
					} else {
						__debugInfo = "139:\src\Utils\Hashmap.gbas";
						DIMPUSH(param5_Array, alias1_B_ref_1933[0].attr7_Element);
						__debugInfo = "139:\src\Utils\Hashmap.gbas";
					};
					__debugInfo = "140:\src\Utils\Hashmap.gbas";
				};
				__debugInfo = "132:\src\Utils\Hashmap.gbas";
			};
			__debugInfo = "142:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "143:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "130:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_7_ToArray = window['method13_type7_HashMap_7_ToArray'];
window['method13_type7_HashMap_7_SetSize'] = function(param4_Size, param4_self) {
	stackPush("method: SetSize", __debugInfo);
	try {
		var local3_Arr_1938 = new OTTArray(new type8_KeyValue());
		__debugInfo = "148:\src\Utils\Hashmap.gbas";
		(param4_self).ToArray(unref(local3_Arr_1938));
		__debugInfo = "149:\src\Utils\Hashmap.gbas";
		param4_self.attr8_Elements = 0;
		__debugInfo = "150:\src\Utils\Hashmap.gbas";
		REDIM(unref(param4_self.attr7_Buckets_ref[0]), [param4_Size], [new type6_Bucket()] );
		__debugInfo = "153:\src\Utils\Hashmap.gbas";
		var forEachSaver5342 = local3_Arr_1938;
		for(var forEachCounter5342 = 0 ; forEachCounter5342 < forEachSaver5342.values.length ; forEachCounter5342++) {
			var local1_E_1939 = forEachSaver5342.values[forEachCounter5342];
		{
				__debugInfo = "152:\src\Utils\Hashmap.gbas";
				(param4_self).Put(local1_E_1939.attr7_Key_Str, local1_E_1939.attr5_Value);
				__debugInfo = "152:\src\Utils\Hashmap.gbas";
			}
			forEachSaver5342.values[forEachCounter5342] = local1_E_1939;
		
		};
		__debugInfo = "154:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "148:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_HashMap_7_SetSize = window['method13_type7_HashMap_7_SetSize'];
window['func7_HashStr'] = function(param7_Str_Str, param6_MaxLen) {
	stackPush("function: HashStr", __debugInfo);
	try {
		var local4_Hash_1942 = 0;
		__debugInfo = "161:\src\Utils\Hashmap.gbas";
		{
			var local1_i_1943 = 0.0;
			__debugInfo = "164:\src\Utils\Hashmap.gbas";
			for (local1_i_1943 = 0;toCheck(local1_i_1943, (((param7_Str_Str).length) - (1)), 1);local1_i_1943 += 1) {
				__debugInfo = "163:\src\Utils\Hashmap.gbas";
				local4_Hash_1942+=~~(((ASC(param7_Str_Str, ~~(local1_i_1943))) + (((local1_i_1943) * (26)))));
				__debugInfo = "163:\src\Utils\Hashmap.gbas";
			};
			__debugInfo = "164:\src\Utils\Hashmap.gbas";
		};
		__debugInfo = "165:\src\Utils\Hashmap.gbas";
		local4_Hash_1942 = MOD(local4_Hash_1942, param6_MaxLen);
		__debugInfo = "166:\src\Utils\Hashmap.gbas";
		return tryClone(local4_Hash_1942);
		__debugInfo = "167:\src\Utils\Hashmap.gbas";
		return 0;
		__debugInfo = "161:\src\Utils\Hashmap.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_HashStr = window['func7_HashStr'];
window['func16_JS_Generator_Str'] = function() {
	stackPush("function: JS_Generator_Str", __debugInfo);
	try {
		__debugInfo = "261:\src\CompilerPasses\Generator\JSGenerator.gbas";
		{
			var Err_Str = "";
			__debugInfo = "262:\src\CompilerPasses\Generator\JSGenerator.gbas";
			try {
				var local11_InWebWorker_1944 = 0, local8_Text_Str_1945 = "", local14_StaticText_Str_1946 = "", local17_StaticDefText_Str_1947 = "";
				__debugInfo = "28:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local11_InWebWorker_1944 = func8_IsDefine("HTML5_WEBWORKER");
				__debugInfo = "30:\src\CompilerPasses\Generator\JSGenerator.gbas";
				func23_ManageFuncParamOverlaps();
				__debugInfo = "32:\src\CompilerPasses\Generator\JSGenerator.gbas";
				global14_StaticText_Str = "";
				__debugInfo = "34:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1945 = "";
				__debugInfo = "41:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if (global9_DEBUGMODE) {
					__debugInfo = "37:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("var __debugInfo = \"\";"))) + (func11_NewLine_Str()));
					__debugInfo = "38:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("var debugMode = true;"))) + (func11_NewLine_Str()));
					__debugInfo = "37:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else {
					__debugInfo = "40:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("var debugMode = false;"))) + (func11_NewLine_Str()));
					__debugInfo = "40:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "44:\src\CompilerPasses\Generator\JSGenerator.gbas";
				global11_LastDummyID = ~~(((global10_LastExprID) + (1337)));
				__debugInfo = "46:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("window['main'] = function()"));
				__debugInfo = "47:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr9_MainScope).values[tmpPositionCache][0]))))) + (func11_NewLine_Str()));
				__debugInfo = "48:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if (local11_InWebWorker_1944) {
					__debugInfo = "48:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("main = window['main'];"))) + (func11_NewLine_Str()));
					__debugInfo = "48:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "49:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local14_StaticText_Str_1946 = "";
				__debugInfo = "50:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local17_StaticDefText_Str_1947 = "";
				__debugInfo = "77:\src\CompilerPasses\Generator\JSGenerator.gbas";
				var forEachSaver5647 = global8_Compiler.attr5_Funcs_ref[0];
				for(var forEachCounter5647 = 0 ; forEachCounter5647 < forEachSaver5647.values.length ; forEachCounter5647++) {
					var local4_Func_ref_1948 = forEachSaver5647.values[forEachCounter5647];
				{
						__debugInfo = "76:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (((((((local4_Func_ref_1948[0].attr6_Native) == (0)) ? 1 : 0)) && ((((local4_Func_ref_1948[0].attr3_Scp) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
							var local4_Find_1949 = 0.0;
							__debugInfo = "57:\src\CompilerPasses\Generator\JSGenerator.gbas";
							if ((((BOUNDS(local4_Func_ref_1948[0].attr7_Statics, 0)) > (0)) ? 1 : 0)) {
								__debugInfo = "55:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local17_StaticDefText_Str_1947 = ((((((((local17_StaticDefText_Str_1947) + ("var "))) + (func13_JSVariDef_Str(unref(local4_Func_ref_1948[0].attr7_Statics), 1, 0)))) + (";"))) + (func11_NewLine_Str()));
								__debugInfo = "56:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local14_StaticText_Str_1946 = ((((((local14_StaticText_Str_1946) + (func13_JSVariDef_Str(unref(local4_Func_ref_1948[0].attr7_Statics), 0, 0)))) + (";"))) + (func11_NewLine_Str()));
								__debugInfo = "55:\src\CompilerPasses\Generator\JSGenerator.gbas";
							};
							__debugInfo = "60:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + ("window['"))) + (local4_Func_ref_1948[0].attr8_Name_Str))) + ("'] = function("));
							__debugInfo = "61:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local4_Find_1949 = 0;
							__debugInfo = "67:\src\CompilerPasses\Generator\JSGenerator.gbas";
							var forEachSaver5573 = local4_Func_ref_1948[0].attr6_Params;
							for(var forEachCounter5573 = 0 ; forEachCounter5573 < forEachSaver5573.values.length ; forEachCounter5573++) {
								var local1_P_1950 = forEachSaver5573.values[forEachCounter5573];
							{
									__debugInfo = "63:\src\CompilerPasses\Generator\JSGenerator.gbas";
									if (local4_Find_1949) {
										__debugInfo = "63:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((local8_Text_Str_1945) + (", "));
										__debugInfo = "63:\src\CompilerPasses\Generator\JSGenerator.gbas";
									};
									__debugInfo = "64:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1950).values[tmpPositionCache][0].attr8_Name_Str));
									__debugInfo = "66:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local4_Find_1949 = 1;
									__debugInfo = "63:\src\CompilerPasses\Generator\JSGenerator.gbas";
								}
								forEachSaver5573.values[forEachCounter5573] = local1_P_1950;
							
							};
							__debugInfo = "68:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((local8_Text_Str_1945) + (") "));
							__debugInfo = "69:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local4_Func_ref_1948[0].attr3_Scp).values[tmpPositionCache][0]))))) + (";"))) + (func11_NewLine_Str()));
							__debugInfo = "73:\src\CompilerPasses\Generator\JSGenerator.gbas";
							if (((((((global9_DEBUGMODE) == (0)) ? 1 : 0)) && ((((local4_Func_ref_1948[0].attr3_Typ) == (2)) ? 1 : 0))) ? 1 : 0)) {
								__debugInfo = "72:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((((((((((local8_Text_Str_1945) + ("window['"))) + (local4_Func_ref_1948[0].attr8_Name_Str))) + ("'] = "))) + (local4_Func_ref_1948[0].attr8_Name_Str))) + (";"))) + (func11_NewLine_Str()));
								__debugInfo = "72:\src\CompilerPasses\Generator\JSGenerator.gbas";
							};
							__debugInfo = "75:\src\CompilerPasses\Generator\JSGenerator.gbas";
							if (local11_InWebWorker_1944) {
								__debugInfo = "75:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((((((((local8_Text_Str_1945) + (local4_Func_ref_1948[0].attr8_Name_Str))) + (" = window['"))) + (local4_Func_ref_1948[0].attr8_Name_Str))) + ("'];"))) + (func11_NewLine_Str()));
								__debugInfo = "75:\src\CompilerPasses\Generator\JSGenerator.gbas";
							};
							__debugInfo = "57:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "76:\src\CompilerPasses\Generator\JSGenerator.gbas";
					}
					forEachSaver5647.values[forEachCounter5647] = local4_Func_ref_1948;
				
				};
				__debugInfo = "89:\src\CompilerPasses\Generator\JSGenerator.gbas";
				var forEachSaver5713 = global8_Compiler.attr5_Funcs_ref[0];
				for(var forEachCounter5713 = 0 ; forEachCounter5713 < forEachSaver5713.values.length ; forEachCounter5713++) {
					var local4_Func_ref_1951 = forEachSaver5713.values[forEachCounter5713];
				{
						__debugInfo = "88:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if ((((local4_Func_ref_1951[0].attr3_Typ) == (4)) ? 1 : 0)) {
							__debugInfo = "82:\src\CompilerPasses\Generator\JSGenerator.gbas";
							func8_IndentUp();
							__debugInfo = "83:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("window['"))) + (local4_Func_ref_1951[0].attr9_OName_Str))) + ("'] = function() {"))) + (func11_NewLine_Str()));
							__debugInfo = "84:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("return function() { throwError(\"NullPrototypeException\"); };"));
							__debugInfo = "85:\src\CompilerPasses\Generator\JSGenerator.gbas";
							func10_IndentDown();
							__debugInfo = "86:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + (func11_NewLine_Str()))) + ("};"))) + (func11_NewLine_Str()));
							__debugInfo = "87:\src\CompilerPasses\Generator\JSGenerator.gbas";
							if (local11_InWebWorker_1944) {
								__debugInfo = "87:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((((((((local8_Text_Str_1945) + (local4_Func_ref_1951[0].attr9_OName_Str))) + (" = window['"))) + (local4_Func_ref_1951[0].attr9_OName_Str))) + ("'];"))) + (func11_NewLine_Str()));
								__debugInfo = "87:\src\CompilerPasses\Generator\JSGenerator.gbas";
							};
							__debugInfo = "82:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "88:\src\CompilerPasses\Generator\JSGenerator.gbas";
					}
					forEachSaver5713.values[forEachCounter5713] = local4_Func_ref_1951;
				
				};
				__debugInfo = "219:\src\CompilerPasses\Generator\JSGenerator.gbas";
				var forEachSaver6425 = global8_Compiler.attr5_Types_ref[0];
				for(var forEachCounter6425 = 0 ; forEachCounter6425 < forEachSaver6425.values.length ; forEachCounter6425++) {
					var local3_Typ_ref_1952 = forEachSaver6425.values[forEachCounter6425];
				{
						var local5_typId_1953 = 0, local3_map_1954 = new type7_HashMap(), local5_First_1955 = 0, local4_map2_1964 = new type7_HashMap();
						__debugInfo = "94:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_typId_1953 = local3_Typ_ref_1952[0].attr2_ID;
						__debugInfo = "96:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						__debugInfo = "97:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("var vtbl_"))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + (" = {"))) + (func11_NewLine_Str()));
						__debugInfo = "98:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_First_1955 = 0;
						__debugInfo = "111:\src\CompilerPasses\Generator\JSGenerator.gbas";
						while ((((local5_typId_1953) != (-(1))) ? 1 : 0)) {
							__debugInfo = "108:\src\CompilerPasses\Generator\JSGenerator.gbas";
							var forEachSaver5837 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_1953).values[tmpPositionCache][0].attr7_Methods;
							for(var forEachCounter5837 = 0 ; forEachCounter5837 < forEachSaver5837.values.length ; forEachCounter5837++) {
								var local3_Mth_1956 = forEachSaver5837.values[forEachCounter5837];
							{
									__debugInfo = "107:\src\CompilerPasses\Generator\JSGenerator.gbas";
									if (((((((local3_map_1954).DoesKeyExist(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1956).values[tmpPositionCache][0].attr9_OName_Str)) ? 0 : 1)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1956).values[tmpPositionCache][0].attr3_Scp) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
										__debugInfo = "102:\src\CompilerPasses\Generator\JSGenerator.gbas";
										if (local5_First_1955) {
											__debugInfo = "102:\src\CompilerPasses\Generator\JSGenerator.gbas";
											local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (", "))) + (func11_NewLine_Str()));
											__debugInfo = "102:\src\CompilerPasses\Generator\JSGenerator.gbas";
										};
										__debugInfo = "104:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1956).values[tmpPositionCache][0].attr9_OName_Str))) + (": "))) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1956).values[tmpPositionCache][0].attr8_Name_Str));
										__debugInfo = "105:\src\CompilerPasses\Generator\JSGenerator.gbas";
										(local3_map_1954).Put(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1956).values[tmpPositionCache][0].attr9_OName_Str, local3_Mth_1956);
										__debugInfo = "106:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local5_First_1955 = 1;
										__debugInfo = "102:\src\CompilerPasses\Generator\JSGenerator.gbas";
									};
									__debugInfo = "107:\src\CompilerPasses\Generator\JSGenerator.gbas";
								}
								forEachSaver5837.values[forEachCounter5837] = local3_Mth_1956;
							
							};
							__debugInfo = "110:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local5_typId_1953 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_1953).values[tmpPositionCache][0].attr9_Extending;
							__debugInfo = "108:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "112:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						__debugInfo = "113:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + (func11_NewLine_Str()))) + ("};"))) + (func11_NewLine_Str()));
						__debugInfo = "120:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if ((((global9_DEBUGMODE) == (0)) ? 1 : 0)) {
							__debugInfo = "117:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("/**"))) + (func11_NewLine_Str()));
							__debugInfo = "118:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("* @constructor"))) + (func11_NewLine_Str()));
							__debugInfo = "119:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("*/"))) + (func11_NewLine_Str()));
							__debugInfo = "117:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "121:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						__debugInfo = "122:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("window ['"))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + ("'] = function() {"))) + (func11_NewLine_Str()));
						__debugInfo = "133:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver5946 = local3_Typ_ref_1952[0].attr10_Attributes;
						for(var forEachCounter5946 = 0 ; forEachCounter5946 < forEachSaver5946.values.length ; forEachCounter5946++) {
							var local4_Attr_1957 = forEachSaver5946.values[forEachCounter5946];
						{
								var alias8_variable_ref_1958 = [new type14_IdentifierVari()];
								__debugInfo = "127:\src\CompilerPasses\Generator\JSGenerator.gbas";
								alias8_variable_ref_1958 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1957).values[tmpPositionCache] /* ALIAS */;
								__debugInfo = "128:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("this."))) + (alias8_variable_ref_1958[0].attr8_Name_Str));
								__debugInfo = "129:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((local8_Text_Str_1945) + (" = "));
								__debugInfo = "130:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((local8_Text_Str_1945) + (func21_JSGetDefaultValue_Str(alias8_variable_ref_1958[0].attr8_datatype, alias8_variable_ref_1958[0].attr3_ref, 0)));
								__debugInfo = "132:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (";"))) + (func11_NewLine_Str()));
								__debugInfo = "127:\src\CompilerPasses\Generator\JSGenerator.gbas";
							}
							forEachSaver5946.values[forEachCounter5946] = local4_Attr_1957;
						
						};
						__debugInfo = "136:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("this.vtbl = vtbl_"))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + (";"))) + (func11_NewLine_Str()));
						__debugInfo = "150:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6036 = local3_Typ_ref_1952[0].attr10_Attributes;
						for(var forEachCounter6036 = 0 ; forEachCounter6036 < forEachSaver6036.values.length ; forEachCounter6036++) {
							var local4_Attr_1959 = forEachSaver6036.values[forEachCounter6036];
						{
								var alias8_variable_ref_1960 = [new type14_IdentifierVari()];
								__debugInfo = "140:\src\CompilerPasses\Generator\JSGenerator.gbas";
								alias8_variable_ref_1960 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1959).values[tmpPositionCache] /* ALIAS */;
								__debugInfo = "149:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if ((((alias8_variable_ref_1960[0].attr6_PreDef) != (-(1))) ? 1 : 0)) {
									__debugInfo = "142:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("this."))) + (alias8_variable_ref_1960[0].attr8_Name_Str));
									__debugInfo = "143:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + (" = "));
									__debugInfo = "144:\src\CompilerPasses\Generator\JSGenerator.gbas";
									if (alias8_variable_ref_1960[0].attr3_ref) {
										__debugInfo = "144:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("["));
										__debugInfo = "144:\src\CompilerPasses\Generator\JSGenerator.gbas";
									};
									__debugInfo = "145:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(alias8_variable_ref_1960[0].attr6_PreDef).values[tmpPositionCache][0]))));
									__debugInfo = "146:\src\CompilerPasses\Generator\JSGenerator.gbas";
									if (alias8_variable_ref_1960[0].attr3_ref) {
										__debugInfo = "146:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("]"));
										__debugInfo = "146:\src\CompilerPasses\Generator\JSGenerator.gbas";
									};
									__debugInfo = "148:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (";"))) + (func11_NewLine_Str()));
									__debugInfo = "142:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "140:\src\CompilerPasses\Generator\JSGenerator.gbas";
							}
							forEachSaver6036.values[forEachCounter6036] = local4_Attr_1959;
						
						};
						__debugInfo = "154:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("return this;"))) + (func11_NewLine_Str()));
						__debugInfo = "155:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						__debugInfo = "156:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + (func11_NewLine_Str()))) + ("};"))) + (func11_NewLine_Str()));
						__debugInfo = "158:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						__debugInfo = "159:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("window['"))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + ("'].prototype.clone = function() {"))) + (func11_NewLine_Str()));
						__debugInfo = "160:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + ("var other = new "))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + ("();"))) + (func11_NewLine_Str()));
						__debugInfo = "182:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6215 = local3_Typ_ref_1952[0].attr10_Attributes;
						for(var forEachCounter6215 = 0 ; forEachCounter6215 < forEachSaver6215.values.length ; forEachCounter6215++) {
							var local4_Attr_1961 = forEachSaver6215.values[forEachCounter6215];
						{
								var alias8_variable_ref_1962 = [new type14_IdentifierVari()], local8_plzclone_1963 = 0;
								__debugInfo = "162:\src\CompilerPasses\Generator\JSGenerator.gbas";
								alias8_variable_ref_1962 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache] /* ALIAS */;
								__debugInfo = "167:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_plzclone_1963 = 0;
								__debugInfo = "172:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if (((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) && ((((((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) {
									__debugInfo = "169:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_plzclone_1963 = 0;
									__debugInfo = "169:\src\CompilerPasses\Generator\JSGenerator.gbas";
								} else {
									__debugInfo = "171:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_plzclone_1963 = 1;
									__debugInfo = "171:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "174:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Attr_1961).values[tmpPositionCache][0].attr3_ref) {
									__debugInfo = "174:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_plzclone_1963 = 1;
									__debugInfo = "174:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "175:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + ("other."))) + (alias8_variable_ref_1962[0].attr8_Name_Str))) + (" = "));
								__debugInfo = "177:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if (local8_plzclone_1963) {
									__debugInfo = "177:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("tryClone("));
									__debugInfo = "177:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "178:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("this."))) + (alias8_variable_ref_1962[0].attr8_Name_Str));
								__debugInfo = "179:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if (local8_plzclone_1963) {
									__debugInfo = "179:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + (")"));
									__debugInfo = "179:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "181:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (";"))) + (func11_NewLine_Str()));
								__debugInfo = "162:\src\CompilerPasses\Generator\JSGenerator.gbas";
							}
							forEachSaver6215.values[forEachCounter6215] = local4_Attr_1961;
						
						};
						__debugInfo = "184:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("other.vtbl = this.vtbl;"))) + (func11_NewLine_Str()));
						__debugInfo = "187:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						__debugInfo = "188:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("return other;"))) + (func11_NewLine_Str()));
						__debugInfo = "189:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("};"))) + (func11_NewLine_Str()));
						__debugInfo = "192:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (local11_InWebWorker_1944) {
							__debugInfo = "192:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local8_Text_Str_1945 = ((((((((((local8_Text_Str_1945) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + (" = window['"))) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + ("'];"))) + (func11_NewLine_Str()));
							__debugInfo = "192:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "195:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_typId_1953 = local3_Typ_ref_1952[0].attr2_ID;
						__debugInfo = "198:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_First_1955 = 0;
						__debugInfo = "218:\src\CompilerPasses\Generator\JSGenerator.gbas";
						while ((((local5_typId_1953) != (-(1))) ? 1 : 0)) {
							__debugInfo = "215:\src\CompilerPasses\Generator\JSGenerator.gbas";
							var forEachSaver6414 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_1953).values[tmpPositionCache][0].attr7_Methods;
							for(var forEachCounter6414 = 0 ; forEachCounter6414 < forEachSaver6414.values.length ; forEachCounter6414++) {
								var local3_Mth_1965 = forEachSaver6414.values[forEachCounter6414];
							{
									__debugInfo = "214:\src\CompilerPasses\Generator\JSGenerator.gbas";
									if (((((((local4_map2_1964).DoesKeyExist(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr9_OName_Str)) ? 0 : 1)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr3_Scp) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
										__debugInfo = "202:\src\CompilerPasses\Generator\JSGenerator.gbas";
										func8_IndentUp();
										__debugInfo = "203:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((((((((((((local8_Text_Str_1945) + (local3_Typ_ref_1952[0].attr8_Name_Str))) + (".prototype."))) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr9_OName_Str))) + (" = function() {"))) + (func11_NewLine_Str()))) + (" return "));
										__debugInfo = "204:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + ("this.vtbl."))) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr9_OName_Str))) + ("("));
										__debugInfo = "205:\src\CompilerPasses\Generator\JSGenerator.gbas";
										{
											var local1_i_1966 = 0.0;
											__debugInfo = "208:\src\CompilerPasses\Generator\JSGenerator.gbas";
											for (local1_i_1966 = 0;toCheck(local1_i_1966, ((BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr6_Params, 0)) - (2)), 1);local1_i_1966 += 1) {
												__debugInfo = "207:\src\CompilerPasses\Generator\JSGenerator.gbas";
												local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + ("arguments["))) + (CAST2STRING(local1_i_1966)))) + ("], "));
												__debugInfo = "207:\src\CompilerPasses\Generator\JSGenerator.gbas";
											};
											__debugInfo = "208:\src\CompilerPasses\Generator\JSGenerator.gbas";
										};
										__debugInfo = "210:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("this"));
										__debugInfo = "211:\src\CompilerPasses\Generator\JSGenerator.gbas";
										func10_IndentDown();
										__debugInfo = "212:\src\CompilerPasses\Generator\JSGenerator.gbas";
										local8_Text_Str_1945 = ((((((((local8_Text_Str_1945) + (");"))) + (func11_NewLine_Str()))) + ("};"))) + (func11_NewLine_Str()));
										__debugInfo = "213:\src\CompilerPasses\Generator\JSGenerator.gbas";
										(local4_map2_1964).Put(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_1965).values[tmpPositionCache][0].attr9_OName_Str, local3_Mth_1965);
										__debugInfo = "202:\src\CompilerPasses\Generator\JSGenerator.gbas";
									};
									__debugInfo = "214:\src\CompilerPasses\Generator\JSGenerator.gbas";
								}
								forEachSaver6414.values[forEachCounter6414] = local3_Mth_1965;
							
							};
							__debugInfo = "217:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local5_typId_1953 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_1953).values[tmpPositionCache][0].attr9_Extending;
							__debugInfo = "215:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "94:\src\CompilerPasses\Generator\JSGenerator.gbas";
					}
					forEachSaver6425.values[forEachCounter6425] = local3_Typ_ref_1952;
				
				};
				__debugInfo = "231:\src\CompilerPasses\Generator\JSGenerator.gbas";
				var forEachSaver6484 = global8_Compiler.attr10_DataBlocks;
				for(var forEachCounter6484 = 0 ; forEachCounter6484 < forEachSaver6484.values.length ; forEachCounter6484++) {
					var local5_block_1967 = forEachSaver6484.values[forEachCounter6484];
				{
						var local4_Done_1968 = 0;
						__debugInfo = "223:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((((local8_Text_Str_1945) + ("var datablock_"))) + (local5_block_1967.attr8_Name_Str))) + (" = [ "));
						__debugInfo = "224:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local4_Done_1968 = 0;
						__debugInfo = "229:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6476 = local5_block_1967.attr5_Datas;
						for(var forEachCounter6476 = 0 ; forEachCounter6476 < forEachSaver6476.values.length ; forEachCounter6476++) {
							var local1_d_1969 = forEachSaver6476.values[forEachCounter6476];
						{
								__debugInfo = "226:\src\CompilerPasses\Generator\JSGenerator.gbas";
								if (local4_Done_1968) {
									__debugInfo = "226:\src\CompilerPasses\Generator\JSGenerator.gbas";
									local8_Text_Str_1945 = ((local8_Text_Str_1945) + (", "));
									__debugInfo = "226:\src\CompilerPasses\Generator\JSGenerator.gbas";
								};
								__debugInfo = "227:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local8_Text_Str_1945 = ((local8_Text_Str_1945) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_d_1969).values[tmpPositionCache][0]))));
								__debugInfo = "228:\src\CompilerPasses\Generator\JSGenerator.gbas";
								local4_Done_1968 = 1;
								__debugInfo = "226:\src\CompilerPasses\Generator\JSGenerator.gbas";
							}
							forEachSaver6476.values[forEachCounter6476] = local1_d_1969;
						
						};
						__debugInfo = "230:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (" ];"))) + (func11_NewLine_Str()));
						__debugInfo = "223:\src\CompilerPasses\Generator\JSGenerator.gbas";
					}
					forEachSaver6484.values[forEachCounter6484] = local5_block_1967;
				
				};
				__debugInfo = "239:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((BOUNDS(global8_Compiler.attr7_Globals, 0)) > (0)) ? 1 : 0)) {
					__debugInfo = "235:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((local8_Text_Str_1945) + ("var "));
					__debugInfo = "236:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((local8_Text_Str_1945) + (func13_JSVariDef_Str(unref(global8_Compiler.attr7_Globals), 1, 0)));
					__debugInfo = "238:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "235:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "252:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((TRIM_Str(local14_StaticText_Str_1946, " \t\r\n\v\f")) != ("")) ? 1 : 0)) {
					__debugInfo = "242:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("// set default statics:"))) + (func11_NewLine_Str()));
					__debugInfo = "243:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((local17_StaticDefText_Str_1947) + (local8_Text_Str_1945));
					__debugInfo = "244:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "245:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("window['initStatics'] = function() {"))) + (func11_NewLine_Str()));
					__debugInfo = "246:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "247:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + (local14_StaticText_Str_1946))) + (func11_NewLine_Str()));
					__debugInfo = "248:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("}"))) + (func11_NewLine_Str()));
					__debugInfo = "242:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else {
					__debugInfo = "251:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("window['initStatics'] = function() {}"))) + (func11_NewLine_Str()));
					__debugInfo = "251:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "253:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if (local11_InWebWorker_1944) {
					__debugInfo = "253:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("initStatics = window['initStatics'];"))) + (func11_NewLine_Str()));
					__debugInfo = "253:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "255:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("for (var __init = 0; __init < preInitFuncs.length; __init++) preInitFuncs[__init]();"))) + (func11_NewLine_Str()));
				__debugInfo = "257:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1945 = ((((local8_Text_Str_1945) + ("delete preInitFuncs;"))) + (func11_NewLine_Str()));
				__debugInfo = "260:\src\CompilerPasses\Generator\JSGenerator.gbas";
				return tryClone(local8_Text_Str_1945);
				__debugInfo = "28:\src\CompilerPasses\Generator\JSGenerator.gbas";
			} catch (Err_Str) {
				if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
					
				}
			};
			__debugInfo = "262:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "263:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "261:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func16_JS_Generator_Str = window['func16_JS_Generator_Str'];
window['func14_JSGenerate_Str'] = function(param4_expr) {
		var __labels = {"Exit": 7934};
		
	stackPush("function: JSGenerate_Str", __debugInfo);
	try {
		var local8_Text_Str_1972 = "";
		var __pc = 6607;
		while(__pc >= 0) {
			switch(__pc) {
				case 6607:
					__debugInfo = "271:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global8_Compiler.attr11_currentPosi = param4_expr.attr5_tokID;
					
				__debugInfo = "272:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local8_Text_Str_1972 = "";
				__debugInfo = "273:\src\CompilerPasses\Generator\JSGenerator.gbas";
				
					var local16___SelectHelper7__1973 = 0;
					case 6617:
						__debugInfo = "273:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local16___SelectHelper7__1973 = param4_expr.attr3_Typ;
						
					case 10955:
						__debugInfo = "1074:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local16___SelectHelper7__1973) == (~~(2))) ? 1 : 0))) { __pc = 6619; break; }
					
					var local4_oScp_1974 = 0.0, local5_oFunc_1975 = 0.0, local13_oLabelDef_Str_1976 = "", local9_oIsInGoto_1977 = 0, local6_IsFunc_1978 = 0, local7_mngGoto_1979 = 0, local13_IsStackPusher_1980 = 0, local7_Def_Str_1984 = "", local8_ERes_Str_1987 = new OTTArray(""), local13_FirstText_Str_1990 = "";
					case 6624:
						__debugInfo = "275:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local4_oScp_1974 = global12_CurrentScope;
						
					__debugInfo = "276:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_oFunc_1975 = global11_CurrentFunc;
					__debugInfo = "277:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local13_oLabelDef_Str_1976 = global12_LabelDef_Str;
					__debugInfo = "278:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local9_oIsInGoto_1977 = global8_IsInGoto;
					__debugInfo = "279:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_IsFunc_1978 = 0;
					__debugInfo = "280:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local7_mngGoto_1979 = 0;
					__debugInfo = "281:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local13_IsStackPusher_1980 = 0;
					case 6670:
						__debugInfo = "282:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((param4_expr.attr6_ScpTyp) == (2)) ? 1 : 0)) || ((((param4_expr.attr6_ScpTyp) == (4)) ? 1 : 0))) ? 1 : 0))) { __pc = 6665; break; }
					
					case 6669:
						__debugInfo = "282:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local13_IsStackPusher_1980 = 1;
						
					__debugInfo = "282:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6665: //dummy jumper1
					;
						
					case 6683:
						__debugInfo = "287:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((func12_ScopeHasGoto(param4_expr)) && (local13_IsStackPusher_1980)) ? 1 : 0))) { __pc = 6675; break; }
					
					case 6679:
						__debugInfo = "285:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_mngGoto_1979 = 1;
						
					__debugInfo = "286:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global8_IsInGoto = 1;
					__debugInfo = "285:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6675: //dummy jumper1
					;
						
					case 6720:
						__debugInfo = "302:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((param4_expr.attr6_ScpTyp) == (2)) ? 1 : 0))) { __pc = 6689; break; }
					
					var local1_i_1981 = 0;
					case 6719:
						__debugInfo = "301:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6719 = global8_Compiler.attr5_Funcs_ref[0];
					var forEachCounter6719 = 0
					
				case 6697: //dummy for1
					if (!(forEachCounter6719 < forEachSaver6719.values.length)) {__pc = 6693; break;}
					var local4_Func_ref_1982 = forEachSaver6719.values[forEachCounter6719];
					
					
					case 6715:
						__debugInfo = "299:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local4_Func_ref_1982[0].attr3_Scp) == (param4_expr.attr2_ID)) ? 1 : 0))) { __pc = 6706; break; }
					
					case 6710:
						__debugInfo = "294:\src\CompilerPasses\Generator\JSGenerator.gbas";
						global11_CurrentFunc = local1_i_1981;
						
					__debugInfo = "295:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_IsFunc_1978 = 1;
					case 6714:
						__debugInfo = "298:\src\CompilerPasses\Generator\JSGenerator.gbas";
						__pc = 6693; break;
						
					__debugInfo = "294:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6706: //dummy jumper1
					;
						
					__debugInfo = "300:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_1981+=1;
					__debugInfo = "299:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver6719.values[forEachCounter6719] = local4_Func_ref_1982;
					
					forEachCounter6719++
					__pc = 6697; break; //back jump
					
				case 6693: //dummy for
					;
						
					__debugInfo = "301:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6689: //dummy jumper1
					;
						
					__debugInfo = "303:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global12_CurrentScope = param4_expr.attr2_ID;
					case 6736:
						__debugInfo = "312:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((((global8_IsInGoto) ? 0 : 1)) || (local7_mngGoto_1979)) ? 1 : 0))) { __pc = 6732; break; }
					
					case 6734:
						__debugInfo = "309:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						
					__debugInfo = "309:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28956;
					break;
					
				case 6732: //dummy jumper1
					
					
					
				case 28956: //dummy jumper2
					;
						
					__debugInfo = "313:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					case 6767:
						__debugInfo = "321:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global9_DEBUGMODE) && (local13_IsStackPusher_1980)) ? 1 : 0))) { __pc = 6745; break; }
					
					case 6758:
						__debugInfo = "318:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("stackPush(\""))) + (func13_ScopeName_Str(param4_expr)))) + ("\", __debugInfo);"))) + (func11_NewLine_Str()));
						
					__debugInfo = "319:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "320:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("try {"))) + (func11_NewLine_Str()));
					__debugInfo = "318:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6745: //dummy jumper1
					;
						
					case 6830:
						__debugInfo = "336:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local6_IsFunc_1978) && (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr15_UsedAsPrototype)) ? 1 : 0))) { __pc = 6777; break; }
					
					case 6829:
						__debugInfo = "335:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6829 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr6_Params;
					var forEachCounter6829 = 0
					
				case 6788: //dummy for1
					if (!(forEachCounter6829 < forEachSaver6829.values.length)) {__pc = 6780; break;}
					var local1_P_1983 = forEachSaver6829.values[forEachCounter6829];
					
					
					case 6828:
						__debugInfo = "334:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1983).values[tmpPositionCache][0].attr3_ref) == (0)) ? 1 : 0))) { __pc = 6800; break; }
					
					case 6826:
						__debugInfo = "331:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1983).values[tmpPositionCache][0].attr8_Name_Str))) + (" = unref("))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_1983).values[tmpPositionCache][0].attr8_Name_Str))) + (");"))) + (func11_NewLine_Str()));
						
					__debugInfo = "331:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28959;
					break;
					
				case 6800: //dummy jumper1
					
					
					
				case 28959: //dummy jumper2
					;
						
					__debugInfo = "334:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver6829.values[forEachCounter6829] = local1_P_1983;
					
					forEachCounter6829++
					__pc = 6788; break; //back jump
					
				case 6780: //dummy for
					;
						
					__debugInfo = "335:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6777: //dummy jumper1
					;
						
					__debugInfo = "339:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local7_Def_Str_1984 = func13_JSVariDef_Str(unref(param4_expr.attr5_Varis), 0, 1);
					case 6864:
						__debugInfo = "344:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((TRIM_Str(local7_Def_Str_1984, " \t\r\n\v\f")) != ("")) ? 1 : 0))) { __pc = 6845; break; }
					
					case 6851:
						__debugInfo = "341:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("var "));
						
					__debugInfo = "342:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local7_Def_Str_1984));
					__debugInfo = "343:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "341:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6845: //dummy jumper1
					;
						
					case 6942:
						__debugInfo = "354:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((global11_CurrentFunc) != (-(1))) ? 1 : 0)) && ((((local5_oFunc_1975) == (-(1))) ? 1 : 0))) ? 1 : 0))) { __pc = 6877; break; }
					
					var local1_i_1985 = 0;
					case 6941:
						__debugInfo = "353:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6941 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr6_Params;
					var forEachCounter6941 = 0
					
				case 6889: //dummy for1
					if (!(forEachCounter6941 < forEachSaver6941.values.length)) {__pc = 6881; break;}
					var local5_Param_1986 = forEachSaver6941.values[forEachCounter6941];
					
					
					case 6940:
						__debugInfo = "352:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Param_1986).values[tmpPositionCache][0].attr9_OwnerVari) != (-(1))) ? 1 : 0))) { __pc = 6902; break; }
					
					case 6936:
						__debugInfo = "350:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("var "))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Param_1986).values[tmpPositionCache][0].attr9_OwnerVari).values[tmpPositionCache][0].attr8_Name_Str))) + (" = ["))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Param_1986).values[tmpPositionCache][0].attr8_Name_Str))) + ("]; /* NEWCODEHERE */"))) + (func11_NewLine_Str()));
						
					__debugInfo = "351:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_1985+=1;
					__debugInfo = "350:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6902: //dummy jumper1
					;
						
					__debugInfo = "352:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver6941.values[forEachCounter6941] = local5_Param_1986;
					
					forEachCounter6941++
					__pc = 6889; break; //back jump
					
				case 6881: //dummy for
					;
						
					__debugInfo = "353:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6877: //dummy jumper1
					;
						
					case 6949:
						__debugInfo = "361:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local7_mngGoto_1979)) { __pc = 6944; break; }
					
					case 6946:
						__debugInfo = "358:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						
					__debugInfo = "359:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "360:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "358:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6944: //dummy jumper1
					;
						
					case 6981:
						__debugInfo = "369:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver6981 = param4_expr.attr5_Exprs;
					var forEachCounter6981 = 0
					
				case 6956: //dummy for1
					if (!(forEachCounter6981 < forEachSaver6981.values.length)) {__pc = 6952; break;}
					var local2_Ex_1988 = forEachSaver6981.values[forEachCounter6981];
					
					
					var local7_add_Str_1989 = "";
					case 6963:
						__debugInfo = "364:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_add_Str_1989 = func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local2_Ex_1988).values[tmpPositionCache][0]));
						
					case 6980:
						__debugInfo = "368:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((TRIM_Str(local7_add_Str_1989, " \t\r\n\v\f")) != ("")) ? 1 : 0))) { __pc = 6969; break; }
					
					case 6975:
						__debugInfo = "366:\src\CompilerPasses\Generator\JSGenerator.gbas";
						DIMPUSH(local8_ERes_Str_1987, CAST2STRING(local2_Ex_1988));
						
					__debugInfo = "367:\src\CompilerPasses\Generator\JSGenerator.gbas";
					DIMPUSH(local8_ERes_Str_1987, local7_add_Str_1989);
					__debugInfo = "366:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6969: //dummy jumper1
					;
						
					__debugInfo = "364:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver6981.values[forEachCounter6981] = local2_Ex_1988;
					
					forEachCounter6981++
					__pc = 6956; break; //back jump
					
				case 6952: //dummy for
					;
						
					case 7038:
						__debugInfo = "388:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local7_mngGoto_1979)) { __pc = 6983; break; }
					
					case 6985:
						__debugInfo = "371:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						
					__debugInfo = "372:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "373:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "376:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("var __pc = "));
					case 7014:
						__debugInfo = "381:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((BOUNDS(local8_ERes_Str_1987, 0)) > (0)) ? 1 : 0))) { __pc = 6999; break; }
					
					case 7007:
						__debugInfo = "378:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local8_ERes_Str_1987.arrAccess(0).values[tmpPositionCache]));
						
					__debugInfo = "378:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28966;
					break;
					
				case 6999: //dummy jumper1
					
					case 7013:
						__debugInfo = "380:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("0"));
						
					__debugInfo = "380:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28966: //dummy jumper2
					;
						
					__debugInfo = "382:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "384:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "385:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("while(__pc >= 0) {"))) + (func11_NewLine_Str()));
					__debugInfo = "386:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "387:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("switch(__pc) {"))) + (func11_NewLine_Str()));
					__debugInfo = "371:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 6983: //dummy jumper1
					;
						
					__debugInfo = "390:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local13_FirstText_Str_1990 = "";
					__debugInfo = "390:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
					var local1_i_1991 = 0.0;
					case 7253:
						__debugInfo = "413:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_i_1991 = 0
					
				case 7047: //dummy for1
					if (!toCheck(local1_i_1991, ((BOUNDS(local8_ERes_Str_1987, 0)) - (1)), 2)) {__pc = 7058; break;}
					
					var local7_add_Str_1992 = "", local2_Ex_1993 = 0, alias4_ExEx_ref_1994 = [new type4_Expr()], local7_HasCase_1995 = 0;
					case 7068:
						__debugInfo = "392:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_add_Str_1992 = local8_ERes_Str_1987.arrAccess(~~(((local1_i_1991) + (1)))).values[tmpPositionCache];
						
					__debugInfo = "393:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local2_Ex_1993 = INT2STR(local8_ERes_Str_1987.arrAccess(~~(local1_i_1991)).values[tmpPositionCache]);
					__debugInfo = "394:\src\CompilerPasses\Generator\JSGenerator.gbas";
					alias4_ExEx_ref_1994 = global5_Exprs_ref[0].arrAccess(local2_Ex_1993).values[tmpPositionCache] /* ALIAS */;
					__debugInfo = "395:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local7_HasCase_1995 = 0;
					case 7177:
						__debugInfo = "400:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local7_mngGoto_1979) || (global8_IsInGoto)) ? 1 : 0)) && ((((((((((((((((((((((((((((((((((local1_i_1991) == (0)) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (20)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (21)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (24)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (25)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (27)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (38)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (26)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (29)) ? 1 : 0))) ? 1 : 0)) || ((((alias4_ExEx_ref_1994[0].attr3_Typ) == (30)) ? 1 : 0))) ? 1 : 0)) || ((((local1_i_1991) == (((BOUNDS(local8_ERes_Str_1987, 0)) - (1)))) ? 1 : 0))) ? 1 : 0))) ? 1 : 0))) { __pc = 7159; break; }
					
					case 7161:
						__debugInfo = "397:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						
					__debugInfo = "398:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local7_HasCase_1995 = 1;
					__debugInfo = "399:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(local2_Ex_1993)))) + (":"))) + (func11_NewLine_Str()));
					__debugInfo = "397:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7159: //dummy jumper1
					;
						
					case 7230:
						__debugInfo = "405:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global9_DEBUGMODE)) { __pc = 7179; break; }
					
					var local7_Add_Str_1996 = "";
					case 7212:
						__debugInfo = "402:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Add_Str_1996 = (((((((("__debugInfo = \"") + (CAST2STRING(global8_Compiler.attr6_Tokens.arrAccess(global5_Exprs_ref[0].arrAccess(local2_Ex_1993).values[tmpPositionCache][0].attr5_tokID).values[tmpPositionCache].attr4_Line_ref[0])))) + (":"))) + (global8_Compiler.attr6_Tokens.arrAccess(global5_Exprs_ref[0].arrAccess(local2_Ex_1993).values[tmpPositionCache][0].attr5_tokID).values[tmpPositionCache].attr8_Path_Str_ref[0]))) + ("\";"));
						
					__debugInfo = "403:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (local7_Add_Str_1996))) + (func11_NewLine_Str()));
					case 7229:
						__debugInfo = "404:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local13_FirstText_Str_1990) == ("")) ? 1 : 0))) { __pc = 7224; break; }
					
					case 7228:
						__debugInfo = "404:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local13_FirstText_Str_1990 = local7_Add_Str_1996;
						
					__debugInfo = "404:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7224: //dummy jumper1
					;
						
					__debugInfo = "402:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7179: //dummy jumper1
					;
						
					__debugInfo = "407:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local7_add_Str_1992));
					__debugInfo = "408:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (";"))) + (func11_NewLine_Str()));
					case 7252:
						__debugInfo = "412:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local7_HasCase_1995)) { __pc = 7244; break; }
					
					case 7246:
						__debugInfo = "410:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						
					__debugInfo = "411:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "410:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7244: //dummy jumper1
					;
						
					__debugInfo = "392:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_1991 += 2;
					__pc = 7047; break; //back jump
					
				case 7058: //dummy for
					;
						
					__debugInfo = "413:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
					case 7264:
						__debugInfo = "417:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local13_FirstText_Str_1990) != ("")) ? 1 : 0))) { __pc = 7257; break; }
					
					case 7263:
						__debugInfo = "416:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local13_FirstText_Str_1990));
						
					__debugInfo = "416:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7257: //dummy jumper1
					;
						
					case 7325:
						__debugInfo = "433:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local7_mngGoto_1979)) { __pc = 7266; break; }
					
					case 7274:
						__debugInfo = "420:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("__pc = -1; break;"))) + (func11_NewLine_Str()));
						
					__debugInfo = "421:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "422:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("default:"))) + (func11_NewLine_Str()));
					__debugInfo = "423:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "424:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("throwError(\"Gotocounter exception pc: \"+__pc);"))) + (func11_NewLine_Str()));
					__debugInfo = "425:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "426:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("}"));
					__debugInfo = "427:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "428:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("}"));
					__debugInfo = "431:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = (((((((("var __labels = {") + (func16_JSRemoveLast_Str(global12_LabelDef_Str, ", ")))) + ("};"))) + (func11_NewLine_Str()))) + (local8_Text_Str_1972));
					__debugInfo = "432:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((func11_NewLine_Str()) + (local8_Text_Str_1972));
					__debugInfo = "420:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7266: //dummy jumper1
					;
						
					case 7339:
						__debugInfo = "434:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((((global8_IsInGoto) ? 0 : 1)) || (local7_mngGoto_1979)) ? 1 : 0))) { __pc = 7332; break; }
					
					case 7338:
						__debugInfo = "434:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = (("{") + (local8_Text_Str_1972));
						
					__debugInfo = "434:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7332: //dummy jumper1
					;
						
					case 7401:
						__debugInfo = "450:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global9_DEBUGMODE) && (local13_IsStackPusher_1980)) ? 1 : 0))) { __pc = 7343; break; }
					
					case 7345:
						__debugInfo = "438:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						
					__debugInfo = "439:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("} catch(ex) {"));
					__debugInfo = "440:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "441:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("if (isKnownException(ex)) throw ex;"));
					__debugInfo = "442:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("alert(formatError(ex));"));
					__debugInfo = "443:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("END();"));
					__debugInfo = "444:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "445:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("} finally {"));
					__debugInfo = "446:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "447:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("stackPop();"));
					__debugInfo = "448:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "449:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("}"))) + (func11_NewLine_Str()));
					__debugInfo = "438:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7343: //dummy jumper1
					;
						
					case 7427:
						__debugInfo = "459:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((((global8_IsInGoto) ? 0 : 1)) || (local7_mngGoto_1979)) ? 1 : 0))) { __pc = 7408; break; }
					
					case 7410:
						__debugInfo = "453:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func10_IndentDown();
						
					__debugInfo = "454:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "455:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("}"));
					__debugInfo = "453:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28975;
					break;
					
				case 7408: //dummy jumper1
					
					case 7426:
						__debugInfo = "458:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
						
					__debugInfo = "458:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28975: //dummy jumper2
					;
						
					__debugInfo = "462:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global12_CurrentScope = ~~(local4_oScp_1974);
					__debugInfo = "463:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_CurrentFunc = ~~(local5_oFunc_1975);
					case 7445:
						__debugInfo = "468:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local7_mngGoto_1979)) { __pc = 7437; break; }
					
					case 7441:
						__debugInfo = "466:\src\CompilerPasses\Generator\JSGenerator.gbas";
						global12_LabelDef_Str = local13_oLabelDef_Str_1976;
						
					__debugInfo = "467:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global8_IsInGoto = local9_oIsInGoto_1977;
					__debugInfo = "466:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7437: //dummy jumper1
					;
						
					__debugInfo = "275:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 6619: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(1))) ? 1 : 0))) { __pc = 7447; break; }
					
					var local7_Sym_Str_1997 = "", local10_HasToBeInt_1998 = 0.0, local10_MightBeInt_1999 = 0;
					case 7457:
						__debugInfo = "470:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Sym_Str_1997 = global9_Operators_ref[0].arrAccess(param4_expr.attr2_Op).values[tmpPositionCache][0].attr7_Sym_Str;
						
					__debugInfo = "470:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_HasToBeInt_1998 = 0;
					__debugInfo = "471:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_MightBeInt_1999 = 0;
					__debugInfo = "472:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
					var local16___SelectHelper8__2000 = "";
					case 7470:
						__debugInfo = "472:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local16___SelectHelper8__2000 = local7_Sym_Str_1997;
						
					case 7535:
						__debugInfo = "494:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local16___SelectHelper8__2000) == ("=")) ? 1 : 0))) { __pc = 7472; break; }
					
					case 7476:
						__debugInfo = "474:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Sym_Str_1997 = "==";
						
					__debugInfo = "475:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_HasToBeInt_1998 = 1;
					__debugInfo = "474:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7472: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == ("<>")) ? 1 : 0))) { __pc = 7482; break; }
					
					case 7486:
						__debugInfo = "477:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Sym_Str_1997 = "!=";
						
					__debugInfo = "478:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_HasToBeInt_1998 = 1;
					__debugInfo = "477:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7482: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == ("OR")) ? 1 : 0))) { __pc = 7492; break; }
					
					case 7496:
						__debugInfo = "480:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Sym_Str_1997 = "||";
						
					__debugInfo = "481:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_HasToBeInt_1998 = 1;
					__debugInfo = "480:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7492: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == ("AND")) ? 1 : 0))) { __pc = 7502; break; }
					
					case 7506:
						__debugInfo = "483:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Sym_Str_1997 = "&&";
						
					__debugInfo = "484:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_HasToBeInt_1998 = 1;
					__debugInfo = "483:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7502: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == ("<")) ? 1 : 0))) { __pc = 7512; break; }
					
					case 7516:
						__debugInfo = "486:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_MightBeInt_1999 = 1;
						
					__debugInfo = "486:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7512: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == (">")) ? 1 : 0))) { __pc = 7518; break; }
					
					case 7522:
						__debugInfo = "488:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_MightBeInt_1999 = 1;
						
					__debugInfo = "488:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7518: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == (">=")) ? 1 : 0))) { __pc = 7524; break; }
					
					case 7528:
						__debugInfo = "490:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_MightBeInt_1999 = 1;
						
					__debugInfo = "490:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7524: //dummy jumper1
					if (!((((local16___SelectHelper8__2000) == ("<=")) ? 1 : 0))) { __pc = 7530; break; }
					
					case 7534:
						__debugInfo = "492:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_MightBeInt_1999 = 1;
						
					__debugInfo = "492:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7530: //dummy jumper1
					;
						
					__debugInfo = "472:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
					case 7712:
						__debugInfo = "520:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local10_HasToBeInt_1998) || (local10_MightBeInt_1999)) ? 1 : 0))) { __pc = 7540; break; }
					
					case 7654:
						__debugInfo = "512:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local10_MightBeInt_1999) && ((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) && ((((global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0))) { __pc = 7567; break; }
					
					var local7_Res_Str_2001 = "";
					case 7571:
						__debugInfo = "499:\src\CompilerPasses\Generator\JSGenerator.gbas";
						
					var local16___SelectHelper9__2002 = "";
					case 7573:
						__debugInfo = "499:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local16___SelectHelper9__2002 = local7_Sym_Str_1997;
						
					case 7598:
						__debugInfo = "508:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local16___SelectHelper9__2002) == ("<")) ? 1 : 0))) { __pc = 7575; break; }
					
					case 7579:
						__debugInfo = "501:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Res_Str_2001 = " == -1";
						
					__debugInfo = "501:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7575: //dummy jumper1
					if (!((((local16___SelectHelper9__2002) == (">")) ? 1 : 0))) { __pc = 7581; break; }
					
					case 7585:
						__debugInfo = "503:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Res_Str_2001 = " == 1";
						
					__debugInfo = "503:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7581: //dummy jumper1
					if (!((((local16___SelectHelper9__2002) == ("<=")) ? 1 : 0))) { __pc = 7587; break; }
					
					case 7591:
						__debugInfo = "505:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Res_Str_2001 = " <= 0";
						
					__debugInfo = "505:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7587: //dummy jumper1
					if (!((((local16___SelectHelper9__2002) == (">=")) ? 1 : 0))) { __pc = 7593; break; }
					
					case 7597:
						__debugInfo = "507:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Res_Str_2001 = " >= 0";
						
					__debugInfo = "507:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7593: //dummy jumper1
					;
						
					__debugInfo = "499:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
						
					__debugInfo = "509:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((((local8_Text_Str_1972) + ("((strcmp(("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0]))))) + ("), ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]))))) + (")) "))) + (local7_Res_Str_2001))) + (" ) ? 1 : 0)"));
					__debugInfo = "499:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28979;
					break;
					
				case 7567: //dummy jumper1
					
					case 7653:
						__debugInfo = "511:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((((local8_Text_Str_1972) + ("((("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0]))))) + (") "))) + (local7_Sym_Str_1997))) + (" ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]))))) + (")) ? 1 : 0)"));
						
					__debugInfo = "511:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28979: //dummy jumper2
					;
						
					__debugInfo = "512:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28978;
					break;
					
				case 7540: //dummy jumper1
					
					var local5_l_Str_2003 = "";
					case 7663:
						__debugInfo = "514:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_l_Str_2003 = func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0]));
						
					case 7711:
						__debugInfo = "519:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local7_Sym_Str_1997) == ("-")) ? 1 : 0)) && ((((local5_l_Str_2003) == ("0")) ? 1 : 0))) ? 1 : 0))) { __pc = 7672; break; }
					
					case 7687:
						__debugInfo = "516:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("-("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "516:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28981;
					break;
					
				case 7672: //dummy jumper1
					
					case 7710:
						__debugInfo = "518:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((((local8_Text_Str_1972) + ("(("))) + (local5_l_Str_2003))) + (") "))) + (local7_Sym_Str_1997))) + (" ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]))))) + ("))"));
						
					__debugInfo = "518:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28981: //dummy jumper2
					;
						
					__debugInfo = "514:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28978: //dummy jumper2
					;
						
					case 7749:
						__debugInfo = "525:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((((((((local7_Sym_Str_1997) == ("/")) ? 1 : 0)) && ((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0))) ? 1 : 0)) && ((((global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0))) ? 1 : 0))) { __pc = 7740; break; }
					
					case 7748:
						__debugInfo = "524:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = (((("CAST2INT(") + (local8_Text_Str_1972))) + (")"));
						
					__debugInfo = "524:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7740: //dummy jumper1
					;
						
					__debugInfo = "470:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7447: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(3))) ? 1 : 0))) { __pc = 7751; break; }
					
					case 7759:
						__debugInfo = "527:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = CAST2STRING(INTEGER(param4_expr.attr6_intval));
						
					__debugInfo = "527:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7751: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(4))) ? 1 : 0))) { __pc = 7761; break; }
					
					case 7768:
						__debugInfo = "529:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = CAST2STRING(param4_expr.attr8_floatval);
						
					__debugInfo = "529:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7761: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(5))) ? 1 : 0))) { __pc = 7770; break; }
					
					case 7776:
						__debugInfo = "531:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = param4_expr.attr10_strval_Str;
						
					__debugInfo = "531:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7770: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(6))) ? 1 : 0))) { __pc = 7778; break; }
					
					case 7985:
						__debugInfo = "561:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_expr.attr4_func).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0))) { __pc = 7791; break; }
					
					var local1_P_2004 = 0, alias2_Ex_ref_2005 = [new type4_Expr()];
					case 7801:
						__debugInfo = "534:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_P_2004 = param4_expr.attr6_Params.arrAccess(-(1)).values[tmpPositionCache];
						
					__debugInfo = "535:\src\CompilerPasses\Generator\JSGenerator.gbas";
					alias2_Ex_ref_2005 = global5_Exprs_ref[0].arrAccess(local1_P_2004).values[tmpPositionCache] /* ALIAS */;
					case 7964:
						__debugInfo = "557:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((alias2_Ex_ref_2005[0].attr3_Typ) == (53)) ? 1 : 0))) { __pc = 7812; break; }
					
					var local5_Found_2006 = 0, local5_typId_2007 = 0;
					case 7835:
						__debugInfo = "538:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((func6_IsType(unref(alias2_Ex_ref_2005[0].attr8_datatype.attr8_Name_Str_ref[0]))) ? 0 : 1))) { __pc = 7821; break; }
					
					case 7834:
						__debugInfo = "538:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func5_Error((((("Internal error (Unable to find '") + (alias2_Ex_ref_2005[0].attr8_datatype.attr8_Name_Str_ref[0]))) + ("')")), 537, "src\CompilerPasses\Generator\JSGenerator.gbas");
						
					__debugInfo = "538:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7821: //dummy jumper1
					;
						
					__debugInfo = "540:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_Found_2006 = 0;
					__debugInfo = "541:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_typId_2007 = global8_LastType.attr2_ID;
					case 7933:
						__debugInfo = "552:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local5_typId_2007) != (-(1))) ? 1 : 0))) {__pc = 28986; break;}
					
					case 7923:
						__debugInfo = "550:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver7923 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2007).values[tmpPositionCache][0].attr7_Methods;
					var forEachCounter7923 = 0
					
				case 7863: //dummy for1
					if (!(forEachCounter7923 < forEachSaver7923.values.length)) {__pc = 7855; break;}
					var local3_Mth_2008 = forEachSaver7923.values[forEachCounter7923];
					
					
					case 7922:
						__debugInfo = "549:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_2008).values[tmpPositionCache][0].attr9_OName_Str) == (global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_expr.attr4_func).values[tmpPositionCache][0].attr9_OName_Str)) ? 1 : 0))) { __pc = 7882; break; }
					
					var local10_Params_Str_2009 = "";
					case 7891:
						__debugInfo = "545:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_Params_Str_2009 = func17_JSDoParameter_Str(param4_expr, param4_expr.attr4_func, 0);
						
					case 7903:
						__debugInfo = "546:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local10_Params_Str_2009) != ("")) ? 1 : 0))) { __pc = 7896; break; }
					
					case 7902:
						__debugInfo = "546:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_Params_Str_2009 = ((local10_Params_Str_2009) + (", "));
						
					__debugInfo = "546:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7896: //dummy jumper1
					;
						
					__debugInfo = "547:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Mth_2008).values[tmpPositionCache][0].attr8_Name_Str))) + ("("))) + (local10_Params_Str_2009))) + ("param4_self)"));
					case 7921:
						__debugInfo = "548:\src\CompilerPasses\Generator\JSGenerator.gbas";
						__pc = __labels["Exit"]; break;
						
					__debugInfo = "545:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 7882: //dummy jumper1
					;
						
					__debugInfo = "549:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver7923.values[forEachCounter7923] = local3_Mth_2008;
					
					forEachCounter7923++
					__pc = 7863; break; //back jump
					
				case 7855: //dummy for
					;
						
					__debugInfo = "551:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_typId_2007 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2007).values[tmpPositionCache][0].attr9_Extending;
					__debugInfo = "550:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 7933; break; //back jump
					
				case 28986:
					;
						
					case 7934:
						__debugInfo = "553:\src\CompilerPasses\Generator\JSGenerator.gbas";
						//label: Exit;
						
					__debugInfo = "538:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28984;
					break;
					
				case 7812: //dummy jumper1
					
					case 7963:
						__debugInfo = "556:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_P_2004).values[tmpPositionCache][0]))))) + (")."))) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_expr.attr4_func).values[tmpPositionCache][0].attr9_OName_Str))) + (func17_JSDoParameter_Str(param4_expr, param4_expr.attr4_func, 1)));
						
					__debugInfo = "556:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28984: //dummy jumper2
					;
						
					__debugInfo = "534:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28983;
					break;
					
				case 7791: //dummy jumper1
					
					case 7984:
						__debugInfo = "560:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_expr.attr4_func).values[tmpPositionCache][0].attr8_Name_Str))) + (func17_JSDoParameter_Str(param4_expr, param4_expr.attr4_func, 1)));
						
					__debugInfo = "560:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28983: //dummy jumper2
					;
						
					__debugInfo = "561:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7778: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(23))) ? 1 : 0))) { __pc = 7987; break; }
					
					case 8004:
						__debugInfo = "564:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (func17_JSDoParameter_Str(param4_expr, -(1), 1)));
						
					__debugInfo = "564:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 7987: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(9))) ? 1 : 0))) { __pc = 8006; break; }
					
					case 8020:
						__debugInfo = "566:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str));
						
					case 8037:
						__debugInfo = "567:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr3_ref)) { __pc = 8030; break; }
					
					case 8036:
						__debugInfo = "567:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("[0]"));
						
					__debugInfo = "567:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8030: //dummy jumper1
					;
						
					__debugInfo = "566:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8006: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(13))) ? 1 : 0))) { __pc = 8039; break; }
					
					case 8050:
						__debugInfo = "571:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0]))));
						
					case 8137:
						__debugInfo = "589:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((BOUNDS(param4_expr.attr4_dims, 0)) != (0)) ? 1 : 0))) { __pc = 8059; break; }
					
					var local1_s_2010 = 0, local7_Add_Str_2011 = "";
					case 8065:
						__debugInfo = "573:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (".arrAccess("));
						
					__debugInfo = "574:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_s_2010 = 0;
					__debugInfo = "575:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local7_Add_Str_2011 = "";
					case 8129:
						__debugInfo = "586:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver8129 = param4_expr.attr4_dims;
					var forEachCounter8129 = 0
					
				case 8080: //dummy for1
					if (!(forEachCounter8129 < forEachSaver8129.values.length)) {__pc = 8076; break;}
					var local1_d_2012 = forEachSaver8129.values[forEachCounter8129];
					
					
					var local1_v_2013 = 0;
					case 8090:
						__debugInfo = "577:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local1_s_2010)) { __pc = 8083; break; }
					
					case 8089:
						__debugInfo = "577:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (", "));
						
					__debugInfo = "577:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8083: //dummy jumper1
					;
						
					__debugInfo = "578:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_d_2012).values[tmpPositionCache][0]))));
					__debugInfo = "580:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_s_2010 = 1;
					__debugInfo = "581:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_v_2013 = func11_GetVariable(param4_expr.attr5_array, 0);
					case 8128:
						__debugInfo = "585:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local1_v_2013) != (-(1))) ? 1 : 0)) && (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2013).values[tmpPositionCache][0].attr3_ref)) ? 1 : 0))) { __pc = 8123; break; }
					
					case 8127:
						__debugInfo = "584:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local7_Add_Str_2011 = "[0]";
						
					__debugInfo = "584:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8123: //dummy jumper1
					;
						
					__debugInfo = "577:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver8129.values[forEachCounter8129] = local1_d_2012;
					
					forEachCounter8129++
					__pc = 8080; break; //back jump
					
				case 8076: //dummy for
					;
						
					__debugInfo = "587:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (").values[tmpPositionCache]"))) + (local7_Add_Str_2011));
					__debugInfo = "573:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8059: //dummy jumper1
					;
						
					__debugInfo = "571:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8039: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(10))) ? 1 : 0))) { __pc = 8139; break; }
					
					case 8152:
						__debugInfo = "591:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0]))))) + (" = "));
						
					__debugInfo = "593:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]))));
					case 8212:
						__debugInfo = "598:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) || (func6_IsType(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0])))) ? 1 : 0))) { __pc = 8183; break; }
					
					case 8211:
						__debugInfo = "597:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0].attr3_Typ) != (35)) ? 1 : 0)) && ((((global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0].attr3_Typ) != (36)) ? 1 : 0))) ? 1 : 0))) { __pc = 8204; break; }
					
					case 8210:
						__debugInfo = "596:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (".clone(/* In Assign */)"));
						
					__debugInfo = "596:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8204: //dummy jumper1
					;
						
					__debugInfo = "597:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8183: //dummy jumper1
					;
						
					__debugInfo = "591:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8139: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(11))) ? 1 : 0))) { __pc = 8214; break; }
					
					var local1_v_2014 = 0, local6_hasRef_2015 = 0, local4_Find_2016 = 0;
					case 8222:
						__debugInfo = "602:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_v_2014 = func11_GetVariable(param4_expr.attr5_array, 0);
						
					__debugInfo = "603:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_hasRef_2015 = 0;
					case 8247:
						__debugInfo = "604:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local1_v_2014) == (-(1))) ? 1 : 0)) || (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2014).values[tmpPositionCache][0].attr3_ref)) ? 1 : 0))) { __pc = 8242; break; }
					
					case 8246:
						__debugInfo = "604:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_hasRef_2015 = 1;
						
					__debugInfo = "604:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8242: //dummy jumper1
					;
						
					__debugInfo = "606:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("DIM("))) + (func14_JSTryUnref_Str(param4_expr.attr5_array)))) + (", ["));
					__debugInfo = "607:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2016 = 0;
					case 8294:
						__debugInfo = "613:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver8294 = param4_expr.attr4_dims;
					var forEachCounter8294 = 0
					
				case 8270: //dummy for1
					if (!(forEachCounter8294 < forEachSaver8294.values.length)) {__pc = 8266; break;}
					var local1_D_2017 = forEachSaver8294.values[forEachCounter8294];
					
					
					case 8282:
						__debugInfo = "609:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local4_Find_2016) == (1)) ? 1 : 0))) { __pc = 8275; break; }
					
					case 8281:
						__debugInfo = "609:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (", "));
						
					__debugInfo = "609:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8275: //dummy jumper1
					;
						
					__debugInfo = "610:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_D_2017).values[tmpPositionCache][0]))));
					__debugInfo = "612:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2016 = 1;
					__debugInfo = "609:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver8294.values[forEachCounter8294] = local1_D_2017;
					
					forEachCounter8294++
					__pc = 8270; break; //back jump
					
				case 8266: //dummy for
					;
						
					__debugInfo = "614:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("], "))) + (func21_JSGetDefaultValue_Str(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0].attr8_datatype, local6_hasRef_2015, 1)))) + (")"));
					__debugInfo = "602:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8214: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(12))) ? 1 : 0))) { __pc = 8314; break; }
					
					var local1_v_2018 = 0, local6_hasRef_2019 = 0, local4_Find_2020 = 0;
					case 8322:
						__debugInfo = "617:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_v_2018 = func11_GetVariable(param4_expr.attr5_array, 0);
						
					__debugInfo = "618:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_hasRef_2019 = 0;
					case 8347:
						__debugInfo = "619:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((((((local1_v_2018) == (-(1))) ? 1 : 0)) || (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2018).values[tmpPositionCache][0].attr3_ref)) ? 1 : 0))) { __pc = 8342; break; }
					
					case 8346:
						__debugInfo = "619:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_hasRef_2019 = 1;
						
					__debugInfo = "619:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8342: //dummy jumper1
					;
						
					__debugInfo = "621:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("REDIM("))) + (func14_JSTryUnref_Str(param4_expr.attr5_array)))) + (", ["));
					__debugInfo = "622:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2020 = 0;
					case 8394:
						__debugInfo = "628:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver8394 = param4_expr.attr4_dims;
					var forEachCounter8394 = 0
					
				case 8370: //dummy for1
					if (!(forEachCounter8394 < forEachSaver8394.values.length)) {__pc = 8366; break;}
					var local1_D_2021 = forEachSaver8394.values[forEachCounter8394];
					
					
					case 8382:
						__debugInfo = "624:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local4_Find_2020) == (1)) ? 1 : 0))) { __pc = 8375; break; }
					
					case 8381:
						__debugInfo = "624:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (", "));
						
					__debugInfo = "624:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8375: //dummy jumper1
					;
						
					__debugInfo = "625:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_D_2021).values[tmpPositionCache][0]))));
					__debugInfo = "627:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2020 = 1;
					__debugInfo = "624:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver8394.values[forEachCounter8394] = local1_D_2021;
					
					forEachCounter8394++
					__pc = 8370; break; //back jump
					
				case 8366: //dummy for
					;
						
					__debugInfo = "629:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("], "))) + (func21_JSGetDefaultValue_Str(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0].attr8_datatype, local6_hasRef_2019, 1)))) + (" )"));
					__debugInfo = "617:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8314: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(15))) ? 1 : 0))) { __pc = 8414; break; }
					
					var local4_cast_2022 = 0;
					case 8418:
						__debugInfo = "632:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local4_cast_2022 = 1;
						
					case 8475:
						__debugInfo = "644:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr3_Typ) == (4)) ? 1 : 0))) { __pc = 8429; break; }
					
					var local5_f_Str_2023 = "";
					case 8434:
						__debugInfo = "634:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local4_cast_2022 = 0;
						
					__debugInfo = "636:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_f_Str_2023 = ((CAST2STRING(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr8_floatval)) + (""));
					__debugInfo = "636:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
					var local1_i_2024 = 0.0;
					case 8474:
						__debugInfo = "643:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_i_2024 = 0
					
				case 8452: //dummy for1
					if (!toCheck(local1_i_2024, (((local5_f_Str_2023).length) - (1)), 1)) {__pc = 8459; break;}
					
					case 8473:
						__debugInfo = "642:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((ASC(local5_f_Str_2023, ~~(local1_i_2024))) == (ASC(".", 0))) ? 1 : 0))) { __pc = 8467; break; }
					
					case 8471:
						__debugInfo = "640:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local4_cast_2022 = 1;
						
					case 8472:
						__debugInfo = "641:\src\CompilerPasses\Generator\JSGenerator.gbas";
						__pc = 8459; break;
						
					__debugInfo = "640:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8467: //dummy jumper1
					;
						
					__debugInfo = "642:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_2024 += 1;
					__pc = 8452; break; //back jump
					
				case 8459: //dummy for
					;
						
					__debugInfo = "643:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
					__debugInfo = "634:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8429: //dummy jumper1
					;
						
					case 8565:
						__debugInfo = "660:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local4_cast_2022)) { __pc = 8477; break; }
					
					case 8488:
						__debugInfo = "647:\src\CompilerPasses\Generator\JSGenerator.gbas";
						
					var local17___SelectHelper10__2025 = "";
					case 8490:
						__debugInfo = "647:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local17___SelectHelper10__2025 = global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0];
						
					case 8553:
						__debugInfo = "657:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local17___SelectHelper10__2025) == ("int")) ? 1 : 0))) { __pc = 8492; break; }
					
					case 8503:
						__debugInfo = "650:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "650:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29002;
					break;
					
				case 8492: //dummy jumper1
					if (!((((local17___SelectHelper10__2025) == ("float")) ? 1 : 0))) { __pc = 8505; break; }
					
					case 8520:
						__debugInfo = "652:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("~~("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "652:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29002;
					break;
					
				case 8505: //dummy jumper1
					if (!((((local17___SelectHelper10__2025) == ("string")) ? 1 : 0))) { __pc = 8522; break; }
					
					case 8537:
						__debugInfo = "654:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("INT2STR("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "654:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29002;
					break;
					
				case 8522: //dummy jumper1
					
					case 8552:
						__debugInfo = "656:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("CAST2INT("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "656:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29002: //dummy jumper2
					;
						
					__debugInfo = "647:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
						
					__debugInfo = "647:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29001;
					break;
					
				case 8477: //dummy jumper1
					
					case 8564:
						__debugInfo = "659:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "659:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29001: //dummy jumper2
					;
						
					__debugInfo = "632:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8414: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(16))) ? 1 : 0))) { __pc = 8567; break; }
					
					case 8662:
						__debugInfo = "678:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0))) { __pc = 8578; break; }
					
					case 8589:
						__debugInfo = "664:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "664:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29003;
					break;
					
				case 8578: //dummy jumper1
					
					case 8600:
						__debugInfo = "666:\src\CompilerPasses\Generator\JSGenerator.gbas";
						
					var local17___SelectHelper11__2026 = "";
					case 8602:
						__debugInfo = "666:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local17___SelectHelper11__2026 = global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0];
						
					case 8661:
						__debugInfo = "677:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local17___SelectHelper11__2026) == ("int")) ? 1 : 0))) { __pc = 8604; break; }
					
					case 8615:
						__debugInfo = "669:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "669:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29004;
					break;
					
				case 8604: //dummy jumper1
					if (!((((local17___SelectHelper11__2026) == ("float")) ? 1 : 0))) { __pc = 8617; break; }
					
					case 8628:
						__debugInfo = "672:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "672:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29004;
					break;
					
				case 8617: //dummy jumper1
					if (!((((local17___SelectHelper11__2026) == ("string")) ? 1 : 0))) { __pc = 8630; break; }
					
					case 8645:
						__debugInfo = "674:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("FLOAT2STR("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "674:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29004;
					break;
					
				case 8630: //dummy jumper1
					
					case 8660:
						__debugInfo = "676:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("CAST2FLOAT("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "676:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29004: //dummy jumper2
					;
						
					__debugInfo = "666:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
						
					__debugInfo = "666:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29003: //dummy jumper2
					;
						
					__debugInfo = "678:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8567: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(17))) ? 1 : 0))) { __pc = 8664; break; }
					
					case 8679:
						__debugInfo = "680:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("CAST2STRING("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "680:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8664: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(18))) ? 1 : 0))) { __pc = 8681; break; }
					
					case 8701:
						__debugInfo = "682:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + ("."))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_nextExpr).values[tmpPositionCache][0]))));
						
					__debugInfo = "682:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8681: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(19))) ? 1 : 0))) { __pc = 8703; break; }
					
					var local1_F_2027 = 0;
					case 8708:
						__debugInfo = "684:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_F_2027 = 0;
						
					__debugInfo = "685:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
					var local17___SelectHelper12__2028 = 0;
					case 8719:
						__debugInfo = "685:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local17___SelectHelper12__2028 = global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr3_Typ;
						
					case 8738:
						__debugInfo = "692:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local17___SelectHelper12__2028) == (~~(3))) ? 1 : 0))) { __pc = 8721; break; }
					
					case 8725:
						__debugInfo = "687:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_F_2027 = 1;
						
					__debugInfo = "687:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8721: //dummy jumper1
					if (!((((local17___SelectHelper12__2028) == (~~(4))) ? 1 : 0))) { __pc = 8727; break; }
					
					case 8731:
						__debugInfo = "689:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_F_2027 = 1;
						
					__debugInfo = "689:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8727: //dummy jumper1
					if (!((((local17___SelectHelper12__2028) == (~~(5))) ? 1 : 0))) { __pc = 8733; break; }
					
					case 8737:
						__debugInfo = "691:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_F_2027 = 1;
						
					__debugInfo = "691:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8733: //dummy jumper1
					;
						
					__debugInfo = "685:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
					case 8765:
						__debugInfo = "698:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local1_F_2027)) { __pc = 8740; break; }
					
					case 8751:
						__debugInfo = "695:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("return "))) + (func14_JSTryUnref_Str(param4_expr.attr4_expr)));
						
					__debugInfo = "695:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29006;
					break;
					
				case 8740: //dummy jumper1
					
					case 8764:
						__debugInfo = "697:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("return tryClone("))) + (func14_JSTryUnref_Str(param4_expr.attr4_expr)))) + (")"));
						
					__debugInfo = "697:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29006: //dummy jumper2
					;
						
					__debugInfo = "684:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8703: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(22))) ? 1 : 0))) { __pc = 8767; break; }
					
					var local8_Name_Str_2029 = "", local5_Found_2030 = 0;
					case 8778:
						__debugInfo = "706:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Name_Str_2029 = REPLACE_Str(unref(param4_expr.attr8_datatype.attr8_Name_Str_ref[0]), "$", "_Str");
						
					case 8807:
						__debugInfo = "714:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver8807 = global8_Compiler.attr5_Funcs_ref[0];
					var forEachCounter8807 = 0
					
				case 8786: //dummy for1
					if (!(forEachCounter8807 < forEachSaver8807.values.length)) {__pc = 8782; break;}
					var local4_Func_ref_2031 = forEachSaver8807.values[forEachCounter8807];
					
					
					case 8806:
						__debugInfo = "713:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local4_Func_ref_2031[0].attr9_OName_Str) == (local8_Name_Str_2029)) ? 1 : 0))) { __pc = 8793; break; }
					
					case 8801:
						__debugInfo = "710:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local4_Func_ref_2031[0].attr8_Name_Str));
						
					__debugInfo = "711:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_Found_2030 = 1;
					case 8805:
						__debugInfo = "712:\src\CompilerPasses\Generator\JSGenerator.gbas";
						__pc = 8782; break;
						
					__debugInfo = "710:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8793: //dummy jumper1
					;
						
					__debugInfo = "713:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver8807.values[forEachCounter8807] = local4_Func_ref_2031;
					
					forEachCounter8807++
					__pc = 8786; break; //back jump
					
				case 8782: //dummy for
					;
						
					case 8817:
						__debugInfo = "715:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((local5_Found_2030) ? 0 : 1))) { __pc = 8810; break; }
					
					case 8816:
						__debugInfo = "715:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local8_Name_Str_2029));
						
					__debugInfo = "715:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8810: //dummy jumper1
					;
						
					__debugInfo = "706:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8767: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(24))) ? 1 : 0))) { __pc = 8819; break; }
					
					case 9082:
						__debugInfo = "809:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 8822; break; }
					
					var local5_dummy_2032 = 0;
					case 8826:
						__debugInfo = "718:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_dummy_2032 = global11_LastDummyID;
						
					__debugInfo = "719:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LastDummyID+=1;
					__debugInfo = "720:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
					var local1_i_2033 = 0.0;
					case 8943:
						__debugInfo = "736:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_i_2033 = 0
					
				case 8835: //dummy for1
					if (!toCheck(local1_i_2033, ((BOUNDS(param4_expr.attr10_Conditions, 0)) - (1)), 1)) {__pc = 8846; break;}
					
					case 8876:
						__debugInfo = "722:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("if (!("))) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr10_Conditions.arrAccess(~~(local1_i_2033)).values[tmpPositionCache]).values[tmpPositionCache][0]))))) + (")) { __pc = "))) + (CAST2STRING(param4_expr.attr10_Conditions.arrAccess(~~(local1_i_2033)).values[tmpPositionCache])))) + ("; break; }"))) + (func11_NewLine_Str()));
						
					__debugInfo = "725:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_Scopes.arrAccess(~~(local1_i_2033)).values[tmpPositionCache]).values[tmpPositionCache][0]))));
					case 8918:
						__debugInfo = "731:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((param4_expr.attr9_elseScope) != (-(1))) ? 1 : 0))) { __pc = 8897; break; }
					
					case 8910:
						__debugInfo = "729:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(local5_dummy_2032)))) + (";"))) + (func11_NewLine_Str()));
						
					__debugInfo = "730:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("break;"))) + (func11_NewLine_Str()));
					__debugInfo = "729:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8897: //dummy jumper1
					;
						
					__debugInfo = "732:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "733:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "734:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "735:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(param4_expr.attr10_Conditions.arrAccess(~~(local1_i_2033)).values[tmpPositionCache])))) + (": //dummy jumper1"))) + (func11_NewLine_Str()));
					__debugInfo = "722:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_2033 += 1;
					__pc = 8835; break; //back jump
					
				case 8846: //dummy for
					;
						
					__debugInfo = "736:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
					case 8982:
						__debugInfo = "745:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((param4_expr.attr9_elseScope) != (-(1))) ? 1 : 0))) { __pc = 8951; break; }
					
					case 8962:
						__debugInfo = "739:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr9_elseScope).values[tmpPositionCache][0]))));
						
					__debugInfo = "741:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "742:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "743:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "744:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(local5_dummy_2032)))) + (": //dummy jumper2"))) + (func11_NewLine_Str()));
					__debugInfo = "739:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 8951: //dummy jumper1
					;
						
					__debugInfo = "718:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29009;
					break;
					
				case 8822: //dummy jumper1
					
					var local8_IsSwitch_2034 = 0;
					case 8987:
						__debugInfo = "749:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_IsSwitch_2034 = 0;
						
					case 9081:
						__debugInfo = "808:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local8_IsSwitch_2034)) { __pc = 8990; break; }
					
					
					__pc = 29012;
					break;
					
				case 8990: //dummy jumper1
					
					case 8993:
						__debugInfo = "795:\src\CompilerPasses\Generator\JSGenerator.gbas";
						
					var local1_i_2035 = 0.0;
					case 9058:
						__debugInfo = "804:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_i_2035 = 0
					
				case 8997: //dummy for1
					if (!toCheck(local1_i_2035, ((BOUNDS(param4_expr.attr10_Conditions, 0)) - (1)), 1)) {__pc = 9008; break;}
					
					case 9027:
						__debugInfo = "801:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local1_i_2035) == (0)) ? 1 : 0))) { __pc = 9014; break; }
					
					case 9020:
						__debugInfo = "798:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("if"));
						
					__debugInfo = "798:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29013;
					break;
					
				case 9014: //dummy jumper1
					
					case 9026:
						__debugInfo = "800:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (" else if"));
						
					__debugInfo = "800:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29013: //dummy jumper2
					;
						
					__debugInfo = "802:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + (" ("))) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr10_Conditions.arrAccess(~~(local1_i_2035)).values[tmpPositionCache]).values[tmpPositionCache][0]))))) + (") "));
					__debugInfo = "803:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_Scopes.arrAccess(~~(local1_i_2035)).values[tmpPositionCache]).values[tmpPositionCache][0]))));
					__debugInfo = "801:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_2035 += 1;
					__pc = 8997; break; //back jump
					
				case 9008: //dummy for
					;
						
					__debugInfo = "804:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
						
					case 9080:
						__debugInfo = "807:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((param4_expr.attr9_elseScope) != (-(1))) ? 1 : 0))) { __pc = 9066; break; }
					
					case 9079:
						__debugInfo = "806:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (" else "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr9_elseScope).values[tmpPositionCache][0]))));
						
					__debugInfo = "806:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 9066: //dummy jumper1
					;
						
					__debugInfo = "795:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29012: //dummy jumper2
					;
						
					__debugInfo = "749:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29009: //dummy jumper2
					;
						
					__debugInfo = "809:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 8819: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(25))) ? 1 : 0))) { __pc = 9084; break; }
					
					case 9203:
						__debugInfo = "831:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9087; break; }
					
					var local6_TmpBID_2036 = 0, local6_TmpCID_2037 = 0;
					case 9091:
						__debugInfo = "812:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_TmpBID_2036 = global11_LoopBreakID;
						
					__debugInfo = "813:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_TmpCID_2037 = global14_LoopContinueID;
					__debugInfo = "814:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = global11_LastDummyID;
					__debugInfo = "815:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = param4_expr.attr2_ID;
					__debugInfo = "816:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LastDummyID+=1;
					__debugInfo = "818:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("if (!("))) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")) {__pc = "))) + (CAST2STRING(global11_LoopBreakID)))) + ("; break;}"))) + (func11_NewLine_Str()));
					__debugInfo = "819:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "820:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(param4_expr.attr2_ID)))) + ("; break; //back jump"))) + (func11_NewLine_Str()));
					__debugInfo = "821:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "822:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "823:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "824:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(global11_LoopBreakID)))) + (":"))) + (func11_NewLine_Str()));
					__debugInfo = "826:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = local6_TmpBID_2036;
					__debugInfo = "827:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = local6_TmpCID_2037;
					__debugInfo = "812:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29015;
					break;
					
				case 9087: //dummy jumper1
					
					case 9192:
						__debugInfo = "829:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("while ("))) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (") "));
						
					__debugInfo = "830:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "829:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29015: //dummy jumper2
					;
						
					__debugInfo = "831:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9084: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(26))) ? 1 : 0))) { __pc = 9205; break; }
					
					case 9329:
						__debugInfo = "855:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9208; break; }
					
					var local6_TmpBID_2038 = 0, local6_TmpCID_2039 = 0;
					case 9212:
						__debugInfo = "834:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_TmpBID_2038 = global11_LoopBreakID;
						
					__debugInfo = "835:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_TmpCID_2039 = global14_LoopContinueID;
					__debugInfo = "837:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = global11_LastDummyID;
					__debugInfo = "838:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = param4_expr.attr2_ID;
					__debugInfo = "839:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LastDummyID+=1;
					__debugInfo = "841:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "842:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("if ("))) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (") {__pc = "))) + (CAST2STRING(global11_LoopBreakID)))) + ("; break;}"))) + (func11_NewLine_Str()));
					__debugInfo = "843:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(param4_expr.attr2_ID)))) + ("; break; //back jump"))) + (func11_NewLine_Str()));
					__debugInfo = "844:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "845:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "846:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "847:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(global11_LoopBreakID)))) + (": //dummy repeat"))) + (func11_NewLine_Str()));
					__debugInfo = "849:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = local6_TmpBID_2038;
					__debugInfo = "850:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = local6_TmpCID_2039;
					__debugInfo = "834:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29016;
					break;
					
				case 9208: //dummy jumper1
					
					case 9304:
						__debugInfo = "852:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("do "));
						
					__debugInfo = "853:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func23_ConditionJSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "854:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + (" while (!("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + ("))"));
					__debugInfo = "852:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29016: //dummy jumper2
					;
						
					__debugInfo = "855:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9205: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(27))) ? 1 : 0))) { __pc = 9331; break; }
					
					var local13_CheckComm_Str_2040 = "";
					case 9346:
						__debugInfo = "862:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(param4_expr.attr5_hasTo)) { __pc = 9337; break; }
					
					case 9341:
						__debugInfo = "859:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local13_CheckComm_Str_2040 = "toCheck";
						
					__debugInfo = "859:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29017;
					break;
					
				case 9337: //dummy jumper1
					
					case 9345:
						__debugInfo = "861:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local13_CheckComm_Str_2040 = "untilCheck";
						
					__debugInfo = "861:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29017: //dummy jumper2
					;
						
					case 9610:
						__debugInfo = "891:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9348; break; }
					
					var local6_TmpBID_2041 = 0, local6_TmpCID_2042 = 0;
					case 9352:
						__debugInfo = "864:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_TmpBID_2041 = global11_LoopBreakID;
						
					__debugInfo = "865:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_TmpCID_2042 = global14_LoopContinueID;
					__debugInfo = "867:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = param4_expr.attr8_stepExpr;
					__debugInfo = "868:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = param4_expr.attr7_varExpr;
					__debugInfo = "870:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0]))))) + (func11_NewLine_Str()));
					__debugInfo = "871:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "872:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "873:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "874:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(param4_expr.attr7_varExpr)))) + (": //dummy for1"))) + (func11_NewLine_Str()));
					__debugInfo = "877:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((((((((((((((local8_Text_Str_1972) + ("if (!"))) + (local13_CheckComm_Str_2040))) + ("("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0].attr4_vari).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_toExpr).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_stepExpr).values[tmpPositionCache][0]))))) + (")) {__pc = "))) + (CAST2STRING(param4_expr.attr8_stepExpr)))) + ("; break;}"))) + (func11_NewLine_Str()));
					__debugInfo = "878:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "879:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0].attr4_vari).values[tmpPositionCache][0]))))) + (" += "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_stepExpr).values[tmpPositionCache][0]))))) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "880:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(param4_expr.attr7_varExpr)))) + ("; break; //back jump"))) + (func11_NewLine_Str()));
					__debugInfo = "881:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "882:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "883:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "884:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(param4_expr.attr8_stepExpr)))) + (": //dummy for"))) + (func11_NewLine_Str()));
					__debugInfo = "886:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = local6_TmpBID_2041;
					__debugInfo = "887:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = local6_TmpCID_2042;
					__debugInfo = "864:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29018;
					break;
					
				case 9348: //dummy jumper1
					
					case 9599:
						__debugInfo = "889:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((((((((((((((((((((local8_Text_Str_1972) + ("for ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0]))))) + (";"))) + (local13_CheckComm_Str_2040))) + ("("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0].attr4_vari).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_toExpr).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_stepExpr).values[tmpPositionCache][0]))))) + (");"))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0].attr4_vari).values[tmpPositionCache][0]))))) + (" += "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_stepExpr).values[tmpPositionCache][0]))))) + (") "));
						
					__debugInfo = "890:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "889:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29018: //dummy jumper2
					;
						
					__debugInfo = "862:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9331: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(38))) ? 1 : 0))) { __pc = 9612; break; }
					
					var local1_c_2043 = 0, local11_varName_Str_2044 = "", local13_StartText_Str_2045 = "", local12_CondText_Str_2046 = "", local11_IncText_Str_2047 = "", local13_EachBegin_Str_2048 = "", local11_EachEnd_Str_2049 = "";
					case 9618:
						__debugInfo = "893:\src\CompilerPasses\Generator\JSGenerator.gbas";
						global14_ForEachCounter = param4_expr.attr2_ID;
						
					__debugInfo = "894:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_c_2043 = global14_ForEachCounter;
					__debugInfo = "895:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("var forEachSaver"))) + (CAST2STRING(local1_c_2043)))) + (" = "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_inExpr).values[tmpPositionCache][0]))))) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "896:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local11_varName_Str_2044 = func16_JSRemoveLast_Str(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr7_varExpr).values[tmpPositionCache][0])), "[0]");
					__debugInfo = "897:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local13_StartText_Str_2045 = (((("var forEachCounter") + (CAST2STRING(local1_c_2043)))) + (" = 0"));
					__debugInfo = "898:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local12_CondText_Str_2046 = (((((((("forEachCounter") + (CAST2STRING(local1_c_2043)))) + (" < forEachSaver"))) + (CAST2STRING(local1_c_2043)))) + (".values.length"));
					__debugInfo = "899:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local11_IncText_Str_2047 = (((("forEachCounter") + (CAST2STRING(local1_c_2043)))) + ("++"));
					__debugInfo = "900:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local13_EachBegin_Str_2048 = (((((((((((((("var ") + (local11_varName_Str_2044))) + (" = forEachSaver"))) + (CAST2STRING(local1_c_2043)))) + (".values[forEachCounter"))) + (CAST2STRING(local1_c_2043)))) + ("];"))) + (func11_NewLine_Str()));
					__debugInfo = "901:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local11_EachEnd_Str_2049 = (((((((((((((("forEachSaver") + (CAST2STRING(local1_c_2043)))) + (".values[forEachCounter"))) + (CAST2STRING(local1_c_2043)))) + ("] = "))) + (local11_varName_Str_2044))) + (";"))) + (func11_NewLine_Str()));
					case 9916:
						__debugInfo = "937:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9727; break; }
					
					var local6_TmpBID_2050 = 0, local6_TmpCID_2051 = 0;
					case 9731:
						__debugInfo = "903:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local6_TmpBID_2050 = global11_LoopBreakID;
						
					__debugInfo = "904:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local6_TmpCID_2051 = global14_LoopContinueID;
					__debugInfo = "906:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = param4_expr.attr7_varExpr;
					__debugInfo = "907:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = param4_expr.attr6_inExpr;
					__debugInfo = "909:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (local13_StartText_Str_2045))) + (func11_NewLine_Str()));
					__debugInfo = "910:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "911:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "912:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "913:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(param4_expr.attr6_inExpr)))) + (": //dummy for1"))) + (func11_NewLine_Str()));
					__debugInfo = "916:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("if (!("))) + (local12_CondText_Str_2046))) + (")) {__pc = "))) + (CAST2STRING(param4_expr.attr7_varExpr)))) + ("; break;}"))) + (func11_NewLine_Str()));
					__debugInfo = "917:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (local13_EachBegin_Str_2048))) + (func11_NewLine_Str()));
					__debugInfo = "918:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "919:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (local11_EachEnd_Str_2049))) + (func11_NewLine_Str()));
					__debugInfo = "920:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (local11_IncText_Str_2047))) + (func11_NewLine_Str()));
					__debugInfo = "921:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(param4_expr.attr6_inExpr)))) + ("; break; //back jump"))) + (func11_NewLine_Str()));
					__debugInfo = "922:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "923:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func11_NewLine_Str()));
					__debugInfo = "924:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "925:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("case "))) + (CAST2STRING(param4_expr.attr7_varExpr)))) + (": //dummy for"))) + (func11_NewLine_Str()));
					__debugInfo = "927:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global11_LoopBreakID = local6_TmpBID_2050;
					__debugInfo = "928:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global14_LoopContinueID = local6_TmpCID_2051;
					__debugInfo = "903:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29019;
					break;
					
				case 9727: //dummy jumper1
					
					case 9866:
						__debugInfo = "930:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_IndentUp();
						
					__debugInfo = "931:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((((((local8_Text_Str_1972) + ("for("))) + (local13_StartText_Str_2045))) + (" ; "))) + (local12_CondText_Str_2046))) + (" ; "))) + (local11_IncText_Str_2047))) + (") {"))) + (func11_NewLine_Str()));
					__debugInfo = "932:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local13_EachBegin_Str_2048));
					__debugInfo = "933:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))))) + (func11_NewLine_Str()));
					__debugInfo = "934:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (local11_EachEnd_Str_2049));
					__debugInfo = "935:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "936:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("}"));
					__debugInfo = "930:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29019: //dummy jumper2
					;
						
					__debugInfo = "893:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9612: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(30))) ? 1 : 0))) { __pc = 9918; break; }
					
					case 9939:
						__debugInfo = "943:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9921; break; }
					
					case 9932:
						__debugInfo = "940:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(global14_LoopContinueID)))) + ("; break"));
						
					__debugInfo = "940:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29020;
					break;
					
				case 9921: //dummy jumper1
					
					case 9938:
						__debugInfo = "942:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("continue"));
						
					__debugInfo = "942:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29020: //dummy jumper2
					;
						
					__debugInfo = "943:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9918: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(29))) ? 1 : 0))) { __pc = 9941; break; }
					
					case 9962:
						__debugInfo = "949:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(global8_IsInGoto)) { __pc = 9944; break; }
					
					case 9955:
						__debugInfo = "946:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("__pc = "))) + (CAST2STRING(global11_LoopBreakID)))) + ("; break"));
						
					__debugInfo = "946:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29021;
					break;
					
				case 9944: //dummy jumper1
					
					case 9961:
						__debugInfo = "948:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("break"));
						
					__debugInfo = "948:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29021: //dummy jumper2
					;
						
					__debugInfo = "949:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9941: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(31))) ? 1 : 0))) { __pc = 9964; break; }
					
					var local9_oIsInGoto_2052 = 0;
					case 9968:
						__debugInfo = "951:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local9_oIsInGoto_2052 = global8_IsInGoto;
						
					__debugInfo = "952:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global8_IsInGoto = 0;
					__debugInfo = "954:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("try "));
					__debugInfo = "955:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr3_Scp).values[tmpPositionCache][0]))));
					__debugInfo = "956:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func8_IndentUp();
					__debugInfo = "957:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + (" catch ("))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (") {"))) + (func11_NewLine_Str()));
					__debugInfo = "958:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((((((((local8_Text_Str_1972) + ("if ("))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (" instanceof OTTException) "))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (" = "))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (".getText(); else throwError("))) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (");"));
					__debugInfo = "959:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_catchScp).values[tmpPositionCache][0]))));
					__debugInfo = "960:\src\CompilerPasses\Generator\JSGenerator.gbas";
					func10_IndentDown();
					__debugInfo = "961:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func11_NewLine_Str()))) + ("}"));
					__debugInfo = "964:\src\CompilerPasses\Generator\JSGenerator.gbas";
					global8_IsInGoto = local9_oIsInGoto_2052;
					__debugInfo = "951:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 9964: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(32))) ? 1 : 0))) { __pc = 10084; break; }
					
					case 10124:
						__debugInfo = "965:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((((local8_Text_Str_1972) + ("throw new OTTException("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (", \""))) + (global8_Compiler.attr6_Tokens.arrAccess(param4_expr.attr5_tokID).values[tmpPositionCache].attr8_Path_Str_ref[0]))) + ("\", "))) + (CAST2STRING(global8_Compiler.attr6_Tokens.arrAccess(param4_expr.attr5_tokID).values[tmpPositionCache].attr4_Line_ref[0])))) + (")"));
						
					__debugInfo = "965:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10084: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(33))) ? 1 : 0))) { __pc = 10126; break; }
					
					case 10138:
						__debugInfo = "968:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("RESTORE(datablock_"))) + (param4_expr.attr8_Name_Str))) + (")"));
						
					__debugInfo = "968:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10126: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(34))) ? 1 : 0))) { __pc = 10140; break; }
					
					var local1_i_2053 = 0.0;
					case 10145:
						__debugInfo = "970:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local1_i_2053 = 0;
						
					case 10188:
						__debugInfo = "975:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver10188 = param4_expr.attr5_Reads;
					var forEachCounter10188 = 0
					
				case 10152: //dummy for1
					if (!(forEachCounter10188 < forEachSaver10188.values.length)) {__pc = 10148; break;}
					var local1_R_2054 = forEachSaver10188.values[forEachCounter10188];
					
					
					case 10163:
						__debugInfo = "972:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_R_2054).values[tmpPositionCache][0]))))) + (" = READ()"));
						
					case 10184:
						__debugInfo = "973:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local1_i_2053) < (((BOUNDS(param4_expr.attr5_Reads, 0)) - (1)))) ? 1 : 0))) { __pc = 10175; break; }
					
					case 10183:
						__debugInfo = "973:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (";"))) + (func11_NewLine_Str()));
						
					__debugInfo = "973:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 10175: //dummy jumper1
					;
						
					__debugInfo = "974:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_i_2053+=1;
					__debugInfo = "972:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver10188.values[forEachCounter10188] = local1_R_2054;
					
					forEachCounter10188++
					__pc = 10152; break; //back jump
					
				case 10148: //dummy for
					;
						
					__debugInfo = "970:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10140: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(35))) ? 1 : 0))) { __pc = 10190; break; }
					
					case 10201:
						__debugInfo = "977:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func21_JSGetDefaultValue_Str(param4_expr.attr8_datatype, 0, 0)));
						
					__debugInfo = "977:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10190: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(36))) ? 1 : 0))) { __pc = 10203; break; }
					
					var local4_Find_2055 = 0;
					case 10209:
						__debugInfo = "979:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("DIM(new OTTArray(), ["));
						
					__debugInfo = "980:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2055 = 0;
					case 10244:
						__debugInfo = "986:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver10244 = param4_expr.attr4_dims;
					var forEachCounter10244 = 0
					
				case 10220: //dummy for1
					if (!(forEachCounter10244 < forEachSaver10244.values.length)) {__pc = 10216; break;}
					var local1_D_2056 = forEachSaver10244.values[forEachCounter10244];
					
					
					case 10232:
						__debugInfo = "982:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((local4_Find_2055) == (1)) ? 1 : 0))) { __pc = 10225; break; }
					
					case 10231:
						__debugInfo = "982:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (", "));
						
					__debugInfo = "982:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 10225: //dummy jumper1
					;
						
					__debugInfo = "983:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local1_D_2056).values[tmpPositionCache][0]))));
					__debugInfo = "985:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2055 = 1;
					__debugInfo = "982:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver10244.values[forEachCounter10244] = local1_D_2056;
					
					forEachCounter10244++
					__pc = 10220; break; //back jump
					
				case 10216: //dummy for
					;
						
					__debugInfo = "987:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("], "))) + (func21_JSGetDefaultValue_Str(param4_expr.attr8_datatype, 1, 1)))) + (")"));
					__debugInfo = "979:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10203: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(37))) ? 1 : 0))) { __pc = 10260; break; }
					
					case 10276:
						__debugInfo = "989:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0].attr8_Name_Str))) + (" = "));
						
					case 10332:
						__debugInfo = "994:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr3_Typ) == (54)) ? 1 : 0))) { __pc = 10286; break; }
					
					case 10319:
						__debugInfo = "991:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("castobj("))) + (func16_JSRemoveLast_Str(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr4_expr).values[tmpPositionCache][0])), "[0]")))) + (", "))) + (func18_ChangeTypeName_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))))) + (")"));
						
					__debugInfo = "991:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29024;
					break;
					
				case 10286: //dummy jumper1
					
					case 10331:
						__debugInfo = "993:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func16_JSRemoveLast_Str(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0])), "[0]")));
						
					__debugInfo = "993:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29024: //dummy jumper2
					;
						
					__debugInfo = "996:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (" /* ALIAS */"));
					__debugInfo = "989:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10260: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(20))) ? 1 : 0))) { __pc = 10339; break; }
					
					case 10351:
						__debugInfo = "998:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("__pc = __labels[\""))) + (param4_expr.attr8_Name_Str))) + ("\"]; break"));
						
					__debugInfo = "998:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10339: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(21))) ? 1 : 0))) { __pc = 10353; break; }
					
					case 10372:
						__debugInfo = "1000:\src\CompilerPasses\Generator\JSGenerator.gbas";
						global12_LabelDef_Str = ((((((((((global12_LabelDef_Str) + ("\""))) + (param4_expr.attr8_Name_Str))) + ("\": "))) + (CAST2STRING(param4_expr.attr2_ID)))) + (", "));
						
					__debugInfo = "1002:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("//label: "))) + (param4_expr.attr8_Name_Str));
					__debugInfo = "1000:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10353: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(39))) ? 1 : 0))) { __pc = 10383; break; }
					
					case 10403:
						__debugInfo = "1004:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0]))))) + ("+="))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
						
					__debugInfo = "1004:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10383: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(40))) ? 1 : 0))) { __pc = 10405; break; }
					
					case 10430:
						__debugInfo = "1006:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("DIMPUSH("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_vari).values[tmpPositionCache][0]))))) + (", "))) + (func16_JSRemoveLast_Str(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0])), "[0]")))) + (")"));
						
					__debugInfo = "1006:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10405: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(41))) ? 1 : 0))) { __pc = 10432; break; }
					
					case 10481:
						__debugInfo = "1012:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((param4_expr.attr4_kern) != (-(1))) ? 1 : 0))) { __pc = 10441; break; }
					
					case 10465:
						__debugInfo = "1009:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("KERNLEN("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_kern).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "1009:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 29025;
					break;
					
				case 10441: //dummy jumper1
					
					case 10480:
						__debugInfo = "1011:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (").length"));
						
					__debugInfo = "1011:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 29025: //dummy jumper2
					;
						
					__debugInfo = "1012:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10432: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(45))) ? 1 : 0))) { __pc = 10483; break; }
					
					case 10507:
						__debugInfo = "1014:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("BOUNDS("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_position).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "1014:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10483: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(42))) ? 1 : 0))) { __pc = 10509; break; }
					
					var local4_Find_2057 = 0;
					case 10524:
						__debugInfo = "1016:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("DIMDATA("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0]))))) + (", ["));
						
					case 10553:
						__debugInfo = "1024:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver10553 = param4_expr.attr5_Exprs;
					var forEachCounter10553 = 0
					
				case 10531: //dummy for1
					if (!(forEachCounter10553 < forEachSaver10553.values.length)) {__pc = 10527; break;}
					var local4_Elem_2058 = forEachSaver10553.values[forEachCounter10553];
					
					
					case 10541:
						__debugInfo = "1019:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(local4_Find_2057)) { __pc = 10534; break; }
					
					case 10540:
						__debugInfo = "1019:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (", "));
						
					__debugInfo = "1019:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 10534: //dummy jumper1
					;
						
					__debugInfo = "1021:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local4_Elem_2058).values[tmpPositionCache][0]))));
					__debugInfo = "1023:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2057 = 1;
					__debugInfo = "1019:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver10553.values[forEachCounter10553] = local4_Elem_2058;
					
					forEachCounter10553++
					__pc = 10531; break; //back jump
					
				case 10527: //dummy for
					;
						
					__debugInfo = "1025:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("])"));
					__debugInfo = "1016:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10509: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(43))) ? 1 : 0))) { __pc = 10560; break; }
					
					case 10568:
						__debugInfo = "1027:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((local8_Text_Str_1972) + ("//DELETE!!111"))) + (func11_NewLine_Str()));
						
					__debugInfo = "1028:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((((((local8_Text_Str_1972) + ("forEachSaver"))) + (CAST2STRING(global14_ForEachCounter)))) + (".values[forEachCounter"))) + (CAST2STRING(global14_ForEachCounter)))) + ("] = "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(global14_ForEachCounter).values[tmpPositionCache][0].attr7_varExpr).values[tmpPositionCache][0]))))) + (";"))) + (func11_NewLine_Str()));
					__debugInfo = "1029:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((((local8_Text_Str_1972) + ("DIMDEL(forEachSaver"))) + (CAST2STRING(global14_ForEachCounter)))) + (", forEachCounter"))) + (CAST2STRING(global14_ForEachCounter)))) + (");"))) + (func11_NewLine_Str()));
					__debugInfo = "1030:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((local8_Text_Str_1972) + ("forEachCounter"))) + (CAST2STRING(global14_ForEachCounter)))) + ("--;"))) + (func11_NewLine_Str()));
					__debugInfo = "1031:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((local8_Text_Str_1972) + ("continue"));
					__debugInfo = "1027:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10560: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(44))) ? 1 : 0))) { __pc = 10632; break; }
					
					case 10656:
						__debugInfo = "1033:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("DIMDEL("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_array).values[tmpPositionCache][0]))))) + (", "))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr8_position).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "1033:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10632: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(46))) ? 1 : 0))) { __pc = 10658; break; }
					
					case 10673:
						__debugInfo = "1035:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("(("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (") ? 0 : 1)"));
						
					__debugInfo = "1035:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10658: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(48))) ? 1 : 0))) { __pc = 10675; break; }
					
					case 10689:
						__debugInfo = "1037:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_expr.attr4_func).values[tmpPositionCache][0].attr8_Name_Str));
						
					__debugInfo = "1037:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10675: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(49))) ? 1 : 0))) { __pc = 10691; break; }
					
					var local8_Cond_Str_2059 = "";
					case 10700:
						__debugInfo = "1039:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Cond_Str_2059 = func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]));
						
					__debugInfo = "1040:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("if (!("))) + (local8_Cond_Str_2059))) + (")) throwError(\"AssertException "))) + (REPLACE_Str(local8_Cond_Str_2059, "\"", "'")))) + ("\")"));
					__debugInfo = "1039:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10691: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(50))) ? 1 : 0))) { __pc = 10719; break; }
					
					case 10734:
						__debugInfo = "1042:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("DEBUG("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (")"));
						
					__debugInfo = "1042:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10719: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(51))) ? 1 : 0))) { __pc = 10736; break; }
					
					case 10773:
						__debugInfo = "1044:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((((((local8_Text_Str_1972) + ("(("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr10_Conditions.arrAccess(0).values[tmpPositionCache]).values[tmpPositionCache][0]))))) + (") ? ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr6_Scopes.arrAccess(0).values[tmpPositionCache]).values[tmpPositionCache][0]))))) + (") : ("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr9_elseScope).values[tmpPositionCache][0]))))) + ("))"));
						
					__debugInfo = "1044:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10736: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(52))) ? 1 : 0))) { __pc = 10775; break; }
					
					case 10787:
						__debugInfo = "1046:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("//REQUIRE: "))) + (param4_expr.attr8_Name_Str))) + ("\n"));
						
					__debugInfo = "1047:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((local8_Text_Str_1972) + (param4_expr.attr11_Content_Str))) + (func11_NewLine_Str()));
					__debugInfo = "1048:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_1972 = ((((((local8_Text_Str_1972) + ("//ENDREQUIRE: "))) + (param4_expr.attr8_Name_Str))) + (func11_NewLine_Str()));
					__debugInfo = "1046:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10775: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(53))) ? 1 : 0))) { __pc = 10809; break; }
					
					var local5_Found_2060 = 0, local3_Scp_2061 = 0;
					case 10814:
						__debugInfo = "1050:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local5_Found_2060 = 0;
						
					__debugInfo = "1051:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local3_Scp_2061 = global12_CurrentScope;
					case 10899:
						__debugInfo = "1064:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((((((((local3_Scp_2061) != (-(1))) ? 1 : 0)) && (((((((((global5_Exprs_ref[0].arrAccess(local3_Scp_2061).values[tmpPositionCache][0].attr6_ScpTyp) == (2)) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local3_Scp_2061).values[tmpPositionCache][0].attr6_ScpTyp) == (4)) ? 1 : 0))) ? 1 : 0)) ? 0 : 1))) ? 1 : 0)) && (((local5_Found_2060) ? 0 : 1))) ? 1 : 0))) {__pc = 29027; break;}
					
					var local5_Varis_2062 = new OTTArray(0);
					case 10855:
						__debugInfo = "1054:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func8_GetVaris(unref(local5_Varis_2062), local3_Scp_2061, 0);
						
					case 10891:
						__debugInfo = "1062:\src\CompilerPasses\Generator\JSGenerator.gbas";
						var forEachSaver10891 = local5_Varis_2062;
					var forEachCounter10891 = 0
					
				case 10859: //dummy for1
					if (!(forEachCounter10891 < forEachSaver10891.values.length)) {__pc = 10857; break;}
					var local1_V_2063 = forEachSaver10891.values[forEachCounter10891];
					
					
					var alias3_Var_ref_2064 = [new type14_IdentifierVari()];
					case 10866:
						__debugInfo = "1056:\src\CompilerPasses\Generator\JSGenerator.gbas";
						alias3_Var_ref_2064 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2063).values[tmpPositionCache] /* ALIAS */;
						
					case 10890:
						__debugInfo = "1061:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!((((alias3_Var_ref_2064[0].attr8_Name_Str) == ((("param4_self_") + (CAST2STRING(alias3_Var_ref_2064[0].attr2_ID))))) ? 1 : 0))) { __pc = 10877; break; }
					
					case 10885:
						__debugInfo = "1058:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((local8_Text_Str_1972) + (alias3_Var_ref_2064[0].attr8_Name_Str));
						
					__debugInfo = "1059:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_Found_2060 = 1;
					case 10889:
						__debugInfo = "1060:\src\CompilerPasses\Generator\JSGenerator.gbas";
						__pc = 10857; break;
						
					__debugInfo = "1058:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 10877: //dummy jumper1
					;
						
					__debugInfo = "1056:\src\CompilerPasses\Generator\JSGenerator.gbas";
					forEachSaver10891.values[forEachCounter10891] = local1_V_2063;
					
					forEachCounter10891++
					__pc = 10859; break; //back jump
					
				case 10857: //dummy for
					;
						
					__debugInfo = "1063:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local3_Scp_2061 = global5_Exprs_ref[0].arrAccess(local3_Scp_2061).values[tmpPositionCache][0].attr10_SuperScope;
					__debugInfo = "1054:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 10899; break; //back jump
					
				case 29027:
					;
						
					case 10908:
						__debugInfo = "1065:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (!(((local5_Found_2060) ? 0 : 1))) { __pc = 10902; break; }
					
					case 10907:
						__debugInfo = "1065:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func5_Error("Self not found for super", 1064, "src\CompilerPasses\Generator\JSGenerator.gbas");
						
					__debugInfo = "1065:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 10902: //dummy jumper1
					;
						
					__debugInfo = "1050:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10809: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(54))) ? 1 : 0))) { __pc = 10910; break; }
					
					case 10934:
						__debugInfo = "1068:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_1972 = ((((((((((local8_Text_Str_1972) + ("castobj("))) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))))) + (", "))) + (func18_ChangeTypeName_Str(unref(param4_expr.attr8_datatype.attr8_Name_Str_ref[0]))))) + (")"));
						
					__debugInfo = "1068:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10910: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(7))) ? 1 : 0))) { __pc = 10936; break; }
					
					
					__pc = 28951;
					break;
					
				case 10936: //dummy jumper1
					if (!((((local16___SelectHelper7__1973) == (~~(8))) ? 1 : 0))) { __pc = 10939; break; }
					
					case 10944:
						__debugInfo = "1071:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func5_Error("Invalid Expression", 1070, "src\CompilerPasses\Generator\JSGenerator.gbas");
						
					__debugInfo = "1071:\src\CompilerPasses\Generator\JSGenerator.gbas";
					__pc = 28951;
					break;
					
				case 10939: //dummy jumper1
					
					case 10954:
						__debugInfo = "1073:\src\CompilerPasses\Generator\JSGenerator.gbas";
						func5_Error((("Unknown expression type: ") + (CAST2STRING(param4_expr.attr3_Typ))), 1072, "src\CompilerPasses\Generator\JSGenerator.gbas");
						
					__debugInfo = "1073:\src\CompilerPasses\Generator\JSGenerator.gbas";
					
				case 28951: //dummy jumper2
					;
						
					__debugInfo = "273:\src\CompilerPasses\Generator\JSGenerator.gbas";
					;
				__debugInfo = "1076:\src\CompilerPasses\Generator\JSGenerator.gbas";
				return tryClone(local8_Text_Str_1972);
				__debugInfo = "1077:\src\CompilerPasses\Generator\JSGenerator.gbas";
				return "";
				__debugInfo = "271:\src\CompilerPasses\Generator\JSGenerator.gbas";__pc = -1; break;
				default:
					throwError("Gotocounter exception pc: "+__pc);
				
			}
		}
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_JSGenerate_Str = window['func14_JSGenerate_Str'];
window['func14_JSTryUnref_Str'] = function(param1_E) {
	stackPush("function: JSTryUnref_Str", __debugInfo);
	try {
		__debugInfo = "1084:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if (func11_JSDoesUnref(param1_E)) {
			__debugInfo = "1081:\src\CompilerPasses\Generator\JSGenerator.gbas";
			return tryClone((((("unref(") + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param1_E).values[tmpPositionCache][0]))))) + (")")));
			__debugInfo = "1081:\src\CompilerPasses\Generator\JSGenerator.gbas";
		} else {
			__debugInfo = "1083:\src\CompilerPasses\Generator\JSGenerator.gbas";
			return tryClone(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param1_E).values[tmpPositionCache][0])));
			__debugInfo = "1083:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1085:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1084:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_JSTryUnref_Str = window['func14_JSTryUnref_Str'];
window['func11_JSDoesUnref'] = function(param4_Expr) {
	stackPush("function: JSDoesUnref", __debugInfo);
	try {
		var local5_unref_2067 = 0;
		__debugInfo = "1088:\src\CompilerPasses\Generator\JSGenerator.gbas";
		local5_unref_2067 = 1;
		__debugInfo = "1124:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if (((global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) ? 0 : 1)) {
			__debugInfo = "1092:\src\CompilerPasses\Generator\JSGenerator.gbas";
			{
				var local17___SelectHelper13__2068 = 0;
				__debugInfo = "1092:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local17___SelectHelper13__2068 = global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr3_Typ;
				__debugInfo = "1123:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((local17___SelectHelper13__2068) == (~~(3))) ? 1 : 0)) {
					__debugInfo = "1094:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1094:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(4))) ? 1 : 0)) {
					__debugInfo = "1096:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1096:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(5))) ? 1 : 0)) {
					__debugInfo = "1098:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1098:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(15))) ? 1 : 0)) {
					__debugInfo = "1100:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = func11_JSDoesUnref(global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr4_expr);
					__debugInfo = "1100:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(16))) ? 1 : 0)) {
					__debugInfo = "1102:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = func11_JSDoesUnref(global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr4_expr);
					__debugInfo = "1102:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(17))) ? 1 : 0)) {
					__debugInfo = "1104:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = func11_JSDoesUnref(global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr4_expr);
					__debugInfo = "1104:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(1))) ? 1 : 0)) {
					__debugInfo = "1106:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1106:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(6))) ? 1 : 0)) {
					__debugInfo = "1108:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1108:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(23))) ? 1 : 0)) {
					__debugInfo = "1110:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1110:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(45))) ? 1 : 0)) {
					__debugInfo = "1112:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1112:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper13__2068) == (~~(41))) ? 1 : 0)) {
					__debugInfo = "1114:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local5_unref_2067 = 0;
					__debugInfo = "1114:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else {
					var local1_v_2069 = 0;
					__debugInfo = "1116:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local1_v_2069 = func11_GetVariable(param4_Expr, 0);
					__debugInfo = "1122:\src\CompilerPasses\Generator\JSGenerator.gbas";
					if ((((local1_v_2069) != (-(1))) ? 1 : 0)) {
						__debugInfo = "1121:\src\CompilerPasses\Generator\JSGenerator.gbas";
						if (((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2069).values[tmpPositionCache][0].attr3_ref) ? 0 : 1)) {
							__debugInfo = "1120:\src\CompilerPasses\Generator\JSGenerator.gbas";
							local5_unref_2067 = 0;
							__debugInfo = "1120:\src\CompilerPasses\Generator\JSGenerator.gbas";
						};
						__debugInfo = "1121:\src\CompilerPasses\Generator\JSGenerator.gbas";
					};
					__debugInfo = "1116:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1092:\src\CompilerPasses\Generator\JSGenerator.gbas";
			};
			__debugInfo = "1092:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1125:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return tryClone(local5_unref_2067);
		__debugInfo = "1126:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return 0;
		__debugInfo = "1088:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_JSDoesUnref = window['func11_JSDoesUnref'];
window['func17_JSDoParameter_Str'] = function(param4_expr, param4_func, param7_DoParam) {
	stackPush("function: JSDoParameter_Str", __debugInfo);
	try {
		var local8_Text_Str_2073 = "", local1_i_2074 = 0.0;
		__debugInfo = "1130:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if (param7_DoParam) {
			__debugInfo = "1130:\src\CompilerPasses\Generator\JSGenerator.gbas";
			local8_Text_Str_2073 = "(";
			__debugInfo = "1130:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1131:\src\CompilerPasses\Generator\JSGenerator.gbas";
		local1_i_2074 = 0;
		__debugInfo = "1146:\src\CompilerPasses\Generator\JSGenerator.gbas";
		var forEachSaver11249 = param4_expr.attr6_Params;
		for(var forEachCounter11249 = 0 ; forEachCounter11249 < forEachSaver11249.values.length ; forEachCounter11249++) {
			var local5_param_2075 = forEachSaver11249.values[forEachCounter11249];
		{
				__debugInfo = "1135:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((((((((param4_func) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0))) ? 1 : 0)) && ((((local1_i_2074) == (((BOUNDS(param4_expr.attr6_Params, 0)) - (1)))) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "1135:\src\CompilerPasses\Generator\JSGenerator.gbas";
					break;
					__debugInfo = "1135:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1136:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if (local1_i_2074) {
					__debugInfo = "1136:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_2073 = ((local8_Text_Str_2073) + (", "));
					__debugInfo = "1136:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1143:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((((((((param4_func) != (-(1))) ? 1 : 0)) && (((global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr15_UsedAsPrototype) ? 0 : 1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_i_2074)).values[tmpPositionCache]).values[tmpPositionCache][0].attr3_ref) == (0)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "1140:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_2073 = ((local8_Text_Str_2073) + (func14_JSTryUnref_Str(local5_param_2075)));
					__debugInfo = "1140:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else {
					__debugInfo = "1142:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_2073 = ((local8_Text_Str_2073) + (func16_JSRemoveLast_Str(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(local5_param_2075).values[tmpPositionCache][0])), "[0]")));
					__debugInfo = "1142:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1145:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local1_i_2074+=1;
				__debugInfo = "1135:\src\CompilerPasses\Generator\JSGenerator.gbas";
			}
			forEachSaver11249.values[forEachCounter11249] = local5_param_2075;
		
		};
		__debugInfo = "1147:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if (param7_DoParam) {
			__debugInfo = "1147:\src\CompilerPasses\Generator\JSGenerator.gbas";
			local8_Text_Str_2073 = ((local8_Text_Str_2073) + (")"));
			__debugInfo = "1147:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1148:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return tryClone(local8_Text_Str_2073);
		__debugInfo = "1149:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1130:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func17_JSDoParameter_Str = window['func17_JSDoParameter_Str'];
window['func13_JSVariDef_Str'] = function(param5_Varis, param12_ForceDefault, param8_NoStatic) {
	stackPush("function: JSVariDef_Str", __debugInfo);
	try {
		var local8_Text_Str_2079 = "", local4_Find_2080 = 0.0;
		__debugInfo = "1152:\src\CompilerPasses\Generator\JSGenerator.gbas";
		local8_Text_Str_2079 = "";
		__debugInfo = "1153:\src\CompilerPasses\Generator\JSGenerator.gbas";
		local4_Find_2080 = 0;
		__debugInfo = "1165:\src\CompilerPasses\Generator\JSGenerator.gbas";
		var forEachSaver11396 = param5_Varis;
		for(var forEachCounter11396 = 0 ; forEachCounter11396 < forEachSaver11396.values.length ; forEachCounter11396++) {
			var local3_Var_2081 = forEachSaver11396.values[forEachCounter11396];
		{
				__debugInfo = "1164:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr3_Typ) != (5)) ? 1 : 0)) && (((((((param8_NoStatic) == (0)) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr3_Typ) != (4)) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) && (func17_JSShouldRedeclare(local3_Var_2081))) ? 1 : 0)) {
					__debugInfo = "1156:\src\CompilerPasses\Generator\JSGenerator.gbas";
					if (local4_Find_2080) {
						__debugInfo = "1156:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_2079 = ((local8_Text_Str_2079) + (", "));
						__debugInfo = "1156:\src\CompilerPasses\Generator\JSGenerator.gbas";
					};
					__debugInfo = "1157:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local8_Text_Str_2079 = ((((local8_Text_Str_2079) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr8_Name_Str))) + (" = "));
					__debugInfo = "1162:\src\CompilerPasses\Generator\JSGenerator.gbas";
					if (((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr6_PreDef) != (-(1))) ? 1 : 0)) && (((((((param12_ForceDefault) == (0)) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "1159:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_2079 = ((local8_Text_Str_2079) + (func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr6_PreDef).values[tmpPositionCache][0]))));
						__debugInfo = "1159:\src\CompilerPasses\Generator\JSGenerator.gbas";
					} else {
						__debugInfo = "1161:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local8_Text_Str_2079 = ((local8_Text_Str_2079) + (func21_JSGetDefaultValue_Str(global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr8_datatype, global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Var_2081).values[tmpPositionCache][0].attr3_ref, 0)));
						__debugInfo = "1161:\src\CompilerPasses\Generator\JSGenerator.gbas";
					};
					__debugInfo = "1163:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local4_Find_2080 = 1;
					__debugInfo = "1156:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1164:\src\CompilerPasses\Generator\JSGenerator.gbas";
			}
			forEachSaver11396.values[forEachCounter11396] = local3_Var_2081;
		
		};
		__debugInfo = "1167:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return tryClone(local8_Text_Str_2079);
		__debugInfo = "1168:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1152:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_JSVariDef_Str = window['func13_JSVariDef_Str'];
window['func23_ConditionJSGenerate_Str'] = function(param4_expr) {
	stackPush("function: ConditionJSGenerate_Str", __debugInfo);
	try {
		__debugInfo = "1175:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if ((((param4_expr.attr3_Typ) == (16)) ? 1 : 0)) {
			__debugInfo = "1172:\src\CompilerPasses\Generator\JSGenerator.gbas";
			return tryClone(func14_JSGenerate_Str(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0])));
			__debugInfo = "1172:\src\CompilerPasses\Generator\JSGenerator.gbas";
		} else {
			__debugInfo = "1174:\src\CompilerPasses\Generator\JSGenerator.gbas";
			return tryClone(func14_JSGenerate_Str(param4_expr));
			__debugInfo = "1174:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1176:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1175:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_ConditionJSGenerate_Str = window['func23_ConditionJSGenerate_Str'];
window['func17_JSShouldRedeclare'] = function(param3_Var) {
	stackPush("function: JSShouldRedeclare", __debugInfo);
	try {
		__debugInfo = "1187:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if ((((global11_CurrentFunc) != (-(1))) ? 1 : 0)) {
			__debugInfo = "1186:\src\CompilerPasses\Generator\JSGenerator.gbas";
			var forEachSaver11451 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr10_CopyParams;
			for(var forEachCounter11451 = 0 ; forEachCounter11451 < forEachSaver11451.values.length ; forEachCounter11451++) {
				var local1_P_2084 = forEachSaver11451.values[forEachCounter11451];
			{
					__debugInfo = "1185:\src\CompilerPasses\Generator\JSGenerator.gbas";
					if ((((local1_P_2084) == (param3_Var)) ? 1 : 0)) {
						__debugInfo = "1184:\src\CompilerPasses\Generator\JSGenerator.gbas";
						return tryClone(0);
						__debugInfo = "1184:\src\CompilerPasses\Generator\JSGenerator.gbas";
					};
					__debugInfo = "1185:\src\CompilerPasses\Generator\JSGenerator.gbas";
				}
				forEachSaver11451.values[forEachCounter11451] = local1_P_2084;
			
			};
			__debugInfo = "1186:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1188:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return 1;
		__debugInfo = "1189:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return 0;
		__debugInfo = "1187:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func17_JSShouldRedeclare = window['func17_JSShouldRedeclare'];
window['func21_JSGetDefaultValue_Str'] = function(param8_datatype, param3_Ref, param11_IgnoreArray) {
	stackPush("function: JSGetDefaultValue_Str", __debugInfo);
	try {
		var local10_RetVal_Str_2088 = "";
		__debugInfo = "1192:\src\CompilerPasses\Generator\JSGenerator.gbas";
		local10_RetVal_Str_2088 = "";
		__debugInfo = "1210:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if ((((param8_datatype.attr7_IsArray_ref[0]) && ((((param11_IgnoreArray) == (0)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1194:\src\CompilerPasses\Generator\JSGenerator.gbas";
			local10_RetVal_Str_2088 = (((("new OTTArray(") + (func21_JSGetDefaultValue_Str(param8_datatype, param3_Ref, 1)))) + (")"));
			__debugInfo = "1194:\src\CompilerPasses\Generator\JSGenerator.gbas";
		} else {
			__debugInfo = "1196:\src\CompilerPasses\Generator\JSGenerator.gbas";
			{
				var local17___SelectHelper14__2089 = "";
				__debugInfo = "1196:\src\CompilerPasses\Generator\JSGenerator.gbas";
				local17___SelectHelper14__2089 = param8_datatype.attr8_Name_Str_ref[0];
				__debugInfo = "1209:\src\CompilerPasses\Generator\JSGenerator.gbas";
				if ((((local17___SelectHelper14__2089) == ("int")) ? 1 : 0)) {
					__debugInfo = "1198:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_RetVal_Str_2088 = "0";
					__debugInfo = "1198:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper14__2089) == ("float")) ? 1 : 0)) {
					__debugInfo = "1200:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_RetVal_Str_2088 = "0.0";
					__debugInfo = "1200:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else if ((((local17___SelectHelper14__2089) == ("string")) ? 1 : 0)) {
					__debugInfo = "1202:\src\CompilerPasses\Generator\JSGenerator.gbas";
					local10_RetVal_Str_2088 = "\"\"";
					__debugInfo = "1202:\src\CompilerPasses\Generator\JSGenerator.gbas";
				} else {
					__debugInfo = "1208:\src\CompilerPasses\Generator\JSGenerator.gbas";
					if (func6_IsType(unref(param8_datatype.attr8_Name_Str_ref[0]))) {
						__debugInfo = "1205:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_RetVal_Str_2088 = (((("new ") + (global8_LastType.attr8_Name_Str))) + ("()"));
						__debugInfo = "1205:\src\CompilerPasses\Generator\JSGenerator.gbas";
					} else {
						__debugInfo = "1207:\src\CompilerPasses\Generator\JSGenerator.gbas";
						local10_RetVal_Str_2088 = REPLACE_Str(unref(param8_datatype.attr8_Name_Str_ref[0]), "$", "_Str");
						__debugInfo = "1207:\src\CompilerPasses\Generator\JSGenerator.gbas";
					};
					__debugInfo = "1208:\src\CompilerPasses\Generator\JSGenerator.gbas";
				};
				__debugInfo = "1196:\src\CompilerPasses\Generator\JSGenerator.gbas";
			};
			__debugInfo = "1196:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1211:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if (param3_Ref) {
			__debugInfo = "1211:\src\CompilerPasses\Generator\JSGenerator.gbas";
			local10_RetVal_Str_2088 = (((("[") + (local10_RetVal_Str_2088))) + ("]"));
			__debugInfo = "1211:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1212:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return tryClone(local10_RetVal_Str_2088);
		__debugInfo = "1213:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1192:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func21_JSGetDefaultValue_Str = window['func21_JSGetDefaultValue_Str'];
window['func16_JSRemoveLast_Str'] = function(param8_Text_Str, param5_L_Str) {
	stackPush("function: JSRemoveLast_Str", __debugInfo);
	try {
		__debugInfo = "1216:\src\CompilerPasses\Generator\JSGenerator.gbas";
		if ((((((((param8_Text_Str).length) > ((param5_L_Str).length)) ? 1 : 0)) && ((((RIGHT_Str(param8_Text_Str, (param5_L_Str).length)) == (param5_L_Str)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1216:\src\CompilerPasses\Generator\JSGenerator.gbas";
			param8_Text_Str = LEFT_Str(param8_Text_Str, (((param8_Text_Str).length) - ((param5_L_Str).length)));
			__debugInfo = "1216:\src\CompilerPasses\Generator\JSGenerator.gbas";
		};
		__debugInfo = "1217:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return tryClone(param8_Text_Str);
		__debugInfo = "1218:\src\CompilerPasses\Generator\JSGenerator.gbas";
		return "";
		__debugInfo = "1216:\src\CompilerPasses\Generator\JSGenerator.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func16_JSRemoveLast_Str = window['func16_JSRemoveLast_Str'];
window['func5_Lexer'] = function() {
	stackPush("function: Lexer", __debugInfo);
	try {
		var local12_Splitter_Str_2092 = new OTTArray(""), local11_SplitterMap_2093 = new type7_HashMap(), local9_LastFound_2095 = 0, local4_Line_2096 = 0, local15_LineContent_Str_2097 = "", local18_NewLineContent_Str_2098 = "", local8_Path_Str_2099 = "", local9_Character_2100 = 0, local5_WasNL_2114 = 0, local6_WasRem_2115 = 0, local6_HasDel_2116 = 0, local1_i_2120 = 0.0;
		__debugInfo = "8:\src\CompilerPasses\Lexer.gbas";
		REDIM(global8_Compiler.attr6_Tokens, [0], new type5_Token() );
		__debugInfo = "9:\src\CompilerPasses\Lexer.gbas";
		global8_Compiler.attr11_LastTokenID = 0;
		__debugInfo = "12:\src\CompilerPasses\Lexer.gbas";
		DIMDATA(local12_Splitter_Str_2092, [" ", "\t", "\n", "-", "+", "*", "/", "^", ",", "=", "<", ">", "|", "&", "[", "]", "(", ")", "!", "\"", "?", ";", ".", ":", CHR_Str(8), CHR_Str(12), "\r", "\f"]);
		__debugInfo = "15:\src\CompilerPasses\Lexer.gbas";
		(local11_SplitterMap_2093).SetSize(((BOUNDS(local12_Splitter_Str_2092, 0)) * (8)));
		__debugInfo = "18:\src\CompilerPasses\Lexer.gbas";
		var forEachSaver11643 = local12_Splitter_Str_2092;
		for(var forEachCounter11643 = 0 ; forEachCounter11643 < forEachSaver11643.values.length ; forEachCounter11643++) {
			var local9_Split_Str_2094 = forEachSaver11643.values[forEachCounter11643];
		{
				__debugInfo = "17:\src\CompilerPasses\Lexer.gbas";
				(local11_SplitterMap_2093).Put(local9_Split_Str_2094, 1);
				__debugInfo = "17:\src\CompilerPasses\Lexer.gbas";
			}
			forEachSaver11643.values[forEachCounter11643] = local9_Split_Str_2094;
		
		};
		__debugInfo = "22:\src\CompilerPasses\Lexer.gbas";
		global8_Compiler.attr8_Code_Str = (("\n") + (global8_Compiler.attr8_Code_Str));
		__debugInfo = "24:\src\CompilerPasses\Lexer.gbas";
		{
			var local1_i_2101 = 0;
			__debugInfo = "97:\src\CompilerPasses\Lexer.gbas";
			for (local1_i_2101 = 0;toCheck(local1_i_2101, (((global8_Compiler.attr8_Code_Str).length) - (1)), 1);local1_i_2101 += 1) {
				var local14_DoubleChar_Str_2102 = "", local11_curChar_Str_2105 = "", local15_TmpLineCont_Str_2106 = "";
				__debugInfo = "26:\src\CompilerPasses\Lexer.gbas";
				local9_Character_2100+=1;
				__debugInfo = "29:\src\CompilerPasses\Lexer.gbas";
				if ((((local1_i_2101) < ((((global8_Compiler.attr8_Code_Str).length) - (2)))) ? 1 : 0)) {
					__debugInfo = "29:\src\CompilerPasses\Lexer.gbas";
					local14_DoubleChar_Str_2102 = MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, 2);
					__debugInfo = "29:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "47:\src\CompilerPasses\Lexer.gbas";
				if ((((local14_DoubleChar_Str_2102) == ("//")) ? 1 : 0)) {
					var local8_Text_Str_2103 = "", local3_Pos_2104 = 0;
					__debugInfo = "31:\src\CompilerPasses\Lexer.gbas";
					local8_Text_Str_2103 = MID_Str(global8_Compiler.attr8_Code_Str, local9_LastFound_2095, ((local1_i_2101) - (local9_LastFound_2095)));
					__debugInfo = "34:\src\CompilerPasses\Lexer.gbas";
					if ((((TRIM_Str(local8_Text_Str_2103, " \t\r\n\v\f")) != ("")) ? 1 : 0)) {
						__debugInfo = "33:\src\CompilerPasses\Lexer.gbas";
						func11_CreateToken(local8_Text_Str_2103, local15_LineContent_Str_2097, local4_Line_2096, local9_Character_2100, local8_Path_Str_2099);
						__debugInfo = "33:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "36:\src\CompilerPasses\Lexer.gbas";
					local3_Pos_2104 = local1_i_2101;
					__debugInfo = "39:\src\CompilerPasses\Lexer.gbas";
					while (((((((MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, 1)) != ("\n")) ? 1 : 0)) && ((((MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, 1)) != ("\f")) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "38:\src\CompilerPasses\Lexer.gbas";
						local1_i_2101+=1;
						__debugInfo = "38:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "40:\src\CompilerPasses\Lexer.gbas";
					local8_Text_Str_2103 = MID_Str(global8_Compiler.attr8_Code_Str, local3_Pos_2104, ((local1_i_2101) - (local3_Pos_2104)));
					__debugInfo = "45:\src\CompilerPasses\Lexer.gbas";
					if ((((((((local8_Text_Str_2103).length) > (("//$$RESETFILE").length)) ? 1 : 0)) && ((((LEFT_Str(local8_Text_Str_2103, ("//$$RESETFILE").length)) == ("//$$RESETFILE")) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "42:\src\CompilerPasses\Lexer.gbas";
						local8_Text_Str_2103 = MID_Str(local8_Text_Str_2103, ((("//$$RESETFILE").length) + (1)), -(1));
						__debugInfo = "43:\src\CompilerPasses\Lexer.gbas";
						local8_Path_Str_2099 = local8_Text_Str_2103;
						__debugInfo = "44:\src\CompilerPasses\Lexer.gbas";
						local4_Line_2096 = 0;
						__debugInfo = "42:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "46:\src\CompilerPasses\Lexer.gbas";
					local9_LastFound_2095 = local1_i_2101;
					__debugInfo = "31:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "49:\src\CompilerPasses\Lexer.gbas";
				local11_curChar_Str_2105 = MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, 1);
				__debugInfo = "51:\src\CompilerPasses\Lexer.gbas";
				local15_TmpLineCont_Str_2106 = local15_LineContent_Str_2097;
				__debugInfo = "52:\src\CompilerPasses\Lexer.gbas";
				if ((((local11_curChar_Str_2105) == ("\f")) ? 1 : 0)) {
					__debugInfo = "52:\src\CompilerPasses\Lexer.gbas";
					local11_curChar_Str_2105 = "\n";
					__debugInfo = "52:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "53:\src\CompilerPasses\Lexer.gbas";
				{
					var local17___SelectHelper15__2107 = "";
					__debugInfo = "53:\src\CompilerPasses\Lexer.gbas";
					local17___SelectHelper15__2107 = local11_curChar_Str_2105;
					__debugInfo = "81:\src\CompilerPasses\Lexer.gbas";
					if ((((local17___SelectHelper15__2107) == ("\n")) ? 1 : 0)) {
						__debugInfo = "55:\src\CompilerPasses\Lexer.gbas";
						local9_Character_2100 = 0;
						__debugInfo = "56:\src\CompilerPasses\Lexer.gbas";
						local4_Line_2096+=1;
						__debugInfo = "56:\src\CompilerPasses\Lexer.gbas";
						{
							var local1_j_2108 = 0;
							__debugInfo = "63:\src\CompilerPasses\Lexer.gbas";
							for (local1_j_2108 = ((local1_i_2101) + (1));toCheck(local1_j_2108, (((global8_Compiler.attr8_Code_Str).length) - (1)), 1);local1_j_2108 += 1) {
								__debugInfo = "62:\src\CompilerPasses\Lexer.gbas";
								if (((((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2108, 1)) == ("\n")) ? 1 : 0)) || ((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2108, 1)) == ("\f")) ? 1 : 0))) ? 1 : 0)) {
									__debugInfo = "59:\src\CompilerPasses\Lexer.gbas";
									local15_TmpLineCont_Str_2106 = TRIM_Str(MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, ((local1_j_2108) - (local1_i_2101))), " \t\r\n\v\f");
									__debugInfo = "60:\src\CompilerPasses\Lexer.gbas";
									if ((((RIGHT_Str(local15_TmpLineCont_Str_2106, 1)) == ("\f")) ? 1 : 0)) {
										__debugInfo = "60:\src\CompilerPasses\Lexer.gbas";
										local15_TmpLineCont_Str_2106 = ((MID_Str(local15_TmpLineCont_Str_2106, 0, (((local15_TmpLineCont_Str_2106).length) - (1)))) + ("\n"));
										__debugInfo = "60:\src\CompilerPasses\Lexer.gbas";
									};
									__debugInfo = "61:\src\CompilerPasses\Lexer.gbas";
									break;
									__debugInfo = "59:\src\CompilerPasses\Lexer.gbas";
								};
								__debugInfo = "62:\src\CompilerPasses\Lexer.gbas";
							};
							__debugInfo = "63:\src\CompilerPasses\Lexer.gbas";
						};
						__debugInfo = "55:\src\CompilerPasses\Lexer.gbas";
					} else if ((((local17___SelectHelper15__2107) == ("\"")) ? 1 : 0)) {
						var local12_WasBackSlash_2109 = 0, local10_WasWasBack_2110 = 0;
						__debugInfo = "64:\src\CompilerPasses\Lexer.gbas";
						local12_WasBackSlash_2109 = 0;
						__debugInfo = "65:\src\CompilerPasses\Lexer.gbas";
						local10_WasWasBack_2110 = 0;
						__debugInfo = "65:\src\CompilerPasses\Lexer.gbas";
						{
							var local1_j_2111 = 0;
							__debugInfo = "79:\src\CompilerPasses\Lexer.gbas";
							for (local1_j_2111 = ((local1_i_2101) + (1));toCheck(local1_j_2111, (((global8_Compiler.attr8_Code_Str).length) - (1)), 1);local1_j_2111 += 1) {
								__debugInfo = "69:\src\CompilerPasses\Lexer.gbas";
								if (((((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2111, 1)) == ("\n")) ? 1 : 0)) || ((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2111, 1)) == ("\f")) ? 1 : 0))) ? 1 : 0)) {
									__debugInfo = "68:\src\CompilerPasses\Lexer.gbas";
									local4_Line_2096+=1;
									__debugInfo = "68:\src\CompilerPasses\Lexer.gbas";
								};
								__debugInfo = "73:\src\CompilerPasses\Lexer.gbas";
								if (((((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2111, 1)) == ("\"")) ? 1 : 0)) && (((((((local12_WasBackSlash_2109) == (0)) ? 1 : 0)) || (local10_WasWasBack_2110)) ? 1 : 0))) ? 1 : 0)) {
									__debugInfo = "71:\src\CompilerPasses\Lexer.gbas";
									local1_i_2101 = local1_j_2111;
									__debugInfo = "72:\src\CompilerPasses\Lexer.gbas";
									break;
									__debugInfo = "71:\src\CompilerPasses\Lexer.gbas";
								};
								__debugInfo = "74:\src\CompilerPasses\Lexer.gbas";
								local10_WasWasBack_2110 = local12_WasBackSlash_2109;
								__debugInfo = "75:\src\CompilerPasses\Lexer.gbas";
								local12_WasBackSlash_2109 = 0;
								__debugInfo = "78:\src\CompilerPasses\Lexer.gbas";
								if ((((MID_Str(global8_Compiler.attr8_Code_Str, local1_j_2111, 1)) == ("\\")) ? 1 : 0)) {
									__debugInfo = "77:\src\CompilerPasses\Lexer.gbas";
									local12_WasBackSlash_2109 = 1;
									__debugInfo = "77:\src\CompilerPasses\Lexer.gbas";
								};
								__debugInfo = "69:\src\CompilerPasses\Lexer.gbas";
							};
							__debugInfo = "79:\src\CompilerPasses\Lexer.gbas";
						};
						__debugInfo = "80:\src\CompilerPasses\Lexer.gbas";
						continue;
						__debugInfo = "64:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "53:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "94:\src\CompilerPasses\Lexer.gbas";
				if ((local11_SplitterMap_2093).DoesKeyExist(local11_curChar_Str_2105)) {
					var local9_Split_Str_2112 = "", local8_Text_Str_2113 = "";
					__debugInfo = "84:\src\CompilerPasses\Lexer.gbas";
					local9_Split_Str_2112 = local11_curChar_Str_2105;
					__debugInfo = "85:\src\CompilerPasses\Lexer.gbas";
					local8_Text_Str_2113 = MID_Str(global8_Compiler.attr8_Code_Str, local9_LastFound_2095, ((local1_i_2101) - (local9_LastFound_2095)));
					__debugInfo = "86:\src\CompilerPasses\Lexer.gbas";
					if ((((local8_Text_Str_2113) == (";")) ? 1 : 0)) {
						__debugInfo = "86:\src\CompilerPasses\Lexer.gbas";
						local8_Text_Str_2113 = "\n";
						__debugInfo = "86:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "87:\src\CompilerPasses\Lexer.gbas";
					func11_CreateToken(local8_Text_Str_2113, local15_LineContent_Str_2097, local4_Line_2096, local9_Character_2100, local8_Path_Str_2099);
					__debugInfo = "89:\src\CompilerPasses\Lexer.gbas";
					local8_Text_Str_2113 = MID_Str(global8_Compiler.attr8_Code_Str, local1_i_2101, (local9_Split_Str_2112).length);
					__debugInfo = "90:\src\CompilerPasses\Lexer.gbas";
					if ((((local8_Text_Str_2113) == (";")) ? 1 : 0)) {
						__debugInfo = "90:\src\CompilerPasses\Lexer.gbas";
						local8_Text_Str_2113 = "\n";
						__debugInfo = "90:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "91:\src\CompilerPasses\Lexer.gbas";
					func11_CreateToken(local8_Text_Str_2113, local15_LineContent_Str_2097, local4_Line_2096, local9_Character_2100, local8_Path_Str_2099);
					__debugInfo = "93:\src\CompilerPasses\Lexer.gbas";
					local9_LastFound_2095 = ((local1_i_2101) + ((local9_Split_Str_2112).length));
					__debugInfo = "84:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "96:\src\CompilerPasses\Lexer.gbas";
				local15_LineContent_Str_2097 = local15_TmpLineCont_Str_2106;
				__debugInfo = "26:\src\CompilerPasses\Lexer.gbas";
			};
			__debugInfo = "97:\src\CompilerPasses\Lexer.gbas";
		};
		__debugInfo = "98:\src\CompilerPasses\Lexer.gbas";
		func11_CreateToken("__EOFFILE__", "__EOFFILE__", local4_Line_2096, 0, local8_Path_Str_2099);
		__debugInfo = "99:\src\CompilerPasses\Lexer.gbas";
		func11_CreateToken("\n", "__EOFFILE__", local4_Line_2096, 0, local8_Path_Str_2099);
		__debugInfo = "102:\src\CompilerPasses\Lexer.gbas";
		local5_WasNL_2114 = 0;
		__debugInfo = "102:\src\CompilerPasses\Lexer.gbas";
		local6_WasRem_2115 = 0;
		__debugInfo = "103:\src\CompilerPasses\Lexer.gbas";
		local6_HasDel_2116 = 0;
		__debugInfo = "104:\src\CompilerPasses\Lexer.gbas";
		{
			var local1_i_2117 = 0.0;
			__debugInfo = "169:\src\CompilerPasses\Lexer.gbas";
			for (local1_i_2117 = 0;toCheck(local1_i_2117, ((global8_Compiler.attr11_LastTokenID) - (1)), 1);local1_i_2117 += 1) {
				var local8_Text_Str_2118 = "";
				__debugInfo = "113:\src\CompilerPasses\Lexer.gbas";
				if (local6_HasDel_2116) {
					__debugInfo = "107:\src\CompilerPasses\Lexer.gbas";
					local6_HasDel_2116 = 0;
					__debugInfo = "108:\src\CompilerPasses\Lexer.gbas";
					global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr5_IsDel = 1;
					__debugInfo = "112:\src\CompilerPasses\Lexer.gbas";
					continue;
					__debugInfo = "107:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "114:\src\CompilerPasses\Lexer.gbas";
				local8_Text_Str_2118 = global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0];
				__debugInfo = "127:\src\CompilerPasses\Lexer.gbas";
				if ((((global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0]) == ("\n")) ? 1 : 0)) {
					__debugInfo = "116:\src\CompilerPasses\Lexer.gbas";
					local8_Text_Str_2118 = "NEWLINE";
					__debugInfo = "123:\src\CompilerPasses\Lexer.gbas";
					if (local5_WasNL_2114) {
						__debugInfo = "118:\src\CompilerPasses\Lexer.gbas";
						global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr5_IsDel = 1;
						__debugInfo = "122:\src\CompilerPasses\Lexer.gbas";
						continue;
						__debugInfo = "118:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "124:\src\CompilerPasses\Lexer.gbas";
					local5_WasNL_2114 = 1;
					__debugInfo = "116:\src\CompilerPasses\Lexer.gbas";
				} else {
					__debugInfo = "126:\src\CompilerPasses\Lexer.gbas";
					local5_WasNL_2114 = 0;
					__debugInfo = "126:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "130:\src\CompilerPasses\Lexer.gbas";
				if ((((global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0]) == ("REM")) ? 1 : 0)) {
					__debugInfo = "129:\src\CompilerPasses\Lexer.gbas";
					local6_WasRem_2115 = 1;
					__debugInfo = "129:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "140:\src\CompilerPasses\Lexer.gbas";
				if ((((local6_WasRem_2115) && ((((global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0]) == ("ENDREM")) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "132:\src\CompilerPasses\Lexer.gbas";
					local6_WasRem_2115 = 0;
					__debugInfo = "133:\src\CompilerPasses\Lexer.gbas";
					local6_HasDel_2116 = 1;
					__debugInfo = "135:\src\CompilerPasses\Lexer.gbas";
					global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr5_IsDel = 1;
					__debugInfo = "139:\src\CompilerPasses\Lexer.gbas";
					continue;
					__debugInfo = "132:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "147:\src\CompilerPasses\Lexer.gbas";
				if (local6_WasRem_2115) {
					__debugInfo = "142:\src\CompilerPasses\Lexer.gbas";
					global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr5_IsDel = 1;
					__debugInfo = "146:\src\CompilerPasses\Lexer.gbas";
					continue;
					__debugInfo = "142:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "168:\src\CompilerPasses\Lexer.gbas";
				if ((((local1_i_2117) < (((global8_Compiler.attr11_LastTokenID) - (1)))) ? 1 : 0)) {
					__debugInfo = "149:\src\CompilerPasses\Lexer.gbas";
					{
						var local17___SelectHelper16__2119 = "";
						__debugInfo = "149:\src\CompilerPasses\Lexer.gbas";
						local17___SelectHelper16__2119 = global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0];
						__debugInfo = "167:\src\CompilerPasses\Lexer.gbas";
						if ((((local17___SelectHelper16__2119) == ("<")) ? 1 : 0)) {
							__debugInfo = "155:\src\CompilerPasses\Lexer.gbas";
							if ((((global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr8_Text_Str_ref[0]) == (">")) ? 1 : 0)) {
								__debugInfo = "152:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr5_IsDel = 1;
								__debugInfo = "154:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0] = "<>";
								__debugInfo = "152:\src\CompilerPasses\Lexer.gbas";
							};
							__debugInfo = "160:\src\CompilerPasses\Lexer.gbas";
							if ((((global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr8_Text_Str_ref[0]) == ("=")) ? 1 : 0)) {
								__debugInfo = "157:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr5_IsDel = 1;
								__debugInfo = "159:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0] = "<=";
								__debugInfo = "157:\src\CompilerPasses\Lexer.gbas";
							};
							__debugInfo = "155:\src\CompilerPasses\Lexer.gbas";
						} else if ((((local17___SelectHelper16__2119) == (">")) ? 1 : 0)) {
							__debugInfo = "166:\src\CompilerPasses\Lexer.gbas";
							if ((((global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr8_Text_Str_ref[0]) == ("=")) ? 1 : 0)) {
								__debugInfo = "163:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(((local1_i_2117) + (1)))).values[tmpPositionCache].attr5_IsDel = 1;
								__debugInfo = "165:\src\CompilerPasses\Lexer.gbas";
								global8_Compiler.attr6_Tokens.arrAccess(~~(local1_i_2117)).values[tmpPositionCache].attr8_Text_Str_ref[0] = ">=";
								__debugInfo = "163:\src\CompilerPasses\Lexer.gbas";
							};
							__debugInfo = "166:\src\CompilerPasses\Lexer.gbas";
						};
						__debugInfo = "149:\src\CompilerPasses\Lexer.gbas";
					};
					__debugInfo = "149:\src\CompilerPasses\Lexer.gbas";
				};
				__debugInfo = "113:\src\CompilerPasses\Lexer.gbas";
			};
			__debugInfo = "169:\src\CompilerPasses\Lexer.gbas";
		};
		__debugInfo = "170:\src\CompilerPasses\Lexer.gbas";
		local1_i_2120 = 0;
		__debugInfo = "210:\src\CompilerPasses\Lexer.gbas";
		return 0;
		__debugInfo = "8:\src\CompilerPasses\Lexer.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_Lexer = window['func5_Lexer'];
window['func7_VariDef'] = function(param9_NoDefault) {
	stackPush("function: VariDef", __debugInfo);
	try {
		var local8_Name_Str_2122 = "", local12_datatype_Str_2123 = "", local7_IsArray_2124 = 0, local12_RightTok_Str_2125 = "", local11_LeftTok_Str_2126 = "", local6_DefVal_2127 = 0, local4_dims_2128 = new OTTArray(0), local4_vari_2131 = new type14_IdentifierVari();
		__debugInfo = "9:\src\CompilerPasses\Parser.gbas";
		local8_Name_Str_2122 = func14_GetCurrent_Str();
		__debugInfo = "10:\src\CompilerPasses\Parser.gbas";
		func14_IsValidVarName();
		__debugInfo = "11:\src\CompilerPasses\Parser.gbas";
		func5_Match(local8_Name_Str_2122, 10, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "12:\src\CompilerPasses\Parser.gbas";
		local12_datatype_Str_2123 = "float";
		__debugInfo = "13:\src\CompilerPasses\Parser.gbas";
		local7_IsArray_2124 = 0;
		__debugInfo = "14:\src\CompilerPasses\Parser.gbas";
		local12_RightTok_Str_2125 = RIGHT_Str(local8_Name_Str_2122, 1);
		__debugInfo = "15:\src\CompilerPasses\Parser.gbas";
		local11_LeftTok_Str_2126 = LEFT_Str(local8_Name_Str_2122, (((local8_Name_Str_2122).length) - (1)));
		__debugInfo = "16:\src\CompilerPasses\Parser.gbas";
		local6_DefVal_2127 = -(1);
		__debugInfo = "19:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper17__2129 = "";
			__debugInfo = "19:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper17__2129 = local12_RightTok_Str_2125;
			__debugInfo = "29:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper17__2129) == ("%")) ? 1 : 0)) {
				__debugInfo = "21:\src\CompilerPasses\Parser.gbas";
				local12_datatype_Str_2123 = "int";
				__debugInfo = "22:\src\CompilerPasses\Parser.gbas";
				local8_Name_Str_2122 = local11_LeftTok_Str_2126;
				__debugInfo = "21:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper17__2129) == ("#")) ? 1 : 0)) {
				__debugInfo = "24:\src\CompilerPasses\Parser.gbas";
				local12_datatype_Str_2123 = "float";
				__debugInfo = "25:\src\CompilerPasses\Parser.gbas";
				local8_Name_Str_2122 = local11_LeftTok_Str_2126;
				__debugInfo = "24:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper17__2129) == ("$")) ? 1 : 0)) {
				__debugInfo = "27:\src\CompilerPasses\Parser.gbas";
				local12_datatype_Str_2123 = "string";
				__debugInfo = "27:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "19:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "48:\src\CompilerPasses\Parser.gbas";
		if (func7_IsToken("[")) {
			__debugInfo = "33:\src\CompilerPasses\Parser.gbas";
			func5_Match("[", 32, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "46:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("]")) {
				__debugInfo = "35:\src\CompilerPasses\Parser.gbas";
				func5_Match("]", 34, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "35:\src\CompilerPasses\Parser.gbas";
			} else {
				var local1_E_2130 = 0;
				__debugInfo = "37:\src\CompilerPasses\Parser.gbas";
				local1_E_2130 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 36, 0);
				__debugInfo = "38:\src\CompilerPasses\Parser.gbas";
				func5_Match("]", 37, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "39:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(local4_dims_2128, local1_E_2130);
				__debugInfo = "45:\src\CompilerPasses\Parser.gbas";
				while (func7_IsToken("[")) {
					__debugInfo = "41:\src\CompilerPasses\Parser.gbas";
					func5_Match("[", 40, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "42:\src\CompilerPasses\Parser.gbas";
					local1_E_2130 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 41, 0);
					__debugInfo = "43:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local4_dims_2128, local1_E_2130);
					__debugInfo = "44:\src\CompilerPasses\Parser.gbas";
					func5_Match("]", 43, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "41:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "37:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "47:\src\CompilerPasses\Parser.gbas";
			local7_IsArray_2124 = 1;
			__debugInfo = "33:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "69:\src\CompilerPasses\Parser.gbas";
		if (func7_IsToken("AS")) {
			__debugInfo = "68:\src\CompilerPasses\Parser.gbas";
			if ((((local12_datatype_Str_2123) == ("float")) ? 1 : 0)) {
				__debugInfo = "52:\src\CompilerPasses\Parser.gbas";
				func5_Match("AS", 51, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "64:\src\CompilerPasses\Parser.gbas";
				if (((((((((((((((((((func7_IsToken("int")) || (func7_IsToken("short"))) ? 1 : 0)) || (func7_IsToken("byte"))) ? 1 : 0)) || (func7_IsToken("bool"))) ? 1 : 0)) || (func7_IsToken("boolean"))) ? 1 : 0)) || (func7_IsToken("long"))) ? 1 : 0)) || (func7_IsToken("single"))) ? 1 : 0)) {
					__debugInfo = "54:\src\CompilerPasses\Parser.gbas";
					local12_datatype_Str_2123 = "int";
					__debugInfo = "54:\src\CompilerPasses\Parser.gbas";
				} else if ((((func7_IsToken("float")) || (func7_IsToken("double"))) ? 1 : 0)) {
					__debugInfo = "56:\src\CompilerPasses\Parser.gbas";
					local12_datatype_Str_2123 = "float";
					__debugInfo = "56:\src\CompilerPasses\Parser.gbas";
				} else if (func7_IsToken("void")) {
					__debugInfo = "58:\src\CompilerPasses\Parser.gbas";
					local12_datatype_Str_2123 = "void";
					__debugInfo = "58:\src\CompilerPasses\Parser.gbas";
				} else if (func7_IsToken("string")) {
					__debugInfo = "60:\src\CompilerPasses\Parser.gbas";
					local12_datatype_Str_2123 = "string";
					__debugInfo = "60:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "62:\src\CompilerPasses\Parser.gbas";
					func15_IsValidDatatype();
					__debugInfo = "63:\src\CompilerPasses\Parser.gbas";
					local12_datatype_Str_2123 = func14_GetCurrent_Str();
					__debugInfo = "62:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "65:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "52:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "67:\src\CompilerPasses\Parser.gbas";
				func5_Error("Unexpected AS", 66, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "67:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "68:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "72:\src\CompilerPasses\Parser.gbas";
		local4_vari_2131.attr8_Name_Str = local8_Name_Str_2122;
		__debugInfo = "73:\src\CompilerPasses\Parser.gbas";
		local4_vari_2131.attr8_datatype.attr8_Name_Str_ref[0] = local12_datatype_Str_2123;
		__debugInfo = "74:\src\CompilerPasses\Parser.gbas";
		local4_vari_2131.attr8_datatype.attr7_IsArray_ref[0] = local7_IsArray_2124;
		__debugInfo = "78:\src\CompilerPasses\Parser.gbas";
		if ((((BOUNDS(local4_dims_2128, 0)) > (0)) ? 1 : 0)) {
			__debugInfo = "77:\src\CompilerPasses\Parser.gbas";
			local6_DefVal_2127 = func25_CreateDimAsExprExpression(local4_vari_2131.attr8_datatype, unref(local4_dims_2128));
			__debugInfo = "77:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "83:\src\CompilerPasses\Parser.gbas";
		if ((((func7_IsToken("=")) && (((param9_NoDefault) ? 0 : 1))) ? 1 : 0)) {
			__debugInfo = "81:\src\CompilerPasses\Parser.gbas";
			func5_Match("=", 80, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "82:\src\CompilerPasses\Parser.gbas";
			local6_DefVal_2127 = func14_EnsureDatatype(func10_Expression(0), local4_vari_2131.attr8_datatype, 81, 0);
			__debugInfo = "81:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "85:\src\CompilerPasses\Parser.gbas";
		local4_vari_2131.attr6_PreDef = local6_DefVal_2127;
		__debugInfo = "86:\src\CompilerPasses\Parser.gbas";
		return tryClone(local4_vari_2131);
		__debugInfo = "87:\src\CompilerPasses\Parser.gbas";
		return tryClone(unref(new type14_IdentifierVari()));
		__debugInfo = "9:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_VariDef = window['func7_VariDef'];
window['func7_FuncDef'] = function(param6_Native, param10_IsCallBack, param3_Typ, param6_CurTyp) {
	stackPush("function: FuncDef", __debugInfo);
	try {
		var local8_Name_Str_2136 = "";
		__debugInfo = "95:\src\CompilerPasses\Parser.gbas";
		if ((((param3_Typ) == (4)) ? 1 : 0)) {
			__debugInfo = "92:\src\CompilerPasses\Parser.gbas";
			func5_Match("PROTOTYPE", 91, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "92:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "94:\src\CompilerPasses\Parser.gbas";
			func5_Match("FUNCTION", 93, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "94:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "96:\src\CompilerPasses\Parser.gbas";
		local8_Name_Str_2136 = func14_GetCurrent_Str();
		__debugInfo = "155:\src\CompilerPasses\Parser.gbas";
		var forEachSaver12920 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter12920 = 0 ; forEachCounter12920 < forEachSaver12920.values.length ; forEachCounter12920++) {
			var local4_func_ref_2137 = forEachSaver12920.values[forEachCounter12920];
		{
				__debugInfo = "154:\src\CompilerPasses\Parser.gbas";
				if (((((((((((((func7_IsToken(func16_AddDataChars_Str(local4_func_ref_2137[0].attr8_Name_Str, unref(local4_func_ref_2137[0])))) || (func7_IsToken(local4_func_ref_2137[0].attr8_Name_Str))) ? 1 : 0)) && ((((local4_func_ref_2137[0].attr10_IsCallback) == (param10_IsCallBack)) ? 1 : 0))) ? 1 : 0)) && ((((local4_func_ref_2137[0].attr3_Typ) == (param3_Typ)) ? 1 : 0))) ? 1 : 0)) && ((((local4_func_ref_2137[0].attr6_MyType) == (param6_CurTyp)) ? 1 : 0))) ? 1 : 0)) {
					var local7_tmpVari_2138 = new type14_IdentifierVari(), local10_MustDefVal_2139 = 0;
					__debugInfo = "100:\src\CompilerPasses\Parser.gbas";
					local7_tmpVari_2138 = func7_VariDef(0).clone(/* In Assign */);
					__debugInfo = "105:\src\CompilerPasses\Parser.gbas";
					func5_Match(":", 104, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "106:\src\CompilerPasses\Parser.gbas";
					local10_MustDefVal_2139 = 0;
					__debugInfo = "128:\src\CompilerPasses\Parser.gbas";
					while ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
						var local3_ref_2140 = 0, local4_vari_ref_2141 = [new type14_IdentifierVari()];
						__debugInfo = "108:\src\CompilerPasses\Parser.gbas";
						local3_ref_2140 = 0;
						__debugInfo = "114:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("BYREF")) {
							__debugInfo = "111:\src\CompilerPasses\Parser.gbas";
							local3_ref_2140 = 1;
							__debugInfo = "112:\src\CompilerPasses\Parser.gbas";
							func5_Match("BYREF", 111, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "113:\src\CompilerPasses\Parser.gbas";
							local4_func_ref_2137[0].attr6_HasRef = 1;
							__debugInfo = "111:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "116:\src\CompilerPasses\Parser.gbas";
						local4_vari_ref_2141[0] = func7_VariDef(0).clone(/* In Assign */);
						__debugInfo = "121:\src\CompilerPasses\Parser.gbas";
						if (local10_MustDefVal_2139) {
							__debugInfo = "118:\src\CompilerPasses\Parser.gbas";
							if ((((local4_vari_ref_2141[0].attr6_PreDef) == (-(1))) ? 1 : 0)) {
								__debugInfo = "118:\src\CompilerPasses\Parser.gbas";
								func5_Error((((("Parameter '") + (local4_vari_ref_2141[0].attr8_Name_Str))) + ("' has to have default value.")), 117, "src\CompilerPasses\Parser.gbas");
								__debugInfo = "118:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "118:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "120:\src\CompilerPasses\Parser.gbas";
							if ((((local4_vari_ref_2141[0].attr6_PreDef) != (-(1))) ? 1 : 0)) {
								__debugInfo = "120:\src\CompilerPasses\Parser.gbas";
								local10_MustDefVal_2139 = 1;
								__debugInfo = "120:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "120:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "122:\src\CompilerPasses\Parser.gbas";
						local4_vari_ref_2141[0].attr3_Typ = ~~(5);
						__debugInfo = "123:\src\CompilerPasses\Parser.gbas";
						local4_vari_ref_2141[0].attr3_ref = local3_ref_2140;
						__debugInfo = "124:\src\CompilerPasses\Parser.gbas";
						local4_vari_ref_2141[0].attr2_ID = BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0);
						__debugInfo = "125:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global8_Compiler.attr5_Varis_ref[0], local4_vari_ref_2141);
						__debugInfo = "126:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(local4_func_ref_2137[0].attr6_Params, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
						__debugInfo = "127:\src\CompilerPasses\Parser.gbas";
						if ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
							__debugInfo = "127:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 126, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "127:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "108:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "139:\src\CompilerPasses\Parser.gbas";
					(global8_Compiler.attr11_GlobalFuncs).Put(local4_func_ref_2137[0].attr8_Name_Str, local4_func_ref_2137[0].attr2_ID);
					__debugInfo = "152:\src\CompilerPasses\Parser.gbas";
					if ((((param3_Typ) != (4)) ? 1 : 0)) {
						__debugInfo = "151:\src\CompilerPasses\Parser.gbas";
						if (((((((param6_Native) == (0)) ? 1 : 0)) && ((((local4_func_ref_2137[0].attr10_IsAbstract) == (0)) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "143:\src\CompilerPasses\Parser.gbas";
							local4_func_ref_2137[0].attr6_Native = 0;
							__debugInfo = "144:\src\CompilerPasses\Parser.gbas";
							func5_Match("\n", 143, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "145:\src\CompilerPasses\Parser.gbas";
							local4_func_ref_2137[0].attr3_Tok = global8_Compiler.attr11_currentPosi;
							__debugInfo = "146:\src\CompilerPasses\Parser.gbas";
							func10_SkipTokens("FUNCTION", "ENDFUNCTION", local4_func_ref_2137[0].attr8_Name_Str);
							__debugInfo = "143:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "150:\src\CompilerPasses\Parser.gbas";
							if (((local4_func_ref_2137[0].attr10_IsAbstract) ? 0 : 1)) {
								__debugInfo = "149:\src\CompilerPasses\Parser.gbas";
								local4_func_ref_2137[0].attr6_Native = 1;
								__debugInfo = "149:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "150:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "151:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "153:\src\CompilerPasses\Parser.gbas";
					return 0;
					__debugInfo = "100:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "154:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver12920.values[forEachCounter12920] = local4_func_ref_2137;
		
		};
		__debugInfo = "160:\src\CompilerPasses\Parser.gbas";
		if (param10_IsCallBack) {
			__debugInfo = "157:\src\CompilerPasses\Parser.gbas";
			func10_SkipTokens("FUNCTION", "ENDFUNCTION", local8_Name_Str_2136);
			__debugInfo = "157:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "159:\src\CompilerPasses\Parser.gbas";
			func5_Error((((("Internal error (func definition for unknown type: ") + (local8_Name_Str_2136))) + (")")), 158, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "159:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "161:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "95:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_FuncDef = window['func7_FuncDef'];
window['func6_SubDef'] = function() {
	stackPush("function: SubDef", __debugInfo);
	try {
		__debugInfo = "165:\src\CompilerPasses\Parser.gbas";
		func5_Match("SUB", 164, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "181:\src\CompilerPasses\Parser.gbas";
		var forEachSaver13013 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter13013 = 0 ; forEachCounter13013 < forEachSaver13013.values.length ; forEachCounter13013++) {
			var local4_func_ref_2142 = forEachSaver13013.values[forEachCounter13013];
		{
				__debugInfo = "180:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken(local4_func_ref_2142[0].attr8_Name_Str)) {
					__debugInfo = "168:\src\CompilerPasses\Parser.gbas";
					local4_func_ref_2142[0].attr8_Name_Str = func14_GetCurrent_Str();
					__debugInfo = "169:\src\CompilerPasses\Parser.gbas";
					local4_func_ref_2142[0].attr8_datatype = global12_voidDatatype.clone(/* In Assign */);
					__debugInfo = "170:\src\CompilerPasses\Parser.gbas";
					local4_func_ref_2142[0].attr3_Typ = ~~(2);
					__debugInfo = "172:\src\CompilerPasses\Parser.gbas";
					(global8_Compiler.attr11_GlobalFuncs).Put(local4_func_ref_2142[0].attr8_Name_Str, local4_func_ref_2142[0].attr2_ID);
					__debugInfo = "174:\src\CompilerPasses\Parser.gbas";
					func5_Match(local4_func_ref_2142[0].attr8_Name_Str, 173, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "175:\src\CompilerPasses\Parser.gbas";
					func5_Match(":", 174, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "176:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 175, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "177:\src\CompilerPasses\Parser.gbas";
					local4_func_ref_2142[0].attr3_Tok = global8_Compiler.attr11_currentPosi;
					__debugInfo = "178:\src\CompilerPasses\Parser.gbas";
					func10_SkipTokens("SUB", "ENDSUB", local4_func_ref_2142[0].attr8_Name_Str);
					__debugInfo = "179:\src\CompilerPasses\Parser.gbas";
					return 0;
					__debugInfo = "168:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "180:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver13013.values[forEachCounter13013] = local4_func_ref_2142;
		
		};
		__debugInfo = "182:\src\CompilerPasses\Parser.gbas";
		func5_Error("Internal error (sub definition for unknown type)", 181, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "183:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "165:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func6_SubDef = window['func6_SubDef'];
window['func8_TypeDefi'] = function() {
	stackPush("function: TypeDefi", __debugInfo);
	try {
		__debugInfo = "187:\src\CompilerPasses\Parser.gbas";
		func5_Match("TYPE", 186, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "255:\src\CompilerPasses\Parser.gbas";
		var forEachSaver13268 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter13268 = 0 ; forEachCounter13268 < forEachSaver13268.values.length ; forEachCounter13268++) {
			var local3_typ_ref_2143 = forEachSaver13268.values[forEachCounter13268];
		{
				__debugInfo = "254:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken(local3_typ_ref_2143[0].attr8_Name_Str)) {
					var local11_ExtName_Str_2144 = "";
					__debugInfo = "190:\src\CompilerPasses\Parser.gbas";
					local3_typ_ref_2143[0].attr8_Name_Str = func14_GetCurrent_Str();
					__debugInfo = "191:\src\CompilerPasses\Parser.gbas";
					func5_Match(local3_typ_ref_2143[0].attr8_Name_Str, 190, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "201:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("EXTENDS")) {
						__debugInfo = "196:\src\CompilerPasses\Parser.gbas";
						func5_Match("EXTENDS", 195, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "197:\src\CompilerPasses\Parser.gbas";
						local11_ExtName_Str_2144 = func14_GetCurrent_Str();
						__debugInfo = "198:\src\CompilerPasses\Parser.gbas";
						func7_GetNext();
						__debugInfo = "196:\src\CompilerPasses\Parser.gbas";
					} else if ((((local3_typ_ref_2143[0].attr8_Name_Str) != ("TObject")) ? 1 : 0)) {
						__debugInfo = "200:\src\CompilerPasses\Parser.gbas";
						local11_ExtName_Str_2144 = "TObject";
						__debugInfo = "200:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "210:\src\CompilerPasses\Parser.gbas";
					if ((((local11_ExtName_Str_2144) != ("")) ? 1 : 0)) {
						__debugInfo = "203:\src\CompilerPasses\Parser.gbas";
						if ((((local11_ExtName_Str_2144) == (local3_typ_ref_2143[0].attr8_Name_Str)) ? 1 : 0)) {
							__debugInfo = "203:\src\CompilerPasses\Parser.gbas";
							func5_Error("Type cannot extend itself!", 202, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "203:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "209:\src\CompilerPasses\Parser.gbas";
						var forEachSaver13113 = global8_Compiler.attr5_Types_ref[0];
						for(var forEachCounter13113 = 0 ; forEachCounter13113 < forEachSaver13113.values.length ; forEachCounter13113++) {
							var local1_T_ref_2145 = forEachSaver13113.values[forEachCounter13113];
						{
								__debugInfo = "208:\src\CompilerPasses\Parser.gbas";
								if ((((local1_T_ref_2145[0].attr8_Name_Str) == (local11_ExtName_Str_2144)) ? 1 : 0)) {
									__debugInfo = "206:\src\CompilerPasses\Parser.gbas";
									local3_typ_ref_2143[0].attr9_Extending = local1_T_ref_2145[0].attr2_ID;
									__debugInfo = "207:\src\CompilerPasses\Parser.gbas";
									break;
									__debugInfo = "206:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "208:\src\CompilerPasses\Parser.gbas";
							}
							forEachSaver13113.values[forEachCounter13113] = local1_T_ref_2145;
						
						};
						__debugInfo = "203:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "212:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken(":")) {
						__debugInfo = "212:\src\CompilerPasses\Parser.gbas";
						func5_Match(":", 211, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "212:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "213:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 212, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "218:\src\CompilerPasses\Parser.gbas";
					var forEachSaver13179 = local3_typ_ref_2143[0].attr7_Methods;
					for(var forEachCounter13179 = 0 ; forEachCounter13179 < forEachSaver13179.values.length ; forEachCounter13179++) {
						var local2_M1_2146 = forEachSaver13179.values[forEachCounter13179];
					{
							__debugInfo = "217:\src\CompilerPasses\Parser.gbas";
							var forEachSaver13178 = local3_typ_ref_2143[0].attr7_Methods;
							for(var forEachCounter13178 = 0 ; forEachCounter13178 < forEachSaver13178.values.length ; forEachCounter13178++) {
								var local2_M2_2147 = forEachSaver13178.values[forEachCounter13178];
							{
									__debugInfo = "216:\src\CompilerPasses\Parser.gbas";
									if (((((((local2_M1_2146) != (local2_M2_2147)) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local2_M2_2147).values[tmpPositionCache][0].attr8_Name_Str) == (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local2_M1_2146).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0))) ? 1 : 0)) {
										__debugInfo = "216:\src\CompilerPasses\Parser.gbas";
										func5_Error((((("Method '") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(local2_M1_2146).values[tmpPositionCache][0].attr8_Name_Str))) + ("' already exists")), 215, "src\CompilerPasses\Parser.gbas");
										__debugInfo = "216:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "216:\src\CompilerPasses\Parser.gbas";
								}
								forEachSaver13178.values[forEachCounter13178] = local2_M2_2147;
							
							};
							__debugInfo = "217:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver13179.values[forEachCounter13179] = local2_M1_2146;
					
					};
					__debugInfo = "251:\src\CompilerPasses\Parser.gbas";
					while ((((func7_IsToken("ENDTYPE")) == (0)) ? 1 : 0)) {
						var local10_IsAbstract_2148 = 0;
						__debugInfo = "220:\src\CompilerPasses\Parser.gbas";
						local10_IsAbstract_2148 = 0;
						__debugInfo = "224:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("ABSTRACT")) {
							__debugInfo = "222:\src\CompilerPasses\Parser.gbas";
							func5_Match("ABSTRACT", 221, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "223:\src\CompilerPasses\Parser.gbas";
							local10_IsAbstract_2148 = 1;
							__debugInfo = "222:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "245:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("FUNCTION")) {
							__debugInfo = "231:\src\CompilerPasses\Parser.gbas";
							if (local10_IsAbstract_2148) {
								__debugInfo = "228:\src\CompilerPasses\Parser.gbas";
								func10_SkipTokens("FUNCTION", "\n", "ABSTRACT FUNCTION");
								__debugInfo = "228:\src\CompilerPasses\Parser.gbas";
							} else {
								__debugInfo = "230:\src\CompilerPasses\Parser.gbas";
								func10_SkipTokens("FUNCTION", "ENDFUNCTION", "FUNCTION IN TYPE");
								__debugInfo = "230:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "231:\src\CompilerPasses\Parser.gbas";
						} else {
							var local4_Vari_2149 = new type14_IdentifierVari();
							__debugInfo = "234:\src\CompilerPasses\Parser.gbas";
							local4_Vari_2149 = func7_VariDef(0).clone(/* In Assign */);
							__debugInfo = "241:\src\CompilerPasses\Parser.gbas";
							local4_Vari_2149.attr3_Typ = ~~(3);
							__debugInfo = "242:\src\CompilerPasses\Parser.gbas";
							func11_AddVariable(local4_Vari_2149, 1);
							__debugInfo = "243:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(local3_typ_ref_2143[0].attr10_Attributes, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
							__debugInfo = "234:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "250:\src\CompilerPasses\Parser.gbas";
						if ((((func7_IsToken("ENDTYPE")) == (0)) ? 1 : 0)) {
							__debugInfo = "249:\src\CompilerPasses\Parser.gbas";
							func5_Match("\n", 248, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "249:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "220:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "252:\src\CompilerPasses\Parser.gbas";
					func5_Match("ENDTYPE", 251, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "253:\src\CompilerPasses\Parser.gbas";
					return 0;
					__debugInfo = "190:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "254:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver13268.values[forEachCounter13268] = local3_typ_ref_2143;
		
		};
		__debugInfo = "256:\src\CompilerPasses\Parser.gbas";
		func5_Error("Internal error (type definition for unknown type)", 255, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "257:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "187:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_TypeDefi = window['func8_TypeDefi'];
window['func11_CompileFunc'] = function(param4_func) {
	stackPush("function: CompileFunc", __debugInfo);
	try {
		__debugInfo = "323:\src\CompilerPasses\Parser.gbas";
		if ((((((((((param4_func.attr3_Scp) == (-(1))) ? 1 : 0)) && ((((param4_func.attr6_Native) == (0)) ? 1 : 0))) ? 1 : 0)) && ((((param4_func.attr10_PlzCompile) == (1)) ? 1 : 0))) ? 1 : 0)) {
			var local6_TmpScp_2734 = 0.0, local3_Tok_2735 = 0, local7_Curfunc_2736 = 0.0, local3_Scp_2738 = 0;
			__debugInfo = "264:\src\CompilerPasses\Parser.gbas";
			if (param4_func.attr10_IsAbstract) {
				
			};
			__debugInfo = "265:\src\CompilerPasses\Parser.gbas";
			local6_TmpScp_2734 = global8_Compiler.attr12_CurrentScope;
			__debugInfo = "266:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr12_CurrentScope = global8_Compiler.attr9_MainScope;
			__debugInfo = "267:\src\CompilerPasses\Parser.gbas";
			local3_Tok_2735 = global8_Compiler.attr11_currentPosi;
			__debugInfo = "268:\src\CompilerPasses\Parser.gbas";
			local7_Curfunc_2736 = global8_Compiler.attr11_currentFunc;
			__debugInfo = "269:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentFunc = param4_func.attr2_ID;
			__debugInfo = "270:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentPosi = ((param4_func.attr3_Tok) - (1));
			__debugInfo = "271:\src\CompilerPasses\Parser.gbas";
			if (((((((param4_func.attr3_Tok) == (0)) ? 1 : 0)) && (((param4_func.attr10_IsAbstract) ? 0 : 1))) ? 1 : 0)) {
				__debugInfo = "271:\src\CompilerPasses\Parser.gbas";
				func5_Error("Internal error (function has no start token)", 270, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "271:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "284:\src\CompilerPasses\Parser.gbas";
			if ((((param4_func.attr3_Typ) == (3)) ? 1 : 0)) {
				var local4_Vari_2737 = new type14_IdentifierVari();
				__debugInfo = "276:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2737.attr8_Name_Str = "self";
				__debugInfo = "277:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2737.attr8_datatype.attr8_Name_Str_ref[0] = global8_Compiler.attr5_Types_ref[0].arrAccess(param4_func.attr6_MyType).values[tmpPositionCache][0].attr8_Name_Str;
				__debugInfo = "278:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2737.attr8_datatype.attr7_IsArray_ref[0] = 0;
				__debugInfo = "279:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2737.attr3_Typ = ~~(5);
				__debugInfo = "281:\src\CompilerPasses\Parser.gbas";
				func11_AddVariable(local4_Vari_2737, 1);
				__debugInfo = "282:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(param4_func.attr6_Params, local4_Vari_2737.attr2_ID);
				__debugInfo = "283:\src\CompilerPasses\Parser.gbas";
				param4_func.attr7_SelfVar = local4_Vari_2737.attr2_ID;
				__debugInfo = "276:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "292:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "307:\src\CompilerPasses\Parser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "309:\src\CompilerPasses\Parser.gbas";
				try {
					__debugInfo = "306:\src\CompilerPasses\Parser.gbas";
					if (((param4_func.attr10_IsAbstract) ? 0 : 1)) {
						__debugInfo = "302:\src\CompilerPasses\Parser.gbas";
						if ((((param4_func.attr3_Typ) == (2)) ? 1 : 0)) {
							__debugInfo = "297:\src\CompilerPasses\Parser.gbas";
							local3_Scp_2738 = func5_Scope("ENDSUB", param4_func.attr2_ID);
							__debugInfo = "297:\src\CompilerPasses\Parser.gbas";
						} else {
							var local1_e_2739 = 0;
							__debugInfo = "299:\src\CompilerPasses\Parser.gbas";
							local3_Scp_2738 = func5_Scope("ENDFUNCTION", param4_func.attr2_ID);
							__debugInfo = "300:\src\CompilerPasses\Parser.gbas";
							local1_e_2739 = func22_CreateReturnExpression(func28_CreateDefaultValueExpression(param4_func.attr8_datatype));
							__debugInfo = "301:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(global5_Exprs_ref[0].arrAccess(local3_Scp_2738).values[tmpPositionCache][0].attr5_Exprs, local1_e_2739);
							__debugInfo = "299:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "302:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "304:\src\CompilerPasses\Parser.gbas";
						local3_Scp_2738 = func21_CreateScopeExpression(~~(2));
						__debugInfo = "305:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(local3_Scp_2738).values[tmpPositionCache][0].attr5_Exprs, func21_CreateEmptyExpression());
						__debugInfo = "304:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "306:\src\CompilerPasses\Parser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "308:\src\CompilerPasses\Parser.gbas";
						local3_Scp_2738 = func21_CreateEmptyExpression();
						__debugInfo = "308:\src\CompilerPasses\Parser.gbas";
					}
				};
				__debugInfo = "309:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "314:\src\CompilerPasses\Parser.gbas";
			param4_func.attr3_Scp = local3_Scp_2738;
			__debugInfo = "316:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentPosi = ((local3_Tok_2735) - (1));
			__debugInfo = "317:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "318:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentFunc = ~~(local7_Curfunc_2736);
			__debugInfo = "319:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr12_CurrentScope = ~~(local6_TmpScp_2734);
			__debugInfo = "320:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "264:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "322:\src\CompilerPasses\Parser.gbas";
			return tryClone(0);
			__debugInfo = "322:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "324:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "323:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_CompileFunc = window['func11_CompileFunc'];
window['func10_Expression'] = function(param4_Prio) {
	stackPush("function: Expression", __debugInfo);
	try {
		__debugInfo = "358:\src\CompilerPasses\Parser.gbas";
		if ((((param4_Prio) < (15)) ? 1 : 0)) {
			var local4_Left_2151 = 0, local5_Right_2152 = 0, local5_Found_2153 = 0;
			__debugInfo = "328:\src\CompilerPasses\Parser.gbas";
			local4_Left_2151 = func10_Expression(((param4_Prio) + (1)));
			__debugInfo = "329:\src\CompilerPasses\Parser.gbas";
			local5_Right_2152 = -(1);
			__debugInfo = "331:\src\CompilerPasses\Parser.gbas";
			local5_Found_2153 = 0;
			__debugInfo = "353:\src\CompilerPasses\Parser.gbas";
			do {
				__debugInfo = "333:\src\CompilerPasses\Parser.gbas";
				local5_Found_2153 = 0;
				__debugInfo = "352:\src\CompilerPasses\Parser.gbas";
				var forEachSaver13371 = global9_Operators_ref[0];
				for(var forEachCounter13371 = 0 ; forEachCounter13371 < forEachSaver13371.values.length ; forEachCounter13371++) {
					var local2_Op_ref_2154 = forEachSaver13371.values[forEachCounter13371];
				{
						__debugInfo = "351:\src\CompilerPasses\Parser.gbas";
						while (((((((local2_Op_ref_2154[0].attr4_Prio) == (param4_Prio)) ? 1 : 0)) && (func7_IsToken(local2_Op_ref_2154[0].attr7_Sym_Str))) ? 1 : 0)) {
							__debugInfo = "336:\src\CompilerPasses\Parser.gbas";
							func5_Match(local2_Op_ref_2154[0].attr7_Sym_Str, 335, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "337:\src\CompilerPasses\Parser.gbas";
							local5_Right_2152 = func10_Expression(((param4_Prio) + (1)));
							__debugInfo = "338:\src\CompilerPasses\Parser.gbas";
							local4_Left_2151 = func24_CreateOperatorExpression(unref(local2_Op_ref_2154[0]), local4_Left_2151, local5_Right_2152);
							__debugInfo = "346:\src\CompilerPasses\Parser.gbas";
							{
								var Error_Str = "";
								__debugInfo = "348:\src\CompilerPasses\Parser.gbas";
								try {
									var local6_Result_2155 = 0.0;
									__debugInfo = "340:\src\CompilerPasses\Parser.gbas";
									local6_Result_2155 = func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(local4_Left_2151).values[tmpPositionCache][0]));
									__debugInfo = "345:\src\CompilerPasses\Parser.gbas";
									if ((((INTEGER(local6_Result_2155)) == (local6_Result_2155)) ? 1 : 0)) {
										__debugInfo = "342:\src\CompilerPasses\Parser.gbas";
										local4_Left_2151 = func19_CreateIntExpression(~~(local6_Result_2155));
										__debugInfo = "342:\src\CompilerPasses\Parser.gbas";
									} else {
										__debugInfo = "344:\src\CompilerPasses\Parser.gbas";
										local5_Right_2152 = func21_CreateFloatExpression(local6_Result_2155);
										__debugInfo = "344:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "340:\src\CompilerPasses\Parser.gbas";
								} catch (Error_Str) {
									if (Error_Str instanceof OTTException) Error_Str = Error_Str.getText(); else throwError(Error_Str);{
										
									}
								};
								__debugInfo = "348:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "349:\src\CompilerPasses\Parser.gbas";
							local5_Found_2153 = 1;
							__debugInfo = "350:\src\CompilerPasses\Parser.gbas";
							break;
							__debugInfo = "336:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "351:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver13371.values[forEachCounter13371] = local2_Op_ref_2154;
				
				};
				__debugInfo = "333:\src\CompilerPasses\Parser.gbas";
			} while (!((((local5_Found_2153) == (0)) ? 1 : 0)));
			__debugInfo = "355:\src\CompilerPasses\Parser.gbas";
			return tryClone(local4_Left_2151);
			__debugInfo = "328:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "357:\src\CompilerPasses\Parser.gbas";
			return tryClone(func6_Factor());
			__debugInfo = "357:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "359:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "358:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_Expression = window['func10_Expression'];
window['func12_CastDatatype'] = function(param8_RetData1_ref, param8_RetData2_ref) {
	stackPush("function: CastDatatype", __debugInfo);
	try {
		var local5_Data1_2743 = 0, local5_Data2_2744 = 0;
		__debugInfo = "363:\src\CompilerPasses\Parser.gbas";
		local5_Data1_2743 = param8_RetData1_ref[0];
		__debugInfo = "364:\src\CompilerPasses\Parser.gbas";
		local5_Data2_2744 = param8_RetData2_ref[0];
		__debugInfo = "388:\src\CompilerPasses\Parser.gbas";
		if ((((global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0])) ? 1 : 0)) {
			__debugInfo = "385:\src\CompilerPasses\Parser.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == (global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0])) ? 1 : 0)) {
				__debugInfo = "368:\src\CompilerPasses\Parser.gbas";
				param8_RetData1_ref[0] = local5_Data1_2743;
				__debugInfo = "369:\src\CompilerPasses\Parser.gbas";
				param8_RetData2_ref[0] = local5_Data2_2744;
				__debugInfo = "370:\src\CompilerPasses\Parser.gbas";
				return tryClone(global5_Exprs_ref[0].arrAccess(param8_RetData1_ref[0]).values[tmpPositionCache][0].attr8_datatype);
				__debugInfo = "368:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "382:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0)) {
					__debugInfo = "373:\src\CompilerPasses\Parser.gbas";
					param8_RetData2_ref[0] = func27_CreateCast2StringExpression(local5_Data2_2744);
					__debugInfo = "373:\src\CompilerPasses\Parser.gbas";
				} else if ((((global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0)) {
					__debugInfo = "375:\src\CompilerPasses\Parser.gbas";
					param8_RetData1_ref[0] = func27_CreateCast2StringExpression(local5_Data1_2743);
					__debugInfo = "375:\src\CompilerPasses\Parser.gbas";
				} else if ((((global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0)) {
					__debugInfo = "377:\src\CompilerPasses\Parser.gbas";
					param8_RetData2_ref[0] = func26_CreateCast2FloatExpression(local5_Data2_2744);
					__debugInfo = "377:\src\CompilerPasses\Parser.gbas";
				} else if ((((global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0)) {
					__debugInfo = "379:\src\CompilerPasses\Parser.gbas";
					param8_RetData1_ref[0] = func26_CreateCast2FloatExpression(local5_Data1_2743);
					__debugInfo = "379:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "381:\src\CompilerPasses\Parser.gbas";
					func5_Error((((((((((((("Cannot cast '") + (global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]))))) + ("' to '"))) + (global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]))))) + ("'")), 380, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "381:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "384:\src\CompilerPasses\Parser.gbas";
				return tryClone(global5_Exprs_ref[0].arrAccess(param8_RetData1_ref[0]).values[tmpPositionCache][0].attr8_datatype);
				__debugInfo = "382:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "385:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "387:\src\CompilerPasses\Parser.gbas";
			func5_Error((((((((((("Dimensions are different: ") + (global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(global5_Exprs_ref[0].arrAccess(local5_Data1_2743).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]))))) + (", "))) + (global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(global5_Exprs_ref[0].arrAccess(local5_Data2_2744).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0])))), 386, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "387:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "389:\src\CompilerPasses\Parser.gbas";
		return tryClone(unref(new type8_Datatype()));
		__debugInfo = "363:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_CastDatatype = window['func12_CastDatatype'];
window['func14_EnsureDatatype'] = function(param4_Expr, param8_NeedData, param4_Line, param6_Strict) {
	stackPush("function: EnsureDatatype", __debugInfo);
	try {
		var local6_myData_2161 = new type8_Datatype();
		__debugInfo = "397:\src\CompilerPasses\Parser.gbas";
		param6_Strict = 0;
		__debugInfo = "400:\src\CompilerPasses\Parser.gbas";
		if ((((param8_NeedData.attr8_Name_Str_ref[0]) == ("")) ? 1 : 0)) {
			__debugInfo = "400:\src\CompilerPasses\Parser.gbas";
			func5_Error("Internal error (datatype is empty)", 399, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "400:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "402:\src\CompilerPasses\Parser.gbas";
		local6_myData_2161 = global5_Exprs_ref[0].arrAccess(param4_Expr).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
		__debugInfo = "461:\src\CompilerPasses\Parser.gbas";
		if (((((((local6_myData_2161.attr8_Name_Str_ref[0]) == (param8_NeedData.attr8_Name_Str_ref[0])) ? 1 : 0)) && ((((local6_myData_2161.attr7_IsArray_ref[0]) == (param8_NeedData.attr7_IsArray_ref[0])) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "404:\src\CompilerPasses\Parser.gbas";
			return tryClone(param4_Expr);
			__debugInfo = "404:\src\CompilerPasses\Parser.gbas";
		} else {
			var local5_func1_2163 = 0, local5_func2_2164 = 0, local7_add_Str_2167 = "";
			__debugInfo = "421:\src\CompilerPasses\Parser.gbas";
			if ((((param6_Strict) == (0)) ? 1 : 0)) {
				__debugInfo = "420:\src\CompilerPasses\Parser.gbas";
				if ((((local6_myData_2161.attr7_IsArray_ref[0]) == (param8_NeedData.attr7_IsArray_ref[0])) ? 1 : 0)) {
					__debugInfo = "419:\src\CompilerPasses\Parser.gbas";
					if ((((((((((local6_myData_2161.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((local6_myData_2161.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((local6_myData_2161.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "418:\src\CompilerPasses\Parser.gbas";
						if ((((((((((param8_NeedData.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((param8_NeedData.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((param8_NeedData.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "410:\src\CompilerPasses\Parser.gbas";
							{
								var local17___SelectHelper18__2162 = "";
								__debugInfo = "410:\src\CompilerPasses\Parser.gbas";
								local17___SelectHelper18__2162 = param8_NeedData.attr8_Name_Str_ref[0];
								__debugInfo = "417:\src\CompilerPasses\Parser.gbas";
								if ((((local17___SelectHelper18__2162) == ("int")) ? 1 : 0)) {
									__debugInfo = "412:\src\CompilerPasses\Parser.gbas";
									return tryClone(func24_CreateCast2IntExpression(param4_Expr));
									__debugInfo = "412:\src\CompilerPasses\Parser.gbas";
								} else if ((((local17___SelectHelper18__2162) == ("float")) ? 1 : 0)) {
									__debugInfo = "414:\src\CompilerPasses\Parser.gbas";
									return tryClone(func26_CreateCast2FloatExpression(param4_Expr));
									__debugInfo = "414:\src\CompilerPasses\Parser.gbas";
								} else if ((((local17___SelectHelper18__2162) == ("string")) ? 1 : 0)) {
									__debugInfo = "416:\src\CompilerPasses\Parser.gbas";
									return tryClone(func27_CreateCast2StringExpression(param4_Expr));
									__debugInfo = "416:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "410:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "410:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "418:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "419:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "420:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "423:\src\CompilerPasses\Parser.gbas";
			local5_func1_2163 = func14_SearchPrototyp(unref(local6_myData_2161.attr8_Name_Str_ref[0]));
			__debugInfo = "424:\src\CompilerPasses\Parser.gbas";
			local5_func2_2164 = func14_SearchPrototyp(unref(param8_NeedData.attr8_Name_Str_ref[0]));
			__debugInfo = "449:\src\CompilerPasses\Parser.gbas";
			if ((((local5_func1_2163) != (-(1))) ? 1 : 0)) {
				__debugInfo = "448:\src\CompilerPasses\Parser.gbas";
				if ((((local5_func2_2164) != (-(1))) ? 1 : 0)) {
					var local7_checker_2165 = new type12_ProtoChecker();
					__debugInfo = "427:\src\CompilerPasses\Parser.gbas";
					if ((((local6_myData_2161.attr7_IsArray_ref[0]) || (param8_NeedData.attr7_IsArray_ref[0])) ? 1 : 0)) {
						__debugInfo = "427:\src\CompilerPasses\Parser.gbas";
						func5_Error("PROTOTYPE cannot be an array.", 426, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "427:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "430:\src\CompilerPasses\Parser.gbas";
					local7_checker_2165.attr8_fromFunc = global8_Compiler.attr5_Funcs_ref[0].arrAccess(local5_func1_2163).values[tmpPositionCache][0].attr2_ID;
					__debugInfo = "431:\src\CompilerPasses\Parser.gbas";
					local7_checker_2165.attr6_toFunc = global8_Compiler.attr5_Funcs_ref[0].arrAccess(local5_func2_2164).values[tmpPositionCache][0].attr2_ID;
					__debugInfo = "432:\src\CompilerPasses\Parser.gbas";
					local7_checker_2165.attr3_Tok = func15_GetCurrentToken().clone(/* In Assign */);
					__debugInfo = "433:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global8_Compiler.attr13_protoCheckers, local7_checker_2165);
					__debugInfo = "435:\src\CompilerPasses\Parser.gbas";
					return tryClone(param4_Expr);
					__debugInfo = "427:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "447:\src\CompilerPasses\Parser.gbas";
					if (((((((((((((param8_NeedData.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((param8_NeedData.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((param8_NeedData.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) && ((((param8_NeedData.attr7_IsArray_ref[0]) == (0)) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "439:\src\CompilerPasses\Parser.gbas";
						{
							var local17___SelectHelper19__2166 = "";
							__debugInfo = "439:\src\CompilerPasses\Parser.gbas";
							local17___SelectHelper19__2166 = param8_NeedData.attr8_Name_Str_ref[0];
							__debugInfo = "446:\src\CompilerPasses\Parser.gbas";
							if ((((local17___SelectHelper19__2166) == ("int")) ? 1 : 0)) {
								__debugInfo = "441:\src\CompilerPasses\Parser.gbas";
								return tryClone(func24_CreateCast2IntExpression(param4_Expr));
								__debugInfo = "441:\src\CompilerPasses\Parser.gbas";
							} else if ((((local17___SelectHelper19__2166) == ("float")) ? 1 : 0)) {
								__debugInfo = "443:\src\CompilerPasses\Parser.gbas";
								return tryClone(func26_CreateCast2FloatExpression(param4_Expr));
								__debugInfo = "443:\src\CompilerPasses\Parser.gbas";
							} else if ((((local17___SelectHelper19__2166) == ("string")) ? 1 : 0)) {
								__debugInfo = "445:\src\CompilerPasses\Parser.gbas";
								return tryClone(func27_CreateCast2StringExpression(param4_Expr));
								__debugInfo = "445:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "439:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "439:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "447:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "448:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "454:\src\CompilerPasses\Parser.gbas";
			if ((((func6_IsType(unref(local6_myData_2161.attr8_Name_Str_ref[0]))) && (func6_IsType(unref(param8_NeedData.attr8_Name_Str_ref[0])))) ? 1 : 0)) {
				__debugInfo = "453:\src\CompilerPasses\Parser.gbas";
				return tryClone(param4_Expr);
				__debugInfo = "453:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "456:\src\CompilerPasses\Parser.gbas";
			local7_add_Str_2167 = "";
			__debugInfo = "459:\src\CompilerPasses\Parser.gbas";
			if (param6_Strict) {
				__debugInfo = "458:\src\CompilerPasses\Parser.gbas";
				local7_add_Str_2167 = " , and maybe can't cast, because it is BYREF (screw you BYREF >:O)!!";
				__debugInfo = "458:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "460:\src\CompilerPasses\Parser.gbas";
			func5_Error((((((((((((((("Cannot cast datatypes. Needs '") + (param8_NeedData.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(param8_NeedData.attr7_IsArray_ref[0]))))) + ("', got '"))) + (local6_myData_2161.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(local6_myData_2161.attr7_IsArray_ref[0]))))) + ("'"))) + (local7_add_Str_2167)), param4_Line, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "421:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "462:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "397:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_EnsureDatatype = window['func14_EnsureDatatype'];
window['func20_BuildArrBrackets_Str'] = function(param7_IsArray) {
	stackPush("function: BuildArrBrackets_Str", __debugInfo);
	try {
		__debugInfo = "469:\src\CompilerPasses\Parser.gbas";
		if (param7_IsArray) {
			__debugInfo = "466:\src\CompilerPasses\Parser.gbas";
			return "[]";
			__debugInfo = "466:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "468:\src\CompilerPasses\Parser.gbas";
			return "";
			__debugInfo = "468:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "470:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "469:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func20_BuildArrBrackets_Str = window['func20_BuildArrBrackets_Str'];
window['func7_Hex2Dec'] = function(param7_hex_Str) {
	stackPush("function: Hex2Dec", __debugInfo);
	try {
		var local1_i_2746 = 0, local1_j_2747 = 0, local4_loop_2748 = 0;
		__debugInfo = "479:\src\CompilerPasses\Parser.gbas";
		local1_i_2746 = 0;
		__debugInfo = "480:\src\CompilerPasses\Parser.gbas";
		local1_j_2747 = 0;
		__debugInfo = "480:\src\CompilerPasses\Parser.gbas";
		{
			__debugInfo = "489:\src\CompilerPasses\Parser.gbas";
			for (local4_loop_2748 = 0;toCheck(local4_loop_2748, (((param7_hex_Str).length) - (1)), 1);local4_loop_2748 += 1) {
				__debugInfo = "482:\src\CompilerPasses\Parser.gbas";
				local1_i_2746 = ((ASC(MID_Str(param7_hex_Str, local4_loop_2748, 1), 0)) - (48));
				__debugInfo = "485:\src\CompilerPasses\Parser.gbas";
				if ((((9) < (local1_i_2746)) ? 1 : 0)) {
					__debugInfo = "484:\src\CompilerPasses\Parser.gbas";
					local1_i_2746+=-(7);
					__debugInfo = "484:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "487:\src\CompilerPasses\Parser.gbas";
				local1_j_2747 = ((local1_j_2747) * (16));
				__debugInfo = "488:\src\CompilerPasses\Parser.gbas";
				local1_j_2747 = bOR(local1_j_2747, bAND(local1_i_2746, 15));
				__debugInfo = "482:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "489:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "491:\src\CompilerPasses\Parser.gbas";
		return tryClone(local1_j_2747);
		__debugInfo = "492:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "479:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_Hex2Dec = window['func7_Hex2Dec'];
window['func6_Factor'] = function() {
	stackPush("function: Factor", __debugInfo);
	try {
		__debugInfo = "725:\src\CompilerPasses\Parser.gbas";
		if (func7_IsToken("(")) {
			var local4_Expr_2169 = 0;
			__debugInfo = "497:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 496, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "498:\src\CompilerPasses\Parser.gbas";
			local4_Expr_2169 = func10_Expression(0);
			__debugInfo = "499:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 498, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "500:\src\CompilerPasses\Parser.gbas";
			return tryClone(local4_Expr_2169);
			__debugInfo = "497:\src\CompilerPasses\Parser.gbas";
		} else if (func12_IsIdentifier(1, 0)) {
			__debugInfo = "502:\src\CompilerPasses\Parser.gbas";
			return tryClone(func10_Identifier(0));
			__debugInfo = "502:\src\CompilerPasses\Parser.gbas";
		} else if (func8_IsString()) {
			var local7_Str_Str_2170 = "";
			__debugInfo = "504:\src\CompilerPasses\Parser.gbas";
			local7_Str_Str_2170 = func14_GetCurrent_Str();
			__debugInfo = "508:\src\CompilerPasses\Parser.gbas";
			if ((((INSTR(local7_Str_Str_2170, "\n", 0)) != (-(1))) ? 1 : 0)) {
				__debugInfo = "507:\src\CompilerPasses\Parser.gbas";
				func5_Error("Expecting '\"'", 506, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "507:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "509:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "510:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateStrExpression(local7_Str_Str_2170));
			__debugInfo = "504:\src\CompilerPasses\Parser.gbas";
		} else if ((((MID_Str(func14_GetCurrent_Str(), 0, 2)) == ("0x")) ? 1 : 0)) {
			var local7_hex_Str_2171 = "";
			__debugInfo = "512:\src\CompilerPasses\Parser.gbas";
			local7_hex_Str_2171 = MID_Str(func14_GetCurrent_Str(), 2, -(1));
			__debugInfo = "513:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "514:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateIntExpression(func7_Hex2Dec(local7_hex_Str_2171)));
			__debugInfo = "512:\src\CompilerPasses\Parser.gbas";
		} else if ((((func8_IsNumber()) || (func7_IsToken("."))) ? 1 : 0)) {
			var local3_Num_2172 = 0, local12_hasToHaveNum_2173 = 0;
			__debugInfo = "517:\src\CompilerPasses\Parser.gbas";
			local12_hasToHaveNum_2173 = 0;
			__debugInfo = "524:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken(".")) {
				__debugInfo = "519:\src\CompilerPasses\Parser.gbas";
				local3_Num_2172 = 0;
				__debugInfo = "520:\src\CompilerPasses\Parser.gbas";
				local12_hasToHaveNum_2173 = 1;
				__debugInfo = "519:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "522:\src\CompilerPasses\Parser.gbas";
				local3_Num_2172 = INT2STR(func14_GetCurrent_Str());
				__debugInfo = "523:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "522:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "542:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken(".")) {
				var local4_Num2_2174 = 0, local3_pos_2175 = 0, local4_FNum_2176 = 0.0;
				__debugInfo = "527:\src\CompilerPasses\Parser.gbas";
				func5_Match(".", 526, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "528:\src\CompilerPasses\Parser.gbas";
				local4_Num2_2174 = INT2STR(func14_GetCurrent_Str());
				__debugInfo = "529:\src\CompilerPasses\Parser.gbas";
				local3_pos_2175 = global8_Compiler.attr11_currentPosi;
				__debugInfo = "535:\src\CompilerPasses\Parser.gbas";
				if (func8_IsNumber()) {
					__debugInfo = "532:\src\CompilerPasses\Parser.gbas";
					func7_GetNext();
					__debugInfo = "532:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "536:\src\CompilerPasses\Parser.gbas";
				local4_FNum_2176 = FLOAT2STR(((((((CAST2STRING(local3_Num_2172)) + ("."))) + (CAST2STRING(local4_Num2_2174)))) + (CAST2STRING(0))));
				__debugInfo = "538:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateFloatExpression(local4_FNum_2176));
				__debugInfo = "527:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "540:\src\CompilerPasses\Parser.gbas";
				if (local12_hasToHaveNum_2173) {
					__debugInfo = "540:\src\CompilerPasses\Parser.gbas";
					func5_Error("Expecting number!", 539, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "540:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "541:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateIntExpression(local3_Num_2172));
				__debugInfo = "540:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "517:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("-")) {
			var local4_Expr_2177 = 0, alias2_Op_ref_2178 = [new type8_Operator()], local7_tmpData_2179 = new type8_Datatype();
			__debugInfo = "544:\src\CompilerPasses\Parser.gbas";
			func5_Match("-", 543, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "545:\src\CompilerPasses\Parser.gbas";
			local4_Expr_2177 = func6_Factor();
			__debugInfo = "546:\src\CompilerPasses\Parser.gbas";
			alias2_Op_ref_2178 = global9_Operators_ref[0].arrAccess(func14_SearchOperator("sub")).values[tmpPositionCache] /* ALIAS */;
			__debugInfo = "548:\src\CompilerPasses\Parser.gbas";
			local7_tmpData_2179 = global5_Exprs_ref[0].arrAccess(local4_Expr_2177).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
			__debugInfo = "549:\src\CompilerPasses\Parser.gbas";
			local7_tmpData_2179.attr7_IsArray_ref[0] = 0;
			__debugInfo = "551:\src\CompilerPasses\Parser.gbas";
			local4_Expr_2177 = func14_EnsureDatatype(local4_Expr_2177, local7_tmpData_2179, 550, 0);
			__debugInfo = "558:\src\CompilerPasses\Parser.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2177).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0)) {
				__debugInfo = "553:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2177 = func24_CreateOperatorExpression(unref(alias2_Op_ref_2178[0]), func21_CreateFloatExpression(0), func14_EnsureDatatype(local4_Expr_2177, global13_floatDatatype, 552, 0));
				__debugInfo = "553:\src\CompilerPasses\Parser.gbas";
			} else if (((((((global5_Exprs_ref[0].arrAccess(local4_Expr_2177).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2177).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "555:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2177 = func24_CreateOperatorExpression(unref(alias2_Op_ref_2178[0]), func19_CreateIntExpression(0), func14_EnsureDatatype(local4_Expr_2177, global11_intDatatype, 554, 0));
				__debugInfo = "555:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "557:\src\CompilerPasses\Parser.gbas";
				func5_Error((((("Unexpected datatype, expecting 'float/int' got '") + (global5_Exprs_ref[0].arrAccess(local4_Expr_2177).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + ("'")), 556, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "557:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "559:\src\CompilerPasses\Parser.gbas";
			return tryClone(local4_Expr_2177);
			__debugInfo = "544:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("TRUE")) {
			__debugInfo = "561:\src\CompilerPasses\Parser.gbas";
			func5_Match("TRUE", 560, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "562:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateIntExpression(1));
			__debugInfo = "561:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("FALSE")) {
			__debugInfo = "564:\src\CompilerPasses\Parser.gbas";
			func5_Match("FALSE", 563, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "565:\src\CompilerPasses\Parser.gbas";
			return tryClone(func21_CreateFloatExpression(0));
			__debugInfo = "564:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("CODELINE")) {
			__debugInfo = "567:\src\CompilerPasses\Parser.gbas";
			func5_Match("CODELINE", 566, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "568:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 567, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "569:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 568, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "570:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateIntExpression(unref(global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr4_Line_ref[0])));
			__debugInfo = "567:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("CODEFILE$")) {
			__debugInfo = "572:\src\CompilerPasses\Parser.gbas";
			func5_Match("CODEFILE$", 571, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "573:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 572, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "574:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 573, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "575:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateStrExpression((((("\"") + (MID_Str(unref(global8_Compiler.attr6_Tokens.arrAccess(global8_Compiler.attr11_currentPosi).values[tmpPositionCache].attr8_Path_Str_ref[0]), 1, -(1))))) + ("\""))));
			__debugInfo = "572:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("LEN")) {
			var local4_Expr_2180 = 0, local7_Kerning_2181 = 0;
			__debugInfo = "577:\src\CompilerPasses\Parser.gbas";
			func5_Match("LEN", 576, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "578:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 577, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "580:\src\CompilerPasses\Parser.gbas";
			local4_Expr_2180 = func10_Expression(0);
			__debugInfo = "581:\src\CompilerPasses\Parser.gbas";
			local7_Kerning_2181 = 0;
			__debugInfo = "605:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken(",")) {
				__debugInfo = "583:\src\CompilerPasses\Parser.gbas";
				func5_Match(",", 582, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "584:\src\CompilerPasses\Parser.gbas";
				local7_Kerning_2181 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 583, 0);
				__debugInfo = "585:\src\CompilerPasses\Parser.gbas";
				func5_Match(")", 584, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "588:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2180 = func14_EnsureDatatype(local4_Expr_2180, global11_strDatatype, 587, 0);
				__debugInfo = "590:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateLenExpression(local4_Expr_2180, local7_Kerning_2181));
				__debugInfo = "583:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "592:\src\CompilerPasses\Parser.gbas";
				func5_Match(")", 591, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "604:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2180).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
					__debugInfo = "601:\src\CompilerPasses\Parser.gbas";
					if ((((((((((global5_Exprs_ref[0].arrAccess(local4_Expr_2180).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2180).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2180).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "596:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2180 = func14_EnsureDatatype(local4_Expr_2180, global11_strDatatype, 595, 0);
						__debugInfo = "598:\src\CompilerPasses\Parser.gbas";
						return tryClone(func19_CreateLenExpression(local4_Expr_2180, -(1)));
						__debugInfo = "596:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "600:\src\CompilerPasses\Parser.gbas";
						func5_Error((((("Cannot get the length of Type '") + (global5_Exprs_ref[0].arrAccess(local4_Expr_2180).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + ("'")), 599, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "600:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "601:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "603:\src\CompilerPasses\Parser.gbas";
					return tryClone(func21_CreateBoundExpression(local4_Expr_2180, func19_CreateIntExpression(0)));
					__debugInfo = "603:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "592:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "577:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("BOUNDS")) {
			var local4_Expr_2182 = 0, local9_Dimension_2183 = 0;
			__debugInfo = "607:\src\CompilerPasses\Parser.gbas";
			func5_Match("BOUNDS", 606, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "608:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 607, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "609:\src\CompilerPasses\Parser.gbas";
			local4_Expr_2182 = func10_Expression(0);
			__debugInfo = "610:\src\CompilerPasses\Parser.gbas";
			func5_Match(",", 609, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "611:\src\CompilerPasses\Parser.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(local4_Expr_2182).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
				__debugInfo = "611:\src\CompilerPasses\Parser.gbas";
				func5_Error("BOUNDS needs array!", 610, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "611:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "612:\src\CompilerPasses\Parser.gbas";
			local9_Dimension_2183 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 611, 0);
			__debugInfo = "613:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 612, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "615:\src\CompilerPasses\Parser.gbas";
			return tryClone(func21_CreateBoundExpression(local4_Expr_2182, local9_Dimension_2183));
			__debugInfo = "607:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("ADDRESSOF")) {
			var local8_Name_Str_2184 = "", local6_MyFunc_2185 = 0;
			__debugInfo = "617:\src\CompilerPasses\Parser.gbas";
			func5_Match("ADDRESSOF", 616, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "618:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 617, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "619:\src\CompilerPasses\Parser.gbas";
			local8_Name_Str_2184 = func14_GetCurrent_Str();
			__debugInfo = "620:\src\CompilerPasses\Parser.gbas";
			local6_MyFunc_2185 = -(1);
			__debugInfo = "626:\src\CompilerPasses\Parser.gbas";
			var forEachSaver14289 = global8_Compiler.attr5_Funcs_ref[0];
			for(var forEachCounter14289 = 0 ; forEachCounter14289 < forEachSaver14289.values.length ; forEachCounter14289++) {
				var local4_Func_ref_2186 = forEachSaver14289.values[forEachCounter14289];
			{
					__debugInfo = "625:\src\CompilerPasses\Parser.gbas";
					if ((((((((((local4_Func_ref_2186[0].attr3_Typ) == (1)) ? 1 : 0)) || ((((local4_Func_ref_2186[0].attr3_Typ) == (2)) ? 1 : 0))) ? 1 : 0)) && ((((local4_Func_ref_2186[0].attr8_Name_Str) == (local8_Name_Str_2184)) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "623:\src\CompilerPasses\Parser.gbas";
						local6_MyFunc_2185 = local4_Func_ref_2186[0].attr2_ID;
						__debugInfo = "624:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "623:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "625:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver14289.values[forEachCounter14289] = local4_Func_ref_2186;
			
			};
			__debugInfo = "627:\src\CompilerPasses\Parser.gbas";
			if ((((local6_MyFunc_2185) == (-(1))) ? 1 : 0)) {
				__debugInfo = "627:\src\CompilerPasses\Parser.gbas";
				func5_Error((((("Function '") + (local8_Name_Str_2184))) + ("' is unknown!")), 626, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "627:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "628:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr5_Funcs_ref[0].arrAccess(local6_MyFunc_2185).values[tmpPositionCache][0].attr10_PlzCompile = 1;
			__debugInfo = "629:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "630:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 629, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "632:\src\CompilerPasses\Parser.gbas";
			return tryClone(func25_CreateAddressOfExpression(local6_MyFunc_2185));
			__debugInfo = "617:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("NOT")) {
			__debugInfo = "634:\src\CompilerPasses\Parser.gbas";
			func5_Match("NOT", 633, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "635:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateNotExpression(func14_EnsureDatatype(func6_Factor(), global13_floatDatatype, 634, 0)));
			__debugInfo = "634:\src\CompilerPasses\Parser.gbas";
		} else if ((((((((((func7_IsToken("DIM")) || (func7_IsToken("DIM%"))) ? 1 : 0)) || (func7_IsToken("DIM$"))) ? 1 : 0)) || (func7_IsToken("DIM#"))) ? 1 : 0)) {
			var local8_datatype_2188 = new type8_Datatype(), local4_dims_2189 = new OTTArray(0);
			__debugInfo = "641:\src\CompilerPasses\Parser.gbas";
			if (((static12_Factor_DIMASEXPRErr) ? 0 : 1)) {
				__debugInfo = "639:\src\CompilerPasses\Parser.gbas";
				static12_Factor_DIMASEXPRErr = 1;
				__debugInfo = "640:\src\CompilerPasses\Parser.gbas";
				func7_Warning("Experimental feature 'DIMASEXPR'");
				__debugInfo = "639:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "643:\src\CompilerPasses\Parser.gbas";
			local8_datatype_2188.attr7_IsArray_ref[0] = 1;
			__debugInfo = "644:\src\CompilerPasses\Parser.gbas";
			local8_datatype_2188.attr8_Name_Str_ref[0] = "float";
			__debugInfo = "645:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("DIM%")) {
				__debugInfo = "645:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2188.attr8_Name_Str_ref[0] = "int";
				__debugInfo = "645:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "646:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("DIM$")) {
				__debugInfo = "646:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2188.attr8_Name_Str_ref[0] = "string";
				__debugInfo = "646:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "647:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("DIM#")) {
				__debugInfo = "647:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2188.attr8_Name_Str_ref[0] = "float";
				__debugInfo = "647:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "648:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "656:\src\CompilerPasses\Parser.gbas";
			do {
				var local1_E_2190 = 0;
				__debugInfo = "652:\src\CompilerPasses\Parser.gbas";
				func5_Match("[", 651, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "653:\src\CompilerPasses\Parser.gbas";
				local1_E_2190 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 652, 0);
				__debugInfo = "654:\src\CompilerPasses\Parser.gbas";
				func5_Match("]", 653, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "655:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(local4_dims_2189, local1_E_2190);
				__debugInfo = "652:\src\CompilerPasses\Parser.gbas";
			} while (!((((func7_IsToken("[")) == (0)) ? 1 : 0)));
			__debugInfo = "666:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("AS")) {
				__debugInfo = "665:\src\CompilerPasses\Parser.gbas";
				if ((((local8_datatype_2188.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0)) {
					__debugInfo = "660:\src\CompilerPasses\Parser.gbas";
					func5_Match("AS", 659, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "661:\src\CompilerPasses\Parser.gbas";
					func15_IsValidDatatype();
					__debugInfo = "662:\src\CompilerPasses\Parser.gbas";
					local8_datatype_2188.attr8_Name_Str_ref[0] = func14_GetCurrent_Str();
					__debugInfo = "660:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "664:\src\CompilerPasses\Parser.gbas";
					func5_Error("Unexpected AS", 663, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "664:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "665:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "668:\src\CompilerPasses\Parser.gbas";
			return tryClone(func25_CreateDimAsExprExpression(local8_datatype_2188, unref(local4_dims_2189)));
			__debugInfo = "641:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("DEFINED")) {
			var local4_Find_2191 = 0;
			__debugInfo = "670:\src\CompilerPasses\Parser.gbas";
			func5_Match("DEFINED", 669, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "671:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 670, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "672:\src\CompilerPasses\Parser.gbas";
			local4_Find_2191 = 0;
			__debugInfo = "678:\src\CompilerPasses\Parser.gbas";
			var forEachSaver14504 = global7_Defines;
			for(var forEachCounter14504 = 0 ; forEachCounter14504 < forEachSaver14504.values.length ; forEachCounter14504++) {
				var local3_Def_2192 = forEachSaver14504.values[forEachCounter14504];
			{
					__debugInfo = "677:\src\CompilerPasses\Parser.gbas";
					if ((((func7_IsToken(local3_Def_2192.attr7_Key_Str)) && ((((INTEGER(FLOAT2STR(local3_Def_2192.attr9_Value_Str))) != (0)) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "675:\src\CompilerPasses\Parser.gbas";
						local4_Find_2191 = 1;
						__debugInfo = "676:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "675:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "677:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver14504.values[forEachCounter14504] = local3_Def_2192;
			
			};
			__debugInfo = "679:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "680:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 679, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "682:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateIntExpression(local4_Find_2191));
			__debugInfo = "670:\src\CompilerPasses\Parser.gbas";
		} else if (func7_IsToken("IIF")) {
			var local4_Cond_2193 = 0, local6_onTrue_2194 = 0, local7_onFalse_2195 = 0;
			__debugInfo = "684:\src\CompilerPasses\Parser.gbas";
			func5_Match("IIF", 683, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "685:\src\CompilerPasses\Parser.gbas";
			func5_Match("(", 684, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "687:\src\CompilerPasses\Parser.gbas";
			local4_Cond_2193 = func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 686, 0);
			__debugInfo = "688:\src\CompilerPasses\Parser.gbas";
			func5_Match(",", 687, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "689:\src\CompilerPasses\Parser.gbas";
			local6_onTrue_2194 = func10_Expression(0);
			__debugInfo = "690:\src\CompilerPasses\Parser.gbas";
			func5_Match(",", 689, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "691:\src\CompilerPasses\Parser.gbas";
			local7_onFalse_2195 = func10_Expression(0);
			__debugInfo = "692:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 691, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "696:\src\CompilerPasses\Parser.gbas";
			if (((((((global5_Exprs_ref[0].arrAccess(local6_onTrue_2194).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]) != (global5_Exprs_ref[0].arrAccess(local7_onFalse_2195).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0])) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local6_onTrue_2194).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) != (global5_Exprs_ref[0].arrAccess(local7_onFalse_2195).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0])) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "695:\src\CompilerPasses\Parser.gbas";
				func5_Error("IIF parameters do not match!", 694, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "695:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "698:\src\CompilerPasses\Parser.gbas";
			return tryClone(func19_CreateIIFExpression(local4_Cond_2193, local6_onTrue_2194, local7_onFalse_2195));
			__debugInfo = "684:\src\CompilerPasses\Parser.gbas";
		} else if (func8_IsDefine("")) {
			__debugInfo = "700:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "707:\src\CompilerPasses\Parser.gbas";
			if ((((CAST2STRING(INTEGER(FLOAT2STR(global10_LastDefine.attr9_Value_Str)))) == (global10_LastDefine.attr9_Value_Str)) ? 1 : 0)) {
				__debugInfo = "702:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateIntExpression(INT2STR(global10_LastDefine.attr9_Value_Str)));
				__debugInfo = "702:\src\CompilerPasses\Parser.gbas";
			} else if (((((((MID_Str(global10_LastDefine.attr9_Value_Str, 0, 1)) == ("\"")) ? 1 : 0)) && ((((MID_Str(global10_LastDefine.attr9_Value_Str, (((global10_LastDefine.attr9_Value_Str).length) - (1)), 1)) == ("\"")) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "704:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateStrExpression(global10_LastDefine.attr9_Value_Str));
				__debugInfo = "704:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "706:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateFloatExpression(FLOAT2STR(global10_LastDefine.attr9_Value_Str)));
				__debugInfo = "706:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "700:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "724:\src\CompilerPasses\Parser.gbas";
			if (((global6_STRICT) ? 0 : 1)) {
				__debugInfo = "711:\src\CompilerPasses\Parser.gbas";
				func14_ImplicitDefine();
				__debugInfo = "712:\src\CompilerPasses\Parser.gbas";
				return tryClone(func10_Identifier(0));
				__debugInfo = "711:\src\CompilerPasses\Parser.gbas";
			} else {
				var local8_vars_Str_2196 = "", local5_Varis_2197 = new OTTArray(0);
				__debugInfo = "715:\src\CompilerPasses\Parser.gbas";
				func14_ImplicitDefine();
				__debugInfo = "717:\src\CompilerPasses\Parser.gbas";
				local8_vars_Str_2196 = "";
				__debugInfo = "719:\src\CompilerPasses\Parser.gbas";
				func8_GetVaris(unref(local5_Varis_2197), -(1), 0);
				__debugInfo = "722:\src\CompilerPasses\Parser.gbas";
				var forEachSaver14685 = local5_Varis_2197;
				for(var forEachCounter14685 = 0 ; forEachCounter14685 < forEachSaver14685.values.length ; forEachCounter14685++) {
					var local4_Vari_2198 = forEachSaver14685.values[forEachCounter14685];
				{
						__debugInfo = "721:\src\CompilerPasses\Parser.gbas";
						local8_vars_Str_2196 = ((((local8_vars_Str_2196) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Vari_2198).values[tmpPositionCache][0].attr8_Name_Str))) + (", "));
						__debugInfo = "721:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver14685.values[forEachCounter14685] = local4_Vari_2198;
				
				};
				__debugInfo = "723:\src\CompilerPasses\Parser.gbas";
				func5_Error((((((((("Unknown variable/function: ") + (func14_GetCurrent_Str()))) + (" possible variables: '"))) + (local8_vars_Str_2196))) + ("'")), 722, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "715:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "724:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "726:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "725:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func6_Factor = window['func6_Factor'];
window['func8_FixError'] = function() {
	stackPush("function: FixError", __debugInfo);
	try {
		__debugInfo = "730:\src\CompilerPasses\Parser.gbas";
		func7_GetNext();
		__debugInfo = "737:\src\CompilerPasses\Parser.gbas";
		if (((func7_IsToken("\n")) ? 0 : 1)) {
			__debugInfo = "736:\src\CompilerPasses\Parser.gbas";
			while (((((((func9_IsKeyword()) == (0)) ? 1 : 0)) && ((((func7_IsToken("\n")) == (0)) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "735:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "735:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "736:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "738:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "730:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_FixError = window['func8_FixError'];
window['func6_Parser'] = function() {
	stackPush("function: Parser", __debugInfo);
	try {
		__debugInfo = "1004:\src\CompilerPasses\Parser.gbas";
		{
			var Err_Str = "";
			__debugInfo = "1005:\src\CompilerPasses\Parser.gbas";
			try {
				var local5_found_2217 = 0;
				__debugInfo = "743:\src\CompilerPasses\Parser.gbas";
				func5_Start();
				__debugInfo = "745:\src\CompilerPasses\Parser.gbas";
				func5_Scope("__EOFFILE__", -(1));
				__debugInfo = "753:\src\CompilerPasses\Parser.gbas";
				var forEachSaver14757 = global8_Compiler.attr5_Funcs_ref[0];
				for(var forEachCounter14757 = 0 ; forEachCounter14757 < forEachSaver14757.values.length ; forEachCounter14757++) {
					var local4_func_ref_2199 = forEachSaver14757.values[forEachCounter14757];
				{
						__debugInfo = "752:\src\CompilerPasses\Parser.gbas";
						if (((((((local4_func_ref_2199[0].attr3_Typ) == (2)) ? 1 : 0)) || ((((local4_func_ref_2199[0].attr3_Typ) == (3)) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "751:\src\CompilerPasses\Parser.gbas";
							local4_func_ref_2199[0].attr10_PlzCompile = 1;
							__debugInfo = "751:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "752:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver14757.values[forEachCounter14757] = local4_func_ref_2199;
				
				};
				__debugInfo = "783:\src\CompilerPasses\Parser.gbas";
				while (1) {
					var local5_Found_2200 = 0;
					__debugInfo = "774:\src\CompilerPasses\Parser.gbas";
					local5_Found_2200 = 0;
					__debugInfo = "781:\src\CompilerPasses\Parser.gbas";
					var forEachSaver14795 = global8_Compiler.attr5_Funcs_ref[0];
					for(var forEachCounter14795 = 0 ; forEachCounter14795 < forEachSaver14795.values.length ; forEachCounter14795++) {
						var local4_func_ref_2201 = forEachSaver14795.values[forEachCounter14795];
					{
							__debugInfo = "780:\src\CompilerPasses\Parser.gbas";
							if ((((local4_func_ref_2201[0].attr10_PlzCompile) && ((((local4_func_ref_2201[0].attr3_Scp) == (-(1))) ? 1 : 0))) ? 1 : 0)) {
								__debugInfo = "778:\src\CompilerPasses\Parser.gbas";
								if (func11_CompileFunc(unref(local4_func_ref_2201[0]))) {
									__debugInfo = "778:\src\CompilerPasses\Parser.gbas";
									local5_Found_2200 = 1;
									__debugInfo = "778:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "778:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "780:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver14795.values[forEachCounter14795] = local4_func_ref_2201;
					
					};
					__debugInfo = "782:\src\CompilerPasses\Parser.gbas";
					if ((((local5_Found_2200) == (0)) ? 1 : 0)) {
						__debugInfo = "782:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "782:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "774:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "790:\src\CompilerPasses\Parser.gbas";
				{
					var local1_i_2202 = 0.0;
					__debugInfo = "814:\src\CompilerPasses\Parser.gbas";
					for (local1_i_2202 = 0;toCheck(local1_i_2202, ((global10_LastExprID) - (1)), 1);local1_i_2202 += 1) {
						var alias4_Expr_ref_2203 = [new type4_Expr()];
						__debugInfo = "792:\src\CompilerPasses\Parser.gbas";
						alias4_Expr_ref_2203 = global5_Exprs_ref[0].arrAccess(~~(local1_i_2202)).values[tmpPositionCache] /* ALIAS */;
						__debugInfo = "813:\src\CompilerPasses\Parser.gbas";
						if (((((((alias4_Expr_ref_2203[0].attr3_Typ) == (6)) ? 1 : 0)) || ((((alias4_Expr_ref_2203[0].attr3_Typ) == (23)) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "812:\src\CompilerPasses\Parser.gbas";
							if (((((((BOUNDS(alias4_Expr_ref_2203[0].attr6_Params, 0)) < (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) && ((((alias4_Expr_ref_2203[0].attr8_wasAdded) == (0)) ? 1 : 0))) ? 1 : 0)) {
								var local4_Meth_2204 = 0, local7_TmpSave_2205 = 0;
								__debugInfo = "795:\src\CompilerPasses\Parser.gbas";
								alias4_Expr_ref_2203[0].attr8_wasAdded = 1;
								__debugInfo = "796:\src\CompilerPasses\Parser.gbas";
								local4_Meth_2204 = 0;
								__debugInfo = "803:\src\CompilerPasses\Parser.gbas";
								if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0)) {
									__debugInfo = "799:\src\CompilerPasses\Parser.gbas";
									if ((((BOUNDS(alias4_Expr_ref_2203[0].attr6_Params, 0)) == (0)) ? 1 : 0)) {
										__debugInfo = "799:\src\CompilerPasses\Parser.gbas";
										func5_Error((((("Internal error (method '") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr8_Name_Str))) + ("' didn't get self parameter)")), 798, "src\CompilerPasses\Parser.gbas");
										__debugInfo = "799:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "800:\src\CompilerPasses\Parser.gbas";
									local4_Meth_2204 = 1;
									__debugInfo = "801:\src\CompilerPasses\Parser.gbas";
									local7_TmpSave_2205 = alias4_Expr_ref_2203[0].attr6_Params.arrAccess(-(1)).values[tmpPositionCache];
									__debugInfo = "802:\src\CompilerPasses\Parser.gbas";
									DIMDEL(alias4_Expr_ref_2203[0].attr6_Params, -(1));
									__debugInfo = "799:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "803:\src\CompilerPasses\Parser.gbas";
								{
									__debugInfo = "808:\src\CompilerPasses\Parser.gbas";
									for (local1_i_2202 = BOUNDS(alias4_Expr_ref_2203[0].attr6_Params, 0);toCheck(local1_i_2202, ((((BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0)) - (1))) - (local4_Meth_2204)), 1);local1_i_2202 += 1) {
										__debugInfo = "807:\src\CompilerPasses\Parser.gbas";
										if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_i_2202)).values[tmpPositionCache]).values[tmpPositionCache][0].attr6_PreDef) != (-(1))) ? 1 : 0)) {
											__debugInfo = "806:\src\CompilerPasses\Parser.gbas";
											DIMPUSH(alias4_Expr_ref_2203[0].attr6_Params, global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(alias4_Expr_ref_2203[0].attr4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_i_2202)).values[tmpPositionCache]).values[tmpPositionCache][0].attr6_PreDef);
											__debugInfo = "806:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "807:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "808:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "811:\src\CompilerPasses\Parser.gbas";
								if (local4_Meth_2204) {
									__debugInfo = "810:\src\CompilerPasses\Parser.gbas";
									DIMPUSH(alias4_Expr_ref_2203[0].attr6_Params, local7_TmpSave_2205);
									__debugInfo = "810:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "795:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "812:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "792:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "814:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "817:\src\CompilerPasses\Parser.gbas";
				func15_CheckPrototypes();
				__debugInfo = "823:\src\CompilerPasses\Parser.gbas";
				{
					var local1_i_2206 = 0.0;
					__debugInfo = "879:\src\CompilerPasses\Parser.gbas";
					for (local1_i_2206 = 0;toCheck(local1_i_2206, ((global10_LastExprID) - (1)), 1);local1_i_2206 += 1) {
						__debugInfo = "878:\src\CompilerPasses\Parser.gbas";
						if (((((((global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr3_Typ) == (23)) ? 1 : 0))) ? 1 : 0)) {
							var local4_Meth_2207 = 0;
							__debugInfo = "832:\src\CompilerPasses\Parser.gbas";
							local4_Meth_2207 = 0;
							__debugInfo = "833:\src\CompilerPasses\Parser.gbas";
							if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0)) {
								__debugInfo = "833:\src\CompilerPasses\Parser.gbas";
								local4_Meth_2207 = 1;
								__debugInfo = "833:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "835:\src\CompilerPasses\Parser.gbas";
							global8_Compiler.attr11_currentPosi = global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr5_tokID;
							__debugInfo = "877:\src\CompilerPasses\Parser.gbas";
							if ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) == (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) {
								var local1_j_2208 = 0.0, local9_NewParams_2209 = new OTTArray(0);
								__debugInfo = "838:\src\CompilerPasses\Parser.gbas";
								local1_j_2208 = 0;
								__debugInfo = "854:\src\CompilerPasses\Parser.gbas";
								var forEachSaver15222 = global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params;
								for(var forEachCounter15222 = 0 ; forEachCounter15222 < forEachSaver15222.values.length ; forEachCounter15222++) {
									var local1_P_2210 = forEachSaver15222.values[forEachCounter15222];
								{
										var local1_S_2211 = 0, local3_Tmp_2212 = 0;
										__debugInfo = "841:\src\CompilerPasses\Parser.gbas";
										local1_S_2211 = 0;
										__debugInfo = "845:\src\CompilerPasses\Parser.gbas";
										if (global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_j_2208)).values[tmpPositionCache]).values[tmpPositionCache][0].attr3_ref) {
											__debugInfo = "843:\src\CompilerPasses\Parser.gbas";
											global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local1_P_2210, 1)).values[tmpPositionCache][0].attr3_ref = 1;
											__debugInfo = "844:\src\CompilerPasses\Parser.gbas";
											local1_S_2211 = 1;
											__debugInfo = "843:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "851:\src\CompilerPasses\Parser.gbas";
										if (((local1_S_2211) ? 0 : 1)) {
											__debugInfo = "848:\src\CompilerPasses\Parser.gbas";
											local3_Tmp_2212 = func14_EnsureDatatype(local1_P_2210, global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_j_2208)).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_datatype, 847, local1_S_2211);
											__debugInfo = "848:\src\CompilerPasses\Parser.gbas";
										} else {
											__debugInfo = "850:\src\CompilerPasses\Parser.gbas";
											local3_Tmp_2212 = local1_P_2210;
											__debugInfo = "850:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "852:\src\CompilerPasses\Parser.gbas";
										DIMPUSH(local9_NewParams_2209, local3_Tmp_2212);
										__debugInfo = "853:\src\CompilerPasses\Parser.gbas";
										local1_j_2208+=1;
										__debugInfo = "841:\src\CompilerPasses\Parser.gbas";
									}
									forEachSaver15222.values[forEachCounter15222] = local1_P_2210;
								
								};
								__debugInfo = "855:\src\CompilerPasses\Parser.gbas";
								global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params = local9_NewParams_2209.clone(/* In Assign */);
								__debugInfo = "838:\src\CompilerPasses\Parser.gbas";
							} else {
								var local8_miss_Str_2213 = "", local9_datas_Str_2214 = "";
								__debugInfo = "856:\src\CompilerPasses\Parser.gbas";
								local8_miss_Str_2213 = "";
								__debugInfo = "868:\src\CompilerPasses\Parser.gbas";
								if ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) < (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) {
									__debugInfo = "858:\src\CompilerPasses\Parser.gbas";
									{
										var local1_j_2215 = 0.0;
										__debugInfo = "861:\src\CompilerPasses\Parser.gbas";
										for (local1_j_2215 = BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0);toCheck(local1_j_2215, ((((BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0)) - (1))) - (local4_Meth_2207)), 1);local1_j_2215 += 1) {
											__debugInfo = "860:\src\CompilerPasses\Parser.gbas";
											local8_miss_Str_2213 = ((((local8_miss_Str_2213) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_j_2215)).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_Name_Str))) + (", "));
											__debugInfo = "860:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "861:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "858:\src\CompilerPasses\Parser.gbas";
								} else if ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) > (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) {
									__debugInfo = "862:\src\CompilerPasses\Parser.gbas";
									{
										var local1_j_2216 = 0.0;
										__debugInfo = "867:\src\CompilerPasses\Parser.gbas";
										for (local1_j_2216 = BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0);toCheck(local1_j_2216, ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) - (local4_Meth_2207))) - (1)), 1);local1_j_2216 += 1) {
											__debugInfo = "866:\src\CompilerPasses\Parser.gbas";
											if ((((global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_j_2216)).values[tmpPositionCache]) < (BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0))) ? 1 : 0)) {
												__debugInfo = "865:\src\CompilerPasses\Parser.gbas";
												local9_datas_Str_2214 = ((((local9_datas_Str_2214) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params.arrAccess(~~(local1_j_2216)).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + (", "));
												__debugInfo = "865:\src\CompilerPasses\Parser.gbas";
											};
											__debugInfo = "866:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "867:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "862:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "869:\src\CompilerPasses\Parser.gbas";
								global8_Compiler.attr11_currentPosi = global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr5_tokID;
								__debugInfo = "876:\src\CompilerPasses\Parser.gbas";
								if ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) > (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) {
									__debugInfo = "871:\src\CompilerPasses\Parser.gbas";
									func5_Error((((((((((((((((("Too many parameters, function '") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr8_Name_Str))) + ("' has: '"))) + (CAST2STRING(((BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0)) - (local4_Meth_2207)))))) + ("' got '"))) + (CAST2STRING(BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0))))) + ("' datatypes '"))) + (local9_datas_Str_2214))) + ("'")), 870, "src\CompilerPasses\Parser.gbas");
									__debugInfo = "871:\src\CompilerPasses\Parser.gbas";
								} else if ((((BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0)) < (BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))) ? 1 : 0)) {
									__debugInfo = "873:\src\CompilerPasses\Parser.gbas";
									func5_Error((((((((((((((((("Too less parameters, function '") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr8_Name_Str))) + ("' has: '"))) + (CAST2STRING(((BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0)) - (local4_Meth_2207)))))) + ("' got '"))) + (CAST2STRING(BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0))))) + ("' missing '"))) + (local8_miss_Str_2213))) + ("'")), 872, "src\CompilerPasses\Parser.gbas");
									__debugInfo = "873:\src\CompilerPasses\Parser.gbas";
								} else {
									__debugInfo = "875:\src\CompilerPasses\Parser.gbas";
									func5_Error((((((((("Internal error (wtf? call: ") + (CAST2STRING(BOUNDS(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr6_Params, 0))))) + (", "))) + (CAST2STRING(BOUNDS(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(~~(local1_i_2206)).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache][0].attr6_Params, 0))))) + (")")), 874, "src\CompilerPasses\Parser.gbas");
									__debugInfo = "875:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "856:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "832:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "878:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "879:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "882:\src\CompilerPasses\Parser.gbas";
				func15_CheckPrototypes();
				__debugInfo = "889:\src\CompilerPasses\Parser.gbas";
				local5_found_2217 = 1;
				__debugInfo = "923:\src\CompilerPasses\Parser.gbas";
				while (local5_found_2217) {
					__debugInfo = "891:\src\CompilerPasses\Parser.gbas";
					local5_found_2217 = 0;
					__debugInfo = "893:\src\CompilerPasses\Parser.gbas";
					{
						var local1_i_2218 = 0.0;
						__debugInfo = "922:\src\CompilerPasses\Parser.gbas";
						for (local1_i_2218 = 0;toCheck(local1_i_2218, ((global10_LastExprID) - (1)), 1);local1_i_2218 += 1) {
							var alias1_E_ref_2219 = [new type4_Expr()], local3_set_2220 = 0, local4_Vari_2221 = 0, local3_var_2222 = 0;
							__debugInfo = "895:\src\CompilerPasses\Parser.gbas";
							alias1_E_ref_2219 = global5_Exprs_ref[0].arrAccess(~~(local1_i_2218)).values[tmpPositionCache] /* ALIAS */;
							__debugInfo = "896:\src\CompilerPasses\Parser.gbas";
							local3_set_2220 = 0;
							__debugInfo = "899:\src\CompilerPasses\Parser.gbas";
							{
								var local17___SelectHelper20__2223 = 0;
								__debugInfo = "899:\src\CompilerPasses\Parser.gbas";
								local17___SelectHelper20__2223 = alias1_E_ref_2219[0].attr3_Typ;
								__debugInfo = "911:\src\CompilerPasses\Parser.gbas";
								if ((((local17___SelectHelper20__2223) == (~~(40))) ? 1 : 0)) {
									__debugInfo = "901:\src\CompilerPasses\Parser.gbas";
									local4_Vari_2221 = alias1_E_ref_2219[0].attr4_vari;
									__debugInfo = "902:\src\CompilerPasses\Parser.gbas";
									local3_var_2222 = func11_GetVariable(alias1_E_ref_2219[0].attr4_expr, 0);
									__debugInfo = "903:\src\CompilerPasses\Parser.gbas";
									local3_set_2220 = 1;
									__debugInfo = "901:\src\CompilerPasses\Parser.gbas";
								} else if ((((local17___SelectHelper20__2223) == (~~(38))) ? 1 : 0)) {
									__debugInfo = "905:\src\CompilerPasses\Parser.gbas";
									local4_Vari_2221 = alias1_E_ref_2219[0].attr6_inExpr;
									__debugInfo = "906:\src\CompilerPasses\Parser.gbas";
									local3_var_2222 = func11_GetVariable(alias1_E_ref_2219[0].attr7_varExpr, 0);
									__debugInfo = "907:\src\CompilerPasses\Parser.gbas";
									local3_set_2220 = 1;
									__debugInfo = "905:\src\CompilerPasses\Parser.gbas";
								} else if ((((local17___SelectHelper20__2223) == (~~(6))) ? 1 : 0)) {
									
								};
								__debugInfo = "899:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "921:\src\CompilerPasses\Parser.gbas";
							if ((((local3_set_2220) && ((((local3_var_2222) >= (0)) ? 1 : 0))) ? 1 : 0)) {
								var local1_v_2224 = 0;
								__debugInfo = "915:\src\CompilerPasses\Parser.gbas";
								local1_v_2224 = func11_GetVariable(local4_Vari_2221, 1);
								__debugInfo = "916:\src\CompilerPasses\Parser.gbas";
								if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_var_2222).values[tmpPositionCache][0].attr3_ref) != (global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2224).values[tmpPositionCache][0].attr3_ref)) ? 1 : 0)) {
									__debugInfo = "916:\src\CompilerPasses\Parser.gbas";
									local5_found_2217 = 1;
									__debugInfo = "916:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "920:\src\CompilerPasses\Parser.gbas";
								global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_var_2222).values[tmpPositionCache][0].attr3_ref = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_v_2224).values[tmpPositionCache][0].attr3_ref;
								__debugInfo = "915:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "895:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "922:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "891:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "930:\src\CompilerPasses\Parser.gbas";
				{
					var local1_i_2225 = 0.0;
					__debugInfo = "955:\src\CompilerPasses\Parser.gbas";
					for (local1_i_2225 = 0;toCheck(local1_i_2225, ((global10_LastExprID) - (1)), 1);local1_i_2225 += 1) {
						var alias4_Expr_ref_2226 = [new type4_Expr()];
						__debugInfo = "932:\src\CompilerPasses\Parser.gbas";
						alias4_Expr_ref_2226 = global5_Exprs_ref[0].arrAccess(~~(local1_i_2225)).values[tmpPositionCache] /* ALIAS */;
						__debugInfo = "933:\src\CompilerPasses\Parser.gbas";
						{
							var local17___SelectHelper21__2227 = 0;
							__debugInfo = "933:\src\CompilerPasses\Parser.gbas";
							local17___SelectHelper21__2227 = alias4_Expr_ref_2226[0].attr3_Typ;
							__debugInfo = "954:\src\CompilerPasses\Parser.gbas";
							if ((((local17___SelectHelper21__2227) == (~~(2))) ? 1 : 0)) {
								__debugInfo = "953:\src\CompilerPasses\Parser.gbas";
								if ((((((((((alias4_Expr_ref_2226[0].attr6_ScpTyp) == (2)) ? 1 : 0)) || ((((alias4_Expr_ref_2226[0].attr6_ScpTyp) == (4)) ? 1 : 0))) ? 1 : 0)) && (BOUNDS(alias4_Expr_ref_2226[0].attr5_Gotos, 0))) ? 1 : 0)) {
									__debugInfo = "938:\src\CompilerPasses\Parser.gbas";
									if (((func12_ScopeHasGoto(unref(alias4_Expr_ref_2226[0]))) ? 0 : 1)) {
										__debugInfo = "938:\src\CompilerPasses\Parser.gbas";
										func5_Error("Internal Error (There is a goto, but I can't find it)", 937, "src\CompilerPasses\Parser.gbas");
										__debugInfo = "938:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "952:\src\CompilerPasses\Parser.gbas";
									var forEachSaver15907 = alias4_Expr_ref_2226[0].attr5_Gotos;
									for(var forEachCounter15907 = 0 ; forEachCounter15907 < forEachSaver15907.values.length ; forEachCounter15907++) {
										var local1_G_2228 = forEachSaver15907.values[forEachCounter15907];
									{
											var local5_Found_2229 = 0;
											__debugInfo = "940:\src\CompilerPasses\Parser.gbas";
											local5_Found_2229 = 0;
											__debugInfo = "946:\src\CompilerPasses\Parser.gbas";
											var forEachSaver15880 = alias4_Expr_ref_2226[0].attr6_Labels;
											for(var forEachCounter15880 = 0 ; forEachCounter15880 < forEachSaver15880.values.length ; forEachCounter15880++) {
												var local1_L_2230 = forEachSaver15880.values[forEachCounter15880];
											{
													__debugInfo = "945:\src\CompilerPasses\Parser.gbas";
													if ((((global5_Exprs_ref[0].arrAccess(local1_L_2230).values[tmpPositionCache][0].attr8_Name_Str) == (global5_Exprs_ref[0].arrAccess(local1_G_2228).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0)) {
														__debugInfo = "943:\src\CompilerPasses\Parser.gbas";
														local5_Found_2229 = 1;
														__debugInfo = "944:\src\CompilerPasses\Parser.gbas";
														break;
														__debugInfo = "943:\src\CompilerPasses\Parser.gbas";
													};
													__debugInfo = "945:\src\CompilerPasses\Parser.gbas";
												}
												forEachSaver15880.values[forEachCounter15880] = local1_L_2230;
											
											};
											__debugInfo = "951:\src\CompilerPasses\Parser.gbas";
											if (((local5_Found_2229) ? 0 : 1)) {
												__debugInfo = "948:\src\CompilerPasses\Parser.gbas";
												global8_Compiler.attr11_currentPosi = global5_Exprs_ref[0].arrAccess(local1_G_2228).values[tmpPositionCache][0].attr5_tokID;
												__debugInfo = "949:\src\CompilerPasses\Parser.gbas";
												func5_Error((((("Label '") + (global5_Exprs_ref[0].arrAccess(local1_G_2228).values[tmpPositionCache][0].attr8_Name_Str))) + ("' does not exist, please use an existing label badass!")), 948, "src\CompilerPasses\Parser.gbas");
												__debugInfo = "948:\src\CompilerPasses\Parser.gbas";
											};
											__debugInfo = "940:\src\CompilerPasses\Parser.gbas";
										}
										forEachSaver15907.values[forEachCounter15907] = local1_G_2228;
									
									};
									__debugInfo = "938:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "953:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "933:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "932:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "955:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "963:\src\CompilerPasses\Parser.gbas";
				var forEachSaver15926 = global8_Compiler.attr5_Types_ref[0];
				for(var forEachCounter15926 = 0 ; forEachCounter15926 < forEachSaver15926.values.length ; forEachCounter15926++) {
					var local3_Typ_ref_2231 = forEachSaver15926.values[forEachCounter15926];
				{
						__debugInfo = "962:\src\CompilerPasses\Parser.gbas";
						local3_Typ_ref_2231[0].attr8_Name_Str = func18_ChangeTypeName_Str(local3_Typ_ref_2231[0].attr8_Name_Str);
						__debugInfo = "962:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver15926.values[forEachCounter15926] = local3_Typ_ref_2231;
				
				};
				__debugInfo = "969:\src\CompilerPasses\Parser.gbas";
				var forEachSaver15936 = global8_Compiler.attr5_Funcs_ref[0];
				for(var forEachCounter15936 = 0 ; forEachCounter15936 < forEachSaver15936.values.length ; forEachCounter15936++) {
					var local4_Func_ref_2232 = forEachSaver15936.values[forEachCounter15936];
				{
						__debugInfo = "968:\src\CompilerPasses\Parser.gbas";
						func14_ChangeFuncName(unref(local4_Func_ref_2232[0]));
						__debugInfo = "968:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver15936.values[forEachCounter15936] = local4_Func_ref_2232;
				
				};
				__debugInfo = "975:\src\CompilerPasses\Parser.gbas";
				var forEachSaver15946 = global8_Compiler.attr5_Varis_ref[0];
				for(var forEachCounter15946 = 0 ; forEachCounter15946 < forEachSaver15946.values.length ; forEachCounter15946++) {
					var local4_Vari_ref_2233 = forEachSaver15946.values[forEachCounter15946];
				{
						__debugInfo = "974:\src\CompilerPasses\Parser.gbas";
						func13_ChangeVarName(unref(local4_Vari_ref_2233[0]));
						__debugInfo = "974:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver15946.values[forEachCounter15946] = local4_Vari_ref_2233;
				
				};
				__debugInfo = "983:\src\CompilerPasses\Parser.gbas";
				var forEachSaver15982 = global8_Compiler.attr5_Varis_ref[0];
				for(var forEachCounter15982 = 0 ; forEachCounter15982 < forEachSaver15982.values.length ; forEachCounter15982++) {
					var local1_V_ref_2234 = forEachSaver15982.values[forEachCounter15982];
				{
						__debugInfo = "982:\src\CompilerPasses\Parser.gbas";
						if (((((((local1_V_ref_2234[0].attr3_Typ) == (1)) ? 1 : 0)) || ((((local1_V_ref_2234[0].attr3_Typ) == (7)) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "981:\src\CompilerPasses\Parser.gbas";
							local1_V_ref_2234[0].attr8_Name_Str = ((((local1_V_ref_2234[0].attr8_Name_Str) + ("_"))) + (CAST2STRING(local1_V_ref_2234[0].attr2_ID)));
							__debugInfo = "981:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "982:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver15982.values[forEachCounter15982] = local1_V_ref_2234;
				
				};
				__debugInfo = "985:\src\CompilerPasses\Parser.gbas";
				{
					var local1_i_2235 = 0.0;
					__debugInfo = "999:\src\CompilerPasses\Parser.gbas";
					for (local1_i_2235 = 0;toCheck(local1_i_2235, ((global10_LastExprID) - (1)), 1);local1_i_2235 += 1) {
						var alias1_E_ref_2236 = [new type4_Expr()];
						__debugInfo = "987:\src\CompilerPasses\Parser.gbas";
						alias1_E_ref_2236 = global5_Exprs_ref[0].arrAccess(~~(local1_i_2235)).values[tmpPositionCache] /* ALIAS */;
						__debugInfo = "998:\src\CompilerPasses\Parser.gbas";
						if (((((((((((((alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]) == ("void")) ? 1 : 0)) || ((((alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0))) ? 1 : 0)) || ((((alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]) == ("string")) ? 1 : 0))) ? 1 : 0)) {
							
						} else {
							__debugInfo = "997:\src\CompilerPasses\Parser.gbas";
							if ((((func6_IsType(unref(alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]))) == (0)) ? 1 : 0)) {
								__debugInfo = "996:\src\CompilerPasses\Parser.gbas";
								var forEachSaver16073 = global8_Compiler.attr5_Funcs_ref[0];
								for(var forEachCounter16073 = 0 ; forEachCounter16073 < forEachSaver16073.values.length ; forEachCounter16073++) {
									var local1_F_ref_2237 = forEachSaver16073.values[forEachCounter16073];
								{
										__debugInfo = "995:\src\CompilerPasses\Parser.gbas";
										if ((((alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0]) == (local1_F_ref_2237[0].attr9_OName_Str)) ? 1 : 0)) {
											__debugInfo = "994:\src\CompilerPasses\Parser.gbas";
											alias1_E_ref_2236[0].attr8_datatype.attr8_Name_Str_ref[0] = local1_F_ref_2237[0].attr8_Name_Str;
											__debugInfo = "994:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "995:\src\CompilerPasses\Parser.gbas";
									}
									forEachSaver16073.values[forEachCounter16073] = local1_F_ref_2237;
								
								};
								__debugInfo = "996:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "997:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "987:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "999:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1001:\src\CompilerPasses\Parser.gbas";
				func23_ManageFuncParamOverlaps();
				__debugInfo = "743:\src\CompilerPasses\Parser.gbas";
			} catch (Err_Str) {
				if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
					
				}
			};
			__debugInfo = "1005:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1006:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1004:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func6_Parser = window['func6_Parser'];
window['func15_CheckPrototypes'] = function() {
	stackPush("function: CheckPrototypes", __debugInfo);
	try {
		__debugInfo = "1036:\src\CompilerPasses\Parser.gbas";
		if ((((BOUNDS(global8_Compiler.attr13_protoCheckers, 0)) > (0)) ? 1 : 0)) {
			__debugInfo = "1034:\src\CompilerPasses\Parser.gbas";
			var forEachSaver16262 = global8_Compiler.attr13_protoCheckers;
			for(var forEachCounter16262 = 0 ; forEachCounter16262 < forEachSaver16262.values.length ; forEachCounter16262++) {
				var local7_checker_2239 = forEachSaver16262.values[forEachCounter16262];
			{
					var alias5_func1_ref_2240 = [new type14_IdentifierFunc()], alias5_func2_ref_2241 = [new type14_IdentifierFunc()], local5_valid_2242 = 0;
					__debugInfo = "1017:\src\CompilerPasses\Parser.gbas";
					alias5_func1_ref_2240 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(local7_checker_2239.attr8_fromFunc).values[tmpPositionCache] /* ALIAS */;
					__debugInfo = "1018:\src\CompilerPasses\Parser.gbas";
					alias5_func2_ref_2241 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(local7_checker_2239.attr6_toFunc).values[tmpPositionCache] /* ALIAS */;
					__debugInfo = "1019:\src\CompilerPasses\Parser.gbas";
					local5_valid_2242 = 0;
					__debugInfo = "1029:\src\CompilerPasses\Parser.gbas";
					if (((((((alias5_func1_ref_2240[0].attr8_datatype.attr8_Name_Str_ref[0]) == (alias5_func2_ref_2241[0].attr8_datatype.attr8_Name_Str_ref[0])) ? 1 : 0)) && ((((alias5_func1_ref_2240[0].attr8_datatype.attr7_IsArray_ref[0]) == (alias5_func2_ref_2241[0].attr8_datatype.attr7_IsArray_ref[0])) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "1028:\src\CompilerPasses\Parser.gbas";
						if ((((BOUNDS(alias5_func1_ref_2240[0].attr6_Params, 0)) == (BOUNDS(alias5_func2_ref_2241[0].attr6_Params, 0))) ? 1 : 0)) {
							__debugInfo = "1022:\src\CompilerPasses\Parser.gbas";
							local5_valid_2242 = 1;
							__debugInfo = "1022:\src\CompilerPasses\Parser.gbas";
							{
								var local1_i_2243 = 0.0;
								__debugInfo = "1027:\src\CompilerPasses\Parser.gbas";
								for (local1_i_2243 = 0;toCheck(local1_i_2243, ((BOUNDS(alias5_func1_ref_2240[0].attr6_Params, 0)) - (1)), 1);local1_i_2243 += 1) {
									var alias2_p1_ref_2244 = [new type14_IdentifierVari()], alias2_p2_ref_2245 = [new type14_IdentifierVari()];
									__debugInfo = "1024:\src\CompilerPasses\Parser.gbas";
									alias2_p1_ref_2244 = global8_Compiler.attr5_Varis_ref[0].arrAccess(alias5_func1_ref_2240[0].attr6_Params.arrAccess(~~(local1_i_2243)).values[tmpPositionCache]).values[tmpPositionCache] /* ALIAS */;
									__debugInfo = "1025:\src\CompilerPasses\Parser.gbas";
									alias2_p2_ref_2245 = global8_Compiler.attr5_Varis_ref[0].arrAccess(alias5_func2_ref_2241[0].attr6_Params.arrAccess(~~(local1_i_2243)).values[tmpPositionCache]).values[tmpPositionCache] /* ALIAS */;
									__debugInfo = "1026:\src\CompilerPasses\Parser.gbas";
									if (((((((alias2_p1_ref_2244[0].attr8_datatype.attr8_Name_Str_ref[0]) != (alias2_p2_ref_2245[0].attr8_datatype.attr8_Name_Str_ref[0])) ? 1 : 0)) || ((((alias2_p1_ref_2244[0].attr8_datatype.attr7_IsArray_ref[0]) != (alias2_p2_ref_2245[0].attr8_datatype.attr7_IsArray_ref[0])) ? 1 : 0))) ? 1 : 0)) {
										__debugInfo = "1026:\src\CompilerPasses\Parser.gbas";
										local5_valid_2242 = 0;
										__debugInfo = "1026:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "1024:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1027:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1022:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1028:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1033:\src\CompilerPasses\Parser.gbas";
					if ((((local5_valid_2242) == (0)) ? 1 : 0)) {
						__debugInfo = "1032:\src\CompilerPasses\Parser.gbas";
						func5_Error((((((((("Cannot cast prototype '") + (func17_BuildPrototyp_Str(local7_checker_2239.attr8_fromFunc)))) + ("' to '"))) + (func17_BuildPrototyp_Str(local7_checker_2239.attr6_toFunc)))) + ("'")), 1031, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1032:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1017:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver16262.values[forEachCounter16262] = local7_checker_2239;
			
			};
			__debugInfo = "1035:\src\CompilerPasses\Parser.gbas";
			REDIM(global8_Compiler.attr13_protoCheckers, [0], new type12_ProtoChecker() );
			__debugInfo = "1034:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1038:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1036:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func15_CheckPrototypes = window['func15_CheckPrototypes'];
window['func5_Scope'] = function(param12_CloseStr_Str, param4_func) {
	stackPush("function: Scope", __debugInfo);
	try {
		var local6_ScpTyp_2248 = 0, local9_Important_2249 = 0, local7_befLoop_2251 = 0, local8_TmpScope_2252 = 0.0, local12_TmpImportant_2253 = 0, local7_OneLine_2256 = 0, local13_OCloseStr_Str_2257 = "", local7_MyScope_2264 = 0;
		var local12_CloseStr_Str_ref_2246 = [param12_CloseStr_Str]; /* NEWCODEHERE */
		__debugInfo = "1042:\src\CompilerPasses\Parser.gbas";
		local6_ScpTyp_2248 = 0;
		__debugInfo = "1043:\src\CompilerPasses\Parser.gbas";
		local9_Important_2249 = 0;
		__debugInfo = "1044:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper22__2250 = "";
			__debugInfo = "1044:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper22__2250 = local12_CloseStr_Str_ref_2246[0];
			__debugInfo = "1070:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper22__2250) == ("ENDIF")) ? 1 : 0)) {
				__debugInfo = "1046:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(1);
				__debugInfo = "1046:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("ENDSELECT")) ? 1 : 0)) {
				__debugInfo = "1048:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(6);
				__debugInfo = "1048:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("WEND")) ? 1 : 0)) {
				__debugInfo = "1050:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(3);
				__debugInfo = "1050:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("UNTIL")) ? 1 : 0)) {
				__debugInfo = "1052:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(3);
				__debugInfo = "1052:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("NEXT")) ? 1 : 0)) {
				__debugInfo = "1054:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(3);
				__debugInfo = "1054:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("ENDFUNCTION")) ? 1 : 0)) {
				__debugInfo = "1056:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(2);
				__debugInfo = "1057:\src\CompilerPasses\Parser.gbas";
				local9_Important_2249 = 1;
				__debugInfo = "1056:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("ENDSUB")) ? 1 : 0)) {
				__debugInfo = "1059:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(2);
				__debugInfo = "1060:\src\CompilerPasses\Parser.gbas";
				local9_Important_2249 = 1;
				__debugInfo = "1059:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("CATCH")) ? 1 : 0)) {
				__debugInfo = "1062:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(5);
				__debugInfo = "1062:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("FINALLY")) ? 1 : 0)) {
				__debugInfo = "1064:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(5);
				__debugInfo = "1064:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper22__2250) == ("__EOFFILE__")) ? 1 : 0)) {
				__debugInfo = "1066:\src\CompilerPasses\Parser.gbas";
				local6_ScpTyp_2248 = ~~(4);
				__debugInfo = "1067:\src\CompilerPasses\Parser.gbas";
				local9_Important_2249 = 1;
				__debugInfo = "1066:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "1069:\src\CompilerPasses\Parser.gbas";
				func5_Error("Internal error (unknown scope type)", 1068, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1069:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1044:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1072:\src\CompilerPasses\Parser.gbas";
		local7_befLoop_2251 = global8_Compiler.attr6_inLoop;
		__debugInfo = "1073:\src\CompilerPasses\Parser.gbas";
		if ((((local6_ScpTyp_2248) == (3)) ? 1 : 0)) {
			__debugInfo = "1073:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr6_inLoop = 1;
			__debugInfo = "1073:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1074:\src\CompilerPasses\Parser.gbas";
		local8_TmpScope_2252 = global8_Compiler.attr12_CurrentScope;
		__debugInfo = "1075:\src\CompilerPasses\Parser.gbas";
		local12_TmpImportant_2253 = global8_Compiler.attr14_ImportantScope;
		__debugInfo = "1076:\src\CompilerPasses\Parser.gbas";
		global8_Compiler.attr12_CurrentScope = func21_CreateScopeExpression(local6_ScpTyp_2248);
		__debugInfo = "1079:\src\CompilerPasses\Parser.gbas";
		if ((((local12_CloseStr_Str_ref_2246[0]) == ("__EOFFILE__")) ? 1 : 0)) {
			__debugInfo = "1078:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr9_MainScope = global8_Compiler.attr12_CurrentScope;
			__debugInfo = "1078:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1083:\src\CompilerPasses\Parser.gbas";
		if (local9_Important_2249) {
			__debugInfo = "1082:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr14_ImportantScope = global8_Compiler.attr12_CurrentScope;
			__debugInfo = "1082:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1094:\src\CompilerPasses\Parser.gbas";
		if (((((((local6_ScpTyp_2248) == (2)) ? 1 : 0)) && ((((param4_func) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1093:\src\CompilerPasses\Parser.gbas";
			var forEachSaver16492 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr6_Params;
			for(var forEachCounter16492 = 0 ; forEachCounter16492 < forEachSaver16492.values.length ; forEachCounter16492++) {
				var local5_param_2254 = forEachSaver16492.values[forEachCounter16492];
			{
					var local4_vari_2255 = new type14_IdentifierVari();
					__debugInfo = "1088:\src\CompilerPasses\Parser.gbas";
					local4_vari_2255 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_param_2254).values[tmpPositionCache][0].clone(/* In Assign */);
					__debugInfo = "1089:\src\CompilerPasses\Parser.gbas";
					local4_vari_2255.attr3_Typ = ~~(1);
					__debugInfo = "1090:\src\CompilerPasses\Parser.gbas";
					func11_AddVariable(local4_vari_2255, 1);
					__debugInfo = "1091:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
					__debugInfo = "1092:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr10_CopyParams, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
					__debugInfo = "1088:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver16492.values[forEachCounter16492] = local5_param_2254;
			
			};
			__debugInfo = "1093:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1095:\src\CompilerPasses\Parser.gbas";
		local7_OneLine_2256 = 0;
		__debugInfo = "1099:\src\CompilerPasses\Parser.gbas";
		if (func7_IsToken("THEN")) {
			__debugInfo = "1097:\src\CompilerPasses\Parser.gbas";
			local7_OneLine_2256 = 1;
			__debugInfo = "1098:\src\CompilerPasses\Parser.gbas";
			func5_Match("THEN", 1097, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1097:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1100:\src\CompilerPasses\Parser.gbas";
		local13_OCloseStr_Str_2257 = local12_CloseStr_Str_ref_2246[0];
		__debugInfo = "1180:\src\CompilerPasses\Parser.gbas";
		while ((((func7_IsToken(func13_IsClosing_Str(local12_CloseStr_Str_ref_2246, local6_ScpTyp_2248))) == (0)) ? 1 : 0)) {
			__debugInfo = "1102:\src\CompilerPasses\Parser.gbas";
			if ((((func8_EOFParse()) == (0)) ? 1 : 0)) {
				__debugInfo = "1102:\src\CompilerPasses\Parser.gbas";
				func5_Error((("Missing closing: ") + (local12_CloseStr_Str_ref_2246[0])), 1101, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1102:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1177:\src\CompilerPasses\Parser.gbas";
			{
				var Err_Str = "";
				__debugInfo = "1179:\src\CompilerPasses\Parser.gbas";
				try {
					var local4_Expr_2258 = 0;
					__debugInfo = "1107:\src\CompilerPasses\Parser.gbas";
					local4_Expr_2258 = -(1);
					__debugInfo = "1113:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("LET")) {
						__debugInfo = "1109:\src\CompilerPasses\Parser.gbas";
						func5_Match("LET", 1108, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1112:\src\CompilerPasses\Parser.gbas";
						if ((((func12_IsIdentifier(0, 0)) == (0)) ? 1 : 0)) {
							__debugInfo = "1111:\src\CompilerPasses\Parser.gbas";
							func5_Error("Expecting identifier after LET.", 1110, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1111:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1109:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1119:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("GOSUB")) {
						__debugInfo = "1115:\src\CompilerPasses\Parser.gbas";
						func5_Match("GOSUB", 1114, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1118:\src\CompilerPasses\Parser.gbas";
						if ((((func14_IsFuncExisting(func14_GetCurrent_Str(), 0)) == (0)) ? 1 : 0)) {
							__debugInfo = "1117:\src\CompilerPasses\Parser.gbas";
							func5_Error("Expecting sub after GOSUB.", 1116, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1117:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1115:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1167:\src\CompilerPasses\Parser.gbas";
					if (func9_IsKeyword()) {
						__debugInfo = "1122:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2258 = func7_Keyword();
						__debugInfo = "1122:\src\CompilerPasses\Parser.gbas";
					} else if (func12_IsIdentifier(1, 0)) {
						__debugInfo = "1124:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2258 = func10_Identifier(1);
						__debugInfo = "1124:\src\CompilerPasses\Parser.gbas";
					} else if (func7_IsToken("super")) {
						__debugInfo = "1127:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2258 = func10_Identifier(1);
						__debugInfo = "1127:\src\CompilerPasses\Parser.gbas";
					} else {
						var local3_pos_2259 = 0, local8_Name_Str_2260 = "";
						__debugInfo = "1129:\src\CompilerPasses\Parser.gbas";
						local3_pos_2259 = global8_Compiler.attr11_currentPosi;
						__debugInfo = "1130:\src\CompilerPasses\Parser.gbas";
						local8_Name_Str_2260 = REPLACE_Str(func14_GetCurrent_Str(), "@", "");
						__debugInfo = "1131:\src\CompilerPasses\Parser.gbas";
						func7_GetNext();
						__debugInfo = "1166:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(":")) {
							var local3_Scp_2261 = 0;
							__debugInfo = "1133:\src\CompilerPasses\Parser.gbas";
							func5_Match(":", 1132, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1134:\src\CompilerPasses\Parser.gbas";
							local4_Expr_2258 = func21_CreateLabelExpression(local8_Name_Str_2260);
							__debugInfo = "1135:\src\CompilerPasses\Parser.gbas";
							local3_Scp_2261 = global8_Compiler.attr12_CurrentScope;
							__debugInfo = "1143:\src\CompilerPasses\Parser.gbas";
							do {
								__debugInfo = "1141:\src\CompilerPasses\Parser.gbas";
								var forEachSaver16668 = global5_Exprs_ref[0].arrAccess(local3_Scp_2261).values[tmpPositionCache][0].attr6_Labels;
								for(var forEachCounter16668 = 0 ; forEachCounter16668 < forEachSaver16668.values.length ; forEachCounter16668++) {
									var local3_lbl_2262 = forEachSaver16668.values[forEachCounter16668];
								{
										__debugInfo = "1140:\src\CompilerPasses\Parser.gbas";
										if ((((global5_Exprs_ref[0].arrAccess(local3_lbl_2262).values[tmpPositionCache][0].attr8_Name_Str) == (local8_Name_Str_2260)) ? 1 : 0)) {
											__debugInfo = "1139:\src\CompilerPasses\Parser.gbas";
											func10_ResetError((((("Duplicate label identifier '") + (local8_Name_Str_2260))) + ("'")), local3_pos_2259);
											__debugInfo = "1139:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "1140:\src\CompilerPasses\Parser.gbas";
									}
									forEachSaver16668.values[forEachCounter16668] = local3_lbl_2262;
								
								};
								__debugInfo = "1142:\src\CompilerPasses\Parser.gbas";
								local3_Scp_2261 = global5_Exprs_ref[0].arrAccess(local3_Scp_2261).values[tmpPositionCache][0].attr10_SuperScope;
								__debugInfo = "1141:\src\CompilerPasses\Parser.gbas";
							} while (!(((((((local3_Scp_2261) == (-(1))) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(local3_Scp_2261).values[tmpPositionCache][0].attr6_ScpTyp) == (2)) ? 1 : 0))) ? 1 : 0)));
							__debugInfo = "1145:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr14_ImportantScope).values[tmpPositionCache][0].attr6_Labels, local4_Expr_2258);
							__debugInfo = "1133:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "1150:\src\CompilerPasses\Parser.gbas";
							if (func7_IsToken("[")) {
								__debugInfo = "1148:\src\CompilerPasses\Parser.gbas";
								func5_Match("[", 1147, "src\CompilerPasses\Parser.gbas");
								__debugInfo = "1149:\src\CompilerPasses\Parser.gbas";
								func5_Match("]", 1148, "src\CompilerPasses\Parser.gbas");
								__debugInfo = "1148:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1165:\src\CompilerPasses\Parser.gbas";
							if ((((func7_IsToken("=")) && (((global6_STRICT) ? 0 : 1))) ? 1 : 0)) {
								__debugInfo = "1153:\src\CompilerPasses\Parser.gbas";
								global8_Compiler.attr11_currentPosi = ((local3_pos_2259) - (1));
								__debugInfo = "1154:\src\CompilerPasses\Parser.gbas";
								func7_GetNext();
								__debugInfo = "1157:\src\CompilerPasses\Parser.gbas";
								func14_ImplicitDefine();
								__debugInfo = "1162:\src\CompilerPasses\Parser.gbas";
								if (func12_IsIdentifier(0, 0)) {
									__debugInfo = "1159:\src\CompilerPasses\Parser.gbas";
									local4_Expr_2258 = func10_Identifier(1);
									__debugInfo = "1159:\src\CompilerPasses\Parser.gbas";
								} else {
									__debugInfo = "1161:\src\CompilerPasses\Parser.gbas";
									func5_Error("Internal error (implicit not created)", 1160, "src\CompilerPasses\Parser.gbas");
									__debugInfo = "1161:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1153:\src\CompilerPasses\Parser.gbas";
							} else {
								__debugInfo = "1164:\src\CompilerPasses\Parser.gbas";
								func10_ResetError("Invalid command (unknown function, variable or keyword).", local3_pos_2259);
								__debugInfo = "1164:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1150:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1129:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1170:\src\CompilerPasses\Parser.gbas";
					if ((((local4_Expr_2258) != (-(1))) ? 1 : 0)) {
						__debugInfo = "1169:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local4_Expr_2258);
						__debugInfo = "1169:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1172:\src\CompilerPasses\Parser.gbas";
					if (local7_OneLine_2256) {
						__debugInfo = "1172:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "1172:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1175:\src\CompilerPasses\Parser.gbas";
					do {
						__debugInfo = "1174:\src\CompilerPasses\Parser.gbas";
						func5_Match("\n", 1173, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1174:\src\CompilerPasses\Parser.gbas";
					} while (!((((func7_IsToken("\n")) == (0)) ? 1 : 0)));
					__debugInfo = "1107:\src\CompilerPasses\Parser.gbas";
				} catch (Err_Str) {
					if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
						__debugInfo = "1178:\src\CompilerPasses\Parser.gbas";
						func8_FixError();
						__debugInfo = "1178:\src\CompilerPasses\Parser.gbas";
					}
				};
				__debugInfo = "1179:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1102:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1182:\src\CompilerPasses\Parser.gbas";
		if (((((((local7_OneLine_2256) == (0)) ? 1 : 0)) && ((((local12_CloseStr_Str_ref_2246[0]) == (local13_OCloseStr_Str_2257)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1182:\src\CompilerPasses\Parser.gbas";
			func5_Match(unref(local12_CloseStr_Str_ref_2246[0]), 1181, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1182:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1183:\src\CompilerPasses\Parser.gbas";
		local7_MyScope_2264 = global8_Compiler.attr12_CurrentScope;
		__debugInfo = "1184:\src\CompilerPasses\Parser.gbas";
		global8_Compiler.attr12_CurrentScope = ~~(local8_TmpScope_2252);
		__debugInfo = "1185:\src\CompilerPasses\Parser.gbas";
		global8_Compiler.attr6_inLoop = local7_befLoop_2251;
		__debugInfo = "1189:\src\CompilerPasses\Parser.gbas";
		if (local9_Important_2249) {
			__debugInfo = "1188:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr14_ImportantScope = local12_TmpImportant_2253;
			__debugInfo = "1188:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1191:\src\CompilerPasses\Parser.gbas";
		return tryClone(local7_MyScope_2264);
		__debugInfo = "1192:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1042:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_Scope = window['func5_Scope'];
window['func10_ResetError'] = function(param7_err_Str, param3_pos) {
	stackPush("function: ResetError", __debugInfo);
	try {
		var local3_tmp_2267 = 0.0;
		__debugInfo = "1195:\src\CompilerPasses\Parser.gbas";
		local3_tmp_2267 = global8_Compiler.attr11_currentPosi;
		__debugInfo = "1197:\src\CompilerPasses\Parser.gbas";
		global8_Compiler.attr11_currentPosi = param3_pos;
		__debugInfo = "1200:\src\CompilerPasses\Parser.gbas";
		{
			var Ex_Str = "";
			__debugInfo = "1203:\src\CompilerPasses\Parser.gbas";
			try {
				__debugInfo = "1199:\src\CompilerPasses\Parser.gbas";
				func5_Error(param7_err_Str, 1198, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1199:\src\CompilerPasses\Parser.gbas";
			} catch (Ex_Str) {
				if (Ex_Str instanceof OTTException) Ex_Str = Ex_Str.getText(); else throwError(Ex_Str);{
					__debugInfo = "1201:\src\CompilerPasses\Parser.gbas";
					global8_Compiler.attr11_currentPosi = ~~(local3_tmp_2267);
					__debugInfo = "1202:\src\CompilerPasses\Parser.gbas";
					throw new OTTException(Ex_Str, "\src\CompilerPasses\Parser.gbas", 1202);
					__debugInfo = "1201:\src\CompilerPasses\Parser.gbas";
				}
			};
			__debugInfo = "1203:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1204:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1195:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_ResetError = window['func10_ResetError'];
window['func13_IsClosing_Str'] = function(param12_CloseStr_Str_ref, param6_ScpTyp) {
	stackPush("function: IsClosing_Str", __debugInfo);
	try {
		__debugInfo = "1207:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper23__2271 = 0;
			__debugInfo = "1207:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper23__2271 = param6_ScpTyp;
			__debugInfo = "1216:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper23__2271) == (~~(1))) ? 1 : 0)) {
				__debugInfo = "1210:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("ELSE")) {
					__debugInfo = "1210:\src\CompilerPasses\Parser.gbas";
					param12_CloseStr_Str_ref[0] = "ELSE";
					__debugInfo = "1210:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1211:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("ELSEIF")) {
					__debugInfo = "1211:\src\CompilerPasses\Parser.gbas";
					param12_CloseStr_Str_ref[0] = "ELSEIF";
					__debugInfo = "1211:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1210:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper23__2271) == (~~(6))) ? 1 : 0)) {
				__debugInfo = "1214:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("CASE")) {
					__debugInfo = "1214:\src\CompilerPasses\Parser.gbas";
					param12_CloseStr_Str_ref[0] = "CASE";
					__debugInfo = "1214:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1215:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("DEFAULT")) {
					__debugInfo = "1215:\src\CompilerPasses\Parser.gbas";
					param12_CloseStr_Str_ref[0] = "DEFAULT";
					__debugInfo = "1215:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1214:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1207:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1217:\src\CompilerPasses\Parser.gbas";
		return tryClone(unref(param12_CloseStr_Str_ref[0]));
		__debugInfo = "1218:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "1207:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_IsClosing_Str = window['func13_IsClosing_Str'];
window['func10_Identifier'] = function(param9_IsCommand) {
	stackPush("function: Identifier", __debugInfo);
	try {
		var local9_PreferVar_2273 = 0, local4_Expr_ref_2274 = [0], local5_IsAcc_2275 = 0;
		__debugInfo = "1222:\src\CompilerPasses\Parser.gbas";
		local9_PreferVar_2273 = 0;
		__debugInfo = "1223:\src\CompilerPasses\Parser.gbas";
		if ((((func7_IsToken("LOCAL")) && ((((param9_IsCommand) == (0)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1223:\src\CompilerPasses\Parser.gbas";
			local9_PreferVar_2273 = 1;
			__debugInfo = "1223:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1224:\src\CompilerPasses\Parser.gbas";
		if ((((func7_IsToken("GLOBAL")) && ((((param9_IsCommand) == (0)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1224:\src\CompilerPasses\Parser.gbas";
			local9_PreferVar_2273 = -(1);
			__debugInfo = "1224:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1227:\src\CompilerPasses\Parser.gbas";
		if ((((local9_PreferVar_2273) != (0)) ? 1 : 0)) {
			__debugInfo = "1227:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "1227:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1229:\src\CompilerPasses\Parser.gbas";
		local4_Expr_ref_2274[0] = -(1);
		__debugInfo = "1230:\src\CompilerPasses\Parser.gbas";
		local5_IsAcc_2275 = 0;
		__debugInfo = "1245:\src\CompilerPasses\Parser.gbas";
		if (func7_IsToken("super")) {
			__debugInfo = "1232:\src\CompilerPasses\Parser.gbas";
			func5_Match("super", 1231, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1244:\src\CompilerPasses\Parser.gbas";
			if (((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
				var local3_typ_2276 = 0;
				__debugInfo = "1233:\src\CompilerPasses\Parser.gbas";
				local3_typ_2276 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType;
				__debugInfo = "1241:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr5_Types_ref[0].arrAccess(local3_typ_2276).values[tmpPositionCache][0].attr9_Extending) != (-(1))) ? 1 : 0)) {
					__debugInfo = "1236:\src\CompilerPasses\Parser.gbas";
					local4_Expr_ref_2274[0] = func21_CreateSuperExpression(global8_Compiler.attr5_Types_ref[0].arrAccess(local3_typ_2276).values[tmpPositionCache][0].attr9_Extending);
					__debugInfo = "1237:\src\CompilerPasses\Parser.gbas";
					func5_Match(".", 1236, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1238:\src\CompilerPasses\Parser.gbas";
					local5_IsAcc_2275 = 1;
					__debugInfo = "1236:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1240:\src\CompilerPasses\Parser.gbas";
					func5_Error("There is no super class/type", 1239, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1240:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1233:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "1243:\src\CompilerPasses\Parser.gbas";
				func5_Error("Super has to be in method", 1242, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1243:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1232:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1270:\src\CompilerPasses\Parser.gbas";
		if ((((func6_IsType("")) && (((func12_IsIdentifier(0, 0)) ? 0 : 1))) ? 1 : 0)) {
			var local4_posi_2277 = 0.0, local7_typ_Str_2278 = "";
			__debugInfo = "1248:\src\CompilerPasses\Parser.gbas";
			local4_posi_2277 = global8_Compiler.attr11_currentPosi;
			__debugInfo = "1249:\src\CompilerPasses\Parser.gbas";
			local7_typ_Str_2278 = func14_GetCurrent_Str();
			__debugInfo = "1250:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "1269:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("(")) {
				__debugInfo = "1252:\src\CompilerPasses\Parser.gbas";
				func5_Match("(", 1251, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1253:\src\CompilerPasses\Parser.gbas";
				local4_Expr_ref_2274[0] = func10_Expression(0);
				__debugInfo = "1254:\src\CompilerPasses\Parser.gbas";
				func5_Match(")", 1253, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1265:\src\CompilerPasses\Parser.gbas";
				if ((((func6_IsType(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) && ((((global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "1256:\src\CompilerPasses\Parser.gbas";
					local4_Expr_ref_2274[0] = func14_CreateCast2Obj(local7_typ_Str_2278, unref(local4_Expr_ref_2274[0]));
					__debugInfo = "1262:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken(".")) {
						__debugInfo = "1258:\src\CompilerPasses\Parser.gbas";
						func5_Match(".", 1257, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1259:\src\CompilerPasses\Parser.gbas";
						local5_IsAcc_2275 = 1;
						__debugInfo = "1258:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1261:\src\CompilerPasses\Parser.gbas";
						return tryClone(unref(local4_Expr_ref_2274[0]));
						__debugInfo = "1261:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1256:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1264:\src\CompilerPasses\Parser.gbas";
					func5_Error("Cannot cast non TYPE or array", 1263, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1264:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1252:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "1268:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr11_currentPosi = ~~(local4_posi_2277);
				__debugInfo = "1268:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1248:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1438:\src\CompilerPasses\Parser.gbas";
		do {
			var local8_Name_Str_2279 = "", local9_SuperExpr_ref_2280 = [0], local5_Varis_2281 = new OTTArray(0), local5_Found_2282 = 0;
			__debugInfo = "1273:\src\CompilerPasses\Parser.gbas";
			local8_Name_Str_2279 = func17_CleanVariable_Str(func14_GetCurrent_Str());
			__debugInfo = "1274:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "1278:\src\CompilerPasses\Parser.gbas";
			if ((((func7_IsToken("%")) || (func7_IsToken("%"))) ? 1 : 0)) {
				__debugInfo = "1277:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "1277:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1280:\src\CompilerPasses\Parser.gbas";
			local9_SuperExpr_ref_2280[0] = local4_Expr_ref_2274[0];
			__debugInfo = "1291:\src\CompilerPasses\Parser.gbas";
			if ((((local4_Expr_ref_2274[0]) == (-(1))) ? 1 : 0)) {
				__debugInfo = "1285:\src\CompilerPasses\Parser.gbas";
				func8_GetVaris(unref(local5_Varis_2281), -(1), local9_PreferVar_2273);
				__debugInfo = "1286:\src\CompilerPasses\Parser.gbas";
				local9_PreferVar_2273 = 0;
				__debugInfo = "1285:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "1289:\src\CompilerPasses\Parser.gbas";
				if ((((func6_IsType(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) == (0)) ? 1 : 0)) {
					__debugInfo = "1289:\src\CompilerPasses\Parser.gbas";
					func5_Error((((("Expecting type, got primitive datatype '") + (global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]))) + ("'")), 1288, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1289:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1290:\src\CompilerPasses\Parser.gbas";
				local5_Varis_2281 = global8_LastType.attr10_Attributes.clone(/* In Assign */);
				__debugInfo = "1289:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1293:\src\CompilerPasses\Parser.gbas";
			local5_Found_2282 = 0;
			__debugInfo = "1325:\src\CompilerPasses\Parser.gbas";
			var forEachSaver17409 = local5_Varis_2281;
			for(var forEachCounter17409 = 0 ; forEachCounter17409 < forEachSaver17409.values.length ; forEachCounter17409++) {
				var local4_Vari_2283 = forEachSaver17409.values[forEachCounter17409];
			{
					__debugInfo = "1324:\src\CompilerPasses\Parser.gbas";
					if ((((local8_Name_Str_2279) == (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Vari_2283).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0)) {
						__debugInfo = "1320:\src\CompilerPasses\Parser.gbas";
						if ((((((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) && ((((local4_Expr_ref_2274[0]) == (-(1))) ? 1 : 0))) ? 1 : 0)) {
							var local13_IsNotImplicit_2284 = 0;
							__debugInfo = "1300:\src\CompilerPasses\Parser.gbas";
							local13_IsNotImplicit_2284 = 0;
							__debugInfo = "1306:\src\CompilerPasses\Parser.gbas";
							var forEachSaver17350 = local5_Varis_2281;
							for(var forEachCounter17350 = 0 ; forEachCounter17350 < forEachSaver17350.values.length ; forEachCounter17350++) {
								var local9_OtherVari_2285 = forEachSaver17350.values[forEachCounter17350];
							{
									__debugInfo = "1305:\src\CompilerPasses\Parser.gbas";
									if ((((((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr8_Name_Str) == (local8_Name_Str_2279)) ? 1 : 0)) && ((((((((((((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr3_Typ) == (1)) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr3_Typ) == (5)) ? 1 : 0))) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr3_Typ) == (4)) ? 1 : 0))) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr3_Typ) == (7)) ? 1 : 0))) ? 1 : 0)) || ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local9_OtherVari_2285).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) && ((((local9_OtherVari_2285) != (local4_Vari_2283)) ? 1 : 0))) ? 1 : 0)) {
										__debugInfo = "1303:\src\CompilerPasses\Parser.gbas";
										local13_IsNotImplicit_2284 = 1;
										__debugInfo = "1304:\src\CompilerPasses\Parser.gbas";
										break;
										__debugInfo = "1303:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "1305:\src\CompilerPasses\Parser.gbas";
								}
								forEachSaver17350.values[forEachCounter17350] = local9_OtherVari_2285;
							
							};
							__debugInfo = "1319:\src\CompilerPasses\Parser.gbas";
							if (((local13_IsNotImplicit_2284) ? 0 : 1)) {
								var alias3_Typ_ref_2286 = [new type14_IdentifierType()];
								__debugInfo = "1309:\src\CompilerPasses\Parser.gbas";
								alias3_Typ_ref_2286 = global8_Compiler.attr5_Types_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType).values[tmpPositionCache] /* ALIAS */;
								__debugInfo = "1316:\src\CompilerPasses\Parser.gbas";
								var forEachSaver17395 = alias3_Typ_ref_2286[0].attr10_Attributes;
								for(var forEachCounter17395 = 0 ; forEachCounter17395 < forEachSaver17395.values.length ; forEachCounter17395++) {
									var local1_A_2287 = forEachSaver17395.values[forEachCounter17395];
								{
										__debugInfo = "1315:\src\CompilerPasses\Parser.gbas";
										if ((((local4_Vari_2283) == (local1_A_2287)) ? 1 : 0)) {
											__debugInfo = "1313:\src\CompilerPasses\Parser.gbas";
											local9_SuperExpr_ref_2280[0] = func24_CreateVariableExpression(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr7_SelfVar);
											__debugInfo = "1314:\src\CompilerPasses\Parser.gbas";
											break;
											__debugInfo = "1313:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "1315:\src\CompilerPasses\Parser.gbas";
									}
									forEachSaver17395.values[forEachCounter17395] = local1_A_2287;
								
								};
								__debugInfo = "1309:\src\CompilerPasses\Parser.gbas";
							} else {
								__debugInfo = "1318:\src\CompilerPasses\Parser.gbas";
								continue;
								__debugInfo = "1318:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1300:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1321:\src\CompilerPasses\Parser.gbas";
						local4_Expr_ref_2274[0] = func24_CreateVariableExpression(local4_Vari_2283);
						__debugInfo = "1322:\src\CompilerPasses\Parser.gbas";
						local5_Found_2282 = 1;
						__debugInfo = "1323:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "1320:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1324:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver17409.values[forEachCounter17409] = local4_Vari_2283;
			
			};
			__debugInfo = "1334:\src\CompilerPasses\Parser.gbas";
			while ((((func7_IsToken("(")) && (local5_Found_2282)) ? 1 : 0)) {
				var local4_func_2288 = 0;
				__debugInfo = "1327:\src\CompilerPasses\Parser.gbas";
				local4_func_2288 = func14_SearchPrototyp(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]));
				__debugInfo = "1333:\src\CompilerPasses\Parser.gbas";
				if ((((local4_func_2288) != (-(1))) ? 1 : 0)) {
					var local6_Params_2289 = new OTTArray(0);
					__debugInfo = "1330:\src\CompilerPasses\Parser.gbas";
					func13_ParseFuncCall(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local4_func_2288).values[tmpPositionCache][0].attr8_datatype, unref(local6_Params_2289), param9_IsCommand);
					__debugInfo = "1332:\src\CompilerPasses\Parser.gbas";
					local4_Expr_ref_2274[0] = func25_CreateProtoCallExpression(unref(local4_Expr_ref_2274[0]), unref(local6_Params_2289));
					__debugInfo = "1330:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1327:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1407:\src\CompilerPasses\Parser.gbas";
			if ((((local5_Found_2282) == (0)) ? 1 : 0)) {
				__debugInfo = "1381:\src\CompilerPasses\Parser.gbas";
				if ((((local4_Expr_ref_2274[0]) != (-(1))) ? 1 : 0)) {
					var local5_typId_2290 = 0;
					__debugInfo = "1337:\src\CompilerPasses\Parser.gbas";
					func6_IsType(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]));
					__debugInfo = "1338:\src\CompilerPasses\Parser.gbas";
					if (global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) {
						__debugInfo = "1338:\src\CompilerPasses\Parser.gbas";
						func5_Error("Cannot access to array.", 1337, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1338:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1340:\src\CompilerPasses\Parser.gbas";
					local5_typId_2290 = global8_LastType.attr2_ID;
					__debugInfo = "1354:\src\CompilerPasses\Parser.gbas";
					while ((((local5_typId_2290) != (-(1))) ? 1 : 0)) {
						__debugInfo = "1351:\src\CompilerPasses\Parser.gbas";
						var forEachSaver17552 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2290).values[tmpPositionCache][0].attr7_Methods;
						for(var forEachCounter17552 = 0 ; forEachCounter17552 < forEachSaver17552.values.length ; forEachCounter17552++) {
							var local1_M_2291 = forEachSaver17552.values[forEachCounter17552];
						{
								__debugInfo = "1350:\src\CompilerPasses\Parser.gbas";
								if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_2291).values[tmpPositionCache][0].attr8_Name_Str) == (local8_Name_Str_2279)) ? 1 : 0)) {
									__debugInfo = "1348:\src\CompilerPasses\Parser.gbas";
									if (((local5_Found_2282) ? 0 : 1)) {
										var local1_a_2292 = 0;
										__debugInfo = "1346:\src\CompilerPasses\Parser.gbas";
										local1_a_2292 = func19_ParseIdentifierFunc(local4_Expr_ref_2274, local9_SuperExpr_ref_2280, param9_IsCommand, local8_Name_Str_2279, local1_M_2291);
										__debugInfo = "1347:\src\CompilerPasses\Parser.gbas";
										if ((((local1_a_2292) != (-(1))) ? 1 : 0)) {
											__debugInfo = "1347:\src\CompilerPasses\Parser.gbas";
											return tryClone(local1_a_2292);
											__debugInfo = "1347:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "1346:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "1349:\src\CompilerPasses\Parser.gbas";
									local5_Found_2282 = 1;
									__debugInfo = "1348:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1350:\src\CompilerPasses\Parser.gbas";
							}
							forEachSaver17552.values[forEachCounter17552] = local1_M_2291;
						
						};
						__debugInfo = "1353:\src\CompilerPasses\Parser.gbas";
						local5_typId_2290 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2290).values[tmpPositionCache][0].attr9_Extending;
						__debugInfo = "1351:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1337:\src\CompilerPasses\Parser.gbas";
				} else {
					var local3_Val_ref_2293 = [0];
					__debugInfo = "1380:\src\CompilerPasses\Parser.gbas";
					if ((global8_Compiler.attr11_GlobalFuncs).GetValue(local8_Name_Str_2279, local3_Val_ref_2293)) {
						var local1_a_2294 = 0;
						__debugInfo = "1359:\src\CompilerPasses\Parser.gbas";
						local1_a_2294 = func19_ParseIdentifierFunc(local4_Expr_ref_2274, local9_SuperExpr_ref_2280, param9_IsCommand, local8_Name_Str_2279, unref(local3_Val_ref_2293[0]));
						__debugInfo = "1360:\src\CompilerPasses\Parser.gbas";
						if ((((local1_a_2294) != (-(1))) ? 1 : 0)) {
							__debugInfo = "1360:\src\CompilerPasses\Parser.gbas";
							return tryClone(local1_a_2294);
							__debugInfo = "1360:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1361:\src\CompilerPasses\Parser.gbas";
						local5_Found_2282 = 1;
						__debugInfo = "1359:\src\CompilerPasses\Parser.gbas";
					} else if (((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
						var alias3_Typ_ref_2295 = [new type14_IdentifierType()], local5_typId_2296 = 0;
						__debugInfo = "1364:\src\CompilerPasses\Parser.gbas";
						alias3_Typ_ref_2295 = global8_Compiler.attr5_Types_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType).values[tmpPositionCache] /* ALIAS */;
						__debugInfo = "1365:\src\CompilerPasses\Parser.gbas";
						local5_typId_2296 = alias3_Typ_ref_2295[0].attr2_ID;
						__debugInfo = "1379:\src\CompilerPasses\Parser.gbas";
						while ((((local5_typId_2296) != (-(1))) ? 1 : 0)) {
							__debugInfo = "1376:\src\CompilerPasses\Parser.gbas";
							var forEachSaver17695 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2296).values[tmpPositionCache][0].attr7_Methods;
							for(var forEachCounter17695 = 0 ; forEachCounter17695 < forEachSaver17695.values.length ; forEachCounter17695++) {
								var local1_M_2297 = forEachSaver17695.values[forEachCounter17695];
							{
									__debugInfo = "1375:\src\CompilerPasses\Parser.gbas";
									if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_2297).values[tmpPositionCache][0].attr8_Name_Str) == (local8_Name_Str_2279)) ? 1 : 0)) {
										__debugInfo = "1372:\src\CompilerPasses\Parser.gbas";
										if (((local5_Found_2282) ? 0 : 1)) {
											var local1_a_2298 = 0;
											__debugInfo = "1370:\src\CompilerPasses\Parser.gbas";
											local1_a_2298 = func19_ParseIdentifierFunc(local4_Expr_ref_2274, local9_SuperExpr_ref_2280, param9_IsCommand, local8_Name_Str_2279, local1_M_2297);
											__debugInfo = "1371:\src\CompilerPasses\Parser.gbas";
											if ((((local1_a_2298) != (-(1))) ? 1 : 0)) {
												__debugInfo = "1371:\src\CompilerPasses\Parser.gbas";
												return tryClone(local1_a_2298);
												__debugInfo = "1371:\src\CompilerPasses\Parser.gbas";
											};
											__debugInfo = "1370:\src\CompilerPasses\Parser.gbas";
										};
										__debugInfo = "1374:\src\CompilerPasses\Parser.gbas";
										local5_Found_2282 = 1;
										__debugInfo = "1372:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "1375:\src\CompilerPasses\Parser.gbas";
								}
								forEachSaver17695.values[forEachCounter17695] = local1_M_2297;
							
							};
							__debugInfo = "1378:\src\CompilerPasses\Parser.gbas";
							local5_typId_2296 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_typId_2296).values[tmpPositionCache][0].attr9_Extending;
							__debugInfo = "1376:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1364:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1380:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1391:\src\CompilerPasses\Parser.gbas";
				while ((((func7_IsToken("(")) && (local5_Found_2282)) ? 1 : 0)) {
					var local4_func_2299 = 0;
					__debugInfo = "1384:\src\CompilerPasses\Parser.gbas";
					local4_func_2299 = func14_SearchPrototyp(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]));
					__debugInfo = "1390:\src\CompilerPasses\Parser.gbas";
					if ((((local4_func_2299) != (-(1))) ? 1 : 0)) {
						var local6_Params_2300 = new OTTArray(0);
						__debugInfo = "1387:\src\CompilerPasses\Parser.gbas";
						func13_ParseFuncCall(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local4_func_2299).values[tmpPositionCache][0].attr8_datatype, unref(local6_Params_2300), param9_IsCommand);
						__debugInfo = "1389:\src\CompilerPasses\Parser.gbas";
						local4_Expr_ref_2274[0] = func25_CreateProtoCallExpression(unref(local4_Expr_ref_2274[0]), unref(local6_Params_2300));
						__debugInfo = "1387:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1384:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1406:\src\CompilerPasses\Parser.gbas";
				if ((((local5_Found_2282) == (0)) ? 1 : 0)) {
					__debugInfo = "1405:\src\CompilerPasses\Parser.gbas";
					if ((((local4_Expr_ref_2274[0]) != (-(1))) ? 1 : 0)) {
						var local8_Atts_Str_2301 = "";
						__debugInfo = "1395:\src\CompilerPasses\Parser.gbas";
						local8_Atts_Str_2301 = "";
						__debugInfo = "1400:\src\CompilerPasses\Parser.gbas";
						var forEachSaver17799 = local5_Varis_2281;
						for(var forEachCounter17799 = 0 ; forEachCounter17799 < forEachSaver17799.values.length ; forEachCounter17799++) {
							var local4_Vari_2302 = forEachSaver17799.values[forEachCounter17799];
						{
								__debugInfo = "1399:\src\CompilerPasses\Parser.gbas";
								if ((((local8_Name_Str_2279) == (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Vari_2302).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0)) {
									__debugInfo = "1398:\src\CompilerPasses\Parser.gbas";
									local8_Atts_Str_2301 = ((((local8_Atts_Str_2301) + (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Vari_2302).values[tmpPositionCache][0].attr8_Name_Str))) + (", "));
									__debugInfo = "1398:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1399:\src\CompilerPasses\Parser.gbas";
							}
							forEachSaver17799.values[forEachCounter17799] = local4_Vari_2302;
						
						};
						__debugInfo = "1401:\src\CompilerPasses\Parser.gbas";
						func6_IsType(unref(global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0]));
						__debugInfo = "1402:\src\CompilerPasses\Parser.gbas";
						func5_Error((((((((((((("Cannot find attribute '") + (local8_Name_Str_2279))) + ("' in type '"))) + (global8_LastType.attr8_Name_Str))) + ("' possible attributes '"))) + (local8_Atts_Str_2301))) + ("'")), 1401, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1395:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1404:\src\CompilerPasses\Parser.gbas";
						func5_Error((((("Internal error ") + (local8_Name_Str_2279))) + (" (expected identifier).")), 1403, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1404:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1405:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1381:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1427:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("[")) {
				var local4_Dims_2303 = new OTTArray(0);
				__debugInfo = "1414:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
					__debugInfo = "1413:\src\CompilerPasses\Parser.gbas";
					func5_Error("Array access, but this identifier is no array", 1412, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1413:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1424:\src\CompilerPasses\Parser.gbas";
				while (func7_IsToken("[")) {
					var local7_dimExpr_2304 = 0;
					__debugInfo = "1416:\src\CompilerPasses\Parser.gbas";
					func5_Match("[", 1415, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1420:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("]")) {
						__debugInfo = "1418:\src\CompilerPasses\Parser.gbas";
						func5_Match("]", 1417, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1419:\src\CompilerPasses\Parser.gbas";
						break;
						__debugInfo = "1418:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1421:\src\CompilerPasses\Parser.gbas";
					local7_dimExpr_2304 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 1420, 0);
					__debugInfo = "1422:\src\CompilerPasses\Parser.gbas";
					func5_Match("]", 1421, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1423:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local4_Dims_2303, local7_dimExpr_2304);
					__debugInfo = "1416:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1426:\src\CompilerPasses\Parser.gbas";
				local4_Expr_ref_2274[0] = func21_CreateArrayExpression(unref(local4_Expr_ref_2274[0]), unref(local4_Dims_2303));
				__debugInfo = "1414:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1429:\src\CompilerPasses\Parser.gbas";
			local4_Expr_ref_2274[0] = func22_CreateAccessExpression(unref(local9_SuperExpr_ref_2280[0]), unref(local4_Expr_ref_2274[0]));
			__debugInfo = "1437:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken(".")) {
				__debugInfo = "1433:\src\CompilerPasses\Parser.gbas";
				func5_Match(".", 1432, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1434:\src\CompilerPasses\Parser.gbas";
				local5_IsAcc_2275 = 1;
				__debugInfo = "1433:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "1436:\src\CompilerPasses\Parser.gbas";
				local5_IsAcc_2275 = 0;
				__debugInfo = "1436:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1273:\src\CompilerPasses\Parser.gbas";
		} while (!((((local5_IsAcc_2275) == (0)) ? 1 : 0)));
		__debugInfo = "1451:\src\CompilerPasses\Parser.gbas";
		if (((((((func7_IsToken("=")) && ((((local4_Expr_ref_2274[0]) != (-(1))) ? 1 : 0))) ? 1 : 0)) && (param9_IsCommand)) ? 1 : 0)) {
			var local7_tmpData_2305 = new type8_Datatype();
			__debugInfo = "1442:\src\CompilerPasses\Parser.gbas";
			if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(unref(local4_Expr_ref_2274[0]), 1)).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0)) {
				__debugInfo = "1442:\src\CompilerPasses\Parser.gbas";
				func5_Error("Assignment invalid, because of CONSTANT variable.", 1441, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1442:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1444:\src\CompilerPasses\Parser.gbas";
			if (((((((global5_Exprs_ref[0].arrAccess(func12_GetRightExpr(unref(local4_Expr_ref_2274[0]))).values[tmpPositionCache][0].attr3_Typ) == (6)) ? 1 : 0)) || ((((global5_Exprs_ref[0].arrAccess(func12_GetRightExpr(unref(local4_Expr_ref_2274[0]))).values[tmpPositionCache][0].attr3_Typ) == (23)) ? 1 : 0))) ? 1 : 0)) {
				__debugInfo = "1444:\src\CompilerPasses\Parser.gbas";
				func5_Error("Cannot assign to function call.", 1443, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1444:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1445:\src\CompilerPasses\Parser.gbas";
			func5_Match("=", 1444, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1446:\src\CompilerPasses\Parser.gbas";
			if ((((param9_IsCommand) == (0)) ? 1 : 0)) {
				__debugInfo = "1446:\src\CompilerPasses\Parser.gbas";
				func5_Error("Assignment is a statement.", 1445, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1446:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1449:\src\CompilerPasses\Parser.gbas";
			local7_tmpData_2305 = global5_Exprs_ref[0].arrAccess(local4_Expr_ref_2274[0]).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
			__debugInfo = "1450:\src\CompilerPasses\Parser.gbas";
			return tryClone(func22_CreateAssignExpression(unref(local4_Expr_ref_2274[0]), func14_EnsureDatatype(func10_Expression(0), local7_tmpData_2305, 1449, 0)));
			__debugInfo = "1442:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1457:\src\CompilerPasses\Parser.gbas";
		if ((((local4_Expr_ref_2274[0]) != (-(1))) ? 1 : 0)) {
			__debugInfo = "1454:\src\CompilerPasses\Parser.gbas";
			return tryClone(unref(local4_Expr_ref_2274[0]));
			__debugInfo = "1454:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "1456:\src\CompilerPasses\Parser.gbas";
			func5_Error("Internal error (Expecting identifier)", 1455, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1456:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1458:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1222:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_Identifier = window['func10_Identifier'];
window['func19_ParseIdentifierFunc'] = function(param4_Expr_ref, param9_SuperExpr_ref, param9_IsCommand, param8_Name_Str, param4_func) {
	stackPush("function: ParseIdentifierFunc", __debugInfo);
	try {
		__debugInfo = "1462:\src\CompilerPasses\Parser.gbas";
		if ((((param4_func) == (-(1))) ? 1 : 0)) {
			__debugInfo = "1462:\src\CompilerPasses\Parser.gbas";
			func5_Error("Internal Error (func is -1, ParseIdentifierFunc", 1461, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1462:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1479:\src\CompilerPasses\Parser.gbas";
		if ((((((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) && ((((param4_Expr_ref[0]) == (-(1))) ? 1 : 0))) ? 1 : 0)) {
			var local3_typ_2311 = 0;
			__debugInfo = "1468:\src\CompilerPasses\Parser.gbas";
			local3_typ_2311 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType;
			__debugInfo = "1478:\src\CompilerPasses\Parser.gbas";
			while ((((local3_typ_2311) != (-(1))) ? 1 : 0)) {
				__debugInfo = "1475:\src\CompilerPasses\Parser.gbas";
				if (((((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr6_MyType) == (local3_typ_2311)) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "1472:\src\CompilerPasses\Parser.gbas";
					param9_SuperExpr_ref[0] = func24_CreateVariableExpression(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr7_SelfVar);
					__debugInfo = "1474:\src\CompilerPasses\Parser.gbas";
					break;
					__debugInfo = "1472:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1477:\src\CompilerPasses\Parser.gbas";
				local3_typ_2311 = global8_Compiler.attr5_Types_ref[0].arrAccess(local3_typ_2311).values[tmpPositionCache][0].attr9_Extending;
				__debugInfo = "1475:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1468:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1481:\src\CompilerPasses\Parser.gbas";
		global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr10_PlzCompile = 1;
		__debugInfo = "1498:\src\CompilerPasses\Parser.gbas";
		if (((((((func7_IsToken("(")) == (0)) ? 1 : 0)) && ((((param9_IsCommand) == (0)) ? 1 : 0))) ? 1 : 0)) {
			var local8_datatype_2312 = new type8_Datatype();
			__debugInfo = "1486:\src\CompilerPasses\Parser.gbas";
			local8_datatype_2312.attr8_Name_Str_ref[0] = param8_Name_Str;
			__debugInfo = "1487:\src\CompilerPasses\Parser.gbas";
			local8_datatype_2312.attr7_IsArray_ref[0] = 0;
			__debugInfo = "1490:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr15_UsedAsPrototype = 1;
			__debugInfo = "1492:\src\CompilerPasses\Parser.gbas";
			return tryClone(func24_CreateFuncDataExpression(local8_datatype_2312));
			__debugInfo = "1486:\src\CompilerPasses\Parser.gbas";
		} else {
			var local6_Params_2313 = new OTTArray(0);
			__debugInfo = "1495:\src\CompilerPasses\Parser.gbas";
			func13_ParseFuncCall(global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr8_datatype, unref(local6_Params_2313), param9_IsCommand);
			__debugInfo = "1497:\src\CompilerPasses\Parser.gbas";
			param4_Expr_ref[0] = func24_CreateFuncCallExpression(global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_func).values[tmpPositionCache][0].attr2_ID, unref(local6_Params_2313));
			__debugInfo = "1495:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1499:\src\CompilerPasses\Parser.gbas";
		return tryClone(-(1));
		__debugInfo = "1500:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1462:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func19_ParseIdentifierFunc = window['func19_ParseIdentifierFunc'];
window['func13_ParseFuncCall'] = function(param8_datatype, param6_Params, param9_IsCommand) {
	stackPush("function: ParseFuncCall", __debugInfo);
	try {
		var local9_OpBracket_2317 = 0, local4_Find_2318 = 0.0, local12_CloseBracket_2319 = 0;
		__debugInfo = "1503:\src\CompilerPasses\Parser.gbas";
		local9_OpBracket_2317 = func7_IsToken("(");
		__debugInfo = "1516:\src\CompilerPasses\Parser.gbas";
		if ((((param8_datatype.attr8_Name_Str_ref[0]) == ("void")) ? 1 : 0)) {
			__debugInfo = "1507:\src\CompilerPasses\Parser.gbas";
			if (((param9_IsCommand) ? 0 : 1)) {
				__debugInfo = "1506:\src\CompilerPasses\Parser.gbas";
				func5_Error("Void function has to be a command!", 1505, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1506:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1508:\src\CompilerPasses\Parser.gbas";
			local9_OpBracket_2317 = 0;
			__debugInfo = "1507:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "1513:\src\CompilerPasses\Parser.gbas";
			if (local9_OpBracket_2317) {
				__debugInfo = "1513:\src\CompilerPasses\Parser.gbas";
				func5_Match("(", 1512, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1513:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1513:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1519:\src\CompilerPasses\Parser.gbas";
		local4_Find_2318 = 0;
		__debugInfo = "1524:\src\CompilerPasses\Parser.gbas";
		while (((((((func7_IsToken("\n")) == (0)) ? 1 : 0)) && ((((func7_IsToken(")")) == (0)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "1521:\src\CompilerPasses\Parser.gbas";
			if (local4_Find_2318) {
				__debugInfo = "1521:\src\CompilerPasses\Parser.gbas";
				func5_Match(",", 1520, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1521:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1522:\src\CompilerPasses\Parser.gbas";
			DIMPUSH(param6_Params, func10_Expression(0));
			__debugInfo = "1523:\src\CompilerPasses\Parser.gbas";
			local4_Find_2318 = 1;
			__debugInfo = "1521:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1526:\src\CompilerPasses\Parser.gbas";
		local12_CloseBracket_2319 = func7_IsToken(")");
		__debugInfo = "1527:\src\CompilerPasses\Parser.gbas";
		if (local12_CloseBracket_2319) {
			__debugInfo = "1527:\src\CompilerPasses\Parser.gbas";
			func5_Match(")", 1526, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1527:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1531:\src\CompilerPasses\Parser.gbas";
		if ((((local12_CloseBracket_2319) != (local9_OpBracket_2317)) ? 1 : 0)) {
			__debugInfo = "1530:\src\CompilerPasses\Parser.gbas";
			func5_Error("Brackets are not closed.", 1529, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "1530:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "1532:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1503:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_ParseFuncCall = window['func13_ParseFuncCall'];
window['func7_Keyword'] = function() {
	stackPush("function: Keyword", __debugInfo);
	try {
		__debugInfo = "1537:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper24__2320 = 0;
			__debugInfo = "1537:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper24__2320 = 1;
			__debugInfo = "2235:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper24__2320) == (func7_IsToken("CALLBACK"))) ? 1 : 0)) {
				__debugInfo = "1539:\src\CompilerPasses\Parser.gbas";
				func5_Match("CALLBACK", 1538, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1540:\src\CompilerPasses\Parser.gbas";
				func7_Keyword();
				__debugInfo = "1539:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("NATIVE"))) ? 1 : 0)) {
				__debugInfo = "1542:\src\CompilerPasses\Parser.gbas";
				func5_Match("NATIVE", 1541, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1543:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("NATIVE", "\n", "");
				__debugInfo = "1542:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("ABSTRACT"))) ? 1 : 0)) {
				__debugInfo = "1545:\src\CompilerPasses\Parser.gbas";
				func5_Match("ABSTRACT", 1544, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1546:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("ABSTRACT", "\n", "");
				__debugInfo = "1545:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("FUNCTION"))) ? 1 : 0)) {
				__debugInfo = "1548:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("FUNCTION", "ENDFUNCTION", "");
				__debugInfo = "1548:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("SUB"))) ? 1 : 0)) {
				__debugInfo = "1550:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("SUB", "ENDSUB", "");
				__debugInfo = "1550:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("TYPE"))) ? 1 : 0)) {
				__debugInfo = "1552:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("TYPE", "ENDTYPE", "");
				__debugInfo = "1552:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("PROTOTYPE"))) ? 1 : 0)) {
				__debugInfo = "1554:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("PROTOTYPE", "\n", "");
				__debugInfo = "1554:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("CONSTANT"))) ? 1 : 0)) {
				__debugInfo = "1556:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("CONSTANT", "\n", "");
				__debugInfo = "1556:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("GLOBAL"))) ? 1 : 0)) {
				__debugInfo = "1575:\src\CompilerPasses\Parser.gbas";
				do {
					var local7_tmpVari_2321 = new type14_IdentifierVari();
					__debugInfo = "1563:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("GLOBAL")) {
						__debugInfo = "1560:\src\CompilerPasses\Parser.gbas";
						func5_Match("GLOBAL", 1559, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1560:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1562:\src\CompilerPasses\Parser.gbas";
						func5_Match(",", 1561, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1562:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1565:\src\CompilerPasses\Parser.gbas";
					local7_tmpVari_2321 = func7_VariDef(0).clone(/* In Assign */);
					__debugInfo = "1574:\src\CompilerPasses\Parser.gbas";
					var forEachSaver18483 = global8_Compiler.attr7_Globals;
					for(var forEachCounter18483 = 0 ; forEachCounter18483 < forEachSaver18483.values.length ; forEachCounter18483++) {
						var local1_V_2322 = forEachSaver18483.values[forEachCounter18483];
					{
							var alias4_Vari_ref_2323 = [new type14_IdentifierVari()];
							__debugInfo = "1567:\src\CompilerPasses\Parser.gbas";
							alias4_Vari_ref_2323 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2322).values[tmpPositionCache] /* ALIAS */;
							__debugInfo = "1573:\src\CompilerPasses\Parser.gbas";
							if (((((((alias4_Vari_ref_2323[0].attr8_Name_Str) == (local7_tmpVari_2321.attr8_Name_Str)) ? 1 : 0)) && ((((alias4_Vari_ref_2323[0].attr6_PreDef) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
								var local7_tmpExpr_2324 = 0;
								__debugInfo = "1569:\src\CompilerPasses\Parser.gbas";
								if ((((global8_Compiler.attr12_CurrentScope) == (-(1))) ? 1 : 0)) {
									__debugInfo = "1569:\src\CompilerPasses\Parser.gbas";
									func5_Error("Internal error (GLOBAL in -1 scope)", 1568, "src\CompilerPasses\Parser.gbas");
									__debugInfo = "1569:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1570:\src\CompilerPasses\Parser.gbas";
								local7_tmpExpr_2324 = func22_CreateAssignExpression(func24_CreateVariableExpression(alias4_Vari_ref_2323[0].attr2_ID), alias4_Vari_ref_2323[0].attr6_PreDef);
								__debugInfo = "1571:\src\CompilerPasses\Parser.gbas";
								DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local7_tmpExpr_2324);
								__debugInfo = "1572:\src\CompilerPasses\Parser.gbas";
								alias4_Vari_ref_2323[0].attr6_PreDef = -(1);
								__debugInfo = "1569:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1567:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver18483.values[forEachCounter18483] = local1_V_2322;
					
					};
					__debugInfo = "1563:\src\CompilerPasses\Parser.gbas";
				} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
				__debugInfo = "1575:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("LOCAL"))) ? 1 : 0)) {
				__debugInfo = "1626:\src\CompilerPasses\Parser.gbas";
				do {
					var local10_DontCreate_2325 = 0;
					__debugInfo = "1582:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("LOCAL")) {
						__debugInfo = "1579:\src\CompilerPasses\Parser.gbas";
						func5_Match("LOCAL", 1578, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1579:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1581:\src\CompilerPasses\Parser.gbas";
						func5_Match(",", 1580, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1581:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1585:\src\CompilerPasses\Parser.gbas";
					local10_DontCreate_2325 = 0;
					__debugInfo = "1604:\src\CompilerPasses\Parser.gbas";
					if (func13_IsVarExisting(func17_CleanVariable_Str(func14_GetCurrent_Str()))) {
						var local5_Varis_2326 = new OTTArray(0);
						__debugInfo = "1587:\src\CompilerPasses\Parser.gbas";
						local10_DontCreate_2325 = 1;
						__debugInfo = "1590:\src\CompilerPasses\Parser.gbas";
						func8_GetVaris(unref(local5_Varis_2326), -(1), 0);
						__debugInfo = "1598:\src\CompilerPasses\Parser.gbas";
						var forEachSaver18562 = local5_Varis_2326;
						for(var forEachCounter18562 = 0 ; forEachCounter18562 < forEachSaver18562.values.length ; forEachCounter18562++) {
							var local1_V_2327 = forEachSaver18562.values[forEachCounter18562];
						{
								__debugInfo = "1597:\src\CompilerPasses\Parser.gbas";
								if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2327).values[tmpPositionCache][0].attr8_Name_Str) == (func17_CleanVariable_Str(func14_GetCurrent_Str()))) ? 1 : 0)) {
									__debugInfo = "1596:\src\CompilerPasses\Parser.gbas";
									if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2327).values[tmpPositionCache][0].attr3_Typ) == (2)) ? 1 : 0)) {
										__debugInfo = "1594:\src\CompilerPasses\Parser.gbas";
										local10_DontCreate_2325 = 0;
										__debugInfo = "1595:\src\CompilerPasses\Parser.gbas";
										break;
										__debugInfo = "1594:\src\CompilerPasses\Parser.gbas";
									};
									__debugInfo = "1596:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "1597:\src\CompilerPasses\Parser.gbas";
							}
							forEachSaver18562.values[forEachCounter18562] = local1_V_2327;
						
						};
						__debugInfo = "1603:\src\CompilerPasses\Parser.gbas";
						if (local10_DontCreate_2325) {
							var local4_Expr_2328 = 0;
							__debugInfo = "1600:\src\CompilerPasses\Parser.gbas";
							func7_Warning((((("Variable '") + (func14_GetCurrent_Str()))) + ("' already exists...")));
							__debugInfo = "1601:\src\CompilerPasses\Parser.gbas";
							local4_Expr_2328 = func10_Identifier(1);
							__debugInfo = "1602:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local4_Expr_2328);
							__debugInfo = "1600:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1587:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1624:\src\CompilerPasses\Parser.gbas";
					if (((local10_DontCreate_2325) ? 0 : 1)) {
						var local4_Vari_2329 = new type14_IdentifierVari(), local4_PDef_2330 = 0;
						__debugInfo = "1608:\src\CompilerPasses\Parser.gbas";
						local4_Vari_2329 = func7_VariDef(0).clone(/* In Assign */);
						__debugInfo = "1609:\src\CompilerPasses\Parser.gbas";
						local4_Vari_2329.attr3_Typ = ~~(1);
						__debugInfo = "1611:\src\CompilerPasses\Parser.gbas";
						local4_PDef_2330 = -(1);
						__debugInfo = "1615:\src\CompilerPasses\Parser.gbas";
						if ((((local4_Vari_2329.attr6_PreDef) != (-(1))) ? 1 : 0)) {
							__debugInfo = "1613:\src\CompilerPasses\Parser.gbas";
							local4_PDef_2330 = local4_Vari_2329.attr6_PreDef;
							__debugInfo = "1614:\src\CompilerPasses\Parser.gbas";
							local4_Vari_2329.attr6_PreDef = -(1);
							__debugInfo = "1613:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1616:\src\CompilerPasses\Parser.gbas";
						func11_AddVariable(local4_Vari_2329, 1);
						__debugInfo = "1617:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
						__debugInfo = "1623:\src\CompilerPasses\Parser.gbas";
						if ((((local4_PDef_2330) != (-(1))) ? 1 : 0)) {
							var local7_tmpExpr_2331 = 0;
							__debugInfo = "1620:\src\CompilerPasses\Parser.gbas";
							if ((((global8_Compiler.attr12_CurrentScope) == (-(1))) ? 1 : 0)) {
								__debugInfo = "1620:\src\CompilerPasses\Parser.gbas";
								func5_Error("Internal error (LOCAL in -1 scope)", 1619, "src\CompilerPasses\Parser.gbas");
								__debugInfo = "1620:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1621:\src\CompilerPasses\Parser.gbas";
							local7_tmpExpr_2331 = func22_CreateAssignExpression(func24_CreateVariableExpression(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1))), local4_PDef_2330);
							__debugInfo = "1622:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local7_tmpExpr_2331);
							__debugInfo = "1620:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1608:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1582:\src\CompilerPasses\Parser.gbas";
				} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
				__debugInfo = "1626:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("ALIAS"))) ? 1 : 0)) {
				__debugInfo = "1659:\src\CompilerPasses\Parser.gbas";
				do {
					var local4_Vari_2332 = new type14_IdentifierVari(), local4_PDef_2333 = 0, local7_tmpExpr_2334 = 0;
					__debugInfo = "1634:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("ALIAS")) {
						__debugInfo = "1631:\src\CompilerPasses\Parser.gbas";
						func5_Match("ALIAS", 1630, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1631:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1633:\src\CompilerPasses\Parser.gbas";
						func5_Match(",", 1632, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1633:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1635:\src\CompilerPasses\Parser.gbas";
					func14_IsValidVarName();
					__debugInfo = "1637:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2332.attr8_Name_Str = func14_GetCurrent_Str();
					__debugInfo = "1638:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2332.attr3_Typ = ~~(7);
					__debugInfo = "1639:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2332.attr3_ref = 1;
					__debugInfo = "1641:\src\CompilerPasses\Parser.gbas";
					func5_Match(local4_Vari_2332.attr8_Name_Str, 1640, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1642:\src\CompilerPasses\Parser.gbas";
					func5_Match("AS", 1641, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1644:\src\CompilerPasses\Parser.gbas";
					local4_PDef_2333 = func10_Identifier(0);
					__debugInfo = "1645:\src\CompilerPasses\Parser.gbas";
					global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local4_PDef_2333, 1)).values[tmpPositionCache][0].attr3_ref = 1;
					__debugInfo = "1646:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2332.attr8_datatype = global5_Exprs_ref[0].arrAccess(local4_PDef_2333).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
					__debugInfo = "1649:\src\CompilerPasses\Parser.gbas";
					func11_AddVariable(local4_Vari_2332, 1);
					__debugInfo = "1650:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
					__debugInfo = "1653:\src\CompilerPasses\Parser.gbas";
					local7_tmpExpr_2334 = func21_CreateAliasExpression(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)), local4_PDef_2333);
					__debugInfo = "1658:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken(",")) {
						__debugInfo = "1655:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local7_tmpExpr_2334);
						__debugInfo = "1655:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1657:\src\CompilerPasses\Parser.gbas";
						return tryClone(local7_tmpExpr_2334);
						__debugInfo = "1657:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1634:\src\CompilerPasses\Parser.gbas";
				} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
				__debugInfo = "1659:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("STATIC"))) ? 1 : 0)) {
				__debugInfo = "1661:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr11_currentFunc) == (-(1))) ? 1 : 0)) {
					__debugInfo = "1661:\src\CompilerPasses\Parser.gbas";
					func5_Error("Static has to be in a FUNCTION", 1660, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1661:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1677:\src\CompilerPasses\Parser.gbas";
				do {
					var local4_Vari_2335 = new type14_IdentifierVari();
					__debugInfo = "1668:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("STATIC")) {
						__debugInfo = "1665:\src\CompilerPasses\Parser.gbas";
						func5_Match("STATIC", 1664, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1665:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1667:\src\CompilerPasses\Parser.gbas";
						func5_Match(",", 1666, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1667:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1670:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2335 = func7_VariDef(0).clone(/* In Assign */);
					__debugInfo = "1671:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2335.attr3_Typ = ~~(4);
					__debugInfo = "1672:\src\CompilerPasses\Parser.gbas";
					local4_Vari_2335.attr4_func = global8_Compiler.attr11_currentFunc;
					__debugInfo = "1673:\src\CompilerPasses\Parser.gbas";
					func11_AddVariable(local4_Vari_2335, 1);
					__debugInfo = "1674:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr7_Statics, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
					__debugInfo = "1675:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
					__debugInfo = "1668:\src\CompilerPasses\Parser.gbas";
				} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
				__debugInfo = "1661:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DIMPUSH"))) ? 1 : 0)) {
				var local4_Vari_2336 = 0, local8_datatype_2337 = new type8_Datatype(), local4_Expr_2338 = 0;
				__debugInfo = "1679:\src\CompilerPasses\Parser.gbas";
				func5_Match("DIMPUSH", 1678, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1680:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2336 = func10_Identifier(0);
				__debugInfo = "1681:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(local4_Vari_2336).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
					__debugInfo = "1681:\src\CompilerPasses\Parser.gbas";
					func5_Error("DIMPUSH needs array", 1680, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1681:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1682:\src\CompilerPasses\Parser.gbas";
				func5_Match(",", 1681, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1684:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2337 = global5_Exprs_ref[0].arrAccess(local4_Vari_2336).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
				__debugInfo = "1685:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2337.attr7_IsArray_ref[0] = 0;
				__debugInfo = "1687:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2338 = func14_EnsureDatatype(func10_Expression(0), local8_datatype_2337, 1686, 0);
				__debugInfo = "1696:\src\CompilerPasses\Parser.gbas";
				return tryClone(func23_CreateDimpushExpression(local4_Vari_2336, local4_Expr_2338));
				__debugInfo = "1679:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DIM"))) ? 1 : 0)) {
				var local3_Arr_2339 = 0;
				__debugInfo = "1698:\src\CompilerPasses\Parser.gbas";
				func5_Match("DIM", 1697, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1699:\src\CompilerPasses\Parser.gbas";
				local3_Arr_2339 = func14_ImplicitDefine();
				__debugInfo = "1702:\src\CompilerPasses\Parser.gbas";
				if ((((local3_Arr_2339) != (-(1))) ? 1 : 0)) {
					__debugInfo = "1701:\src\CompilerPasses\Parser.gbas";
					global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Arr_2339).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0] = 1;
					__debugInfo = "1701:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1720:\src\CompilerPasses\Parser.gbas";
				if (func12_IsIdentifier(0, 0)) {
					var local4_expr_2340 = 0, local5_LExpr_2341 = 0, local4_Dims_2342 = new OTTArray(0);
					__debugInfo = "1705:\src\CompilerPasses\Parser.gbas";
					local4_expr_2340 = func10_Identifier(0);
					__debugInfo = "1706:\src\CompilerPasses\Parser.gbas";
					local5_LExpr_2341 = func12_GetRightExpr(local4_expr_2340);
					__debugInfo = "1707:\src\CompilerPasses\Parser.gbas";
					if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local4_expr_2340, 1)).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
						__debugInfo = "1707:\src\CompilerPasses\Parser.gbas";
						func5_Error("Array expected.", 1706, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1707:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1709:\src\CompilerPasses\Parser.gbas";
					{
						var local17___SelectHelper25__2343 = 0;
						__debugInfo = "1709:\src\CompilerPasses\Parser.gbas";
						local17___SelectHelper25__2343 = global5_Exprs_ref[0].arrAccess(local5_LExpr_2341).values[tmpPositionCache][0].attr3_Typ;
						__debugInfo = "1715:\src\CompilerPasses\Parser.gbas";
						if ((((local17___SelectHelper25__2343) == (~~(13))) ? 1 : 0)) {
							__debugInfo = "1711:\src\CompilerPasses\Parser.gbas";
							local4_Dims_2342 = global5_Exprs_ref[0].arrAccess(local5_LExpr_2341).values[tmpPositionCache][0].attr4_dims.clone(/* In Assign */);
							__debugInfo = "1712:\src\CompilerPasses\Parser.gbas";
							DIM(global5_Exprs_ref[0].arrAccess(local5_LExpr_2341).values[tmpPositionCache][0].attr4_dims, [0], 0);
							__debugInfo = "1711:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "1714:\src\CompilerPasses\Parser.gbas";
							func5_Error("Internal error (array not parsed)", 1713, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1714:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1709:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1717:\src\CompilerPasses\Parser.gbas";
					return tryClone(func19_CreateDimExpression(local4_expr_2340, unref(local4_Dims_2342)));
					__debugInfo = "1705:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1719:\src\CompilerPasses\Parser.gbas";
					func5_Error("DIM needs identifier", 1718, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1719:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1698:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("REDIM"))) ? 1 : 0)) {
				var local3_Arr_2344 = 0;
				__debugInfo = "1722:\src\CompilerPasses\Parser.gbas";
				func5_Match("REDIM", 1721, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1723:\src\CompilerPasses\Parser.gbas";
				local3_Arr_2344 = func14_ImplicitDefine();
				__debugInfo = "1726:\src\CompilerPasses\Parser.gbas";
				if ((((local3_Arr_2344) != (-(1))) ? 1 : 0)) {
					__debugInfo = "1725:\src\CompilerPasses\Parser.gbas";
					global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_Arr_2344).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0] = 1;
					__debugInfo = "1725:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1742:\src\CompilerPasses\Parser.gbas";
				if (func12_IsIdentifier(0, 0)) {
					var local4_expr_2345 = 0, local5_LExpr_2346 = 0, local4_Dims_2347 = new OTTArray(0);
					__debugInfo = "1728:\src\CompilerPasses\Parser.gbas";
					local4_expr_2345 = func10_Identifier(0);
					__debugInfo = "1729:\src\CompilerPasses\Parser.gbas";
					local5_LExpr_2346 = func12_GetRightExpr(local4_expr_2345);
					__debugInfo = "1730:\src\CompilerPasses\Parser.gbas";
					if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local4_expr_2345, 1)).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
						__debugInfo = "1730:\src\CompilerPasses\Parser.gbas";
						func5_Error("Array expected.", 1729, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1730:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1732:\src\CompilerPasses\Parser.gbas";
					{
						var local17___SelectHelper26__2348 = 0;
						__debugInfo = "1732:\src\CompilerPasses\Parser.gbas";
						local17___SelectHelper26__2348 = global5_Exprs_ref[0].arrAccess(local5_LExpr_2346).values[tmpPositionCache][0].attr3_Typ;
						__debugInfo = "1738:\src\CompilerPasses\Parser.gbas";
						if ((((local17___SelectHelper26__2348) == (~~(13))) ? 1 : 0)) {
							__debugInfo = "1734:\src\CompilerPasses\Parser.gbas";
							local4_Dims_2347 = global5_Exprs_ref[0].arrAccess(local5_LExpr_2346).values[tmpPositionCache][0].attr4_dims.clone(/* In Assign */);
							__debugInfo = "1735:\src\CompilerPasses\Parser.gbas";
							DIM(global5_Exprs_ref[0].arrAccess(local5_LExpr_2346).values[tmpPositionCache][0].attr4_dims, [0], 0);
							__debugInfo = "1734:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "1737:\src\CompilerPasses\Parser.gbas";
							func5_Error("Internal error (array not parsed)", 1736, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1737:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1732:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1739:\src\CompilerPasses\Parser.gbas";
					return tryClone(func21_CreateReDimExpression(local4_expr_2345, unref(local4_Dims_2347)));
					__debugInfo = "1728:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1741:\src\CompilerPasses\Parser.gbas";
					func5_Error("REDIM needs identifier", 1740, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1741:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1722:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DIMDATA"))) ? 1 : 0)) {
				var local5_Array_2349 = 0, local2_Ex_2350 = new OTTArray(0);
				__debugInfo = "1744:\src\CompilerPasses\Parser.gbas";
				func5_Match("DIMDATA", 1743, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1746:\src\CompilerPasses\Parser.gbas";
				local5_Array_2349 = func14_ImplicitDefine();
				__debugInfo = "1752:\src\CompilerPasses\Parser.gbas";
				if ((((local5_Array_2349) != (-(1))) ? 1 : 0)) {
					__debugInfo = "1748:\src\CompilerPasses\Parser.gbas";
					global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Array_2349).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0] = 1;
					__debugInfo = "1749:\src\CompilerPasses\Parser.gbas";
					local5_Array_2349 = func10_Identifier(0);
					__debugInfo = "1748:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1751:\src\CompilerPasses\Parser.gbas";
					local5_Array_2349 = func10_Expression(0);
					__debugInfo = "1751:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1754:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(local5_Array_2349).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
					__debugInfo = "1754:\src\CompilerPasses\Parser.gbas";
					func5_Error("DIMDATA needs array, stupid...", 1753, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1754:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1766:\src\CompilerPasses\Parser.gbas";
				while ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
					__debugInfo = "1757:\src\CompilerPasses\Parser.gbas";
					func5_Match(",", 1756, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1765:\src\CompilerPasses\Parser.gbas";
					if ((((BOUNDS(local2_Ex_2350, 0)) == (0)) ? 1 : 0)) {
						__debugInfo = "1759:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(local2_Ex_2350, func10_Expression(0));
						__debugInfo = "1759:\src\CompilerPasses\Parser.gbas";
					} else {
						var local7_datatyp_2351 = new type8_Datatype(), local1_E_2352 = 0;
						__debugInfo = "1762:\src\CompilerPasses\Parser.gbas";
						local7_datatyp_2351 = global5_Exprs_ref[0].arrAccess(local2_Ex_2350.arrAccess(0).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
						__debugInfo = "1763:\src\CompilerPasses\Parser.gbas";
						local1_E_2352 = func14_EnsureDatatype(func10_Expression(0), local7_datatyp_2351, 1762, 0);
						__debugInfo = "1764:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(local2_Ex_2350, local1_E_2352);
						__debugInfo = "1762:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1757:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1768:\src\CompilerPasses\Parser.gbas";
				return tryClone(func23_CreateDimDataExpression(local5_Array_2349, unref(local2_Ex_2350)));
				__debugInfo = "1744:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DELETE"))) ? 1 : 0)) {
				var local11_VarName_Str_2353 = "";
				__debugInfo = "1770:\src\CompilerPasses\Parser.gbas";
				func5_Match("DELETE", 1769, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1771:\src\CompilerPasses\Parser.gbas";
				local11_VarName_Str_2353 = func14_GetCurrent_Str();
				__debugInfo = "1772:\src\CompilerPasses\Parser.gbas";
				if (((((((local11_VarName_Str_2353) != (global8_Compiler.attr18_currentForEach_Str)) ? 1 : 0)) && ((((local11_VarName_Str_2353) != ("\n")) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "1772:\src\CompilerPasses\Parser.gbas";
					func5_Error((((((((("DELETE, invalid name '") + (local11_VarName_Str_2353))) + ("' expecting '"))) + (global8_Compiler.attr18_currentForEach_Str))) + ("'")), 1771, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1772:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1773:\src\CompilerPasses\Parser.gbas";
				if ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
					__debugInfo = "1773:\src\CompilerPasses\Parser.gbas";
					func7_GetNext();
					__debugInfo = "1773:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1774:\src\CompilerPasses\Parser.gbas";
				return tryClone(func22_CreateDeleteExpression());
				__debugInfo = "1770:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DIMDEL"))) ? 1 : 0)) {
				var local5_Array_2354 = 0;
				__debugInfo = "1776:\src\CompilerPasses\Parser.gbas";
				func5_Match("DIMDEL", 1775, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1777:\src\CompilerPasses\Parser.gbas";
				local5_Array_2354 = func10_Identifier(0);
				__debugInfo = "1778:\src\CompilerPasses\Parser.gbas";
				func5_Match(",", 1777, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1779:\src\CompilerPasses\Parser.gbas";
				return tryClone(func22_CreateDimDelExpression(local5_Array_2354, func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 1778, 0)));
				__debugInfo = "1776:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("RETURN"))) ? 1 : 0)) {
				__debugInfo = "1796:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) {
					var local4_Expr_2355 = 0, local8_datatype_2356 = new type8_Datatype();
					__debugInfo = "1782:\src\CompilerPasses\Parser.gbas";
					func5_Match("RETURN", 1781, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1785:\src\CompilerPasses\Parser.gbas";
					local8_datatype_2356 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
					__debugInfo = "1792:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken("\n")) {
						__debugInfo = "1787:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2355 = func28_CreateDefaultValueExpression(local8_datatype_2356);
						__debugInfo = "1787:\src\CompilerPasses\Parser.gbas";
					} else if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr3_Typ) == (2)) ? 1 : 0)) {
						__debugInfo = "1789:\src\CompilerPasses\Parser.gbas";
						func5_Error("Sub cannot return a value", 1788, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1789:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "1791:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2355 = func14_EnsureDatatype(func10_Expression(0), local8_datatype_2356, 1790, 0);
						__debugInfo = "1791:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "1793:\src\CompilerPasses\Parser.gbas";
					return tryClone(func22_CreateReturnExpression(local4_Expr_2355));
					__debugInfo = "1782:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1795:\src\CompilerPasses\Parser.gbas";
					func5_Error("RETURN have to be in a function or sub.", 1794, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1795:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1796:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("INLINE"))) ? 1 : 0)) {
				__debugInfo = "1798:\src\CompilerPasses\Parser.gbas";
				func5_Error("INLINE/ENDINLINE not supported", 1797, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1798:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("REQUIRE"))) ? 1 : 0)) {
				var local8_Name_Str_2357 = "";
				__debugInfo = "1800:\src\CompilerPasses\Parser.gbas";
				func5_Match("REQUIRE", 1799, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1801:\src\CompilerPasses\Parser.gbas";
				local8_Name_Str_2357 = REPLACE_Str(func14_GetCurrent_Str(), "\"", "");
				__debugInfo = "1802:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "1803:\src\CompilerPasses\Parser.gbas";
				return tryClone(~~(func23_CreateRequireExpression(local8_Name_Str_2357)));
				__debugInfo = "1800:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("EXPORT"))) ? 1 : 0)) {
				var local3_Exp_2358 = new type7_TExport(), local5_Found_2359 = 0;
				__debugInfo = "1805:\src\CompilerPasses\Parser.gbas";
				func5_Match("EXPORT", 1804, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1807:\src\CompilerPasses\Parser.gbas";
				local3_Exp_2358.attr8_Name_Str = REPLACE_Str(func14_GetCurrent_Str(), "\"", "");
				__debugInfo = "1808:\src\CompilerPasses\Parser.gbas";
				local5_Found_2359 = 0;
				__debugInfo = "1816:\src\CompilerPasses\Parser.gbas";
				var forEachSaver19539 = global8_Compiler.attr5_Funcs_ref[0];
				for(var forEachCounter19539 = 0 ; forEachCounter19539 < forEachSaver19539.values.length ; forEachCounter19539++) {
					var local1_F_ref_2360 = forEachSaver19539.values[forEachCounter19539];
				{
						__debugInfo = "1815:\src\CompilerPasses\Parser.gbas";
						if (((((((local1_F_ref_2360[0].attr3_Typ) == (1)) ? 1 : 0)) && ((((local3_Exp_2358.attr8_Name_Str) == (local1_F_ref_2360[0].attr8_Name_Str)) ? 1 : 0))) ? 1 : 0)) {
							__debugInfo = "1812:\src\CompilerPasses\Parser.gbas";
							local1_F_ref_2360[0].attr10_PlzCompile = 1;
							__debugInfo = "1813:\src\CompilerPasses\Parser.gbas";
							local5_Found_2359 = 1;
							__debugInfo = "1814:\src\CompilerPasses\Parser.gbas";
							break;
							__debugInfo = "1812:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1815:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver19539.values[forEachCounter19539] = local1_F_ref_2360;
				
				};
				__debugInfo = "1826:\src\CompilerPasses\Parser.gbas";
				if (((local5_Found_2359) ? 0 : 1)) {
					__debugInfo = "1825:\src\CompilerPasses\Parser.gbas";
					var forEachSaver19579 = global8_Compiler.attr7_Globals;
					for(var forEachCounter19579 = 0 ; forEachCounter19579 < forEachSaver19579.values.length ; forEachCounter19579++) {
						var local1_V_2361 = forEachSaver19579.values[forEachCounter19579];
					{
							__debugInfo = "1824:\src\CompilerPasses\Parser.gbas";
							if (((((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2361).values[tmpPositionCache][0].attr3_Typ) == (2)) ? 1 : 0)) && ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_V_2361).values[tmpPositionCache][0].attr8_Name_Str) == (local3_Exp_2358.attr8_Name_Str)) ? 1 : 0))) ? 1 : 0)) {
								__debugInfo = "1822:\src\CompilerPasses\Parser.gbas";
								local5_Found_2359 = 1;
								__debugInfo = "1823:\src\CompilerPasses\Parser.gbas";
								break;
								__debugInfo = "1822:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1824:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver19579.values[forEachCounter19579] = local1_V_2361;
					
					};
					__debugInfo = "1825:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1828:\src\CompilerPasses\Parser.gbas";
				if (((local5_Found_2359) ? 0 : 1)) {
					__debugInfo = "1828:\src\CompilerPasses\Parser.gbas";
					func5_Error((((("Cannot export undefined function/global '") + (local3_Exp_2358.attr8_Name_Str))) + ("'")), 1827, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1828:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1829:\src\CompilerPasses\Parser.gbas";
				local3_Exp_2358.attr8_Name_Str = REPLACE_Str(local3_Exp_2358.attr8_Name_Str, "$", "_Str");
				__debugInfo = "1830:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "1835:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken(",")) {
					__debugInfo = "1832:\src\CompilerPasses\Parser.gbas";
					func5_Match(",", 1831, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1833:\src\CompilerPasses\Parser.gbas";
					local3_Exp_2358.attr12_RealName_Str = REPLACE_Str(func14_GetCurrent_Str(), "\"", "");
					__debugInfo = "1834:\src\CompilerPasses\Parser.gbas";
					func7_GetNext();
					__debugInfo = "1832:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1837:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global8_Compiler.attr7_Exports, local3_Exp_2358);
				__debugInfo = "1838:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateEmptyExpression());
				__debugInfo = "1805:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("IF"))) ? 1 : 0)) {
				var local4_Cnds_2362 = new OTTArray(0), local4_Scps_2363 = new OTTArray(0), local7_elseScp_2364 = 0;
				__debugInfo = "1841:\src\CompilerPasses\Parser.gbas";
				func5_Match("IF", 1840, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1843:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(local4_Cnds_2362, func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 1842, 0));
				__debugInfo = "1846:\src\CompilerPasses\Parser.gbas";
				if ((((func7_IsToken("THEN")) == (0)) ? 1 : 0)) {
					__debugInfo = "1845:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 1844, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1845:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1848:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(local4_Scps_2363, func5_Scope("ENDIF", -(1)));
				__debugInfo = "1856:\src\CompilerPasses\Parser.gbas";
				while (func7_IsToken("ELSEIF")) {
					__debugInfo = "1852:\src\CompilerPasses\Parser.gbas";
					func5_Match("ELSEIF", 1851, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1853:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local4_Cnds_2362, func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 1852, 0));
					__debugInfo = "1854:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 1853, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1855:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local4_Scps_2363, func5_Scope("ENDIF", -(1)));
					__debugInfo = "1852:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1863:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("ELSE")) {
					__debugInfo = "1858:\src\CompilerPasses\Parser.gbas";
					func5_Match("ELSE", 1857, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1859:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 1858, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1860:\src\CompilerPasses\Parser.gbas";
					local7_elseScp_2364 = func5_Scope("ENDIF", -(1));
					__debugInfo = "1858:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "1862:\src\CompilerPasses\Parser.gbas";
					local7_elseScp_2364 = -(1);
					__debugInfo = "1862:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1865:\src\CompilerPasses\Parser.gbas";
				return tryClone(func18_CreateIfExpression(unref(local4_Cnds_2362), unref(local4_Scps_2363), local7_elseScp_2364));
				__debugInfo = "1841:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("WHILE"))) ? 1 : 0)) {
				var local4_Expr_2365 = 0, local3_Scp_2366 = 0;
				__debugInfo = "1867:\src\CompilerPasses\Parser.gbas";
				func5_Match("WHILE", 1866, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1868:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2365 = func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 1867, 0);
				__debugInfo = "1869:\src\CompilerPasses\Parser.gbas";
				func5_Match("\n", 1868, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1870:\src\CompilerPasses\Parser.gbas";
				local3_Scp_2366 = func5_Scope("WEND", -(1));
				__debugInfo = "1871:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateWhileExpression(local4_Expr_2365, local3_Scp_2366));
				__debugInfo = "1867:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("REPEAT"))) ? 1 : 0)) {
				var local3_Scp_2367 = 0, local4_Expr_2368 = 0;
				__debugInfo = "1873:\src\CompilerPasses\Parser.gbas";
				func5_Match("REPEAT", 1872, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1874:\src\CompilerPasses\Parser.gbas";
				func5_Match("\n", 1873, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1875:\src\CompilerPasses\Parser.gbas";
				local3_Scp_2367 = func5_Scope("UNTIL", -(1));
				__debugInfo = "1876:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2368 = func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 1875, 0);
				__debugInfo = "1877:\src\CompilerPasses\Parser.gbas";
				return tryClone(func22_CreateRepeatExpression(local4_Expr_2368, local3_Scp_2367));
				__debugInfo = "1873:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("FOR"))) ? 1 : 0)) {
				var local8_TmpScope_2369 = 0.0, local4_Expr_2370 = 0, local6_OScope_2380 = 0;
				__debugInfo = "1879:\src\CompilerPasses\Parser.gbas";
				local8_TmpScope_2369 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "1880:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = func21_CreateScopeExpression(~~(3));
				__debugInfo = "1881:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2370 = -(1);
				__debugInfo = "1937:\src\CompilerPasses\Parser.gbas";
				{
					var Error_Str = "";
					__debugInfo = "1939:\src\CompilerPasses\Parser.gbas";
					try {
						var local10_IsImplicit_2371 = 0, local7_varExpr_2372 = 0, local3_Var_2375 = 0.0, local5_hasTo_2376 = 0, local6_toExpr_2377 = 0, local8_stepExpr_2378 = 0;
						__debugInfo = "1883:\src\CompilerPasses\Parser.gbas";
						func5_Match("FOR", 1882, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1886:\src\CompilerPasses\Parser.gbas";
						local10_IsImplicit_2371 = -(1);
						__debugInfo = "1912:\src\CompilerPasses\Parser.gbas";
						if (func12_IsIdentifier(0, 1)) {
							__debugInfo = "1890:\src\CompilerPasses\Parser.gbas";
							local7_varExpr_2372 = func10_Identifier(1);
							__debugInfo = "1890:\src\CompilerPasses\Parser.gbas";
						} else {
							var local4_Vari_2373 = new type14_IdentifierVari(), local4_PDef_2374 = 0;
							__debugInfo = "1892:\src\CompilerPasses\Parser.gbas";
							local10_IsImplicit_2371 = 1;
							__debugInfo = "1895:\src\CompilerPasses\Parser.gbas";
							local4_Vari_2373 = func7_VariDef(0).clone(/* In Assign */);
							__debugInfo = "1896:\src\CompilerPasses\Parser.gbas";
							local4_Vari_2373.attr3_Typ = ~~(1);
							__debugInfo = "1898:\src\CompilerPasses\Parser.gbas";
							local4_PDef_2374 = -(1);
							__debugInfo = "1902:\src\CompilerPasses\Parser.gbas";
							if ((((local4_Vari_2373.attr6_PreDef) != (-(1))) ? 1 : 0)) {
								__debugInfo = "1900:\src\CompilerPasses\Parser.gbas";
								local4_PDef_2374 = local4_Vari_2373.attr6_PreDef;
								__debugInfo = "1901:\src\CompilerPasses\Parser.gbas";
								local4_Vari_2373.attr6_PreDef = -(1);
								__debugInfo = "1900:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1903:\src\CompilerPasses\Parser.gbas";
							func11_AddVariable(local4_Vari_2373, 1);
							__debugInfo = "1904:\src\CompilerPasses\Parser.gbas";
							local10_IsImplicit_2371 = ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1));
							__debugInfo = "1907:\src\CompilerPasses\Parser.gbas";
							DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
							__debugInfo = "1911:\src\CompilerPasses\Parser.gbas";
							if ((((local4_PDef_2374) != (-(1))) ? 1 : 0)) {
								__debugInfo = "1910:\src\CompilerPasses\Parser.gbas";
								local7_varExpr_2372 = func22_CreateAssignExpression(func24_CreateVariableExpression(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1))), local4_PDef_2374);
								__debugInfo = "1910:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "1892:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1913:\src\CompilerPasses\Parser.gbas";
						if ((((global5_Exprs_ref[0].arrAccess(local7_varExpr_2372).values[tmpPositionCache][0].attr3_Typ) != (10)) ? 1 : 0)) {
							__debugInfo = "1913:\src\CompilerPasses\Parser.gbas";
							func5_Error("FOR, variable needs assignment.", 1912, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1913:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1914:\src\CompilerPasses\Parser.gbas";
						local3_Var_2375 = func11_GetVariable(global5_Exprs_ref[0].arrAccess(local7_varExpr_2372).values[tmpPositionCache][0].attr4_vari, 1);
						__debugInfo = "1924:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("TO")) {
							__debugInfo = "1917:\src\CompilerPasses\Parser.gbas";
							local5_hasTo_2376 = 1;
							__debugInfo = "1918:\src\CompilerPasses\Parser.gbas";
							func5_Match("TO", 1917, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1917:\src\CompilerPasses\Parser.gbas";
						} else if (func7_IsToken("UNTIL")) {
							__debugInfo = "1920:\src\CompilerPasses\Parser.gbas";
							local5_hasTo_2376 = 0;
							__debugInfo = "1921:\src\CompilerPasses\Parser.gbas";
							func5_Match("UNTIL", 1920, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1920:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "1923:\src\CompilerPasses\Parser.gbas";
							func5_Error("FOR needs TO or UNTIL!", 1922, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1923:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1925:\src\CompilerPasses\Parser.gbas";
						local6_toExpr_2377 = func14_EnsureDatatype(func10_Expression(0), global8_Compiler.attr5_Varis_ref[0].arrAccess(~~(local3_Var_2375)).values[tmpPositionCache][0].attr8_datatype, 1924, 0);
						__debugInfo = "1926:\src\CompilerPasses\Parser.gbas";
						local8_stepExpr_2378 = func14_EnsureDatatype(func19_CreateIntExpression(1), global8_Compiler.attr5_Varis_ref[0].arrAccess(~~(local3_Var_2375)).values[tmpPositionCache][0].attr8_datatype, 1925, 0);
						__debugInfo = "1930:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("STEP")) {
							__debugInfo = "1928:\src\CompilerPasses\Parser.gbas";
							func5_Match("STEP", 1927, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1929:\src\CompilerPasses\Parser.gbas";
							local8_stepExpr_2378 = func14_EnsureDatatype(func10_Expression(0), global8_Compiler.attr5_Varis_ref[0].arrAccess(~~(local3_Var_2375)).values[tmpPositionCache][0].attr8_datatype, 1928, 0);
							__debugInfo = "1928:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1931:\src\CompilerPasses\Parser.gbas";
						func5_Match("\n", 1930, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1934:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2370 = func19_CreateForExpression(local7_varExpr_2372, local6_toExpr_2377, local8_stepExpr_2378, local5_hasTo_2376, func5_Scope("NEXT", -(1)));
						__debugInfo = "1936:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local4_Expr_2370);
						__debugInfo = "1883:\src\CompilerPasses\Parser.gbas";
					} catch (Error_Str) {
						if (Error_Str instanceof OTTException) Error_Str = Error_Str.getText(); else throwError(Error_Str);{
							__debugInfo = "1938:\src\CompilerPasses\Parser.gbas";
							func8_FixError();
							__debugInfo = "1938:\src\CompilerPasses\Parser.gbas";
						}
					};
					__debugInfo = "1939:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1940:\src\CompilerPasses\Parser.gbas";
				local6_OScope_2380 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "1941:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = ~~(local8_TmpScope_2369);
				__debugInfo = "1942:\src\CompilerPasses\Parser.gbas";
				return tryClone(local6_OScope_2380);
				__debugInfo = "1879:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("FOREACH"))) ? 1 : 0)) {
				var local8_TmpScope_2381 = 0.0, local14_TmpForEach_Str_2382 = "", local4_Expr_2383 = 0;
				__debugInfo = "1944:\src\CompilerPasses\Parser.gbas";
				local8_TmpScope_2381 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "1945:\src\CompilerPasses\Parser.gbas";
				local14_TmpForEach_Str_2382 = global8_Compiler.attr18_currentForEach_Str;
				__debugInfo = "1946:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = func21_CreateScopeExpression(~~(3));
				__debugInfo = "1947:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2383 = -(1);
				__debugInfo = "1986:\src\CompilerPasses\Parser.gbas";
				{
					var Error_Str = "";
					__debugInfo = "1988:\src\CompilerPasses\Parser.gbas";
					try {
						var local7_varExpr_2384 = 0, local4_Vari_2385 = new type14_IdentifierVari(), local6_InExpr_2386 = 0, local3_var_2387 = 0;
						__debugInfo = "1949:\src\CompilerPasses\Parser.gbas";
						func5_Match("FOREACH", 1948, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1959:\src\CompilerPasses\Parser.gbas";
						local4_Vari_2385 = func7_VariDef(0).clone(/* In Assign */);
						__debugInfo = "1960:\src\CompilerPasses\Parser.gbas";
						local4_Vari_2385.attr3_Typ = ~~(1);
						__debugInfo = "1965:\src\CompilerPasses\Parser.gbas";
						if ((((local4_Vari_2385.attr6_PreDef) != (-(1))) ? 1 : 0)) {
							__debugInfo = "1964:\src\CompilerPasses\Parser.gbas";
							func5_Error("No default value, in FOREACH", 1963, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1964:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1966:\src\CompilerPasses\Parser.gbas";
						func11_AddVariable(local4_Vari_2385, 1);
						__debugInfo = "1967:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
						__debugInfo = "1968:\src\CompilerPasses\Parser.gbas";
						local7_varExpr_2384 = func24_CreateVariableExpression(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
						__debugInfo = "1970:\src\CompilerPasses\Parser.gbas";
						global8_Compiler.attr18_currentForEach_Str = global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local7_varExpr_2384, 1)).values[tmpPositionCache][0].attr8_Name_Str;
						__debugInfo = "1971:\src\CompilerPasses\Parser.gbas";
						func5_Match("IN", 1970, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1972:\src\CompilerPasses\Parser.gbas";
						local6_InExpr_2386 = func10_Identifier(0);
						__debugInfo = "1974:\src\CompilerPasses\Parser.gbas";
						if ((((global5_Exprs_ref[0].arrAccess(local6_InExpr_2386).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) == (0)) ? 1 : 0)) {
							__debugInfo = "1974:\src\CompilerPasses\Parser.gbas";
							func5_Error("Expecting Array", 1973, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "1974:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "1976:\src\CompilerPasses\Parser.gbas";
						global5_Exprs_ref[0].arrAccess(local7_varExpr_2384).values[tmpPositionCache][0].attr8_datatype = global5_Exprs_ref[0].arrAccess(local6_InExpr_2386).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
						__debugInfo = "1977:\src\CompilerPasses\Parser.gbas";
						global5_Exprs_ref[0].arrAccess(local7_varExpr_2384).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0] = 0;
						__debugInfo = "1979:\src\CompilerPasses\Parser.gbas";
						local3_var_2387 = func11_GetVariable(local7_varExpr_2384, 1);
						__debugInfo = "1980:\src\CompilerPasses\Parser.gbas";
						global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_var_2387).values[tmpPositionCache][0].attr8_datatype = global5_Exprs_ref[0].arrAccess(local6_InExpr_2386).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
						__debugInfo = "1981:\src\CompilerPasses\Parser.gbas";
						global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_var_2387).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0] = 0;
						__debugInfo = "1982:\src\CompilerPasses\Parser.gbas";
						global8_Compiler.attr5_Varis_ref[0].arrAccess(local3_var_2387).values[tmpPositionCache][0].attr3_ref = global8_Compiler.attr5_Varis_ref[0].arrAccess(func11_GetVariable(local6_InExpr_2386, 1)).values[tmpPositionCache][0].attr3_ref;
						__debugInfo = "1984:\src\CompilerPasses\Parser.gbas";
						func5_Match("\n", 1983, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "1985:\src\CompilerPasses\Parser.gbas";
						local4_Expr_2383 = func23_CreateForEachExpression(local7_varExpr_2384, local6_InExpr_2386, func5_Scope("NEXT", -(1)));
						__debugInfo = "1949:\src\CompilerPasses\Parser.gbas";
					} catch (Error_Str) {
						if (Error_Str instanceof OTTException) Error_Str = Error_Str.getText(); else throwError(Error_Str);{
							__debugInfo = "1987:\src\CompilerPasses\Parser.gbas";
							func8_FixError();
							__debugInfo = "1987:\src\CompilerPasses\Parser.gbas";
						}
					};
					__debugInfo = "1988:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1989:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = ~~(local8_TmpScope_2381);
				__debugInfo = "1990:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr18_currentForEach_Str = local14_TmpForEach_Str_2382;
				__debugInfo = "1991:\src\CompilerPasses\Parser.gbas";
				return tryClone(local4_Expr_2383);
				__debugInfo = "1944:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("BREAK"))) ? 1 : 0)) {
				__debugInfo = "1993:\src\CompilerPasses\Parser.gbas";
				func5_Match("BREAK", 1992, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1994:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr6_inLoop) == (0)) ? 1 : 0)) {
					__debugInfo = "1994:\src\CompilerPasses\Parser.gbas";
					func5_Error("BREAK not inside loop", 1993, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1994:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1995:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateBreakExpression());
				__debugInfo = "1993:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("CONTINUE"))) ? 1 : 0)) {
				__debugInfo = "1997:\src\CompilerPasses\Parser.gbas";
				func5_Match("CONTINUE", 1996, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "1998:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr6_inLoop) == (0)) ? 1 : 0)) {
					__debugInfo = "1998:\src\CompilerPasses\Parser.gbas";
					func5_Error("CONTINUE not inside loop", 1997, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "1998:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "1999:\src\CompilerPasses\Parser.gbas";
				return tryClone(func24_CreateContinueExpression());
				__debugInfo = "1997:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("TRY"))) ? 1 : 0)) {
				var local6_tryScp_2389 = 0, local4_Vari_2390 = new type14_IdentifierVari(), local2_id_2391 = 0.0, local7_myScope_2392 = 0, local8_TmpScope_2393 = 0.0;
				__debugInfo = "2001:\src\CompilerPasses\Parser.gbas";
				func5_Match("TRY", 2000, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2002:\src\CompilerPasses\Parser.gbas";
				func5_Match("\n", 2001, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2003:\src\CompilerPasses\Parser.gbas";
				local6_tryScp_2389 = func5_Scope("CATCH", -(1));
				__debugInfo = "2005:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2390 = func7_VariDef(0).clone(/* In Assign */);
				__debugInfo = "2006:\src\CompilerPasses\Parser.gbas";
				if ((((local4_Vari_2390.attr8_datatype.attr8_Name_Str_ref[0]) != ("string")) ? 1 : 0)) {
					__debugInfo = "2006:\src\CompilerPasses\Parser.gbas";
					func5_Error("Catch variable must be string", 2005, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2006:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2007:\src\CompilerPasses\Parser.gbas";
				if (local4_Vari_2390.attr8_datatype.attr7_IsArray_ref[0]) {
					__debugInfo = "2007:\src\CompilerPasses\Parser.gbas";
					func5_Error("Catch variable must be non array", 2006, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2007:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2008:\src\CompilerPasses\Parser.gbas";
				local2_id_2391 = BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0);
				__debugInfo = "2009:\src\CompilerPasses\Parser.gbas";
				func11_AddVariable(local4_Vari_2390, 0);
				__debugInfo = "2010:\src\CompilerPasses\Parser.gbas";
				local7_myScope_2392 = -(1);
				__debugInfo = "2012:\src\CompilerPasses\Parser.gbas";
				local8_TmpScope_2393 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "2013:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = func21_CreateScopeExpression(~~(1));
				__debugInfo = "2024:\src\CompilerPasses\Parser.gbas";
				{
					var Error_Str = "";
					__debugInfo = "2026:\src\CompilerPasses\Parser.gbas";
					try {
						var local7_ctchScp_2394 = 0, local1_e_2395 = 0;
						__debugInfo = "2015:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ~~(local2_id_2391));
						__debugInfo = "2017:\src\CompilerPasses\Parser.gbas";
						func5_Match("\n", 2016, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "2018:\src\CompilerPasses\Parser.gbas";
						local7_ctchScp_2394 = func5_Scope("FINALLY", -(1));
						__debugInfo = "2020:\src\CompilerPasses\Parser.gbas";
						local1_e_2395 = func19_CreateTryExpression(local6_tryScp_2389, local7_ctchScp_2394, ~~(local2_id_2391));
						__debugInfo = "2021:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local1_e_2395);
						__debugInfo = "2023:\src\CompilerPasses\Parser.gbas";
						local7_myScope_2392 = global8_Compiler.attr12_CurrentScope;
						__debugInfo = "2015:\src\CompilerPasses\Parser.gbas";
					} catch (Error_Str) {
						if (Error_Str instanceof OTTException) Error_Str = Error_Str.getText(); else throwError(Error_Str);{
							__debugInfo = "2025:\src\CompilerPasses\Parser.gbas";
							func8_FixError();
							__debugInfo = "2025:\src\CompilerPasses\Parser.gbas";
						}
					};
					__debugInfo = "2026:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2027:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = ~~(local8_TmpScope_2393);
				__debugInfo = "2029:\src\CompilerPasses\Parser.gbas";
				return tryClone(local7_myScope_2392);
				__debugInfo = "2001:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("THROW"))) ? 1 : 0)) {
				__debugInfo = "2031:\src\CompilerPasses\Parser.gbas";
				func5_Match("THROW", 2030, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2032:\src\CompilerPasses\Parser.gbas";
				return tryClone(func21_CreateThrowExpression(func14_EnsureDatatype(func10_Expression(0), global11_strDatatype, 2031, 0)));
				__debugInfo = "2031:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("SELECT"))) ? 1 : 0)) {
				var local4_Vari_2398 = new type14_IdentifierVari(), local5_Cond1_2399 = 0, local8_datatype_2400 = new type8_Datatype(), local5_Conds_2401 = new OTTArray(0), local4_Scps_2402 = new OTTArray(0), local7_elseScp_2403 = 0, local8_TmpScope_2404 = 0.0, local8_VariExpr_2405 = 0, local1_e_2406 = 0, local7_myScope_2412 = 0;
				__debugInfo = "2035:\src\CompilerPasses\Parser.gbas";
				static12_Keyword_SelectHelper+=1;
				__debugInfo = "2037:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2398.attr8_Name_Str = (((("__SelectHelper") + (CAST2STRING(static12_Keyword_SelectHelper)))) + ("_"));
				__debugInfo = "2038:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2398.attr3_Typ = ~~(1);
				__debugInfo = "2041:\src\CompilerPasses\Parser.gbas";
				func5_Match("SELECT", 2040, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2043:\src\CompilerPasses\Parser.gbas";
				local5_Cond1_2399 = func10_Expression(0);
				__debugInfo = "2045:\src\CompilerPasses\Parser.gbas";
				local8_datatype_2400 = global5_Exprs_ref[0].arrAccess(local5_Cond1_2399).values[tmpPositionCache][0].attr8_datatype.clone(/* In Assign */);
				__debugInfo = "2046:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2398.attr8_datatype = local8_datatype_2400.clone(/* In Assign */);
				__debugInfo = "2050:\src\CompilerPasses\Parser.gbas";
				local7_elseScp_2403 = -(1);
				__debugInfo = "2054:\src\CompilerPasses\Parser.gbas";
				func11_AddVariable(local4_Vari_2398, 0);
				__debugInfo = "2055:\src\CompilerPasses\Parser.gbas";
				local8_TmpScope_2404 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "2056:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = func21_CreateScopeExpression(~~(1));
				__debugInfo = "2059:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Varis, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
				__debugInfo = "2060:\src\CompilerPasses\Parser.gbas";
				local8_VariExpr_2405 = func24_CreateVariableExpression(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
				__debugInfo = "2061:\src\CompilerPasses\Parser.gbas";
				local1_e_2406 = func22_CreateAssignExpression(local8_VariExpr_2405, local5_Cond1_2399);
				__debugInfo = "2062:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local1_e_2406);
				__debugInfo = "2063:\src\CompilerPasses\Parser.gbas";
				local5_Cond1_2399 = local8_VariExpr_2405;
				__debugInfo = "2065:\src\CompilerPasses\Parser.gbas";
				func5_Match("\n", 2064, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2102:\src\CompilerPasses\Parser.gbas";
				while (func7_IsToken("CASE")) {
					var local5_Cond2_2407 = 0;
					__debugInfo = "2067:\src\CompilerPasses\Parser.gbas";
					func5_Match("CASE", 2066, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2068:\src\CompilerPasses\Parser.gbas";
					local5_Cond2_2407 = -(1);
					__debugInfo = "2097:\src\CompilerPasses\Parser.gbas";
					do {
						var local2_Op_2408 = 0.0, local5_Expr1_2409 = 0, local5_Expr2_2410 = 0, local7_tmpCond_2411 = 0;
						__debugInfo = "2070:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							__debugInfo = "2070:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2069, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2070:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2072:\src\CompilerPasses\Parser.gbas";
						local2_Op_2408 = func14_SearchOperator("=");
						__debugInfo = "2076:\src\CompilerPasses\Parser.gbas";
						if (func10_IsOperator()) {
							__debugInfo = "2074:\src\CompilerPasses\Parser.gbas";
							local2_Op_2408 = func14_SearchOperator(func14_GetCurrent_Str());
							__debugInfo = "2075:\src\CompilerPasses\Parser.gbas";
							func7_GetNext();
							__debugInfo = "2074:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2077:\src\CompilerPasses\Parser.gbas";
						local5_Expr1_2409 = -(1);
						__debugInfo = "2078:\src\CompilerPasses\Parser.gbas";
						local5_Expr2_2410 = -(1);
						__debugInfo = "2080:\src\CompilerPasses\Parser.gbas";
						local5_Expr1_2409 = func14_EnsureDatatype(func10_Expression(0), local8_datatype_2400, 2079, 0);
						__debugInfo = "2091:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken("TO")) {
							__debugInfo = "2082:\src\CompilerPasses\Parser.gbas";
							func5_Match("TO", 2081, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2083:\src\CompilerPasses\Parser.gbas";
							local5_Expr2_2410 = func14_EnsureDatatype(func10_Expression(0), local8_datatype_2400, 2082, 0);
							__debugInfo = "2085:\src\CompilerPasses\Parser.gbas";
							local5_Expr1_2409 = func24_CreateOperatorExpression(unref(global9_Operators_ref[0].arrAccess(func14_SearchOperator(">=")).values[tmpPositionCache][0]), local5_Cond1_2399, local5_Expr1_2409);
							__debugInfo = "2086:\src\CompilerPasses\Parser.gbas";
							local5_Expr2_2410 = func24_CreateOperatorExpression(unref(global9_Operators_ref[0].arrAccess(func14_SearchOperator("<=")).values[tmpPositionCache][0]), local5_Cond1_2399, local5_Expr2_2410);
							__debugInfo = "2088:\src\CompilerPasses\Parser.gbas";
							local7_tmpCond_2411 = func24_CreateOperatorExpression(unref(global9_Operators_ref[0].arrAccess(func14_SearchOperator("AND")).values[tmpPositionCache][0]), local5_Expr1_2409, local5_Expr2_2410);
							__debugInfo = "2082:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2090:\src\CompilerPasses\Parser.gbas";
							local7_tmpCond_2411 = func24_CreateOperatorExpression(unref(global9_Operators_ref[0].arrAccess(~~(local2_Op_2408)).values[tmpPositionCache][0]), local5_Cond1_2399, local5_Expr1_2409);
							__debugInfo = "2090:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2096:\src\CompilerPasses\Parser.gbas";
						if ((((local5_Cond2_2407) == (-(1))) ? 1 : 0)) {
							__debugInfo = "2093:\src\CompilerPasses\Parser.gbas";
							local5_Cond2_2407 = local7_tmpCond_2411;
							__debugInfo = "2093:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2095:\src\CompilerPasses\Parser.gbas";
							local5_Cond2_2407 = func24_CreateOperatorExpression(unref(global9_Operators_ref[0].arrAccess(func14_SearchOperator("OR")).values[tmpPositionCache][0]), local5_Cond2_2407, local7_tmpCond_2411);
							__debugInfo = "2095:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2070:\src\CompilerPasses\Parser.gbas";
					} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
					__debugInfo = "2099:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 2098, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2100:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local5_Conds_2401, local5_Cond2_2407);
					__debugInfo = "2101:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local4_Scps_2402, func5_Scope("ENDSELECT", -(1)));
					__debugInfo = "2067:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2107:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken("DEFAULT")) {
					__debugInfo = "2104:\src\CompilerPasses\Parser.gbas";
					func5_Match("DEFAULT", 2103, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2105:\src\CompilerPasses\Parser.gbas";
					func5_Match("\n", 2104, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2106:\src\CompilerPasses\Parser.gbas";
					local7_elseScp_2403 = func5_Scope("ENDSELECT", -(1));
					__debugInfo = "2104:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2110:\src\CompilerPasses\Parser.gbas";
				if (((((((local7_elseScp_2403) == (-(1))) ? 1 : 0)) && ((((BOUNDS(local5_Conds_2401, 0)) == (0)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "2109:\src\CompilerPasses\Parser.gbas";
					func5_Match("ENDSELECT", 2108, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2109:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2112:\src\CompilerPasses\Parser.gbas";
				local1_e_2406 = func18_CreateIfExpression(unref(local5_Conds_2401), unref(local4_Scps_2402), local7_elseScp_2403);
				__debugInfo = "2113:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global5_Exprs_ref[0].arrAccess(global8_Compiler.attr12_CurrentScope).values[tmpPositionCache][0].attr5_Exprs, local1_e_2406);
				__debugInfo = "2114:\src\CompilerPasses\Parser.gbas";
				local7_myScope_2412 = global8_Compiler.attr12_CurrentScope;
				__debugInfo = "2115:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr12_CurrentScope = ~~(local8_TmpScope_2404);
				__debugInfo = "2116:\src\CompilerPasses\Parser.gbas";
				return tryClone(local7_myScope_2412);
				__debugInfo = "2035:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("STARTDATA"))) ? 1 : 0)) {
				__debugInfo = "2118:\src\CompilerPasses\Parser.gbas";
				func5_Match("STARTDATA", 2117, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2119:\src\CompilerPasses\Parser.gbas";
				func10_SkipTokens("STARTDATA", "ENDDATA", func14_GetCurrent_Str());
				__debugInfo = "2118:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("RESTORE"))) ? 1 : 0)) {
				var local8_Name_Str_2413 = "";
				__debugInfo = "2121:\src\CompilerPasses\Parser.gbas";
				func5_Match("RESTORE", 2120, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2122:\src\CompilerPasses\Parser.gbas";
				local8_Name_Str_2413 = func14_GetCurrent_Str();
				__debugInfo = "2123:\src\CompilerPasses\Parser.gbas";
				func5_Match(local8_Name_Str_2413, 2122, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2128:\src\CompilerPasses\Parser.gbas";
				var forEachSaver20856 = global8_Compiler.attr10_DataBlocks;
				for(var forEachCounter20856 = 0 ; forEachCounter20856 < forEachSaver20856.values.length ; forEachCounter20856++) {
					var local5_block_2414 = forEachSaver20856.values[forEachCounter20856];
				{
						__debugInfo = "2127:\src\CompilerPasses\Parser.gbas";
						if ((((local5_block_2414.attr8_Name_Str) == (local8_Name_Str_2413)) ? 1 : 0)) {
							__debugInfo = "2126:\src\CompilerPasses\Parser.gbas";
							return tryClone(func23_CreateRestoreExpression(local8_Name_Str_2413));
							__debugInfo = "2126:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2127:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver20856.values[forEachCounter20856] = local5_block_2414;
				
				};
				__debugInfo = "2129:\src\CompilerPasses\Parser.gbas";
				func5_Error((((("RESTORE label '") + (local8_Name_Str_2413))) + ("' unknown.")), 2128, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2121:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("READ"))) ? 1 : 0)) {
				var local5_Reads_2415 = new OTTArray(0);
				__debugInfo = "2131:\src\CompilerPasses\Parser.gbas";
				func5_Match("READ", 2130, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2137:\src\CompilerPasses\Parser.gbas";
				do {
					var local1_e_2416 = 0;
					__debugInfo = "2134:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken(",")) {
						__debugInfo = "2134:\src\CompilerPasses\Parser.gbas";
						func5_Match(",", 2133, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "2134:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2135:\src\CompilerPasses\Parser.gbas";
					local1_e_2416 = func10_Identifier(0);
					__debugInfo = "2136:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(local5_Reads_2415, local1_e_2416);
					__debugInfo = "2134:\src\CompilerPasses\Parser.gbas";
				} while (!((((func7_IsToken(",")) == (0)) ? 1 : 0)));
				__debugInfo = "2139:\src\CompilerPasses\Parser.gbas";
				return tryClone(func20_CreateReadExpression(unref(local5_Reads_2415)));
				__debugInfo = "2131:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("GOTO"))) ? 1 : 0)) {
				var local8_Name_Str_2418 = "", local4_Expr_2419 = 0, local3_Scp_2420 = 0;
				__debugInfo = "2142:\src\CompilerPasses\Parser.gbas";
				func5_Match("GOTO", 2141, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2143:\src\CompilerPasses\Parser.gbas";
				local8_Name_Str_2418 = func14_GetCurrent_Str();
				__debugInfo = "2144:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "2145:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr7_HasGoto = 1;
				__debugInfo = "2149:\src\CompilerPasses\Parser.gbas";
				if (((static7_Keyword_GOTOErr) ? 0 : 1)) {
					__debugInfo = "2147:\src\CompilerPasses\Parser.gbas";
					static7_Keyword_GOTOErr = 1;
					__debugInfo = "2148:\src\CompilerPasses\Parser.gbas";
					func7_Warning("GOTO may cause problems!");
					__debugInfo = "2147:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2151:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2419 = func20_CreateGotoExpression(local8_Name_Str_2418);
				__debugInfo = "2153:\src\CompilerPasses\Parser.gbas";
				local3_Scp_2420 = global8_Compiler.attr14_ImportantScope;
				__debugInfo = "2156:\src\CompilerPasses\Parser.gbas";
				if ((((local3_Scp_2420) == (-(1))) ? 1 : 0)) {
					__debugInfo = "2155:\src\CompilerPasses\Parser.gbas";
					func5_Error("Internal error (GOTO Scp is -1", 2154, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2155:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2158:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global5_Exprs_ref[0].arrAccess(local3_Scp_2420).values[tmpPositionCache][0].attr5_Gotos, local4_Expr_2419);
				__debugInfo = "2159:\src\CompilerPasses\Parser.gbas";
				return tryClone(local4_Expr_2419);
				__debugInfo = "2142:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("INC"))) ? 1 : 0)) {
				var local4_Vari_2421 = 0, local7_AddExpr_2422 = 0;
				__debugInfo = "2161:\src\CompilerPasses\Parser.gbas";
				func5_Match("INC", 2160, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2162:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2421 = func10_Identifier(0);
				__debugInfo = "2163:\src\CompilerPasses\Parser.gbas";
				if (global5_Exprs_ref[0].arrAccess(local4_Vari_2421).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) {
					__debugInfo = "2163:\src\CompilerPasses\Parser.gbas";
					func5_Error("Cannot increment array...", 2162, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2163:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2165:\src\CompilerPasses\Parser.gbas";
				{
					var local17___SelectHelper27__2423 = "";
					__debugInfo = "2165:\src\CompilerPasses\Parser.gbas";
					local17___SelectHelper27__2423 = global5_Exprs_ref[0].arrAccess(local4_Vari_2421).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0];
					__debugInfo = "2189:\src\CompilerPasses\Parser.gbas";
					if ((((local17___SelectHelper27__2423) == ("int")) ? 1 : 0)) {
						__debugInfo = "2172:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							__debugInfo = "2168:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2167, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2169:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 2168, 0);
							__debugInfo = "2168:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2171:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func19_CreateIntExpression(1);
							__debugInfo = "2171:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2172:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper27__2423) == ("float")) ? 1 : 0)) {
						__debugInfo = "2179:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							__debugInfo = "2175:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2174, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2176:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 2175, 0);
							__debugInfo = "2175:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2178:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func21_CreateFloatExpression(1);
							__debugInfo = "2178:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2179:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper27__2423) == ("string")) ? 1 : 0)) {
						__debugInfo = "2186:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							__debugInfo = "2182:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2181, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2183:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func14_EnsureDatatype(func10_Expression(0), global11_strDatatype, 2182, 0);
							__debugInfo = "2182:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2185:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2422 = func19_CreateStrExpression(" ");
							__debugInfo = "2185:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2186:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "2188:\src\CompilerPasses\Parser.gbas";
						func5_Error("Cannot increment type or prototype", 2187, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "2188:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2165:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2190:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateIncExpression(local4_Vari_2421, local7_AddExpr_2422));
				__debugInfo = "2161:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DEC"))) ? 1 : 0)) {
				var local4_Vari_2424 = 0, local7_AddExpr_2425 = 0;
				__debugInfo = "2192:\src\CompilerPasses\Parser.gbas";
				func5_Match("DEC", 2191, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2193:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2424 = func10_Identifier(0);
				__debugInfo = "2195:\src\CompilerPasses\Parser.gbas";
				if (global5_Exprs_ref[0].arrAccess(local4_Vari_2424).values[tmpPositionCache][0].attr8_datatype.attr7_IsArray_ref[0]) {
					__debugInfo = "2195:\src\CompilerPasses\Parser.gbas";
					func5_Error("Cannot decrement array...", 2194, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2195:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2196:\src\CompilerPasses\Parser.gbas";
				{
					var local17___SelectHelper28__2426 = "";
					__debugInfo = "2196:\src\CompilerPasses\Parser.gbas";
					local17___SelectHelper28__2426 = global5_Exprs_ref[0].arrAccess(local4_Vari_2424).values[tmpPositionCache][0].attr8_datatype.attr8_Name_Str_ref[0];
					__debugInfo = "2217:\src\CompilerPasses\Parser.gbas";
					if ((((local17___SelectHelper28__2426) == ("int")) ? 1 : 0)) {
						__debugInfo = "2204:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							var alias2_Op_ref_2427 = [new type8_Operator()];
							__debugInfo = "2199:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2198, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2200:\src\CompilerPasses\Parser.gbas";
							alias2_Op_ref_2427 = global9_Operators_ref[0].arrAccess(func14_SearchOperator("sub")).values[tmpPositionCache] /* ALIAS */;
							__debugInfo = "2201:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2425 = func24_CreateOperatorExpression(unref(alias2_Op_ref_2427[0]), func19_CreateIntExpression(0), func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 2200, 0));
							__debugInfo = "2199:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2203:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2425 = func19_CreateIntExpression(-(1));
							__debugInfo = "2203:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2204:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper28__2426) == ("float")) ? 1 : 0)) {
						__debugInfo = "2212:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(",")) {
							var alias2_Op_ref_2428 = [new type8_Operator()];
							__debugInfo = "2207:\src\CompilerPasses\Parser.gbas";
							func5_Match(",", 2206, "src\CompilerPasses\Parser.gbas");
							__debugInfo = "2208:\src\CompilerPasses\Parser.gbas";
							alias2_Op_ref_2428 = global9_Operators_ref[0].arrAccess(func14_SearchOperator("sub")).values[tmpPositionCache] /* ALIAS */;
							__debugInfo = "2209:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2425 = func24_CreateOperatorExpression(unref(alias2_Op_ref_2428[0]), func21_CreateFloatExpression(0), func14_EnsureDatatype(func10_Expression(0), global13_floatDatatype, 2208, 0));
							__debugInfo = "2207:\src\CompilerPasses\Parser.gbas";
						} else {
							__debugInfo = "2211:\src\CompilerPasses\Parser.gbas";
							local7_AddExpr_2425 = func21_CreateFloatExpression(-(1));
							__debugInfo = "2211:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2212:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper28__2426) == ("string")) ? 1 : 0)) {
						__debugInfo = "2214:\src\CompilerPasses\Parser.gbas";
						func5_Error("Cannot decrement string...", 2213, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "2214:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "2216:\src\CompilerPasses\Parser.gbas";
						func5_Error("Cannot decrement type or prototype", 2215, "src\CompilerPasses\Parser.gbas");
						__debugInfo = "2216:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2196:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2218:\src\CompilerPasses\Parser.gbas";
				return tryClone(func19_CreateIncExpression(local4_Vari_2424, local7_AddExpr_2425));
				__debugInfo = "2192:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("ASSERT"))) ? 1 : 0)) {
				var local4_Expr_2429 = 0;
				__debugInfo = "2220:\src\CompilerPasses\Parser.gbas";
				func5_Match("ASSERT", 2219, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2221:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2429 = func14_EnsureDatatype(func10_Expression(0), global11_intDatatype, 2220, 0);
				__debugInfo = "2225:\src\CompilerPasses\Parser.gbas";
				if (global9_DEBUGMODE) {
					__debugInfo = "2224:\src\CompilerPasses\Parser.gbas";
					return tryClone(func22_CreateAssertExpression(local4_Expr_2429));
					__debugInfo = "2224:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2220:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper24__2320) == (func7_IsToken("DEBUG"))) ? 1 : 0)) {
				var local4_Expr_2430 = 0;
				__debugInfo = "2227:\src\CompilerPasses\Parser.gbas";
				func5_Match("DEBUG", 2226, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2228:\src\CompilerPasses\Parser.gbas";
				local4_Expr_2430 = func14_EnsureDatatype(func10_Expression(0), global11_strDatatype, 2227, 0);
				__debugInfo = "2232:\src\CompilerPasses\Parser.gbas";
				if (global9_DEBUGMODE) {
					__debugInfo = "2231:\src\CompilerPasses\Parser.gbas";
					return tryClone(func27_CreateDebugOutputExpression(local4_Expr_2430));
					__debugInfo = "2231:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2227:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2234:\src\CompilerPasses\Parser.gbas";
				func5_Error("Unexpected keyword", 2233, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2234:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "1537:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2236:\src\CompilerPasses\Parser.gbas";
		return tryClone(func21_CreateEmptyExpression());
		__debugInfo = "2237:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "1537:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_Keyword = window['func7_Keyword'];
window['func14_ImplicitDefine'] = function() {
	stackPush("function: ImplicitDefine", __debugInfo);
	try {
		__debugInfo = "2261:\src\CompilerPasses\Parser.gbas";
		if ((((global6_STRICT) == (0)) ? 1 : 0)) {
			__debugInfo = "2260:\src\CompilerPasses\Parser.gbas";
			if (((func12_IsIdentifier(0, 0)) ? 0 : 1)) {
				var local3_pos_2431 = 0, local4_Vari_2432 = new type14_IdentifierVari();
				__debugInfo = "2244:\src\CompilerPasses\Parser.gbas";
				local3_pos_2431 = global8_Compiler.attr11_currentPosi;
				__debugInfo = "2248:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2432 = func7_VariDef(1).clone(/* In Assign */);
				__debugInfo = "2249:\src\CompilerPasses\Parser.gbas";
				local4_Vari_2432.attr3_Typ = ~~(2);
				__debugInfo = "2250:\src\CompilerPasses\Parser.gbas";
				func11_AddVariable(local4_Vari_2432, 0);
				__debugInfo = "2251:\src\CompilerPasses\Parser.gbas";
				DIMPUSH(global8_Compiler.attr7_Globals, ((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
				__debugInfo = "2252:\src\CompilerPasses\Parser.gbas";
				func7_Warning((((("Implicit variable declaration '") + (local4_Vari_2432.attr8_Name_Str))) + ("'")));
				__debugInfo = "2255:\src\CompilerPasses\Parser.gbas";
				global8_Compiler.attr11_currentPosi = ((local3_pos_2431) - (1));
				__debugInfo = "2256:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "2259:\src\CompilerPasses\Parser.gbas";
				return tryClone(((BOUNDS(global8_Compiler.attr5_Varis_ref[0], 0)) - (1)));
				__debugInfo = "2244:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2260:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2262:\src\CompilerPasses\Parser.gbas";
		return tryClone(-(1));
		__debugInfo = "2263:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2261:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_ImplicitDefine = window['func14_ImplicitDefine'];
window['func9_IsKeyword'] = function() {
	stackPush("function: IsKeyword", __debugInfo);
	try {
		__debugInfo = "2267:\src\CompilerPasses\Parser.gbas";
		return tryClone((global10_KeywordMap).DoesKeyExist(func14_GetCurrent_Str()));
		__debugInfo = "2268:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2267:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func9_IsKeyword = window['func9_IsKeyword'];
window['func12_IsIdentifier'] = function(param9_CheckType, param18_IgnoreImplicitSelf) {
	stackPush("function: IsIdentifier", __debugInfo);
	try {
		var local11_Current_Str_2437 = "", local5_dummy_ref_2438 = [0], local5_Varis_2439 = new OTTArray(0);
		__debugInfo = "2272:\src\CompilerPasses\Parser.gbas";
		if ((((func7_IsToken("GLOBAL")) || (func7_IsToken("LOCAL"))) ? 1 : 0)) {
			__debugInfo = "2272:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "2272:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2284:\src\CompilerPasses\Parser.gbas";
		if ((((func6_IsType("")) && (param9_CheckType)) ? 1 : 0)) {
			var local3_pos_2435 = 0, local3_ret_2436 = 0;
			__debugInfo = "2275:\src\CompilerPasses\Parser.gbas";
			local3_pos_2435 = global8_Compiler.attr11_currentPosi;
			__debugInfo = "2276:\src\CompilerPasses\Parser.gbas";
			func7_GetNext();
			__debugInfo = "2282:\src\CompilerPasses\Parser.gbas";
			if (func7_IsToken("(")) {
				__debugInfo = "2279:\src\CompilerPasses\Parser.gbas";
				local3_ret_2436 = 1;
				__debugInfo = "2279:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2281:\src\CompilerPasses\Parser.gbas";
				local3_ret_2436 = 0;
				__debugInfo = "2281:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2283:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentPosi = local3_pos_2435;
			__debugInfo = "2275:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2286:\src\CompilerPasses\Parser.gbas";
		local11_Current_Str_2437 = func14_GetCurrent_Str();
		__debugInfo = "2294:\src\CompilerPasses\Parser.gbas";
		if ((global8_Compiler.attr11_GlobalFuncs).GetValue(local11_Current_Str_2437, local5_dummy_ref_2438)) {
			__debugInfo = "2294:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "2294:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2297:\src\CompilerPasses\Parser.gbas";
		func8_GetVaris(unref(local5_Varis_2439), -(1), 0);
		__debugInfo = "2297:\src\CompilerPasses\Parser.gbas";
		{
			var local1_i_2440 = 0.0;
			__debugInfo = "2306:\src\CompilerPasses\Parser.gbas";
			for (local1_i_2440 = ((BOUNDS(local5_Varis_2439, 0)) - (1));toCheck(local1_i_2440, 0, -(1));local1_i_2440 += -(1)) {
				__debugInfo = "2305:\src\CompilerPasses\Parser.gbas";
				if ((((func17_CleanVariable_Str(local11_Current_Str_2437)) == (global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Varis_2439.arrAccess(~~(local1_i_2440)).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_Name_Str)) ? 1 : 0)) {
					__debugInfo = "2304:\src\CompilerPasses\Parser.gbas";
					if ((((param18_IgnoreImplicitSelf) && ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local5_Varis_2439.arrAccess(~~(local1_i_2440)).values[tmpPositionCache]).values[tmpPositionCache][0].attr3_Typ) == (3)) ? 1 : 0))) ? 1 : 0)) {
						__debugInfo = "2301:\src\CompilerPasses\Parser.gbas";
						return tryClone(0);
						__debugInfo = "2301:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "2303:\src\CompilerPasses\Parser.gbas";
						return 1;
						__debugInfo = "2303:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2304:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2305:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2306:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2326:\src\CompilerPasses\Parser.gbas";
		if ((((((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) && (((param18_IgnoreImplicitSelf) ? 0 : 1))) ? 1 : 0)) {
			var alias3_Typ_ref_2441 = [new type14_IdentifierType()], local5_myTyp_2442 = 0;
			__debugInfo = "2310:\src\CompilerPasses\Parser.gbas";
			alias3_Typ_ref_2441 = global8_Compiler.attr5_Types_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType).values[tmpPositionCache] /* ALIAS */;
			__debugInfo = "2311:\src\CompilerPasses\Parser.gbas";
			local5_myTyp_2442 = alias3_Typ_ref_2441[0].attr2_ID;
			__debugInfo = "2320:\src\CompilerPasses\Parser.gbas";
			while ((((local5_myTyp_2442) != (-(1))) ? 1 : 0)) {
				__debugInfo = "2317:\src\CompilerPasses\Parser.gbas";
				var forEachSaver21543 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_myTyp_2442).values[tmpPositionCache][0].attr7_Methods;
				for(var forEachCounter21543 = 0 ; forEachCounter21543 < forEachSaver21543.values.length ; forEachCounter21543++) {
					var local1_M_2443 = forEachSaver21543.values[forEachCounter21543];
				{
						__debugInfo = "2316:\src\CompilerPasses\Parser.gbas";
						if (func7_IsToken(global8_Compiler.attr5_Funcs_ref[0].arrAccess(local1_M_2443).values[tmpPositionCache][0].attr8_Name_Str)) {
							__debugInfo = "2315:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2315:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2316:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver21543.values[forEachCounter21543] = local1_M_2443;
				
				};
				__debugInfo = "2319:\src\CompilerPasses\Parser.gbas";
				local5_myTyp_2442 = global8_Compiler.attr5_Types_ref[0].arrAccess(local5_myTyp_2442).values[tmpPositionCache][0].attr9_Extending;
				__debugInfo = "2317:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2325:\src\CompilerPasses\Parser.gbas";
			var forEachSaver21574 = alias3_Typ_ref_2441[0].attr10_Attributes;
			for(var forEachCounter21574 = 0 ; forEachCounter21574 < forEachSaver21574.values.length ; forEachCounter21574++) {
				var local1_A_2444 = forEachSaver21574.values[forEachCounter21574];
			{
					__debugInfo = "2324:\src\CompilerPasses\Parser.gbas";
					if (func7_IsToken(global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_A_2444).values[tmpPositionCache][0].attr8_Name_Str)) {
						__debugInfo = "2323:\src\CompilerPasses\Parser.gbas";
						return 1;
						__debugInfo = "2323:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2324:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver21574.values[forEachCounter21574] = local1_A_2444;
			
			};
			__debugInfo = "2310:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2328:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2329:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2272:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_IsIdentifier = window['func12_IsIdentifier'];
window['func8_IsNumber'] = function() {
	stackPush("function: IsNumber", __debugInfo);
	try {
		__debugInfo = "2332:\src\CompilerPasses\Parser.gbas";
		{
			var local1_i_2445 = 0.0;
			__debugInfo = "2337:\src\CompilerPasses\Parser.gbas";
			for (local1_i_2445 = 0;toCheck(local1_i_2445, (((func14_GetCurrent_Str()).length) - (1)), 1);local1_i_2445 += 1) {
				__debugInfo = "2336:\src\CompilerPasses\Parser.gbas";
				if (((((((ASC(func14_GetCurrent_Str(), ~~(local1_i_2445))) < (48)) ? 1 : 0)) || ((((ASC(func14_GetCurrent_Str(), ~~(local1_i_2445))) > (57)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "2335:\src\CompilerPasses\Parser.gbas";
					return tryClone(0);
					__debugInfo = "2335:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2336:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2337:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2338:\src\CompilerPasses\Parser.gbas";
		return 1;
		__debugInfo = "2339:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2332:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_IsNumber = window['func8_IsNumber'];
window['func8_IsString'] = function() {
	stackPush("function: IsString", __debugInfo);
	try {
		__debugInfo = "2347:\src\CompilerPasses\Parser.gbas";
		if (((((((MID_Str(func14_GetCurrent_Str(), 0, 1)) == ("\"")) ? 1 : 0)) && ((((MID_Str(func14_GetCurrent_Str(), (((func14_GetCurrent_Str()).length) - (1)), 1)) == ("\"")) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "2344:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "2344:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "2346:\src\CompilerPasses\Parser.gbas";
			return tryClone(0);
			__debugInfo = "2346:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2348:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2347:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_IsString = window['func8_IsString'];
window['func6_IsType'] = function(param7_Str_Str) {
	stackPush("function: IsType", __debugInfo);
	try {
		__debugInfo = "2352:\src\CompilerPasses\Parser.gbas";
		if ((((param7_Str_Str) == ("")) ? 1 : 0)) {
			__debugInfo = "2352:\src\CompilerPasses\Parser.gbas";
			param7_Str_Str = func14_GetCurrent_Str();
			__debugInfo = "2352:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2358:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21675 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter21675 = 0 ; forEachCounter21675 < forEachSaver21675.values.length ; forEachCounter21675++) {
			var local3_typ_ref_2447 = forEachSaver21675.values[forEachCounter21675];
		{
				__debugInfo = "2357:\src\CompilerPasses\Parser.gbas";
				if ((((local3_typ_ref_2447[0].attr12_RealName_Str) == (param7_Str_Str)) ? 1 : 0)) {
					__debugInfo = "2355:\src\CompilerPasses\Parser.gbas";
					global8_LastType = local3_typ_ref_2447[0].clone(/* In Assign */);
					__debugInfo = "2356:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2355:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2357:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21675.values[forEachCounter21675] = local3_typ_ref_2447;
		
		};
		__debugInfo = "2359:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2360:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2352:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func6_IsType = window['func6_IsType'];
window['func13_IsVarExisting'] = function(param7_Var_Str) {
	stackPush("function: IsVarExisting", __debugInfo);
	try {
		var local4_Vars_2449 = new OTTArray(0);
		__debugInfo = "2365:\src\CompilerPasses\Parser.gbas";
		func8_GetVaris(unref(local4_Vars_2449), -(1), 0);
		__debugInfo = "2365:\src\CompilerPasses\Parser.gbas";
		{
			var local1_i_2450 = 0.0;
			__debugInfo = "2368:\src\CompilerPasses\Parser.gbas";
			for (local1_i_2450 = ((BOUNDS(local4_Vars_2449, 0)) - (1));toCheck(local1_i_2450, 0, -(1));local1_i_2450 += -(1)) {
				__debugInfo = "2367:\src\CompilerPasses\Parser.gbas";
				if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Vars_2449.arrAccess(~~(local1_i_2450)).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_Name_Str) == (param7_Var_Str)) ? 1 : 0)) {
					__debugInfo = "2367:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2367:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2367:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2368:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2374:\src\CompilerPasses\Parser.gbas";
		return tryClone((global10_KeywordMap).DoesKeyExist(param7_Var_Str));
		__debugInfo = "2375:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2365:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_IsVarExisting = window['func13_IsVarExisting'];
window['func14_IsValidVarName'] = function() {
	stackPush("function: IsValidVarName", __debugInfo);
	try {
		__debugInfo = "2379:\src\CompilerPasses\Parser.gbas";
		if (func9_IsKeyword()) {
			__debugInfo = "2379:\src\CompilerPasses\Parser.gbas";
			func5_Error((((("Invalid identifier name: '") + (func14_GetCurrent_Str()))) + ("' is already a keyword")), 2378, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2379:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2381:\src\CompilerPasses\Parser.gbas";
		if (func8_IsNumber()) {
			__debugInfo = "2381:\src\CompilerPasses\Parser.gbas";
			func5_Error((((("Invalid Identifier name: '") + (func14_GetCurrent_Str()))) + ("' is a number")), 2380, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2381:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2382:\src\CompilerPasses\Parser.gbas";
		if (func8_IsString()) {
			__debugInfo = "2382:\src\CompilerPasses\Parser.gbas";
			func5_Error((((("Invalid identifier name: '") + (func14_GetCurrent_Str()))) + ("' is a string")), 2381, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2382:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2383:\src\CompilerPasses\Parser.gbas";
		if (func10_IsOperator()) {
			__debugInfo = "2383:\src\CompilerPasses\Parser.gbas";
			func5_Error((((("Invalid identifier name: '") + (func14_GetCurrent_Str()))) + ("' is an operator")), 2382, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2383:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2385:\src\CompilerPasses\Parser.gbas";
		return 1;
		__debugInfo = "2386:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2379:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_IsValidVarName = window['func14_IsValidVarName'];
window['func14_IsFuncExisting'] = function(param8_func_Str, param10_IsCallback) {
	stackPush("function: IsFuncExisting", __debugInfo);
	try {
		__debugInfo = "2392:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21800 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter21800 = 0 ; forEachCounter21800 < forEachSaver21800.values.length ; forEachCounter21800++) {
			var local1_T_ref_2453 = forEachSaver21800.values[forEachCounter21800];
		{
				__debugInfo = "2391:\src\CompilerPasses\Parser.gbas";
				if ((((local1_T_ref_2453[0].attr8_Name_Str) == (param8_func_Str)) ? 1 : 0)) {
					__debugInfo = "2391:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2391:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2391:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21800.values[forEachCounter21800] = local1_T_ref_2453;
		
		};
		__debugInfo = "2394:\src\CompilerPasses\Parser.gbas";
		if ((global10_KeywordMap).DoesKeyExist(param8_func_Str)) {
			__debugInfo = "2394:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "2394:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2398:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21844 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter21844 = 0 ; forEachCounter21844 < forEachSaver21844.values.length ; forEachCounter21844++) {
			var local1_F_ref_2454 = forEachSaver21844.values[forEachCounter21844];
		{
				__debugInfo = "2397:\src\CompilerPasses\Parser.gbas";
				if ((((((((((param8_func_Str) == (local1_F_ref_2454[0].attr8_Name_Str)) ? 1 : 0)) && (((((((local1_F_ref_2454[0].attr3_Typ) == (2)) ? 1 : 0)) || ((((local1_F_ref_2454[0].attr3_Typ) == (1)) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) && ((((local1_F_ref_2454[0].attr10_IsCallback) == (param10_IsCallback)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "2397:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2397:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2397:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21844.values[forEachCounter21844] = local1_F_ref_2454;
		
		};
		__debugInfo = "2400:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2401:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2392:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_IsFuncExisting = window['func14_IsFuncExisting'];
window['func10_IsOperator'] = function() {
	stackPush("function: IsOperator", __debugInfo);
	try {
		__debugInfo = "2407:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21865 = global9_Operators_ref[0];
		for(var forEachCounter21865 = 0 ; forEachCounter21865 < forEachSaver21865.values.length ; forEachCounter21865++) {
			var local2_Op_ref_2455 = forEachSaver21865.values[forEachCounter21865];
		{
				__debugInfo = "2406:\src\CompilerPasses\Parser.gbas";
				if (func7_IsToken(local2_Op_ref_2455[0].attr7_Sym_Str)) {
					__debugInfo = "2406:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2406:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2406:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21865.values[forEachCounter21865] = local2_Op_ref_2455;
		
		};
		__debugInfo = "2408:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2409:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2407:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_IsOperator = window['func10_IsOperator'];
window['func15_IsValidDatatype'] = function() {
	stackPush("function: IsValidDatatype", __debugInfo);
	try {
		__debugInfo = "2414:\src\CompilerPasses\Parser.gbas";
		if (func6_IsType("")) {
			__debugInfo = "2414:\src\CompilerPasses\Parser.gbas";
			return 1;
			__debugInfo = "2414:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2421:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21900 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter21900 = 0 ; forEachCounter21900 < forEachSaver21900.values.length ; forEachCounter21900++) {
			var local4_func_ref_2456 = forEachSaver21900.values[forEachCounter21900];
		{
				__debugInfo = "2420:\src\CompilerPasses\Parser.gbas";
				if (((((((local4_func_ref_2456[0].attr3_Typ) == (4)) ? 1 : 0)) && (func7_IsToken(local4_func_ref_2456[0].attr8_Name_Str))) ? 1 : 0)) {
					__debugInfo = "2419:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2419:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2420:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21900.values[forEachCounter21900] = local4_func_ref_2456;
		
		};
		__debugInfo = "2425:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21914 = global8_Compiler.attr5_Types_ref[0];
		for(var forEachCounter21914 = 0 ; forEachCounter21914 < forEachSaver21914.values.length ; forEachCounter21914++) {
			var local3_typ_ref_2457 = forEachSaver21914.values[forEachCounter21914];
		{
				__debugInfo = "2424:\src\CompilerPasses\Parser.gbas";
				STDOUT(((local3_typ_ref_2457[0].attr12_RealName_Str) + ("\n")));
				__debugInfo = "2424:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21914.values[forEachCounter21914] = local3_typ_ref_2457;
		
		};
		__debugInfo = "2426:\src\CompilerPasses\Parser.gbas";
		func5_Error((("Unknown datatype: ") + (func14_GetCurrent_Str())), 2425, "src\CompilerPasses\Parser.gbas");
		__debugInfo = "2427:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2414:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func15_IsValidDatatype = window['func15_IsValidDatatype'];
window['func8_IsDefine'] = function(param7_Def_Str) {
	stackPush("function: IsDefine", __debugInfo);
	try {
		__debugInfo = "2432:\src\CompilerPasses\Parser.gbas";
		if ((((param7_Def_Str) == ("")) ? 1 : 0)) {
			__debugInfo = "2432:\src\CompilerPasses\Parser.gbas";
			param7_Def_Str = func14_GetCurrent_Str();
			__debugInfo = "2432:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2438:\src\CompilerPasses\Parser.gbas";
		var forEachSaver21951 = global7_Defines;
		for(var forEachCounter21951 = 0 ; forEachCounter21951 < forEachSaver21951.values.length ; forEachCounter21951++) {
			var local3_Def_2459 = forEachSaver21951.values[forEachCounter21951];
		{
				__debugInfo = "2437:\src\CompilerPasses\Parser.gbas";
				if ((((local3_Def_2459.attr7_Key_Str) == (param7_Def_Str)) ? 1 : 0)) {
					__debugInfo = "2435:\src\CompilerPasses\Parser.gbas";
					global10_LastDefine = local3_Def_2459.clone(/* In Assign */);
					__debugInfo = "2436:\src\CompilerPasses\Parser.gbas";
					return 1;
					__debugInfo = "2435:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2437:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver21951.values[forEachCounter21951] = local3_Def_2459;
		
		};
		__debugInfo = "2439:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2440:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2432:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_IsDefine = window['func8_IsDefine'];
window['func8_GetVaris'] = function(param5_Varis, param3_Scp, param9_PreferVar) {
	stackPush("function: GetVaris", __debugInfo);
	try {
		__debugInfo = "2444:\src\CompilerPasses\Parser.gbas";
		if ((((param3_Scp) == (-(1))) ? 1 : 0)) {
			__debugInfo = "2444:\src\CompilerPasses\Parser.gbas";
			param3_Scp = global8_Compiler.attr12_CurrentScope;
			__debugInfo = "2444:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2451:\src\CompilerPasses\Parser.gbas";
		if (((((((param9_PreferVar) == (-(1))) ? 1 : 0)) && ((((BOUNDS(param5_Varis, 0)) == (0)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "2450:\src\CompilerPasses\Parser.gbas";
			var forEachSaver21998 = global8_Compiler.attr7_Globals;
			for(var forEachCounter21998 = 0 ; forEachCounter21998 < forEachSaver21998.values.length ; forEachCounter21998++) {
				var local4_Vari_2463 = forEachSaver21998.values[forEachCounter21998];
			{
					__debugInfo = "2449:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(param5_Varis, local4_Vari_2463);
					__debugInfo = "2449:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver21998.values[forEachCounter21998] = local4_Vari_2463;
			
			};
			__debugInfo = "2450:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2464:\src\CompilerPasses\Parser.gbas";
		if ((((param3_Scp) != (-(1))) ? 1 : 0)) {
			__debugInfo = "2456:\src\CompilerPasses\Parser.gbas";
			var forEachSaver22022 = global5_Exprs_ref[0].arrAccess(~~(param3_Scp)).values[tmpPositionCache][0].attr5_Varis;
			for(var forEachCounter22022 = 0 ; forEachCounter22022 < forEachSaver22022.values.length ; forEachCounter22022++) {
				var local4_Vari_2464 = forEachSaver22022.values[forEachCounter22022];
			{
					__debugInfo = "2455:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(param5_Varis, local4_Vari_2464);
					__debugInfo = "2455:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver22022.values[forEachCounter22022] = local4_Vari_2464;
			
			};
			__debugInfo = "2463:\src\CompilerPasses\Parser.gbas";
			if (((((((global8_Compiler.attr11_currentFunc) != (-(1))) ? 1 : 0)) && ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType) != (-(1))) ? 1 : 0))) ? 1 : 0)) {
				var alias3_Typ_ref_2465 = [new type14_IdentifierType()];
				__debugInfo = "2459:\src\CompilerPasses\Parser.gbas";
				alias3_Typ_ref_2465 = global8_Compiler.attr5_Types_ref[0].arrAccess(global8_Compiler.attr5_Funcs_ref[0].arrAccess(global8_Compiler.attr11_currentFunc).values[tmpPositionCache][0].attr6_MyType).values[tmpPositionCache] /* ALIAS */;
				__debugInfo = "2462:\src\CompilerPasses\Parser.gbas";
				var forEachSaver22071 = alias3_Typ_ref_2465[0].attr10_Attributes;
				for(var forEachCounter22071 = 0 ; forEachCounter22071 < forEachSaver22071.values.length ; forEachCounter22071++) {
					var local1_A_2466 = forEachSaver22071.values[forEachCounter22071];
				{
						__debugInfo = "2461:\src\CompilerPasses\Parser.gbas";
						DIMPUSH(param5_Varis, local1_A_2466);
						__debugInfo = "2461:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver22071.values[forEachCounter22071] = local1_A_2466;
				
				};
				__debugInfo = "2459:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2456:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2473:\src\CompilerPasses\Parser.gbas";
		if (((((((global5_Exprs_ref[0].arrAccess(~~(param3_Scp)).values[tmpPositionCache][0].attr10_SuperScope) != (-(1))) ? 1 : 0)) && ((((global5_Exprs_ref[0].arrAccess(~~(param3_Scp)).values[tmpPositionCache][0].attr6_ScpTyp) != (2)) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "2467:\src\CompilerPasses\Parser.gbas";
			func8_GetVaris(unref(param5_Varis), global5_Exprs_ref[0].arrAccess(~~(param3_Scp)).values[tmpPositionCache][0].attr10_SuperScope, 0);
			__debugInfo = "2467:\src\CompilerPasses\Parser.gbas";
		} else if ((((param9_PreferVar) >= (0)) ? 1 : 0)) {
			__debugInfo = "2472:\src\CompilerPasses\Parser.gbas";
			var forEachSaver22120 = global8_Compiler.attr7_Globals;
			for(var forEachCounter22120 = 0 ; forEachCounter22120 < forEachSaver22120.values.length ; forEachCounter22120++) {
				var local4_Vari_2467 = forEachSaver22120.values[forEachCounter22120];
			{
					__debugInfo = "2471:\src\CompilerPasses\Parser.gbas";
					DIMPUSH(param5_Varis, local4_Vari_2467);
					__debugInfo = "2471:\src\CompilerPasses\Parser.gbas";
				}
				forEachSaver22120.values[forEachCounter22120] = local4_Vari_2467;
			
			};
			__debugInfo = "2472:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2474:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2444:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_GetVaris = window['func8_GetVaris'];
window['func11_GetVariable'] = function(param4_expr, param3_err) {
	stackPush("function: GetVariable", __debugInfo);
	try {
		var local6_hasErr_2470 = 0;
		__debugInfo = "2481:\src\CompilerPasses\Parser.gbas";
		local6_hasErr_2470 = 0;
		__debugInfo = "2482:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper29__2471 = 0;
			__debugInfo = "2482:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper29__2471 = global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr3_Typ;
			__debugInfo = "2505:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper29__2471) == (~~(9))) ? 1 : 0)) {
				__debugInfo = "2484:\src\CompilerPasses\Parser.gbas";
				return tryClone(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr4_vari);
				__debugInfo = "2484:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper29__2471) == (~~(13))) ? 1 : 0)) {
				__debugInfo = "2486:\src\CompilerPasses\Parser.gbas";
				return tryClone(func11_GetVariable(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr5_array, param3_err));
				__debugInfo = "2486:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper29__2471) == (~~(18))) ? 1 : 0)) {
				__debugInfo = "2488:\src\CompilerPasses\Parser.gbas";
				return tryClone(func11_GetVariable(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr8_nextExpr, param3_err));
				__debugInfo = "2488:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper29__2471) == (~~(54))) ? 1 : 0)) {
				__debugInfo = "2490:\src\CompilerPasses\Parser.gbas";
				return tryClone(func11_GetVariable(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr4_expr, param3_err));
				__debugInfo = "2490:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper29__2471) == (~~(6))) ? 1 : 0)) {
				__debugInfo = "2502:\src\CompilerPasses\Parser.gbas";
				if ((((global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr4_func) != (-(1))) ? 1 : 0)) {
					var alias4_func_ref_2472 = [new type14_IdentifierFunc()];
					__debugInfo = "2493:\src\CompilerPasses\Parser.gbas";
					alias4_func_ref_2472 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr4_func).values[tmpPositionCache] /* ALIAS */;
					__debugInfo = "2499:\src\CompilerPasses\Parser.gbas";
					if ((((alias4_func_ref_2472[0].attr3_Typ) == (3)) ? 1 : 0)) {
						__debugInfo = "2496:\src\CompilerPasses\Parser.gbas";
						return tryClone(-(1));
						__debugInfo = "2496:\src\CompilerPasses\Parser.gbas";
					} else {
						__debugInfo = "2498:\src\CompilerPasses\Parser.gbas";
						local6_hasErr_2470 = 1;
						__debugInfo = "2498:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2493:\src\CompilerPasses\Parser.gbas";
				} else {
					__debugInfo = "2501:\src\CompilerPasses\Parser.gbas";
					local6_hasErr_2470 = 1;
					__debugInfo = "2501:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2502:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2504:\src\CompilerPasses\Parser.gbas";
				local6_hasErr_2470 = 1;
				__debugInfo = "2504:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2482:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2514:\src\CompilerPasses\Parser.gbas";
		if ((((local6_hasErr_2470) && (param3_err)) ? 1 : 0)) {
			var local7_add_Str_2473 = "";
			__debugInfo = "2507:\src\CompilerPasses\Parser.gbas";
			local7_add_Str_2473 = "";
			__debugInfo = "2511:\src\CompilerPasses\Parser.gbas";
			func5_Error((("Variable expected.") + (local7_add_Str_2473)), 2510, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2507:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "2513:\src\CompilerPasses\Parser.gbas";
			return tryClone(-(1));
			__debugInfo = "2513:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2515:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2481:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_GetVariable = window['func11_GetVariable'];
window['func12_GetRightExpr'] = function(param4_expr) {
	stackPush("function: GetRightExpr", __debugInfo);
	try {
		__debugInfo = "2519:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper30__2475 = 0;
			__debugInfo = "2519:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper30__2475 = global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr3_Typ;
			__debugInfo = "2524:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper30__2475) == (~~(18))) ? 1 : 0)) {
				__debugInfo = "2521:\src\CompilerPasses\Parser.gbas";
				return tryClone(func12_GetRightExpr(global5_Exprs_ref[0].arrAccess(param4_expr).values[tmpPositionCache][0].attr8_nextExpr));
				__debugInfo = "2521:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2523:\src\CompilerPasses\Parser.gbas";
				return tryClone(param4_expr);
				__debugInfo = "2523:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2519:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2525:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2519:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_GetRightExpr = window['func12_GetRightExpr'];
window['func16_AddDataChars_Str'] = function(param8_Text_Str, param4_func) {
	stackPush("function: AddDataChars_Str", __debugInfo);
	try {
		__debugInfo = "2529:\src\CompilerPasses\Parser.gbas";
		if ((((param4_func.attr8_datatype.attr8_Name_Str_ref[0]) == ("int")) ? 1 : 0)) {
			__debugInfo = "2529:\src\CompilerPasses\Parser.gbas";
			return tryClone(((param8_Text_Str) + ("%")));
			__debugInfo = "2529:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2530:\src\CompilerPasses\Parser.gbas";
		if ((((param4_func.attr8_datatype.attr8_Name_Str_ref[0]) == ("float")) ? 1 : 0)) {
			__debugInfo = "2530:\src\CompilerPasses\Parser.gbas";
			return tryClone(((param8_Text_Str) + ("#")));
			__debugInfo = "2530:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2531:\src\CompilerPasses\Parser.gbas";
		return tryClone(param8_Text_Str);
		__debugInfo = "2532:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2529:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func16_AddDataChars_Str = window['func16_AddDataChars_Str'];
window['func10_SkipTokens'] = function(param8_Open_Str, param9_Close_Str, param8_Name_Str) {
	stackPush("function: SkipTokens", __debugInfo);
	try {
		var local8_startpos_2481 = 0;
		__debugInfo = "2536:\src\CompilerPasses\Parser.gbas";
		local8_startpos_2481 = global8_Compiler.attr11_currentPosi;
		__debugInfo = "2541:\src\CompilerPasses\Parser.gbas";
		while (((((((func7_IsToken(param9_Close_Str)) == (0)) ? 1 : 0)) && (func7_HasNext())) ? 1 : 0)) {
			__debugInfo = "2540:\src\CompilerPasses\Parser.gbas";
			if (func7_HasNext()) {
				__debugInfo = "2539:\src\CompilerPasses\Parser.gbas";
				func7_GetNext();
				__debugInfo = "2539:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2540:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2552:\src\CompilerPasses\Parser.gbas";
		if ((((func7_HasNext()) == (0)) ? 1 : 0)) {
			var local6_tmpPos_2482 = 0.0;
			__debugInfo = "2544:\src\CompilerPasses\Parser.gbas";
			local6_tmpPos_2482 = global8_Compiler.attr11_currentPosi;
			__debugInfo = "2545:\src\CompilerPasses\Parser.gbas";
			global8_Compiler.attr11_currentPosi = local8_startpos_2481;
			__debugInfo = "2548:\src\CompilerPasses\Parser.gbas";
			{
				var ex_Str = "";
				__debugInfo = "2551:\src\CompilerPasses\Parser.gbas";
				try {
					__debugInfo = "2547:\src\CompilerPasses\Parser.gbas";
					func5_Error(((((((((((param8_Open_Str) + (" "))) + (param8_Name_Str))) + (" needs '"))) + (param9_Close_Str))) + ("', unexpected end of file.")), 2546, "src\CompilerPasses\Parser.gbas");
					__debugInfo = "2547:\src\CompilerPasses\Parser.gbas";
				} catch (ex_Str) {
					if (ex_Str instanceof OTTException) ex_Str = ex_Str.getText(); else throwError(ex_Str);{
						__debugInfo = "2549:\src\CompilerPasses\Parser.gbas";
						global8_Compiler.attr11_currentPosi = ~~(local6_tmpPos_2482);
						__debugInfo = "2550:\src\CompilerPasses\Parser.gbas";
						throw new OTTException(ex_Str, "\src\CompilerPasses\Parser.gbas", 2550);
						__debugInfo = "2549:\src\CompilerPasses\Parser.gbas";
					}
				};
				__debugInfo = "2551:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2544:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2553:\src\CompilerPasses\Parser.gbas";
		if ((((param9_Close_Str) != ("\n")) ? 1 : 0)) {
			__debugInfo = "2553:\src\CompilerPasses\Parser.gbas";
			func5_Match(param9_Close_Str, 2552, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2553:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2554:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2536:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_SkipTokens = window['func10_SkipTokens'];
window['func17_BuildPrototyp_Str'] = function(param1_F) {
	stackPush("function: BuildPrototyp_Str", __debugInfo);
	try {
		var alias4_Func_ref_2485 = [new type14_IdentifierFunc()], local8_Text_Str_2486 = "", local5_Found_2487 = 0;
		__debugInfo = "2558:\src\CompilerPasses\Parser.gbas";
		alias4_Func_ref_2485 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(param1_F).values[tmpPositionCache] /* ALIAS */;
		__debugInfo = "2559:\src\CompilerPasses\Parser.gbas";
		local8_Text_Str_2486 = (((((("RETURN TYPE: ") + (alias4_Func_ref_2485[0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(alias4_Func_ref_2485[0].attr8_datatype.attr7_IsArray_ref[0]))))) + (" PARAMETER:"));
		__debugInfo = "2560:\src\CompilerPasses\Parser.gbas";
		local5_Found_2487 = 0;
		__debugInfo = "2566:\src\CompilerPasses\Parser.gbas";
		var forEachSaver22462 = alias4_Func_ref_2485[0].attr6_Params;
		for(var forEachCounter22462 = 0 ; forEachCounter22462 < forEachSaver22462.values.length ; forEachCounter22462++) {
			var local1_P_2488 = forEachSaver22462.values[forEachCounter22462];
		{
				var alias5_Param_ref_2489 = [new type14_IdentifierVari()];
				__debugInfo = "2562:\src\CompilerPasses\Parser.gbas";
				alias5_Param_ref_2489 = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_2488).values[tmpPositionCache] /* ALIAS */;
				__debugInfo = "2563:\src\CompilerPasses\Parser.gbas";
				if (local5_Found_2487) {
					__debugInfo = "2563:\src\CompilerPasses\Parser.gbas";
					local8_Text_Str_2486 = ((local8_Text_Str_2486) + (", "));
					__debugInfo = "2563:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2564:\src\CompilerPasses\Parser.gbas";
				local8_Text_Str_2486 = ((((local8_Text_Str_2486) + (alias5_Param_ref_2489[0].attr8_datatype.attr8_Name_Str_ref[0]))) + (func20_BuildArrBrackets_Str(unref(alias5_Param_ref_2489[0].attr8_datatype.attr7_IsArray_ref[0]))));
				__debugInfo = "2565:\src\CompilerPasses\Parser.gbas";
				local5_Found_2487 = 1;
				__debugInfo = "2562:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver22462.values[forEachCounter22462] = local1_P_2488;
		
		};
		__debugInfo = "2568:\src\CompilerPasses\Parser.gbas";
		return tryClone(local8_Text_Str_2486);
		__debugInfo = "2569:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2558:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func17_BuildPrototyp_Str = window['func17_BuildPrototyp_Str'];
window['func14_SearchPrototyp'] = function(param8_Name_Str) {
	stackPush("function: SearchPrototyp", __debugInfo);
	try {
		var local3_Ret_ref_2491 = [0];
		__debugInfo = "2586:\src\CompilerPasses\Parser.gbas";
		if ((global8_Compiler.attr11_GlobalFuncs).GetValue(param8_Name_Str, local3_Ret_ref_2491)) {
			__debugInfo = "2582:\src\CompilerPasses\Parser.gbas";
			if ((((global8_Compiler.attr5_Funcs_ref[0].arrAccess(local3_Ret_ref_2491[0]).values[tmpPositionCache][0].attr3_Typ) == (2)) ? 1 : 0)) {
				__debugInfo = "2579:\src\CompilerPasses\Parser.gbas";
				return tryClone(-(1));
				__debugInfo = "2579:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2581:\src\CompilerPasses\Parser.gbas";
				return tryClone(unref(local3_Ret_ref_2491[0]));
				__debugInfo = "2581:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2582:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "2585:\src\CompilerPasses\Parser.gbas";
			return tryClone(-(1));
			__debugInfo = "2585:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2587:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2586:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_SearchPrototyp = window['func14_SearchPrototyp'];
window['func14_SearchOperator'] = function(param8_Name_Str) {
	stackPush("function: SearchOperator", __debugInfo);
	try {
		__debugInfo = "2593:\src\CompilerPasses\Parser.gbas";
		var forEachSaver22528 = global9_Operators_ref[0];
		for(var forEachCounter22528 = 0 ; forEachCounter22528 < forEachSaver22528.values.length ; forEachCounter22528++) {
			var local2_Op_ref_2493 = forEachSaver22528.values[forEachCounter22528];
		{
				__debugInfo = "2592:\src\CompilerPasses\Parser.gbas";
				if (((((((local2_Op_ref_2493[0].attr7_Sym_Str) == (param8_Name_Str)) ? 1 : 0)) || ((((local2_Op_ref_2493[0].attr8_Name_Str) == (param8_Name_Str)) ? 1 : 0))) ? 1 : 0)) {
					__debugInfo = "2592:\src\CompilerPasses\Parser.gbas";
					return tryClone(local2_Op_ref_2493[0].attr2_ID);
					__debugInfo = "2592:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2592:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver22528.values[forEachCounter22528] = local2_Op_ref_2493;
		
		};
		__debugInfo = "2594:\src\CompilerPasses\Parser.gbas";
		return tryClone(-(1));
		__debugInfo = "2595:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2593:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_SearchOperator = window['func14_SearchOperator'];
window['func17_CleanVariable_Str'] = function(param7_Var_Str) {
	stackPush("function: CleanVariable_Str", __debugInfo);
	try {
		var local11_Postfix_Str_2495 = "";
		__debugInfo = "2599:\src\CompilerPasses\Parser.gbas";
		local11_Postfix_Str_2495 = RIGHT_Str(param7_Var_Str, 1);
		__debugInfo = "2604:\src\CompilerPasses\Parser.gbas";
		if (((((((local11_Postfix_Str_2495) == ("%")) ? 1 : 0)) || ((((local11_Postfix_Str_2495) == ("#")) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "2601:\src\CompilerPasses\Parser.gbas";
			return tryClone(LEFT_Str(param7_Var_Str, (((param7_Var_Str).length) - (1))));
			__debugInfo = "2601:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "2603:\src\CompilerPasses\Parser.gbas";
			return tryClone(param7_Var_Str);
			__debugInfo = "2603:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2605:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2599:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func17_CleanVariable_Str = window['func17_CleanVariable_Str'];
window['func12_ScopeHasGoto'] = function(param3_scp) {
	stackPush("function: ScopeHasGoto", __debugInfo);
	try {
		__debugInfo = "2608:\src\CompilerPasses\Parser.gbas";
		if ((((param3_scp.attr3_Typ) != (2)) ? 1 : 0)) {
			__debugInfo = "2608:\src\CompilerPasses\Parser.gbas";
			func5_Error("Internal error (Cant look for Scope)", 2607, "src\CompilerPasses\Parser.gbas");
			__debugInfo = "2608:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2639:\src\CompilerPasses\Parser.gbas";
		var forEachSaver22733 = param3_scp.attr5_Exprs;
		for(var forEachCounter22733 = 0 ; forEachCounter22733 < forEachSaver22733.values.length ; forEachCounter22733++) {
			var local1_E_2497 = forEachSaver22733.values[forEachCounter22733];
		{
				var alias4_SubE_ref_2498 = [new type4_Expr()];
				__debugInfo = "2610:\src\CompilerPasses\Parser.gbas";
				alias4_SubE_ref_2498 = global5_Exprs_ref[0].arrAccess(local1_E_2497).values[tmpPositionCache] /* ALIAS */;
				__debugInfo = "2611:\src\CompilerPasses\Parser.gbas";
				{
					var local17___SelectHelper31__2499 = 0;
					__debugInfo = "2611:\src\CompilerPasses\Parser.gbas";
					local17___SelectHelper31__2499 = alias4_SubE_ref_2498[0].attr3_Typ;
					__debugInfo = "2638:\src\CompilerPasses\Parser.gbas";
					if ((((local17___SelectHelper31__2499) == (~~(24))) ? 1 : 0)) {
						__debugInfo = "2615:\src\CompilerPasses\Parser.gbas";
						var forEachSaver22613 = alias4_SubE_ref_2498[0].attr6_Scopes;
						for(var forEachCounter22613 = 0 ; forEachCounter22613 < forEachSaver22613.values.length ; forEachCounter22613++) {
							var local1_E_2500 = forEachSaver22613.values[forEachCounter22613];
						{
								__debugInfo = "2614:\src\CompilerPasses\Parser.gbas";
								if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(local1_E_2500).values[tmpPositionCache][0]))) {
									__debugInfo = "2614:\src\CompilerPasses\Parser.gbas";
									return 1;
									__debugInfo = "2614:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "2614:\src\CompilerPasses\Parser.gbas";
							}
							forEachSaver22613.values[forEachCounter22613] = local1_E_2500;
						
						};
						__debugInfo = "2618:\src\CompilerPasses\Parser.gbas";
						if ((((alias4_SubE_ref_2498[0].attr9_elseScope) != (-(1))) ? 1 : 0)) {
							__debugInfo = "2617:\src\CompilerPasses\Parser.gbas";
							if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr9_elseScope).values[tmpPositionCache][0]))) {
								__debugInfo = "2617:\src\CompilerPasses\Parser.gbas";
								return 1;
								__debugInfo = "2617:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "2617:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2615:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(25))) ? 1 : 0)) {
						__debugInfo = "2620:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr3_Scp).values[tmpPositionCache][0]))) {
							__debugInfo = "2620:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2620:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2620:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(26))) ? 1 : 0)) {
						__debugInfo = "2622:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr3_Scp).values[tmpPositionCache][0]))) {
							__debugInfo = "2622:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2622:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2622:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(27))) ? 1 : 0)) {
						__debugInfo = "2624:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr3_Scp).values[tmpPositionCache][0]))) {
							__debugInfo = "2624:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2624:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2624:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(38))) ? 1 : 0)) {
						__debugInfo = "2626:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr3_Scp).values[tmpPositionCache][0]))) {
							__debugInfo = "2626:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2626:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2626:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(31))) ? 1 : 0)) {
						__debugInfo = "2628:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr3_Scp).values[tmpPositionCache][0]))) {
							__debugInfo = "2628:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2628:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2629:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(global5_Exprs_ref[0].arrAccess(alias4_SubE_ref_2498[0].attr8_catchScp).values[tmpPositionCache][0]))) {
							__debugInfo = "2629:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2629:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2628:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(20))) ? 1 : 0)) {
						__debugInfo = "2631:\src\CompilerPasses\Parser.gbas";
						return 1;
						__debugInfo = "2631:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper31__2499) == (~~(2))) ? 1 : 0)) {
						__debugInfo = "2633:\src\CompilerPasses\Parser.gbas";
						if (func12_ScopeHasGoto(unref(alias4_SubE_ref_2498[0]))) {
							__debugInfo = "2633:\src\CompilerPasses\Parser.gbas";
							return 1;
							__debugInfo = "2633:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2633:\src\CompilerPasses\Parser.gbas";
					} else {
						
					};
					__debugInfo = "2611:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2610:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver22733.values[forEachCounter22733] = local1_E_2497;
		
		};
		__debugInfo = "2640:\src\CompilerPasses\Parser.gbas";
		return tryClone(0);
		__debugInfo = "2641:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2608:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_ScopeHasGoto = window['func12_ScopeHasGoto'];
window['func13_ScopeName_Str'] = function(param4_expr) {
	stackPush("function: ScopeName_Str", __debugInfo);
	try {
		__debugInfo = "2645:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper32__2502 = 0;
			__debugInfo = "2645:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper32__2502 = param4_expr.attr6_ScpTyp;
			__debugInfo = "2669:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper32__2502) == (~~(1))) ? 1 : 0)) {
				__debugInfo = "2647:\src\CompilerPasses\Parser.gbas";
				return "if";
				__debugInfo = "2647:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper32__2502) == (~~(3))) ? 1 : 0)) {
				__debugInfo = "2649:\src\CompilerPasses\Parser.gbas";
				return "loop";
				__debugInfo = "2649:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper32__2502) == (~~(5))) ? 1 : 0)) {
				__debugInfo = "2651:\src\CompilerPasses\Parser.gbas";
				return "try";
				__debugInfo = "2651:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper32__2502) == (~~(4))) ? 1 : 0)) {
				__debugInfo = "2653:\src\CompilerPasses\Parser.gbas";
				return "main";
				__debugInfo = "2653:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper32__2502) == (~~(2))) ? 1 : 0)) {
				__debugInfo = "2655:\src\CompilerPasses\Parser.gbas";
				{
					var local17___SelectHelper33__2503 = 0;
					__debugInfo = "2655:\src\CompilerPasses\Parser.gbas";
					local17___SelectHelper33__2503 = global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr3_Typ;
					__debugInfo = "2664:\src\CompilerPasses\Parser.gbas";
					if ((((local17___SelectHelper33__2503) == (~~(2))) ? 1 : 0)) {
						__debugInfo = "2657:\src\CompilerPasses\Parser.gbas";
						return tryClone((("sub: ") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr9_OName_Str)));
						__debugInfo = "2657:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper33__2503) == (~~(3))) ? 1 : 0)) {
						__debugInfo = "2659:\src\CompilerPasses\Parser.gbas";
						return tryClone((("method: ") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr9_OName_Str)));
						__debugInfo = "2659:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper33__2503) == (~~(1))) ? 1 : 0)) {
						__debugInfo = "2661:\src\CompilerPasses\Parser.gbas";
						return tryClone((("function: ") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr9_OName_Str)));
						__debugInfo = "2661:\src\CompilerPasses\Parser.gbas";
					} else if ((((local17___SelectHelper33__2503) == (~~(4))) ? 1 : 0)) {
						__debugInfo = "2663:\src\CompilerPasses\Parser.gbas";
						return tryClone((("prototype: ") + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(global11_CurrentFunc).values[tmpPositionCache][0].attr9_OName_Str)));
						__debugInfo = "2663:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2655:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2655:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper32__2502) == (~~(6))) ? 1 : 0)) {
				__debugInfo = "2666:\src\CompilerPasses\Parser.gbas";
				return "select";
				__debugInfo = "2666:\src\CompilerPasses\Parser.gbas";
			} else {
				__debugInfo = "2668:\src\CompilerPasses\Parser.gbas";
				func5_Error("Internal error (unknown scope type)", 2667, "src\CompilerPasses\Parser.gbas");
				__debugInfo = "2668:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2645:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2670:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2645:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_ScopeName_Str = window['func13_ScopeName_Str'];
window['func13_ChangeVarName'] = function(param4_Vari) {
	stackPush("function: ChangeVarName", __debugInfo);
	try {
		__debugInfo = "2675:\src\CompilerPasses\Parser.gbas";
		param4_Vari.attr8_Name_Str = TRIM_Str(REPLACE_Str(param4_Vari.attr8_Name_Str, "$", "_Str"), " \t\r\n\v\f");
		__debugInfo = "2677:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper34__2505 = 0;
			__debugInfo = "2677:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper34__2505 = param4_Vari.attr3_Typ;
			__debugInfo = "2705:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper34__2505) == (~~(1))) ? 1 : 0)) {
				__debugInfo = "2679:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("local") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2679:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(2))) ? 1 : 0)) {
				var local5_Found_2506 = 0;
				__debugInfo = "2681:\src\CompilerPasses\Parser.gbas";
				local5_Found_2506 = 0;
				__debugInfo = "2693:\src\CompilerPasses\Parser.gbas";
				var forEachSaver22944 = global8_Compiler.attr7_Exports;
				for(var forEachCounter22944 = 0 ; forEachCounter22944 < forEachSaver22944.values.length ; forEachCounter22944++) {
					var local3_Exp_2507 = forEachSaver22944.values[forEachCounter22944];
				{
						__debugInfo = "2692:\src\CompilerPasses\Parser.gbas";
						if ((((local3_Exp_2507.attr8_Name_Str) == (param4_Vari.attr8_Name_Str)) ? 1 : 0)) {
							__debugInfo = "2684:\src\CompilerPasses\Parser.gbas";
							local5_Found_2506 = 1;
							__debugInfo = "2687:\src\CompilerPasses\Parser.gbas";
							if (param4_Vari.attr3_ref) {
								__debugInfo = "2686:\src\CompilerPasses\Parser.gbas";
								func5_Error((((("Cannot export '") + (param4_Vari.attr8_Name_Str))) + ("' because it is a reference (dont use in connection with BYREF and ALIAS!)")), 2685, "src\CompilerPasses\Parser.gbas");
								__debugInfo = "2686:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "2690:\src\CompilerPasses\Parser.gbas";
							if ((((local3_Exp_2507.attr12_RealName_Str) != ("")) ? 1 : 0)) {
								__debugInfo = "2689:\src\CompilerPasses\Parser.gbas";
								param4_Vari.attr8_Name_Str = local3_Exp_2507.attr12_RealName_Str;
								__debugInfo = "2689:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "2691:\src\CompilerPasses\Parser.gbas";
							return 0;
							__debugInfo = "2684:\src\CompilerPasses\Parser.gbas";
						};
						__debugInfo = "2692:\src\CompilerPasses\Parser.gbas";
					}
					forEachSaver22944.values[forEachCounter22944] = local3_Exp_2507;
				
				};
				__debugInfo = "2694:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("global") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2681:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(3))) ? 1 : 0)) {
				__debugInfo = "2696:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("attr") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2696:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(4))) ? 1 : 0)) {
				__debugInfo = "2698:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((((((("static") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (global8_Compiler.attr5_Funcs_ref[0].arrAccess(param4_Vari.attr4_func).values[tmpPositionCache][0].attr9_OName_Str))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2698:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(5))) ? 1 : 0)) {
				__debugInfo = "2700:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("param") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2700:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(6))) ? 1 : 0)) {
				__debugInfo = "2702:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("const") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2702:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper34__2505) == (~~(7))) ? 1 : 0)) {
				__debugInfo = "2704:\src\CompilerPasses\Parser.gbas";
				param4_Vari.attr8_Name_Str = (((((("alias") + (CAST2STRING((param4_Vari.attr8_Name_Str).length)))) + ("_"))) + (param4_Vari.attr8_Name_Str));
				__debugInfo = "2704:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2677:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2706:\src\CompilerPasses\Parser.gbas";
		if (param4_Vari.attr3_ref) {
			__debugInfo = "2706:\src\CompilerPasses\Parser.gbas";
			param4_Vari.attr8_Name_Str = ((param4_Vari.attr8_Name_Str) + ("_ref"));
			__debugInfo = "2706:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2713:\src\CompilerPasses\Parser.gbas";
		if ((((param4_Vari.attr6_PreDef) != (-(1))) ? 1 : 0)) {
			__debugInfo = "2712:\src\CompilerPasses\Parser.gbas";
			if ((((global5_Exprs_ref[0].arrAccess(param4_Vari.attr6_PreDef).values[tmpPositionCache][0].attr3_Typ) == (36)) ? 1 : 0)) {
				__debugInfo = "2711:\src\CompilerPasses\Parser.gbas";
				global5_Exprs_ref[0].arrAccess(param4_Vari.attr6_PreDef).values[tmpPositionCache][0].attr4_vari = param4_Vari.attr2_ID;
				__debugInfo = "2711:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2712:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2714:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2675:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_ChangeVarName = window['func13_ChangeVarName'];
window['func14_ChangeFuncName'] = function(param4_Func) {
	stackPush("function: ChangeFuncName", __debugInfo);
	try {
		__debugInfo = "2717:\src\CompilerPasses\Parser.gbas";
		param4_Func.attr8_Name_Str = TRIM_Str(REPLACE_Str(param4_Func.attr8_Name_Str, "$", "_Str"), " \t\r\n\v\f");
		__debugInfo = "2719:\src\CompilerPasses\Parser.gbas";
		param4_Func.attr9_OName_Str = param4_Func.attr8_Name_Str;
		__debugInfo = "2720:\src\CompilerPasses\Parser.gbas";
		{
			var local17___SelectHelper35__2509 = 0;
			__debugInfo = "2720:\src\CompilerPasses\Parser.gbas";
			local17___SelectHelper35__2509 = param4_Func.attr3_Typ;
			__debugInfo = "2739:\src\CompilerPasses\Parser.gbas";
			if ((((local17___SelectHelper35__2509) == (~~(3))) ? 1 : 0)) {
				__debugInfo = "2722:\src\CompilerPasses\Parser.gbas";
				param4_Func.attr8_Name_Str = (((((((((((((("method") + (CAST2STRING((global8_Compiler.attr5_Types_ref[0].arrAccess(param4_Func.attr6_MyType).values[tmpPositionCache][0].attr8_Name_Str).length)))) + ("_"))) + (global8_Compiler.attr5_Types_ref[0].arrAccess(param4_Func.attr6_MyType).values[tmpPositionCache][0].attr8_Name_Str))) + ("_"))) + (CAST2STRING((param4_Func.attr8_Name_Str).length)))) + ("_"))) + (param4_Func.attr8_Name_Str));
				__debugInfo = "2722:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper35__2509) == (~~(1))) ? 1 : 0)) {
				__debugInfo = "2736:\src\CompilerPasses\Parser.gbas";
				if ((((param4_Func.attr6_Native) == (0)) ? 1 : 0)) {
					var local5_Found_2510 = 0;
					__debugInfo = "2725:\src\CompilerPasses\Parser.gbas";
					local5_Found_2510 = 0;
					__debugInfo = "2734:\src\CompilerPasses\Parser.gbas";
					var forEachSaver23248 = global8_Compiler.attr7_Exports;
					for(var forEachCounter23248 = 0 ; forEachCounter23248 < forEachSaver23248.values.length ; forEachCounter23248++) {
						var local3_Exp_2511 = forEachSaver23248.values[forEachCounter23248];
					{
							__debugInfo = "2733:\src\CompilerPasses\Parser.gbas";
							if ((((local3_Exp_2511.attr8_Name_Str) == (param4_Func.attr8_Name_Str)) ? 1 : 0)) {
								__debugInfo = "2728:\src\CompilerPasses\Parser.gbas";
								local5_Found_2510 = 1;
								__debugInfo = "2731:\src\CompilerPasses\Parser.gbas";
								if ((((local3_Exp_2511.attr12_RealName_Str) != ("")) ? 1 : 0)) {
									__debugInfo = "2730:\src\CompilerPasses\Parser.gbas";
									param4_Func.attr8_Name_Str = local3_Exp_2511.attr12_RealName_Str;
									__debugInfo = "2730:\src\CompilerPasses\Parser.gbas";
								};
								__debugInfo = "2732:\src\CompilerPasses\Parser.gbas";
								break;
								__debugInfo = "2728:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "2733:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver23248.values[forEachCounter23248] = local3_Exp_2511;
					
					};
					__debugInfo = "2735:\src\CompilerPasses\Parser.gbas";
					if (((local5_Found_2510) ? 0 : 1)) {
						__debugInfo = "2735:\src\CompilerPasses\Parser.gbas";
						param4_Func.attr8_Name_Str = (((((("func") + (CAST2STRING((param4_Func.attr8_Name_Str).length)))) + ("_"))) + (param4_Func.attr8_Name_Str));
						__debugInfo = "2735:\src\CompilerPasses\Parser.gbas";
					};
					__debugInfo = "2725:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2736:\src\CompilerPasses\Parser.gbas";
			} else if ((((local17___SelectHelper35__2509) == (~~(2))) ? 1 : 0)) {
				
			};
			__debugInfo = "2720:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2740:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2717:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func14_ChangeFuncName = window['func14_ChangeFuncName'];
window['func18_ChangeTypeName_Str'] = function(param8_Name_Str) {
	stackPush("function: ChangeTypeName_Str", __debugInfo);
	try {
		__debugInfo = "2747:\src\CompilerPasses\Parser.gbas";
		if ((((((((((((((((((((((((((((((((((param8_Name_Str) == ("string")) ? 1 : 0)) || ((((param8_Name_Str) == ("void")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("float")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("double")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("int")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("short")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("byte")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("bool")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("boolean")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("long")) ? 1 : 0))) ? 1 : 0)) || ((((param8_Name_Str) == ("single")) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "2744:\src\CompilerPasses\Parser.gbas";
			return tryClone(param8_Name_Str);
			__debugInfo = "2744:\src\CompilerPasses\Parser.gbas";
		} else {
			__debugInfo = "2746:\src\CompilerPasses\Parser.gbas";
			return tryClone((((((("type") + (CAST2STRING((param8_Name_Str).length)))) + ("_"))) + (param8_Name_Str)));
			__debugInfo = "2746:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2748:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2747:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func18_ChangeTypeName_Str = window['func18_ChangeTypeName_Str'];
window['func11_NewLine_Str'] = function() {
	stackPush("function: NewLine_Str", __debugInfo);
	try {
		var local8_Text_Str_2513 = "";
		__debugInfo = "2753:\src\CompilerPasses\Parser.gbas";
		local8_Text_Str_2513 = "\n";
		__debugInfo = "2753:\src\CompilerPasses\Parser.gbas";
		{
			var local1_i_2514 = 0.0;
			__debugInfo = "2756:\src\CompilerPasses\Parser.gbas";
			for (local1_i_2514 = 1;toCheck(local1_i_2514, global6_Indent, 1);local1_i_2514 += 1) {
				__debugInfo = "2755:\src\CompilerPasses\Parser.gbas";
				local8_Text_Str_2513 = ((local8_Text_Str_2513) + ("\t"));
				__debugInfo = "2755:\src\CompilerPasses\Parser.gbas";
			};
			__debugInfo = "2756:\src\CompilerPasses\Parser.gbas";
		};
		__debugInfo = "2757:\src\CompilerPasses\Parser.gbas";
		return tryClone(local8_Text_Str_2513);
		__debugInfo = "2758:\src\CompilerPasses\Parser.gbas";
		return "";
		__debugInfo = "2753:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_NewLine_Str = window['func11_NewLine_Str'];
window['func8_IndentUp'] = function() {
	stackPush("function: IndentUp", __debugInfo);
	try {
		__debugInfo = "2760:\src\CompilerPasses\Parser.gbas";
		global6_Indent+=1;
		__debugInfo = "2761:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2760:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func8_IndentUp = window['func8_IndentUp'];
window['func10_IndentDown'] = function() {
	stackPush("function: IndentDown", __debugInfo);
	try {
		__debugInfo = "2763:\src\CompilerPasses\Parser.gbas";
		global6_Indent+=-1;
		__debugInfo = "2764:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2763:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_IndentDown = window['func10_IndentDown'];
window['func23_ManageFuncParamOverlaps'] = function() {
	stackPush("function: ManageFuncParamOverlaps", __debugInfo);
	try {
		__debugInfo = "2795:\src\CompilerPasses\Parser.gbas";
		var forEachSaver23479 = global8_Compiler.attr5_Funcs_ref[0];
		for(var forEachCounter23479 = 0 ; forEachCounter23479 < forEachSaver23479.values.length ; forEachCounter23479++) {
			var local4_Func_ref_2515 = forEachSaver23479.values[forEachCounter23479];
		{
				__debugInfo = "2794:\src\CompilerPasses\Parser.gbas";
				if ((((((((((local4_Func_ref_2515[0].attr6_Native) == (0)) ? 1 : 0)) && ((((local4_Func_ref_2515[0].attr3_Scp) != (-(1))) ? 1 : 0))) ? 1 : 0)) && ((((local4_Func_ref_2515[0].attr10_IsAbstract) == (0)) ? 1 : 0))) ? 1 : 0)) {
					var local1_i_2516 = 0;
					__debugInfo = "2772:\src\CompilerPasses\Parser.gbas";
					local1_i_2516 = 0;
					__debugInfo = "2793:\src\CompilerPasses\Parser.gbas";
					var forEachSaver23477 = local4_Func_ref_2515[0].attr6_Params;
					for(var forEachCounter23477 = 0 ; forEachCounter23477 < forEachSaver23477.values.length ; forEachCounter23477++) {
						var local1_P_2517 = forEachSaver23477.values[forEachCounter23477];
					{
							__debugInfo = "2790:\src\CompilerPasses\Parser.gbas";
							if ((((global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_2517).values[tmpPositionCache][0].attr3_ref) != (global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Func_ref_2515[0].attr10_CopyParams.arrAccess(local1_i_2516).values[tmpPositionCache]).values[tmpPositionCache][0].attr3_ref)) ? 1 : 0)) {
								__debugInfo = "2783:\src\CompilerPasses\Parser.gbas";
								global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_2517).values[tmpPositionCache][0].attr9_OwnerVari = local4_Func_ref_2515[0].attr10_CopyParams.arrAccess(local1_i_2516).values[tmpPositionCache];
								__debugInfo = "2783:\src\CompilerPasses\Parser.gbas";
							} else {
								__debugInfo = "2789:\src\CompilerPasses\Parser.gbas";
								global8_Compiler.attr5_Varis_ref[0].arrAccess(local4_Func_ref_2515[0].attr10_CopyParams.arrAccess(local1_i_2516).values[tmpPositionCache]).values[tmpPositionCache][0].attr8_Name_Str = global8_Compiler.attr5_Varis_ref[0].arrAccess(local1_P_2517).values[tmpPositionCache][0].attr8_Name_Str;
								__debugInfo = "2789:\src\CompilerPasses\Parser.gbas";
							};
							__debugInfo = "2792:\src\CompilerPasses\Parser.gbas";
							local1_i_2516+=1;
							__debugInfo = "2790:\src\CompilerPasses\Parser.gbas";
						}
						forEachSaver23477.values[forEachCounter23477] = local1_P_2517;
					
					};
					__debugInfo = "2772:\src\CompilerPasses\Parser.gbas";
				};
				__debugInfo = "2794:\src\CompilerPasses\Parser.gbas";
			}
			forEachSaver23479.values[forEachCounter23479] = local4_Func_ref_2515;
		
		};
		__debugInfo = "2796:\src\CompilerPasses\Parser.gbas";
		return 0;
		__debugInfo = "2795:\src\CompilerPasses\Parser.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func23_ManageFuncParamOverlaps = window['func23_ManageFuncParamOverlaps'];
window['func11_Precompiler'] = function() {
	stackPush("function: Precompiler", __debugInfo);
	try {
		__debugInfo = "8:\src\CompilerPasses\Preprocessor.gbas";
		func5_Start();
		__debugInfo = "13:\src\CompilerPasses\Preprocessor.gbas";
		{
			var Err_Str = "";
			__debugInfo = "14:\src\CompilerPasses\Preprocessor.gbas";
			try {
				__debugInfo = "12:\src\CompilerPasses\Preprocessor.gbas";
				while (func8_EOFParse()) {
					__debugInfo = "11:\src\CompilerPasses\Preprocessor.gbas";
					func10_PreCommand(0);
					__debugInfo = "11:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "12:\src\CompilerPasses\Preprocessor.gbas";
			} catch (Err_Str) {
				if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
					
				}
			};
			__debugInfo = "14:\src\CompilerPasses\Preprocessor.gbas";
		};
		__debugInfo = "15:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "8:\src\CompilerPasses\Preprocessor.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_Precompiler = window['func11_Precompiler'];
window['func10_PreCommand'] = function(param9_IgnoreAll) {
	stackPush("function: PreCommand", __debugInfo);
	try {
		__debugInfo = "165:\src\CompilerPasses\Preprocessor.gbas";
		if (func7_IsToken("?")) {
			var local7_Cur_Str_2520 = "";
			__debugInfo = "18:\src\CompilerPasses\Preprocessor.gbas";
			func14_MatchAndRemove("?", 17, "src\CompilerPasses\Preprocessor.gbas");
			__debugInfo = "19:\src\CompilerPasses\Preprocessor.gbas";
			local7_Cur_Str_2520 = func14_GetCurrent_Str();
			__debugInfo = "20:\src\CompilerPasses\Preprocessor.gbas";
			func13_RemoveCurrent();
			__debugInfo = "21:\src\CompilerPasses\Preprocessor.gbas";
			{
				var local17___SelectHelper36__2521 = "";
				__debugInfo = "21:\src\CompilerPasses\Preprocessor.gbas";
				local17___SelectHelper36__2521 = local7_Cur_Str_2520;
				__debugInfo = "150:\src\CompilerPasses\Preprocessor.gbas";
				if ((((local17___SelectHelper36__2521) == ("DEFINE")) ? 1 : 0)) {
					var local3_Def_2522 = new type7_TDefine();
					__debugInfo = "24:\src\CompilerPasses\Preprocessor.gbas";
					local3_Def_2522.attr7_Key_Str = func14_GetCurrent_Str();
					__debugInfo = "25:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "31:\src\CompilerPasses\Preprocessor.gbas";
					if ((((func7_IsToken("\n")) == (0)) ? 1 : 0)) {
						__debugInfo = "27:\src\CompilerPasses\Preprocessor.gbas";
						local3_Def_2522.attr9_Value_Str = func14_GetCurrent_Str();
						__debugInfo = "28:\src\CompilerPasses\Preprocessor.gbas";
						func13_RemoveCurrent();
						__debugInfo = "27:\src\CompilerPasses\Preprocessor.gbas";
					} else {
						__debugInfo = "30:\src\CompilerPasses\Preprocessor.gbas";
						local3_Def_2522.attr9_Value_Str = CAST2STRING(1);
						__debugInfo = "30:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "32:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "32:\src\CompilerPasses\Preprocessor.gbas";
						DIMPUSH(global7_Defines, local3_Def_2522);
						__debugInfo = "32:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "24:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("UNDEF")) ? 1 : 0)) {
					__debugInfo = "38:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "37:\src\CompilerPasses\Preprocessor.gbas";
						var forEachSaver23574 = global7_Defines;
						for(var forEachCounter23574 = 0 ; forEachCounter23574 < forEachSaver23574.values.length ; forEachCounter23574++) {
							var local3_Def_2523 = forEachSaver23574.values[forEachCounter23574];
						{
								__debugInfo = "36:\src\CompilerPasses\Preprocessor.gbas";
								if (func7_IsToken(local3_Def_2523.attr7_Key_Str)) {
									__debugInfo = "36:\src\CompilerPasses\Preprocessor.gbas";
									//DELETE!!111
									forEachSaver23574.values[forEachCounter23574] = local3_Def_2523;
									DIMDEL(forEachSaver23574, forEachCounter23574);
									forEachCounter23574--;
									continue;
									__debugInfo = "36:\src\CompilerPasses\Preprocessor.gbas";
								};
								__debugInfo = "36:\src\CompilerPasses\Preprocessor.gbas";
							}
							forEachSaver23574.values[forEachCounter23574] = local3_Def_2523;
						
						};
						__debugInfo = "37:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "39:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "38:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("IFDEF")) ? 1 : 0)) {
					__debugInfo = "56:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						var local4_doIt_2524 = 0;
						__debugInfo = "42:\src\CompilerPasses\Preprocessor.gbas";
						local4_doIt_2524 = 0;
						__debugInfo = "48:\src\CompilerPasses\Preprocessor.gbas";
						var forEachSaver23605 = global7_Defines;
						for(var forEachCounter23605 = 0 ; forEachCounter23605 < forEachSaver23605.values.length ; forEachCounter23605++) {
							var local3_Def_2525 = forEachSaver23605.values[forEachCounter23605];
						{
								__debugInfo = "47:\src\CompilerPasses\Preprocessor.gbas";
								if (func7_IsToken(local3_Def_2525.attr7_Key_Str)) {
									__debugInfo = "45:\src\CompilerPasses\Preprocessor.gbas";
									local4_doIt_2524 = 1;
									__debugInfo = "46:\src\CompilerPasses\Preprocessor.gbas";
									break;
									__debugInfo = "45:\src\CompilerPasses\Preprocessor.gbas";
								};
								__debugInfo = "47:\src\CompilerPasses\Preprocessor.gbas";
							}
							forEachSaver23605.values[forEachCounter23605] = local3_Def_2525;
						
						};
						__debugInfo = "49:\src\CompilerPasses\Preprocessor.gbas";
						func13_RemoveCurrent();
						__debugInfo = "50:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 49, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "51:\src\CompilerPasses\Preprocessor.gbas";
						func5_PreIf(local4_doIt_2524);
						__debugInfo = "42:\src\CompilerPasses\Preprocessor.gbas";
					} else {
						__debugInfo = "53:\src\CompilerPasses\Preprocessor.gbas";
						func13_RemoveCurrent();
						__debugInfo = "54:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 53, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "55:\src\CompilerPasses\Preprocessor.gbas";
						func5_PreIf(2);
						__debugInfo = "53:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "56:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("IFNDEF")) ? 1 : 0)) {
					__debugInfo = "74:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						var local4_doIt_2526 = 0;
						__debugInfo = "59:\src\CompilerPasses\Preprocessor.gbas";
						local4_doIt_2526 = 1;
						__debugInfo = "65:\src\CompilerPasses\Preprocessor.gbas";
						var forEachSaver23650 = global7_Defines;
						for(var forEachCounter23650 = 0 ; forEachCounter23650 < forEachSaver23650.values.length ; forEachCounter23650++) {
							var local3_Def_2527 = forEachSaver23650.values[forEachCounter23650];
						{
								__debugInfo = "64:\src\CompilerPasses\Preprocessor.gbas";
								if (func7_IsToken(local3_Def_2527.attr7_Key_Str)) {
									__debugInfo = "62:\src\CompilerPasses\Preprocessor.gbas";
									local4_doIt_2526 = 0;
									__debugInfo = "63:\src\CompilerPasses\Preprocessor.gbas";
									break;
									__debugInfo = "62:\src\CompilerPasses\Preprocessor.gbas";
								};
								__debugInfo = "64:\src\CompilerPasses\Preprocessor.gbas";
							}
							forEachSaver23650.values[forEachCounter23650] = local3_Def_2527;
						
						};
						__debugInfo = "66:\src\CompilerPasses\Preprocessor.gbas";
						func13_RemoveCurrent();
						__debugInfo = "67:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 66, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "69:\src\CompilerPasses\Preprocessor.gbas";
						func5_PreIf(local4_doIt_2526);
						__debugInfo = "59:\src\CompilerPasses\Preprocessor.gbas";
					} else {
						__debugInfo = "71:\src\CompilerPasses\Preprocessor.gbas";
						func13_RemoveCurrent();
						__debugInfo = "72:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 71, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "73:\src\CompilerPasses\Preprocessor.gbas";
						func5_PreIf(2);
						__debugInfo = "71:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "74:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("IF")) ? 1 : 0)) {
					__debugInfo = "107:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						var local6_Result_2528 = 0, local3_Pos_2529 = 0.0;
						__debugInfo = "78:\src\CompilerPasses\Preprocessor.gbas";
						local6_Result_2528 = 0;
						__debugInfo = "79:\src\CompilerPasses\Preprocessor.gbas";
						local3_Pos_2529 = global8_Compiler.attr11_currentPosi;
						__debugInfo = "82:\src\CompilerPasses\Preprocessor.gbas";
						{
							var Error_Str = "";
							__debugInfo = "84:\src\CompilerPasses\Preprocessor.gbas";
							try {
								__debugInfo = "81:\src\CompilerPasses\Preprocessor.gbas";
								local6_Result_2528 = ~~(func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(func10_Expression(0)).values[tmpPositionCache][0])));
								__debugInfo = "81:\src\CompilerPasses\Preprocessor.gbas";
							} catch (Error_Str) {
								if (Error_Str instanceof OTTException) Error_Str = Error_Str.getText(); else throwError(Error_Str);{
									__debugInfo = "83:\src\CompilerPasses\Preprocessor.gbas";
									func5_Error((((("Unable to evaluate IF (syntax error?) '") + (Error_Str))) + ("'")), 82, "src\CompilerPasses\Preprocessor.gbas");
									__debugInfo = "83:\src\CompilerPasses\Preprocessor.gbas";
								}
							};
							__debugInfo = "84:\src\CompilerPasses\Preprocessor.gbas";
						};
						__debugInfo = "85:\src\CompilerPasses\Preprocessor.gbas";
						global8_Compiler.attr11_currentPosi = ~~(((local3_Pos_2529) - (1)));
						__debugInfo = "86:\src\CompilerPasses\Preprocessor.gbas";
						func7_GetNext();
						__debugInfo = "90:\src\CompilerPasses\Preprocessor.gbas";
						while (((func7_IsToken("\n")) ? 0 : 1)) {
							__debugInfo = "89:\src\CompilerPasses\Preprocessor.gbas";
							func13_RemoveCurrent();
							__debugInfo = "89:\src\CompilerPasses\Preprocessor.gbas";
						};
						__debugInfo = "92:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 91, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "99:\src\CompilerPasses\Preprocessor.gbas";
						if ((((local6_Result_2528) == (1)) ? 1 : 0)) {
							__debugInfo = "96:\src\CompilerPasses\Preprocessor.gbas";
							func5_PreIf(1);
							__debugInfo = "96:\src\CompilerPasses\Preprocessor.gbas";
						} else {
							__debugInfo = "98:\src\CompilerPasses\Preprocessor.gbas";
							func5_PreIf(0);
							__debugInfo = "98:\src\CompilerPasses\Preprocessor.gbas";
						};
						__debugInfo = "78:\src\CompilerPasses\Preprocessor.gbas";
					} else {
						__debugInfo = "103:\src\CompilerPasses\Preprocessor.gbas";
						while (((func7_IsToken("\n")) ? 0 : 1)) {
							__debugInfo = "102:\src\CompilerPasses\Preprocessor.gbas";
							func13_RemoveCurrent();
							__debugInfo = "102:\src\CompilerPasses\Preprocessor.gbas";
						};
						__debugInfo = "104:\src\CompilerPasses\Preprocessor.gbas";
						func14_MatchAndRemove("\n", 103, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "106:\src\CompilerPasses\Preprocessor.gbas";
						func5_PreIf(2);
						__debugInfo = "103:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "107:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("WARNING")) ? 1 : 0)) {
					__debugInfo = "109:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "109:\src\CompilerPasses\Preprocessor.gbas";
						func7_Warning(func14_GetCurrent_Str());
						__debugInfo = "109:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "110:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "109:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("ERROR")) ? 1 : 0)) {
					__debugInfo = "112:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "112:\src\CompilerPasses\Preprocessor.gbas";
						func5_Error(func14_GetCurrent_Str(), 111, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "112:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "113:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "112:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("ELSE")) ? 1 : 0)) {
					__debugInfo = "115:\src\CompilerPasses\Preprocessor.gbas";
					return 1;
					__debugInfo = "115:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("ENDIF")) ? 1 : 0)) {
					__debugInfo = "117:\src\CompilerPasses\Preprocessor.gbas";
					return 2;
					__debugInfo = "117:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("OPTIMIZE")) ? 1 : 0)) {
					__debugInfo = "140:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "130:\src\CompilerPasses\Preprocessor.gbas";
						{
							var local17___SelectHelper37__2531 = "";
							__debugInfo = "130:\src\CompilerPasses\Preprocessor.gbas";
							local17___SelectHelper37__2531 = func14_GetCurrent_Str();
							__debugInfo = "139:\src\CompilerPasses\Preprocessor.gbas";
							if ((((local17___SelectHelper37__2531) == ("SIMPLE")) ? 1 : 0)) {
								__debugInfo = "132:\src\CompilerPasses\Preprocessor.gbas";
								global13_OptimizeLevel = 1;
								__debugInfo = "132:\src\CompilerPasses\Preprocessor.gbas";
							} else if ((((local17___SelectHelper37__2531) == ("AGGRESSIVE")) ? 1 : 0)) {
								__debugInfo = "134:\src\CompilerPasses\Preprocessor.gbas";
								global13_OptimizeLevel = 2;
								__debugInfo = "134:\src\CompilerPasses\Preprocessor.gbas";
							} else if ((((local17___SelectHelper37__2531) == ("NONE")) ? 1 : 0)) {
								__debugInfo = "136:\src\CompilerPasses\Preprocessor.gbas";
								global13_OptimizeLevel = 0;
								__debugInfo = "136:\src\CompilerPasses\Preprocessor.gbas";
							} else {
								__debugInfo = "138:\src\CompilerPasses\Preprocessor.gbas";
								func5_Error("Unknown optimization level", 137, "src\CompilerPasses\Preprocessor.gbas");
								__debugInfo = "138:\src\CompilerPasses\Preprocessor.gbas";
							};
							__debugInfo = "130:\src\CompilerPasses\Preprocessor.gbas";
						};
						__debugInfo = "130:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "141:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "140:\src\CompilerPasses\Preprocessor.gbas";
				} else if ((((local17___SelectHelper36__2521) == ("GRAPHICS")) ? 1 : 0)) {
					__debugInfo = "143:\src\CompilerPasses\Preprocessor.gbas";
					if (((param9_IgnoreAll) ? 0 : 1)) {
						__debugInfo = "143:\src\CompilerPasses\Preprocessor.gbas";
						global7_CONSOLE = 0;
						__debugInfo = "143:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "143:\src\CompilerPasses\Preprocessor.gbas";
				} else {
					__debugInfo = "149:\src\CompilerPasses\Preprocessor.gbas";
					func5_Error((((("Expecting preprocessor command got '") + (local7_Cur_Str_2520))) + ("'")), 148, "src\CompilerPasses\Preprocessor.gbas");
					__debugInfo = "149:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "21:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "152:\src\CompilerPasses\Preprocessor.gbas";
			func14_MatchAndRemove("\n", 151, "src\CompilerPasses\Preprocessor.gbas");
			__debugInfo = "18:\src\CompilerPasses\Preprocessor.gbas";
		} else {
			var local6_Is_Str_2532 = "";
			__debugInfo = "154:\src\CompilerPasses\Preprocessor.gbas";
			local6_Is_Str_2532 = func14_GetCurrent_Str();
			__debugInfo = "164:\src\CompilerPasses\Preprocessor.gbas";
			if ((((local6_Is_Str_2532) == ("_")) ? 1 : 0)) {
				__debugInfo = "156:\src\CompilerPasses\Preprocessor.gbas";
				func13_RemoveCurrent();
				__debugInfo = "157:\src\CompilerPasses\Preprocessor.gbas";
				func14_MatchAndRemove("\n", 156, "src\CompilerPasses\Preprocessor.gbas");
				__debugInfo = "156:\src\CompilerPasses\Preprocessor.gbas";
			} else {
				__debugInfo = "163:\src\CompilerPasses\Preprocessor.gbas";
				if (param9_IgnoreAll) {
					__debugInfo = "160:\src\CompilerPasses\Preprocessor.gbas";
					func13_RemoveCurrent();
					__debugInfo = "160:\src\CompilerPasses\Preprocessor.gbas";
				} else {
					__debugInfo = "162:\src\CompilerPasses\Preprocessor.gbas";
					func7_GetNext();
					__debugInfo = "162:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "163:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "154:\src\CompilerPasses\Preprocessor.gbas";
		};
		__debugInfo = "167:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "168:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "165:\src\CompilerPasses\Preprocessor.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func10_PreCommand = window['func10_PreCommand'];
window['func5_PreIf'] = function(param4_doIt) {
	stackPush("function: PreIf", __debugInfo);
	try {
		var local8_Text_Str_2534 = "";
		__debugInfo = "189:\src\CompilerPasses\Preprocessor.gbas";
		if ((((param4_doIt) == (0)) ? 1 : 0)) {
			__debugInfo = "177:\src\CompilerPasses\Preprocessor.gbas";
			if ((((func7_PreSkip(1)) == (1)) ? 1 : 0)) {
				__debugInfo = "174:\src\CompilerPasses\Preprocessor.gbas";
				func14_MatchAndRemove("\n", 173, "src\CompilerPasses\Preprocessor.gbas");
				__debugInfo = "176:\src\CompilerPasses\Preprocessor.gbas";
				if ((((func7_PreSkip(0)) == (1)) ? 1 : 0)) {
					__debugInfo = "176:\src\CompilerPasses\Preprocessor.gbas";
					func5_Error("Expecting '?ENDIF'", 175, "src\CompilerPasses\Preprocessor.gbas");
					__debugInfo = "176:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "174:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "177:\src\CompilerPasses\Preprocessor.gbas";
		} else if ((((param4_doIt) == (1)) ? 1 : 0)) {
			__debugInfo = "181:\src\CompilerPasses\Preprocessor.gbas";
			if ((((func7_PreSkip(0)) == (1)) ? 1 : 0)) {
				__debugInfo = "180:\src\CompilerPasses\Preprocessor.gbas";
				if ((((func7_PreSkip(1)) == (1)) ? 1 : 0)) {
					__debugInfo = "180:\src\CompilerPasses\Preprocessor.gbas";
					func5_Error("Expectiong '?ENDIF'", 179, "src\CompilerPasses\Preprocessor.gbas");
					__debugInfo = "180:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "180:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "181:\src\CompilerPasses\Preprocessor.gbas";
		} else if ((((param4_doIt) == (2)) ? 1 : 0)) {
			__debugInfo = "186:\src\CompilerPasses\Preprocessor.gbas";
			if ((((func7_PreSkip(1)) == (1)) ? 1 : 0)) {
				__debugInfo = "185:\src\CompilerPasses\Preprocessor.gbas";
				if ((((func7_PreSkip(1)) == (1)) ? 1 : 0)) {
					__debugInfo = "185:\src\CompilerPasses\Preprocessor.gbas";
					func5_Error("Expecting '?ENDIF'", 184, "src\CompilerPasses\Preprocessor.gbas");
					__debugInfo = "185:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "185:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "186:\src\CompilerPasses\Preprocessor.gbas";
		} else {
			__debugInfo = "188:\src\CompilerPasses\Preprocessor.gbas";
			func5_Error("Internal error (unknown preif)", 187, "src\CompilerPasses\Preprocessor.gbas");
			__debugInfo = "188:\src\CompilerPasses\Preprocessor.gbas";
		};
		__debugInfo = "190:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "189:\src\CompilerPasses\Preprocessor.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func5_PreIf = window['func5_PreIf'];
window['func7_PreSkip'] = function(param9_RemoveAll) {
	stackPush("function: PreSkip", __debugInfo);
	try {
		__debugInfo = "198:\src\CompilerPasses\Preprocessor.gbas";
		while (func8_EOFParse()) {
			var local1_E_2536 = 0;
			__debugInfo = "194:\src\CompilerPasses\Preprocessor.gbas";
			local1_E_2536 = func10_PreCommand(param9_RemoveAll);
			__debugInfo = "197:\src\CompilerPasses\Preprocessor.gbas";
			if ((((local1_E_2536) > (0)) ? 1 : 0)) {
				__debugInfo = "196:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(local1_E_2536);
				__debugInfo = "196:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "194:\src\CompilerPasses\Preprocessor.gbas";
		};
		__debugInfo = "199:\src\CompilerPasses\Preprocessor.gbas";
		func5_Error("Unexpected End Of File (maybe missing ?ENDIF)", 198, "src\CompilerPasses\Preprocessor.gbas");
		__debugInfo = "200:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "198:\src\CompilerPasses\Preprocessor.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func7_PreSkip = window['func7_PreSkip'];
window['func13_CalculateTree'] = function(param4_expr) {
	stackPush("function: CalculateTree", __debugInfo);
	try {
		__debugInfo = "203:\src\CompilerPasses\Preprocessor.gbas";
		{
			var local17___SelectHelper38__2538 = 0;
			__debugInfo = "203:\src\CompilerPasses\Preprocessor.gbas";
			local17___SelectHelper38__2538 = param4_expr.attr3_Typ;
			__debugInfo = "247:\src\CompilerPasses\Preprocessor.gbas";
			if ((((local17___SelectHelper38__2538) == (~~(3))) ? 1 : 0)) {
				__debugInfo = "205:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(param4_expr.attr6_intval);
				__debugInfo = "205:\src\CompilerPasses\Preprocessor.gbas";
			} else if ((((local17___SelectHelper38__2538) == (~~(4))) ? 1 : 0)) {
				__debugInfo = "207:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(param4_expr.attr8_floatval);
				__debugInfo = "207:\src\CompilerPasses\Preprocessor.gbas";
			} else if ((((local17___SelectHelper38__2538) == (~~(46))) ? 1 : 0)) {
				__debugInfo = "209:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(unref(((func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))) ? 0 : 1)));
				__debugInfo = "209:\src\CompilerPasses\Preprocessor.gbas";
			} else if ((((local17___SelectHelper38__2538) == (~~(15))) ? 1 : 0)) {
				__debugInfo = "211:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(INTEGER(func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0]))));
				__debugInfo = "211:\src\CompilerPasses\Preprocessor.gbas";
			} else if ((((local17___SelectHelper38__2538) == (~~(16))) ? 1 : 0)) {
				__debugInfo = "213:\src\CompilerPasses\Preprocessor.gbas";
				return tryClone(func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_expr).values[tmpPositionCache][0])));
				__debugInfo = "213:\src\CompilerPasses\Preprocessor.gbas";
			} else if ((((local17___SelectHelper38__2538) == (~~(1))) ? 1 : 0)) {
				var local4_Left_2539 = 0.0, local5_Right_2540 = 0.0;
				__debugInfo = "215:\src\CompilerPasses\Preprocessor.gbas";
				local4_Left_2539 = func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr4_Left).values[tmpPositionCache][0]));
				__debugInfo = "216:\src\CompilerPasses\Preprocessor.gbas";
				local5_Right_2540 = func13_CalculateTree(unref(global5_Exprs_ref[0].arrAccess(param4_expr.attr5_Right).values[tmpPositionCache][0]));
				__debugInfo = "217:\src\CompilerPasses\Preprocessor.gbas";
				{
					var local17___SelectHelper39__2541 = "";
					__debugInfo = "217:\src\CompilerPasses\Preprocessor.gbas";
					local17___SelectHelper39__2541 = global9_Operators_ref[0].arrAccess(param4_expr.attr2_Op).values[tmpPositionCache][0].attr7_Sym_Str;
					__debugInfo = "244:\src\CompilerPasses\Preprocessor.gbas";
					if ((((local17___SelectHelper39__2541) == ("+")) ? 1 : 0)) {
						__debugInfo = "219:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone(((local4_Left_2539) + (local5_Right_2540)));
						__debugInfo = "219:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("-")) ? 1 : 0)) {
						__debugInfo = "221:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone(((local4_Left_2539) - (local5_Right_2540)));
						__debugInfo = "221:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("*")) ? 1 : 0)) {
						__debugInfo = "223:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone(((local4_Left_2539) * (local5_Right_2540)));
						__debugInfo = "223:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("/")) ? 1 : 0)) {
						__debugInfo = "225:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone(((local4_Left_2539) / (local5_Right_2540)));
						__debugInfo = "225:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("^")) ? 1 : 0)) {
						__debugInfo = "227:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone(POW(local4_Left_2539, local5_Right_2540));
						__debugInfo = "227:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("=")) ? 1 : 0)) {
						__debugInfo = "229:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) == (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "229:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == (">")) ? 1 : 0)) {
						__debugInfo = "231:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) > (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "231:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("<")) ? 1 : 0)) {
						__debugInfo = "233:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) < (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "233:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("<=")) ? 1 : 0)) {
						__debugInfo = "235:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) <= (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "235:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == (">=")) ? 1 : 0)) {
						__debugInfo = "237:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) >= (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "237:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("AND")) ? 1 : 0)) {
						__debugInfo = "239:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) && (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "239:\src\CompilerPasses\Preprocessor.gbas";
					} else if ((((local17___SelectHelper39__2541) == ("OR")) ? 1 : 0)) {
						__debugInfo = "241:\src\CompilerPasses\Preprocessor.gbas";
						return tryClone((((local4_Left_2539) || (local5_Right_2540)) ? 1 : 0));
						__debugInfo = "241:\src\CompilerPasses\Preprocessor.gbas";
					} else {
						__debugInfo = "243:\src\CompilerPasses\Preprocessor.gbas";
						func5_Error("Internal error (unimplemented operator!)", 242, "src\CompilerPasses\Preprocessor.gbas");
						__debugInfo = "243:\src\CompilerPasses\Preprocessor.gbas";
					};
					__debugInfo = "217:\src\CompilerPasses\Preprocessor.gbas";
				};
				__debugInfo = "215:\src\CompilerPasses\Preprocessor.gbas";
			} else {
				__debugInfo = "246:\src\CompilerPasses\Preprocessor.gbas";
				throw new OTTException((((("Unable to resolve '") + (CAST2STRING(param4_expr.attr3_Typ)))) + ("'")), "\src\CompilerPasses\Preprocessor.gbas", 246);
				__debugInfo = "246:\src\CompilerPasses\Preprocessor.gbas";
			};
			__debugInfo = "203:\src\CompilerPasses\Preprocessor.gbas";
		};
		__debugInfo = "248:\src\CompilerPasses\Preprocessor.gbas";
		return 0;
		__debugInfo = "203:\src\CompilerPasses\Preprocessor.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func13_CalculateTree = window['func13_CalculateTree'];
window['func12_DoTarget_Str'] = function(param8_Name_Str) {
	stackPush("function: DoTarget_Str", __debugInfo);
	try {
		var local10_Output_Str_2543 = "";
		__debugInfo = "40:\src\Target.gbas";
		global8_Compiler.attr14_errorState_Str = ((((" (target '") + (param8_Name_Str))) + ("' error)"));
		__debugInfo = "41:\src\Target.gbas";
		global10_Target_Str = param8_Name_Str;
		__debugInfo = "42:\src\Target.gbas";
		global13_SettingIn_Str = "";
		__debugInfo = "44:\src\Target.gbas";
		REDIM(global9_Templates, [0], new type9_TTemplate() );
		__debugInfo = "45:\src\Target.gbas";
		REDIM(global9_Libraries, [0], new type8_TLibrary() );
		__debugInfo = "46:\src\Target.gbas";
		REDIM(global10_Blacklists, [0], new type10_TBlackList() );
		__debugInfo = "47:\src\Target.gbas";
		REDIM(global7_Actions, [0], new type7_TAction() );
		__debugInfo = "72:\src\Target.gbas";
		local10_Output_Str_2543 = "";
		__debugInfo = "80:\src\Target.gbas";
		var forEachSaver24262 = global10_Generators;
		for(var forEachCounter24262 = 0 ; forEachCounter24262 < forEachSaver24262.values.length ; forEachCounter24262++) {
			var local1_G_2544 = forEachSaver24262.values[forEachCounter24262];
		{
				__debugInfo = "79:\src\Target.gbas";
				if ((((UCASE_Str(local1_G_2544.attr8_Name_Str)) == (UCASE_Str(global8_Lang_Str))) ? 1 : 0)) {
					__debugInfo = "75:\src\Target.gbas";
					global8_Compiler.attr14_errorState_Str = " (generate error)";
					__debugInfo = "76:\src\Target.gbas";
					local10_Output_Str_2543 = (("") + (CAST2STRING(local1_G_2544.attr8_genProto())));
					__debugInfo = "77:\src\Target.gbas";
					global8_Compiler.attr14_errorState_Str = ((((" (target '") + (param8_Name_Str))) + ("' error)"));
					__debugInfo = "78:\src\Target.gbas";
					break;
					__debugInfo = "75:\src\Target.gbas";
				};
				__debugInfo = "79:\src\Target.gbas";
			}
			forEachSaver24262.values[forEachCounter24262] = local1_G_2544;
		
		};
		__debugInfo = "81:\src\Target.gbas";
		if ((((local10_Output_Str_2543) == ("")) ? 1 : 0)) {
			__debugInfo = "81:\src\Target.gbas";
			func5_Error("Empty output!", 80, "src\Target.gbas");
			__debugInfo = "81:\src\Target.gbas";
		};
		__debugInfo = "202:\src\Target.gbas";
		return tryClone(local10_Output_Str_2543);
		__debugInfo = "203:\src\Target.gbas";
		return "";
		__debugInfo = "40:\src\Target.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func12_DoTarget_Str = window['func12_DoTarget_Str'];
window['func11_SetupTarget'] = function(param8_Name_Str) {
	stackPush("function: SetupTarget", __debugInfo);
	try {
		__debugInfo = "206:\src\Target.gbas";
		global13_SettingIn_Str = "";
		__debugInfo = "207:\src\Target.gbas";
		global10_Target_Str = param8_Name_Str;
		__debugInfo = "214:\src\Target.gbas";
		if (global7_CONSOLE) {
			__debugInfo = "211:\src\Target.gbas";
			global8_Mode_Str = "console";
			__debugInfo = "211:\src\Target.gbas";
		} else {
			__debugInfo = "213:\src\Target.gbas";
			global8_Mode_Str = "2d";
			__debugInfo = "213:\src\Target.gbas";
		};
		__debugInfo = "224:\src\Target.gbas";
		global10_Target_Str = "HTML5";
		__debugInfo = "225:\src\Target.gbas";
		global8_Lang_Str = "js";
		__debugInfo = "226:\src\Target.gbas";
		RegisterDefine(UCASE_Str(global10_Target_Str), "1");
		__debugInfo = "227:\src\Target.gbas";
		RegisterDefine("JS", "1");
		__debugInfo = "230:\src\Target.gbas";
		return 0;
		__debugInfo = "206:\src\Target.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
func11_SetupTarget = window['func11_SetupTarget'];
window['method9_type3_XML_7_ReadXML'] = function(param8_File_Str, param5_event, param4_self) {
	stackPush("method: ReadXML", __debugInfo);
	try {
		__debugInfo = "18:\src\Utils\XMLReader.gbas";
		param4_self.attr5_Event = param5_event;
		__debugInfo = "19:\src\Utils\XMLReader.gbas";
		param4_self.attr8_Text_Str = func12_LoadFile_Str(param8_File_Str);
		__debugInfo = "20:\src\Utils\XMLReader.gbas";
		param4_self.attr8_Position = 0;
		__debugInfo = "22:\src\Utils\XMLReader.gbas";
		(param4_self).SkipWhitespaces();
		__debugInfo = "26:\src\Utils\XMLReader.gbas";
		while (((((param4_self).Get_Str()) != ("<")) ? 1 : 0)) {
			__debugInfo = "25:\src\Utils\XMLReader.gbas";
			param4_self.attr8_Position+=1;
			__debugInfo = "25:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "33:\src\Utils\XMLReader.gbas";
		if ((((MID_Str(param4_self.attr8_Text_Str, param4_self.attr8_Position, 2)) == ("<?")) ? 1 : 0)) {
			__debugInfo = "31:\src\Utils\XMLReader.gbas";
			while (((((param4_self).Get_Str()) != (">")) ? 1 : 0)) {
				__debugInfo = "30:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "30:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "32:\src\Utils\XMLReader.gbas";
			param4_self.attr8_Position+=1;
			__debugInfo = "31:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "34:\src\Utils\XMLReader.gbas";
		(param4_self).SkipWhitespaces();
		__debugInfo = "37:\src\Utils\XMLReader.gbas";
		{
			var Err_Str = "";
			__debugInfo = "45:\src\Utils\XMLReader.gbas";
			try {
				__debugInfo = "36:\src\Utils\XMLReader.gbas";
				(param4_self).ParseNode();
				__debugInfo = "36:\src\Utils\XMLReader.gbas";
			} catch (Err_Str) {
				if (Err_Str instanceof OTTException) Err_Str = Err_Str.getText(); else throwError(Err_Str);{
					__debugInfo = "44:\src\Utils\XMLReader.gbas";
					if ((((Err_Str) == ("EXIT")) ? 1 : 0)) {
						
					} else {
						__debugInfo = "40:\src\Utils\XMLReader.gbas";
						STDOUT(Err_Str);
						__debugInfo = "40:\src\Utils\XMLReader.gbas";
					};
					__debugInfo = "44:\src\Utils\XMLReader.gbas";
				}
			};
			__debugInfo = "45:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "46:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "18:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_7_ReadXML = window['method9_type3_XML_7_ReadXML'];
window['method9_type3_XML_10_ParseLayer'] = function(param4_self) {
	stackPush("method: ParseLayer", __debugInfo);
	try {
		__debugInfo = "49:\src\Utils\XMLReader.gbas";
		(param4_self).SkipWhitespaces();
		__debugInfo = "64:\src\Utils\XMLReader.gbas";
		while (((((param4_self).Get_Str()) == ("<")) ? 1 : 0)) {
			var local8_HasSlash_2553 = 0;
			__debugInfo = "53:\src\Utils\XMLReader.gbas";
			local8_HasSlash_2553 = 0;
			__debugInfo = "54:\src\Utils\XMLReader.gbas";
			param4_self.attr8_Position+=1;
			__debugInfo = "55:\src\Utils\XMLReader.gbas";
			(param4_self).SkipWhitespaces();
			__debugInfo = "58:\src\Utils\XMLReader.gbas";
			if (((((param4_self).Get_Str()) == ("/")) ? 1 : 0)) {
				__debugInfo = "57:\src\Utils\XMLReader.gbas";
				local8_HasSlash_2553 = 1;
				__debugInfo = "57:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "61:\src\Utils\XMLReader.gbas";
			while (((((param4_self).Get_Str()) != ("<")) ? 1 : 0)) {
				__debugInfo = "60:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=-1;
				__debugInfo = "60:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "62:\src\Utils\XMLReader.gbas";
			if (local8_HasSlash_2553) {
				__debugInfo = "62:\src\Utils\XMLReader.gbas";
				return tryClone(0);
				__debugInfo = "62:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "63:\src\Utils\XMLReader.gbas";
			(param4_self).ParseNode();
			__debugInfo = "53:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "65:\src\Utils\XMLReader.gbas";
		return tryClone(1);
		__debugInfo = "66:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "49:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_10_ParseLayer = window['method9_type3_XML_10_ParseLayer'];
window['method9_type3_XML_9_ParseNode'] = function(param4_self) {
	stackPush("method: ParseNode", __debugInfo);
	try {
		var local8_Name_Str_2556 = "", local10_Attributes_2557 = new OTTArray(new type12_xmlAttribute());
		__debugInfo = "69:\src\Utils\XMLReader.gbas";
		if (((((param4_self).Get_Str()) != ("<")) ? 1 : 0)) {
			__debugInfo = "69:\src\Utils\XMLReader.gbas";
			throw new OTTException("XML Error - Expecting '<'", "\src\Utils\XMLReader.gbas", 69);
			__debugInfo = "69:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "70:\src\Utils\XMLReader.gbas";
		param4_self.attr8_Position+=1;
		__debugInfo = "71:\src\Utils\XMLReader.gbas";
		(param4_self).SkipWhitespaces();
		__debugInfo = "73:\src\Utils\XMLReader.gbas";
		local8_Name_Str_2556 = (param4_self).ParseIdentifier_Str();
		__debugInfo = "104:\src\Utils\XMLReader.gbas";
		if (((((param4_self).Get_Str()) == (" ")) ? 1 : 0)) {
			__debugInfo = "78:\src\Utils\XMLReader.gbas";
			(param4_self).SkipWhitespaces();
			__debugInfo = "103:\src\Utils\XMLReader.gbas";
			while ((((((((param4_self).Get_Str()) != ("/")) ? 1 : 0)) && (((((param4_self).Get_Str()) != (">")) ? 1 : 0))) ? 1 : 0)) {
				var local3_Att_2558 = new type12_xmlAttribute(), local3_Pos_2559 = 0;
				__debugInfo = "80:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "83:\src\Utils\XMLReader.gbas";
				local3_Att_2558.attr8_Name_Str = (param4_self).ParseIdentifier_Str();
				__debugInfo = "84:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "86:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != ("=")) ? 1 : 0)) {
					__debugInfo = "86:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Expecting '='", "\src\Utils\XMLReader.gbas", 86);
					__debugInfo = "86:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "87:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "89:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "91:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != ("\"")) ? 1 : 0)) {
					__debugInfo = "91:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Expecting '\"'", "\src\Utils\XMLReader.gbas", 91);
					__debugInfo = "91:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "93:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "94:\src\Utils\XMLReader.gbas";
				local3_Pos_2559 = param4_self.attr8_Position;
				__debugInfo = "97:\src\Utils\XMLReader.gbas";
				while (((((param4_self).Get_Str()) != ("\"")) ? 1 : 0)) {
					__debugInfo = "96:\src\Utils\XMLReader.gbas";
					param4_self.attr8_Position+=1;
					__debugInfo = "96:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "98:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "99:\src\Utils\XMLReader.gbas";
				local3_Att_2558.attr9_Value_Str = MID_Str(param4_self.attr8_Text_Str, local3_Pos_2559, ((((param4_self.attr8_Position) - (local3_Pos_2559))) - (1)));
				__debugInfo = "100:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "102:\src\Utils\XMLReader.gbas";
				DIMPUSH(local10_Attributes_2557, local3_Att_2558);
				__debugInfo = "80:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "78:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "106:\src\Utils\XMLReader.gbas";
		param4_self.attr5_Event(local8_Name_Str_2556, local10_Attributes_2557);
		__debugInfo = "108:\src\Utils\XMLReader.gbas";
		{
			var local17___SelectHelper40__2560 = "";
			__debugInfo = "108:\src\Utils\XMLReader.gbas";
			local17___SelectHelper40__2560 = (param4_self).Get_Str();
			__debugInfo = "135:\src\Utils\XMLReader.gbas";
			if ((((local17___SelectHelper40__2560) == (">")) ? 1 : 0)) {
				__debugInfo = "110:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "111:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "113:\src\Utils\XMLReader.gbas";
				if ((param4_self).ParseLayer()) {
					__debugInfo = "113:\src\Utils\XMLReader.gbas";
					throw new OTTException((((("XML Error - Unexpected End of File, expecting </") + (local8_Name_Str_2556))) + (">")), "\src\Utils\XMLReader.gbas", 113);
					__debugInfo = "113:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "116:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "117:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != ("<")) ? 1 : 0)) {
					__debugInfo = "117:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Expecting '<'", "\src\Utils\XMLReader.gbas", 117);
					__debugInfo = "117:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "118:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "119:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "120:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != ("/")) ? 1 : 0)) {
					__debugInfo = "120:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Expecting '/'", "\src\Utils\XMLReader.gbas", 120);
					__debugInfo = "120:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "121:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "123:\src\Utils\XMLReader.gbas";
				if ((((local8_Name_Str_2556) != ((param4_self).ParseIdentifier_Str())) ? 1 : 0)) {
					__debugInfo = "123:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Nodes do not match", "\src\Utils\XMLReader.gbas", 123);
					__debugInfo = "123:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "124:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != (">")) ? 1 : 0)) {
					__debugInfo = "124:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error Expecting '>'", "\src\Utils\XMLReader.gbas", 124);
					__debugInfo = "124:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "126:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "127:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "110:\src\Utils\XMLReader.gbas";
			} else if ((((local17___SelectHelper40__2560) == ("/")) ? 1 : 0)) {
				__debugInfo = "129:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "130:\src\Utils\XMLReader.gbas";
				if (((((param4_self).Get_Str()) != (">")) ? 1 : 0)) {
					__debugInfo = "130:\src\Utils\XMLReader.gbas";
					throw new OTTException("XML Error - Expecting '>'", "\src\Utils\XMLReader.gbas", 130);
					__debugInfo = "130:\src\Utils\XMLReader.gbas";
				};
				__debugInfo = "131:\src\Utils\XMLReader.gbas";
				param4_self.attr8_Position+=1;
				__debugInfo = "132:\src\Utils\XMLReader.gbas";
				(param4_self).SkipWhitespaces();
				__debugInfo = "129:\src\Utils\XMLReader.gbas";
			} else {
				__debugInfo = "134:\src\Utils\XMLReader.gbas";
				throw new OTTException("XML Error", "\src\Utils\XMLReader.gbas", 134);
				__debugInfo = "134:\src\Utils\XMLReader.gbas";
			};
			__debugInfo = "108:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "136:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "69:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_9_ParseNode = window['method9_type3_XML_9_ParseNode'];
window['method9_type3_XML_19_ParseIdentifier_Str'] = function(param4_self) {
	stackPush("method: ParseIdentifier_Str", __debugInfo);
	try {
		var local3_Pos_2563 = 0;
		__debugInfo = "139:\src\Utils\XMLReader.gbas";
		local3_Pos_2563 = param4_self.attr8_Position;
		__debugInfo = "142:\src\Utils\XMLReader.gbas";
		while ((((((((((((((param4_self).Get_Str()) != (" ")) ? 1 : 0)) && (((((param4_self).Get_Str()) != ("/")) ? 1 : 0))) ? 1 : 0)) && (((((param4_self).Get_Str()) != (">")) ? 1 : 0))) ? 1 : 0)) && (((((param4_self).Get_Str()) != ("=")) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "141:\src\Utils\XMLReader.gbas";
			param4_self.attr8_Position+=1;
			__debugInfo = "141:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "143:\src\Utils\XMLReader.gbas";
		if ((((param4_self.attr8_Position) >= ((param4_self.attr8_Text_Str).length)) ? 1 : 0)) {
			__debugInfo = "143:\src\Utils\XMLReader.gbas";
			throw new OTTException("XML Error", "\src\Utils\XMLReader.gbas", 143);
			__debugInfo = "143:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "144:\src\Utils\XMLReader.gbas";
		return tryClone(UCASE_Str(MID_Str(param4_self.attr8_Text_Str, local3_Pos_2563, ((param4_self.attr8_Position) - (local3_Pos_2563)))));
		__debugInfo = "145:\src\Utils\XMLReader.gbas";
		return "";
		__debugInfo = "139:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_19_ParseIdentifier_Str = window['method9_type3_XML_19_ParseIdentifier_Str'];
window['method9_type3_XML_7_Get_Str'] = function(param4_self) {
	stackPush("method: Get_Str", __debugInfo);
	try {
		__debugInfo = "153:\src\Utils\XMLReader.gbas";
		if ((((param4_self.attr8_Position) >= ((param4_self.attr8_Text_Str).length)) ? 1 : 0)) {
			__debugInfo = "149:\src\Utils\XMLReader.gbas";
			throw new OTTException("XML Error - Unexpected End Of File", "\src\Utils\XMLReader.gbas", 149);
			__debugInfo = "149:\src\Utils\XMLReader.gbas";
		} else {
			__debugInfo = "152:\src\Utils\XMLReader.gbas";
			return tryClone(MID_Str(param4_self.attr8_Text_Str, param4_self.attr8_Position, 1));
			__debugInfo = "152:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "154:\src\Utils\XMLReader.gbas";
		return "";
		__debugInfo = "153:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_7_Get_Str = window['method9_type3_XML_7_Get_Str'];
window['method9_type3_XML_15_SkipWhitespaces'] = function(param4_self) {
	stackPush("method: SkipWhitespaces", __debugInfo);
	try {
		__debugInfo = "159:\src\Utils\XMLReader.gbas";
		while (((((((param4_self.attr8_Position) < ((param4_self.attr8_Text_Str).length)) ? 1 : 0)) && ((((((((((((((param4_self).Get_Str()) == (" ")) ? 1 : 0)) || (((((param4_self).Get_Str()) == ("\n")) ? 1 : 0))) ? 1 : 0)) || (((((param4_self).Get_Str()) == (CHR_Str(13))) ? 1 : 0))) ? 1 : 0)) || (((((param4_self).Get_Str()) == ("\t")) ? 1 : 0))) ? 1 : 0))) ? 1 : 0)) {
			__debugInfo = "158:\src\Utils\XMLReader.gbas";
			param4_self.attr8_Position+=1;
			__debugInfo = "158:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "160:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "159:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method9_type3_XML_15_SkipWhitespaces = window['method9_type3_XML_15_SkipWhitespaces'];
window['method13_type7_TObject_12_ToString_Str'] = function(param4_self) {
	stackPush("method: ToString_Str", __debugInfo);
	try {
		__debugInfo = "177:\src\Utils\XMLReader.gbas";
		return "Object";
		__debugInfo = "178:\src\Utils\XMLReader.gbas";
		return "";
		__debugInfo = "177:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_TObject_12_ToString_Str = window['method13_type7_TObject_12_ToString_Str'];
window['method13_type7_TObject_6_Equals'] = function(param3_Obj, param4_self) {
	stackPush("method: Equals", __debugInfo);
	try {
		__debugInfo = "184:\src\Utils\XMLReader.gbas";
		if ((((param3_Obj) == (param4_self)) ? 1 : 0)) {
			__debugInfo = "181:\src\Utils\XMLReader.gbas";
			return 1;
			__debugInfo = "181:\src\Utils\XMLReader.gbas";
		} else {
			__debugInfo = "183:\src\Utils\XMLReader.gbas";
			return tryClone(0);
			__debugInfo = "183:\src\Utils\XMLReader.gbas";
		};
		__debugInfo = "185:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "184:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_TObject_6_Equals = window['method13_type7_TObject_6_Equals'];
window['method13_type7_TObject_10_ToHashCode'] = function(param4_self) {
	stackPush("method: ToHashCode", __debugInfo);
	try {
		__debugInfo = "187:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "188:\src\Utils\XMLReader.gbas";
		return 0;
		__debugInfo = "187:\src\Utils\XMLReader.gbas";
	} catch(ex) {
		if (isKnownException(ex)) throw ex;
		alert(formatError(ex));
		END();
	} finally {
		stackPop();
	}
	
};
method13_type7_TObject_10_ToHashCode = window['method13_type7_TObject_10_ToHashCode'];
window['Lang_Generator_Str'] = function() {
	return function() { throwError("NullPrototypeException"); };
};
Lang_Generator_Str = window['Lang_Generator_Str'];
window['XMLEvent'] = function() {
	return function() { throwError("NullPrototypeException"); };
};
XMLEvent = window['XMLEvent'];
var vtbl_type9_TCompiler = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type9_TCompiler'] = function() {
	this.attr8_Code_Str = "";
	this.attr6_Tokens = new OTTArray(new type5_Token());
	this.attr11_currentPosi = 0;
	this.attr11_GlobalFuncs = new type7_HashMap();
	this.attr5_Funcs_ref = [new OTTArray([new type14_IdentifierFunc()])];
	this.attr7_Globals = new OTTArray(0);
	this.attr5_Types_ref = [new OTTArray([new type14_IdentifierType()])];
	this.attr5_Varis_ref = [new OTTArray([new type14_IdentifierVari()])];
	this.attr13_protoCheckers = new OTTArray(new type12_ProtoChecker());
	this.attr10_DataBlocks = new OTTArray(new type9_DataBlock());
	this.attr9_MainScope = 0;
	this.attr12_CurrentScope = 0;
	this.attr14_ImportantScope = 0;
	this.attr11_currentFunc = 0;
	this.attr18_currentForEach_Str = "";
	this.attr6_inLoop = 0;
	this.attr13_LastMaxTokens = 0;
	this.attr8_WasError = 0;
	this.attr7_HasGoto = 0;
	this.attr14_errorState_Str = "";
	this.attr7_Exports = new OTTArray(new type7_TExport());
	this.attr11_LastTokenID = 0;
	this.attr8_GetIdent = 0;
	this.vtbl = vtbl_type9_TCompiler;
	this.attr12_CurrentScope = -(1);
	this.attr14_ImportantScope = -(1);
	this.attr11_currentFunc = -(1);
	this.attr8_WasError = 0;
	this.attr7_HasGoto = 0;
	this.attr14_errorState_Str = "";
	this.attr11_LastTokenID = 0;
	this.attr8_GetIdent = 0;
	return this;
	
};
window['type9_TCompiler'].prototype.clone = function() {
	var other = new type9_TCompiler();
	other.attr8_Code_Str = this.attr8_Code_Str;
	other.attr6_Tokens = tryClone(this.attr6_Tokens);
	other.attr11_currentPosi = this.attr11_currentPosi;
	other.attr11_GlobalFuncs = tryClone(this.attr11_GlobalFuncs);
	other.attr5_Funcs_ref = tryClone(this.attr5_Funcs_ref);
	other.attr7_Globals = tryClone(this.attr7_Globals);
	other.attr5_Types_ref = tryClone(this.attr5_Types_ref);
	other.attr5_Varis_ref = tryClone(this.attr5_Varis_ref);
	other.attr13_protoCheckers = tryClone(this.attr13_protoCheckers);
	other.attr10_DataBlocks = tryClone(this.attr10_DataBlocks);
	other.attr9_MainScope = this.attr9_MainScope;
	other.attr12_CurrentScope = this.attr12_CurrentScope;
	other.attr14_ImportantScope = this.attr14_ImportantScope;
	other.attr11_currentFunc = this.attr11_currentFunc;
	other.attr18_currentForEach_Str = this.attr18_currentForEach_Str;
	other.attr6_inLoop = this.attr6_inLoop;
	other.attr13_LastMaxTokens = this.attr13_LastMaxTokens;
	other.attr8_WasError = this.attr8_WasError;
	other.attr7_HasGoto = this.attr7_HasGoto;
	other.attr14_errorState_Str = this.attr14_errorState_Str;
	other.attr7_Exports = tryClone(this.attr7_Exports);
	other.attr11_LastTokenID = this.attr11_LastTokenID;
	other.attr8_GetIdent = this.attr8_GetIdent;
	other.vtbl = this.vtbl;
	return other;
};
type9_TCompiler = window['type9_TCompiler'];
type9_TCompiler.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type9_TCompiler.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type9_TCompiler.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type14_IdentifierFunc = {
	Save: method21_type14_IdentifierFunc_4_Save, 
	Load: method21_type14_IdentifierFunc_4_Load, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type14_IdentifierFunc'] = function() {
	this.attr9_OName_Str = "";
	this.attr8_Name_Str = "";
	this.attr6_Params = new OTTArray(0);
	this.attr10_CopyParams = new OTTArray(0);
	this.attr7_Statics = new OTTArray(0);
	this.attr8_datatype = new type8_Datatype();
	this.attr6_Native = 0;
	this.attr3_Scp = 0;
	this.attr2_ID = 0;
	this.attr3_Typ = 0;
	this.attr3_Tok = 0;
	this.attr10_PlzCompile = 0;
	this.attr6_HasRef = 0;
	this.attr15_UsedAsPrototype = 0;
	this.attr6_MyType = 0;
	this.attr7_SelfVar = 0;
	this.attr10_IsAbstract = 0;
	this.attr10_IsCallback = 0;
	this.vtbl = vtbl_type14_IdentifierFunc;
	this.attr3_Scp = -(1);
	this.attr6_HasRef = 0;
	this.attr15_UsedAsPrototype = 0;
	this.attr6_MyType = -(1);
	this.attr7_SelfVar = -(1);
	this.attr10_IsCallback = 0;
	return this;
	
};
window['type14_IdentifierFunc'].prototype.clone = function() {
	var other = new type14_IdentifierFunc();
	other.attr9_OName_Str = this.attr9_OName_Str;
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr6_Params = tryClone(this.attr6_Params);
	other.attr10_CopyParams = tryClone(this.attr10_CopyParams);
	other.attr7_Statics = tryClone(this.attr7_Statics);
	other.attr8_datatype = tryClone(this.attr8_datatype);
	other.attr6_Native = this.attr6_Native;
	other.attr3_Scp = this.attr3_Scp;
	other.attr2_ID = this.attr2_ID;
	other.attr3_Typ = this.attr3_Typ;
	other.attr3_Tok = this.attr3_Tok;
	other.attr10_PlzCompile = this.attr10_PlzCompile;
	other.attr6_HasRef = this.attr6_HasRef;
	other.attr15_UsedAsPrototype = this.attr15_UsedAsPrototype;
	other.attr6_MyType = this.attr6_MyType;
	other.attr7_SelfVar = this.attr7_SelfVar;
	other.attr10_IsAbstract = this.attr10_IsAbstract;
	other.attr10_IsCallback = this.attr10_IsCallback;
	other.vtbl = this.vtbl;
	return other;
};
type14_IdentifierFunc = window['type14_IdentifierFunc'];
type14_IdentifierFunc.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type14_IdentifierFunc.prototype.Load = function() {
	 return this.vtbl.Load(arguments[0], this);
};
type14_IdentifierFunc.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type14_IdentifierFunc.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type14_IdentifierFunc.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type14_IdentifierVari = {
	Save: method21_type14_IdentifierVari_4_Save, 
	Load: method21_type14_IdentifierVari_4_Load, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type14_IdentifierVari'] = function() {
	this.attr8_Name_Str = "";
	this.attr8_datatype = new type8_Datatype();
	this.attr3_Typ = 0;
	this.attr2_ID = 0;
	this.attr6_PreDef = 0;
	this.attr3_ref = 0;
	this.attr9_OwnerVari = 0;
	this.attr4_func = 0;
	this.vtbl = vtbl_type14_IdentifierVari;
	this.attr6_PreDef = -(1);
	this.attr3_ref = 0;
	this.attr9_OwnerVari = -(1);
	return this;
	
};
window['type14_IdentifierVari'].prototype.clone = function() {
	var other = new type14_IdentifierVari();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr8_datatype = tryClone(this.attr8_datatype);
	other.attr3_Typ = this.attr3_Typ;
	other.attr2_ID = this.attr2_ID;
	other.attr6_PreDef = this.attr6_PreDef;
	other.attr3_ref = this.attr3_ref;
	other.attr9_OwnerVari = this.attr9_OwnerVari;
	other.attr4_func = this.attr4_func;
	other.vtbl = this.vtbl;
	return other;
};
type14_IdentifierVari = window['type14_IdentifierVari'];
type14_IdentifierVari.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type14_IdentifierVari.prototype.Load = function() {
	 return this.vtbl.Load(arguments[0], this);
};
type14_IdentifierVari.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type14_IdentifierVari.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type14_IdentifierVari.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type14_IdentifierType = {
	Save: method21_type14_IdentifierType_4_Save, 
	Load: method21_type14_IdentifierType_4_Load, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type14_IdentifierType'] = function() {
	this.attr8_Name_Str = "";
	this.attr12_RealName_Str = "";
	this.attr10_Attributes = new OTTArray(0);
	this.attr7_Methods = new OTTArray(0);
	this.attr7_PreSize = new OTTArray(0);
	this.attr2_ID = 0;
	this.attr9_Extending = 0;
	this.attr10_Createable = 0;
	this.attr8_IsNative = 0;
	this.vtbl = vtbl_type14_IdentifierType;
	this.attr9_Extending = -(1);
	this.attr10_Createable = 1;
	this.attr8_IsNative = 0;
	return this;
	
};
window['type14_IdentifierType'].prototype.clone = function() {
	var other = new type14_IdentifierType();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr12_RealName_Str = this.attr12_RealName_Str;
	other.attr10_Attributes = tryClone(this.attr10_Attributes);
	other.attr7_Methods = tryClone(this.attr7_Methods);
	other.attr7_PreSize = tryClone(this.attr7_PreSize);
	other.attr2_ID = this.attr2_ID;
	other.attr9_Extending = this.attr9_Extending;
	other.attr10_Createable = this.attr10_Createable;
	other.attr8_IsNative = this.attr8_IsNative;
	other.vtbl = this.vtbl;
	return other;
};
type14_IdentifierType = window['type14_IdentifierType'];
type14_IdentifierType.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type14_IdentifierType.prototype.Load = function() {
	 return this.vtbl.Load(arguments[0], this);
};
type14_IdentifierType.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type14_IdentifierType.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type14_IdentifierType.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type8_Datatype = {
	Save: method14_type8_Datatype_4_Save, 
	Load: method14_type8_Datatype_4_Load, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type8_Datatype'] = function() {
	this.attr8_Name_Str_ref = [""];
	this.attr7_IsArray_ref = [0];
	this.vtbl = vtbl_type8_Datatype;
	return this;
	
};
window['type8_Datatype'].prototype.clone = function() {
	var other = new type8_Datatype();
	other.attr8_Name_Str_ref = tryClone(this.attr8_Name_Str_ref);
	other.attr7_IsArray_ref = tryClone(this.attr7_IsArray_ref);
	other.vtbl = this.vtbl;
	return other;
};
type8_Datatype = window['type8_Datatype'];
type8_Datatype.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type8_Datatype.prototype.Load = function() {
	 return this.vtbl.Load(arguments[0], this);
};
type8_Datatype.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type8_Datatype.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type8_Datatype.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type9_DataBlock = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type9_DataBlock'] = function() {
	this.attr8_Name_Str = "";
	this.attr5_Datas = new OTTArray(0);
	this.vtbl = vtbl_type9_DataBlock;
	return this;
	
};
window['type9_DataBlock'].prototype.clone = function() {
	var other = new type9_DataBlock();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr5_Datas = tryClone(this.attr5_Datas);
	other.vtbl = this.vtbl;
	return other;
};
type9_DataBlock = window['type9_DataBlock'];
type9_DataBlock.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type9_DataBlock.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type9_DataBlock.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type12_ProtoChecker = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type12_ProtoChecker'] = function() {
	this.attr3_Tok = new type5_Token();
	this.attr8_fromFunc = 0;
	this.attr6_toFunc = 0;
	this.vtbl = vtbl_type12_ProtoChecker;
	return this;
	
};
window['type12_ProtoChecker'].prototype.clone = function() {
	var other = new type12_ProtoChecker();
	other.attr3_Tok = tryClone(this.attr3_Tok);
	other.attr8_fromFunc = this.attr8_fromFunc;
	other.attr6_toFunc = this.attr6_toFunc;
	other.vtbl = this.vtbl;
	return other;
};
type12_ProtoChecker = window['type12_ProtoChecker'];
type12_ProtoChecker.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type12_ProtoChecker.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type12_ProtoChecker.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type5_Token = {
	Load: method11_type5_Token_4_Load, 
	Save: method11_type5_Token_4_Save, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type5_Token'] = function() {
	this.attr4_Line_ref = [0];
	this.attr15_LineContent_Str_ref = [""];
	this.attr9_Character_ref = [0];
	this.attr8_Path_Str_ref = [""];
	this.attr8_Text_Str_ref = [""];
	this.attr5_IsDel = 0;
	this.vtbl = vtbl_type5_Token;
	this.attr5_IsDel = 0;
	return this;
	
};
window['type5_Token'].prototype.clone = function() {
	var other = new type5_Token();
	other.attr4_Line_ref = tryClone(this.attr4_Line_ref);
	other.attr15_LineContent_Str_ref = tryClone(this.attr15_LineContent_Str_ref);
	other.attr9_Character_ref = tryClone(this.attr9_Character_ref);
	other.attr8_Path_Str_ref = tryClone(this.attr8_Path_Str_ref);
	other.attr8_Text_Str_ref = tryClone(this.attr8_Text_Str_ref);
	other.attr5_IsDel = this.attr5_IsDel;
	other.vtbl = this.vtbl;
	return other;
};
type5_Token = window['type5_Token'];
type5_Token.prototype.Load = function() {
	 return this.vtbl.Load(arguments[0], this);
};
type5_Token.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type5_Token.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type5_Token.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type5_Token.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type7_TExport = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type7_TExport'] = function() {
	this.attr8_Name_Str = "";
	this.attr12_RealName_Str = "";
	this.vtbl = vtbl_type7_TExport;
	return this;
	
};
window['type7_TExport'].prototype.clone = function() {
	var other = new type7_TExport();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr12_RealName_Str = this.attr12_RealName_Str;
	other.vtbl = this.vtbl;
	return other;
};
type7_TExport = window['type7_TExport'];
type7_TExport.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type7_TExport.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type7_TExport.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type4_Expr = {
	Load: method10_type4_Expr_4_Load, 
	Save: method10_type4_Expr_4_Save, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type4_Expr'] = function() {
	this.attr8_datatype = new type8_Datatype();
	this.attr3_Typ = 0;
	this.attr2_ID = 0;
	this.attr5_tokID = 0;
	this.attr4_Left = 0;
	this.attr5_Right = 0;
	this.attr2_Op = 0;
	this.attr5_Exprs = new OTTArray(0);
	this.attr5_Varis = new OTTArray(0);
	this.attr10_SuperScope = 0;
	this.attr6_ScpTyp = 0;
	this.attr6_Labels = new OTTArray(0);
	this.attr5_Gotos = new OTTArray(0);
	this.attr6_intval = 0;
	this.attr8_floatval = 0.0;
	this.attr10_strval_Str = "";
	this.attr4_func = 0;
	this.attr6_Params = new OTTArray(0);
	this.attr8_wasAdded = 0;
	this.attr4_vari = 0;
	this.attr5_array = 0;
	this.attr4_dims = new OTTArray(0);
	this.attr4_expr = 0;
	this.attr8_nextExpr = 0;
	this.attr8_Name_Str = "";
	this.attr10_Conditions = new OTTArray(0);
	this.attr6_Scopes = new OTTArray(0);
	this.attr9_elseScope = 0;
	this.attr5_dummy = 0.0;
	this.attr3_Scp = 0;
	this.attr7_varExpr = 0;
	this.attr6_toExpr = 0;
	this.attr8_stepExpr = 0;
	this.attr5_hasTo = 0;
	this.attr6_inExpr = 0;
	this.attr8_catchScp = 0;
	this.attr5_Reads = new OTTArray(0);
	this.attr4_kern = 0;
	this.attr8_position = 0;
	this.attr11_Content_Str = "";
	this.vtbl = vtbl_type4_Expr;
	this.attr10_SuperScope = -(1);
	this.attr8_wasAdded = 0;
	this.attr9_elseScope = -(1);
	this.attr5_dummy = -(42);
	this.attr4_kern = -(1);
	return this;
	
};
window['type4_Expr'].prototype.clone = function() {
	var other = new type4_Expr();
	other.attr8_datatype = tryClone(this.attr8_datatype);
	other.attr3_Typ = this.attr3_Typ;
	other.attr2_ID = this.attr2_ID;
	other.attr5_tokID = this.attr5_tokID;
	other.attr4_Left = this.attr4_Left;
	other.attr5_Right = this.attr5_Right;
	other.attr2_Op = this.attr2_Op;
	other.attr5_Exprs = tryClone(this.attr5_Exprs);
	other.attr5_Varis = tryClone(this.attr5_Varis);
	other.attr10_SuperScope = this.attr10_SuperScope;
	other.attr6_ScpTyp = this.attr6_ScpTyp;
	other.attr6_Labels = tryClone(this.attr6_Labels);
	other.attr5_Gotos = tryClone(this.attr5_Gotos);
	other.attr6_intval = this.attr6_intval;
	other.attr8_floatval = this.attr8_floatval;
	other.attr10_strval_Str = this.attr10_strval_Str;
	other.attr4_func = this.attr4_func;
	other.attr6_Params = tryClone(this.attr6_Params);
	other.attr8_wasAdded = this.attr8_wasAdded;
	other.attr4_vari = this.attr4_vari;
	other.attr5_array = this.attr5_array;
	other.attr4_dims = tryClone(this.attr4_dims);
	other.attr4_expr = this.attr4_expr;
	other.attr8_nextExpr = this.attr8_nextExpr;
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr10_Conditions = tryClone(this.attr10_Conditions);
	other.attr6_Scopes = tryClone(this.attr6_Scopes);
	other.attr9_elseScope = this.attr9_elseScope;
	other.attr5_dummy = this.attr5_dummy;
	other.attr3_Scp = this.attr3_Scp;
	other.attr7_varExpr = this.attr7_varExpr;
	other.attr6_toExpr = this.attr6_toExpr;
	other.attr8_stepExpr = this.attr8_stepExpr;
	other.attr5_hasTo = this.attr5_hasTo;
	other.attr6_inExpr = this.attr6_inExpr;
	other.attr8_catchScp = this.attr8_catchScp;
	other.attr5_Reads = tryClone(this.attr5_Reads);
	other.attr4_kern = this.attr4_kern;
	other.attr8_position = this.attr8_position;
	other.attr11_Content_Str = this.attr11_Content_Str;
	other.vtbl = this.vtbl;
	return other;
};
type4_Expr = window['type4_Expr'];
type4_Expr.prototype.Load = function() {
	 return this.vtbl.Load(this);
};
type4_Expr.prototype.Save = function() {
	 return this.vtbl.Save(arguments[0], this);
};
type4_Expr.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type4_Expr.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type4_Expr.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type8_Operator = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type8_Operator'] = function() {
	this.attr8_Name_Str = "";
	this.attr7_Sym_Str = "";
	this.attr3_Typ = 0;
	this.attr4_Prio = 0;
	this.attr2_ID = 0;
	this.vtbl = vtbl_type8_Operator;
	return this;
	
};
window['type8_Operator'].prototype.clone = function() {
	var other = new type8_Operator();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr7_Sym_Str = this.attr7_Sym_Str;
	other.attr3_Typ = this.attr3_Typ;
	other.attr4_Prio = this.attr4_Prio;
	other.attr2_ID = this.attr2_ID;
	other.vtbl = this.vtbl;
	return other;
};
type8_Operator = window['type8_Operator'];
type8_Operator.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type8_Operator.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type8_Operator.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type7_TDefine = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type7_TDefine'] = function() {
	this.attr7_Key_Str = "";
	this.attr9_Value_Str = "";
	this.vtbl = vtbl_type7_TDefine;
	return this;
	
};
window['type7_TDefine'].prototype.clone = function() {
	var other = new type7_TDefine();
	other.attr7_Key_Str = this.attr7_Key_Str;
	other.attr9_Value_Str = this.attr9_Value_Str;
	other.vtbl = this.vtbl;
	return other;
};
type7_TDefine = window['type7_TDefine'];
type7_TDefine.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type7_TDefine.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type7_TDefine.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type10_TGenerator = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type10_TGenerator'] = function() {
	this.attr8_Name_Str = "";
	this.attr8_genProto = Lang_Generator_Str;
	this.vtbl = vtbl_type10_TGenerator;
	return this;
	
};
window['type10_TGenerator'].prototype.clone = function() {
	var other = new type10_TGenerator();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr8_genProto = tryClone(this.attr8_genProto);
	other.vtbl = this.vtbl;
	return other;
};
type10_TGenerator = window['type10_TGenerator'];
type10_TGenerator.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type10_TGenerator.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type10_TGenerator.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type13_Documentation = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type13_Documentation'] = function() {
	this.attr7_typ_Str = "";
	this.attr4_desc = new OTTArray(new type11_LangElement());
	this.attr8_name_Str = "";
	this.attr6_params = new OTTArray(new type12_ParamElement());
	this.attr7_see_Str = new OTTArray("");
	this.vtbl = vtbl_type13_Documentation;
	return this;
	
};
window['type13_Documentation'].prototype.clone = function() {
	var other = new type13_Documentation();
	other.attr7_typ_Str = this.attr7_typ_Str;
	other.attr4_desc = tryClone(this.attr4_desc);
	other.attr8_name_Str = this.attr8_name_Str;
	other.attr6_params = tryClone(this.attr6_params);
	other.attr7_see_Str = tryClone(this.attr7_see_Str);
	other.vtbl = this.vtbl;
	return other;
};
type13_Documentation = window['type13_Documentation'];
type13_Documentation.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type13_Documentation.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type13_Documentation.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type12_ParamElement = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type12_ParamElement'] = function() {
	this.attr8_name_Str = "";
	this.attr4_desc = new OTTArray(new type11_LangElement());
	this.vtbl = vtbl_type12_ParamElement;
	return this;
	
};
window['type12_ParamElement'].prototype.clone = function() {
	var other = new type12_ParamElement();
	other.attr8_name_Str = this.attr8_name_Str;
	other.attr4_desc = tryClone(this.attr4_desc);
	other.vtbl = this.vtbl;
	return other;
};
type12_ParamElement = window['type12_ParamElement'];
type12_ParamElement.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type12_ParamElement.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type12_ParamElement.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type11_LangElement = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type11_LangElement'] = function() {
	this.attr8_desc_Str = "";
	this.attr8_lang_Str = "";
	this.vtbl = vtbl_type11_LangElement;
	return this;
	
};
window['type11_LangElement'].prototype.clone = function() {
	var other = new type11_LangElement();
	other.attr8_desc_Str = this.attr8_desc_Str;
	other.attr8_lang_Str = this.attr8_lang_Str;
	other.vtbl = this.vtbl;
	return other;
};
type11_LangElement = window['type11_LangElement'];
type11_LangElement.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type11_LangElement.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type11_LangElement.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type6_Bucket = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type6_Bucket'] = function() {
	this.attr3_Set = 0;
	this.attr8_Elements = new OTTArray(new type8_KeyValue());
	this.attr7_Element = new type8_KeyValue();
	this.vtbl = vtbl_type6_Bucket;
	this.attr3_Set = 0;
	return this;
	
};
window['type6_Bucket'].prototype.clone = function() {
	var other = new type6_Bucket();
	other.attr3_Set = this.attr3_Set;
	other.attr8_Elements = tryClone(this.attr8_Elements);
	other.attr7_Element = tryClone(this.attr7_Element);
	other.vtbl = this.vtbl;
	return other;
};
type6_Bucket = window['type6_Bucket'];
type6_Bucket.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type6_Bucket.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type6_Bucket.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type8_KeyValue = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type8_KeyValue'] = function() {
	this.attr7_Key_Str = "";
	this.attr5_Value = 0;
	this.vtbl = vtbl_type8_KeyValue;
	return this;
	
};
window['type8_KeyValue'].prototype.clone = function() {
	var other = new type8_KeyValue();
	other.attr7_Key_Str = this.attr7_Key_Str;
	other.attr5_Value = this.attr5_Value;
	other.vtbl = this.vtbl;
	return other;
};
type8_KeyValue = window['type8_KeyValue'];
type8_KeyValue.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type8_KeyValue.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type8_KeyValue.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type7_HashMap = {
	Put: method13_type7_HashMap_3_Put, 
	DoesKeyExist: method13_type7_HashMap_12_DoesKeyExist, 
	GetValue: method13_type7_HashMap_8_GetValue, 
	Remove: method13_type7_HashMap_6_Remove, 
	ToArray: method13_type7_HashMap_7_ToArray, 
	SetSize: method13_type7_HashMap_7_SetSize, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type7_HashMap'] = function() {
	this.attr7_Buckets_ref = [new OTTArray([new type6_Bucket()])];
	this.attr8_Elements = 0;
	this.vtbl = vtbl_type7_HashMap;
	return this;
	
};
window['type7_HashMap'].prototype.clone = function() {
	var other = new type7_HashMap();
	other.attr7_Buckets_ref = tryClone(this.attr7_Buckets_ref);
	other.attr8_Elements = this.attr8_Elements;
	other.vtbl = this.vtbl;
	return other;
};
type7_HashMap = window['type7_HashMap'];
type7_HashMap.prototype.Put = function() {
	 return this.vtbl.Put(arguments[0], arguments[1], this);
};
type7_HashMap.prototype.DoesKeyExist = function() {
	 return this.vtbl.DoesKeyExist(arguments[0], this);
};
type7_HashMap.prototype.GetValue = function() {
	 return this.vtbl.GetValue(arguments[0], arguments[1], this);
};
type7_HashMap.prototype.Remove = function() {
	 return this.vtbl.Remove(arguments[0], this);
};
type7_HashMap.prototype.ToArray = function() {
	 return this.vtbl.ToArray(arguments[0], this);
};
type7_HashMap.prototype.SetSize = function() {
	 return this.vtbl.SetSize(arguments[0], this);
};
type7_HashMap.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type7_HashMap.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type7_HashMap.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type9_TTemplate = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type9_TTemplate'] = function() {
	this.attr8_Path_Str = "";
	this.attr8_Mode_Str = "";
	this.attr8_Name_Str = "";
	this.vtbl = vtbl_type9_TTemplate;
	return this;
	
};
window['type9_TTemplate'].prototype.clone = function() {
	var other = new type9_TTemplate();
	other.attr8_Path_Str = this.attr8_Path_Str;
	other.attr8_Mode_Str = this.attr8_Mode_Str;
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.vtbl = this.vtbl;
	return other;
};
type9_TTemplate = window['type9_TTemplate'];
type9_TTemplate.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type9_TTemplate.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type9_TTemplate.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type8_TLibrary = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type8_TLibrary'] = function() {
	this.attr8_Path_Str = "";
	this.attr8_Mode_Str = "";
	this.vtbl = vtbl_type8_TLibrary;
	return this;
	
};
window['type8_TLibrary'].prototype.clone = function() {
	var other = new type8_TLibrary();
	other.attr8_Path_Str = this.attr8_Path_Str;
	other.attr8_Mode_Str = this.attr8_Mode_Str;
	other.vtbl = this.vtbl;
	return other;
};
type8_TLibrary = window['type8_TLibrary'];
type8_TLibrary.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type8_TLibrary.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type8_TLibrary.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type10_TBlackList = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type10_TBlackList'] = function() {
	this.attr3_Typ = 0;
	this.attr8_Name_Str = "";
	this.attr10_Action_Str = "";
	this.vtbl = vtbl_type10_TBlackList;
	return this;
	
};
window['type10_TBlackList'].prototype.clone = function() {
	var other = new type10_TBlackList();
	other.attr3_Typ = this.attr3_Typ;
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr10_Action_Str = this.attr10_Action_Str;
	other.vtbl = this.vtbl;
	return other;
};
type10_TBlackList = window['type10_TBlackList'];
type10_TBlackList.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type10_TBlackList.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type10_TBlackList.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type7_TAction = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type7_TAction'] = function() {
	this.attr8_Name_Str = "";
	this.attr3_Att = new OTTArray(new type12_xmlAttribute());
	this.vtbl = vtbl_type7_TAction;
	return this;
	
};
window['type7_TAction'].prototype.clone = function() {
	var other = new type7_TAction();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr3_Att = tryClone(this.attr3_Att);
	other.vtbl = this.vtbl;
	return other;
};
type7_TAction = window['type7_TAction'];
type7_TAction.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type7_TAction.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type7_TAction.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type12_xmlAttribute = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type12_xmlAttribute'] = function() {
	this.attr8_Name_Str = "";
	this.attr9_Value_Str = "";
	this.vtbl = vtbl_type12_xmlAttribute;
	return this;
	
};
window['type12_xmlAttribute'].prototype.clone = function() {
	var other = new type12_xmlAttribute();
	other.attr8_Name_Str = this.attr8_Name_Str;
	other.attr9_Value_Str = this.attr9_Value_Str;
	other.vtbl = this.vtbl;
	return other;
};
type12_xmlAttribute = window['type12_xmlAttribute'];
type12_xmlAttribute.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type12_xmlAttribute.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type12_xmlAttribute.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type3_XML = {
	ReadXML: method9_type3_XML_7_ReadXML, 
	ParseLayer: method9_type3_XML_10_ParseLayer, 
	ParseNode: method9_type3_XML_9_ParseNode, 
	ParseIdentifier_Str: method9_type3_XML_19_ParseIdentifier_Str, 
	Get_Str: method9_type3_XML_7_Get_Str, 
	SkipWhitespaces: method9_type3_XML_15_SkipWhitespaces, 
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type3_XML'] = function() {
	this.attr8_Text_Str = "";
	this.attr5_Event = XMLEvent;
	this.attr8_Position = 0;
	this.attr8_DontCall = 0;
	this.vtbl = vtbl_type3_XML;
	this.attr8_DontCall = 0;
	return this;
	
};
window['type3_XML'].prototype.clone = function() {
	var other = new type3_XML();
	other.attr8_Text_Str = this.attr8_Text_Str;
	other.attr5_Event = tryClone(this.attr5_Event);
	other.attr8_Position = this.attr8_Position;
	other.attr8_DontCall = this.attr8_DontCall;
	other.vtbl = this.vtbl;
	return other;
};
type3_XML = window['type3_XML'];
type3_XML.prototype.ReadXML = function() {
	 return this.vtbl.ReadXML(arguments[0], arguments[1], this);
};
type3_XML.prototype.ParseLayer = function() {
	 return this.vtbl.ParseLayer(this);
};
type3_XML.prototype.ParseNode = function() {
	 return this.vtbl.ParseNode(this);
};
type3_XML.prototype.ParseIdentifier_Str = function() {
	 return this.vtbl.ParseIdentifier_Str(this);
};
type3_XML.prototype.Get_Str = function() {
	 return this.vtbl.Get_Str(this);
};
type3_XML.prototype.SkipWhitespaces = function() {
	 return this.vtbl.SkipWhitespaces(this);
};
type3_XML.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type3_XML.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type3_XML.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type7_TObject = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type7_TObject'] = function() {
	this.vtbl = vtbl_type7_TObject;
	return this;
	
};
window['type7_TObject'].prototype.clone = function() {
	var other = new type7_TObject();
	other.vtbl = this.vtbl;
	return other;
};
type7_TObject = window['type7_TObject'];
type7_TObject.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type7_TObject.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type7_TObject.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type6_TObj3D = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type6_TObj3D'] = function() {
	this.vtbl = vtbl_type6_TObj3D;
	return this;
	
};
window['type6_TObj3D'].prototype.clone = function() {
	var other = new type6_TObj3D();
	other.vtbl = this.vtbl;
	return other;
};
type6_TObj3D = window['type6_TObj3D'];
type6_TObj3D.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type6_TObj3D.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type6_TObj3D.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var vtbl_type10_DataBuffer = {
	ToString_Str: method13_type7_TObject_12_ToString_Str, 
	Equals: method13_type7_TObject_6_Equals, 
	ToHashCode: method13_type7_TObject_10_ToHashCode
};
window ['type10_DataBuffer'] = function() {
	this.vtbl = vtbl_type10_DataBuffer;
	return this;
	
};
window['type10_DataBuffer'].prototype.clone = function() {
	var other = new type10_DataBuffer();
	other.vtbl = this.vtbl;
	return other;
};
type10_DataBuffer = window['type10_DataBuffer'];
type10_DataBuffer.prototype.ToString_Str = function() {
	 return this.vtbl.ToString_Str(this);
};
type10_DataBuffer.prototype.Equals = function() {
	 return this.vtbl.Equals(arguments[0], this);
};
type10_DataBuffer.prototype.ToHashCode = function() {
	 return this.vtbl.ToHashCode(this);
};
var const11_VERSION_Str = "1", const11_XMLNAME_Str = "WIN32", const12_FUNC_IS_FUNC = 1, const11_FUNC_IS_SUB = 2, const14_FUNC_IS_METHOD = 3, const13_FUNC_IS_PROTO = 4, const22_IDENTIFIERFUNC_VERSION = 1000, const13_VARI_IS_LOCAL = 1, const14_VARI_IS_GLOBAL = 2, const12_VARI_IS_ATTR = 3, const14_VARI_IS_STATIC = 4, const13_VARI_IS_PARAM = 5, const13_VARI_IS_CONST = 6, const13_VARI_IS_ALIAS = 7, const22_IDENTIFIERVARI_VERSION = 2000, const22_IDENTIFIERTYPE_VERSION = 3000, const16_DATATYPE_VERSION = 4000, const13_TOKEN_VERSION = 5000, const11_SCOPE_IS_IF = 1, const13_SCOPE_IS_FUNC = 2, const13_SCOPE_IS_LOOP = 3, const13_SCOPE_IS_MAIN = 4, const12_SCOPE_IS_TRY = 5, const15_SCOPE_IS_SELECT = 6, const12_EXPR_VERSION = 1, const11_OP_IS_UNAER = 1, const12_OP_IS_BINAER = 2, const10_OP_IS_BOOL = 3, const16_EXPR_IS_OPERATOR = 1, const13_EXPR_IS_SCOPE = 2, const11_EXPR_IS_INT = 3, const13_EXPR_IS_FLOAT = 4, const11_EXPR_IS_STR = 5, const16_EXPR_IS_FUNCCALL = 6, const13_EXPR_IS_EMPTY = 7, const13_EXPR_IS_DEBUG = 8, const12_EXPR_IS_VARI = 9, const14_EXPR_IS_ASSIGN = 10, const11_EXPR_IS_DIM = 11, const13_EXPR_IS_REDIM = 12, const13_EXPR_IS_ARRAY = 13, const16_EXPR_IS_CAST2INT = 15, const18_EXPR_IS_CAST2FLOAT = 16, const19_EXPR_IS_CAST2STRING = 17, const14_EXPR_IS_ACCESS = 18, const14_EXPR_IS_RETURN = 19, const12_EXPR_IS_GOTO = 20, const13_EXPR_IS_LABEL = 21, const16_EXPR_IS_FUNCDATA = 22, const17_EXPR_IS_PROTOCALL = 23, const10_EXPR_IS_IF = 24, const13_EXPR_IS_WHILE = 25, const14_EXPR_IS_REPEAT = 26, const11_EXPR_IS_FOR = 27, const13_EXPR_IS_BREAK = 29, const16_EXPR_IS_CONTINUE = 30, const11_EXPR_IS_TRY = 31, const13_EXPR_IS_THROW = 32, const15_EXPR_IS_RESTORE = 33, const12_EXPR_IS_READ = 34, const14_EXPR_IS_DEFVAL = 35, const17_EXPR_IS_DIMASEXPR = 36, const13_EXPR_IS_ALIAS = 37, const15_EXPR_IS_FOREACH = 38, const11_EXPR_IS_INC = 39, const15_EXPR_IS_DIMPUSH = 40, const11_EXPR_IS_LEN = 41, const15_EXPR_IS_DIMDATA = 42, const14_EXPR_IS_DELETE = 43, const14_EXPR_IS_DIMDEL = 44, const13_EXPR_IS_BOUND = 45, const11_EXPR_IS_NOT = 46, const13_EXPR_IS_DUMMY = 47, const17_EXPR_IS_ADDRESSOF = 48, const14_EXPR_IS_ASSERT = 49, const19_EXPR_IS_DEBUGOUTPUT = 50, const11_EXPR_IS_IIF = 51, const15_EXPR_IS_REQUIRE = 52, const13_EXPR_IS_SUPER = 53, const16_EXPR_IS_CAST2OBJ = 54, const6_BL_EXT = 1, const7_BL_FILE = 2, const19_GL_DEPTH_BUFFER_BIT = 256, const21_GL_STENCIL_BUFFER_BIT = 1024, const19_GL_COLOR_BUFFER_BIT = 16384, const8_GL_FALSE = 0, const7_GL_TRUE = 1, const9_GL_POINTS = 0, const8_GL_LINES = 1, const12_GL_LINE_LOOP = 2, const13_GL_LINE_STRIP = 3, const12_GL_TRIANGLES = 4, const17_GL_TRIANGLE_STRIP = 5, const15_GL_TRIANGLE_FAN = 6, const7_GL_ZERO = 0, const6_GL_ONE = 1, const12_GL_SRC_COLOR = 768, const22_GL_ONE_MINUS_SRC_COLOR = 769, const12_GL_SRC_ALPHA = 770, const22_GL_ONE_MINUS_SRC_ALPHA = 771, const12_GL_DST_ALPHA = 772, const22_GL_ONE_MINUS_DST_ALPHA = 773, const12_GL_DST_COLOR = 774, const22_GL_ONE_MINUS_DST_COLOR = 775, const21_GL_SRC_ALPHA_SATURATE = 776, const11_GL_FUNC_ADD = 32774, const17_GL_BLEND_EQUATION = 32777, const21_GL_BLEND_EQUATION_RGB = 32777, const23_GL_BLEND_EQUATION_ALPHA = 34877, const16_GL_FUNC_SUBTRACT = 32778, const24_GL_FUNC_REVERSE_SUBTRACT = 32779, const16_GL_BLEND_DST_RGB = 32968, const16_GL_BLEND_SRC_RGB = 32969, const18_GL_BLEND_DST_ALPHA = 32970, const18_GL_BLEND_SRC_ALPHA = 32971, const17_GL_CONSTANT_COLOR = 32769, const27_GL_ONE_MINUS_CONSTANT_COLOR = 32770, const17_GL_CONSTANT_ALPHA = 32771, const27_GL_ONE_MINUS_CONSTANT_ALPHA = 32772, const14_GL_BLEND_COLOR = 32773, const15_GL_ARRAY_BUFFER = 34962, const23_GL_ELEMENT_ARRAY_BUFFER = 34963, const23_GL_ARRAY_BUFFER_BINDING = 34964, const31_GL_ELEMENT_ARRAY_BUFFER_BINDING = 34965, const14_GL_STREAM_DRAW = 35040, const14_GL_STATIC_DRAW = 35044, const15_GL_DYNAMIC_DRAW = 35048, const14_GL_BUFFER_SIZE = 34660, const15_GL_BUFFER_USAGE = 34661, const24_GL_CURRENT_VERTEX_ATTRIB = 34342, const8_GL_FRONT = 1028, const7_GL_BACK = 1029, const17_GL_FRONT_AND_BACK = 1032, const13_GL_TEXTURE_2D = 3553, const12_GL_CULL_FACE = 2884, const8_GL_BLEND = 3042, const9_GL_DITHER = 3024, const15_GL_STENCIL_TEST = 2960, const13_GL_DEPTH_TEST = 2929, const15_GL_SCISSOR_TEST = 3089, const22_GL_POLYGON_OFFSET_FILL = 32823, const27_GL_SAMPLE_ALPHA_TO_COVERAGE = 32926, const18_GL_SAMPLE_COVERAGE = 32928, const11_GL_NO_ERROR = 0, const15_GL_INVALID_ENUM = 1280, const16_GL_INVALID_VALUE = 1281, const20_GL_INVALID_OPERATION = 1282, const16_GL_OUT_OF_MEMORY = 1285, const5_GL_CW = 2304, const6_GL_CCW = 2305, const13_GL_LINE_WIDTH = 2849, const27_GL_ALIASED_POINT_SIZE_RANGE = 33901, const27_GL_ALIASED_LINE_WIDTH_RANGE = 33902, const17_GL_CULL_FACE_MODE = 2885, const13_GL_FRONT_FACE = 2886, const14_GL_DEPTH_RANGE = 2928, const18_GL_DEPTH_WRITEMASK = 2930, const20_GL_DEPTH_CLEAR_VALUE = 2931, const13_GL_DEPTH_FUNC = 2932, const22_GL_STENCIL_CLEAR_VALUE = 2961, const15_GL_STENCIL_FUNC = 2962, const15_GL_STENCIL_FAIL = 2964, const26_GL_STENCIL_PASS_DEPTH_FAIL = 2965, const26_GL_STENCIL_PASS_DEPTH_PASS = 2966, const14_GL_STENCIL_REF = 2967, const21_GL_STENCIL_VALUE_MASK = 2963, const20_GL_STENCIL_WRITEMASK = 2968, const20_GL_STENCIL_BACK_FUNC = 34816, const20_GL_STENCIL_BACK_FAIL = 34817, const31_GL_STENCIL_BACK_PASS_DEPTH_FAIL = 34818, const31_GL_STENCIL_BACK_PASS_DEPTH_PASS = 34819, const19_GL_STENCIL_BACK_REF = 36003, const26_GL_STENCIL_BACK_VALUE_MASK = 36004, const25_GL_STENCIL_BACK_WRITEMASK = 36005, const11_GL_VIEWPORT = 2978, const14_GL_SCISSOR_BOX = 3088, const20_GL_COLOR_CLEAR_VALUE = 3106, const18_GL_COLOR_WRITEMASK = 3107, const19_GL_UNPACK_ALIGNMENT = 3317, const17_GL_PACK_ALIGNMENT = 3333, const19_GL_MAX_TEXTURE_SIZE = 3379, const20_GL_MAX_VIEWPORT_DIMS = 3386, const16_GL_SUBPIXEL_BITS = 3408, const11_GL_RED_BITS = 3410, const13_GL_GREEN_BITS = 3411, const12_GL_BLUE_BITS = 3412, const13_GL_ALPHA_BITS = 3413, const13_GL_DEPTH_BITS = 3414, const15_GL_STENCIL_BITS = 3415, const23_GL_POLYGON_OFFSET_UNITS = 10752, const24_GL_POLYGON_OFFSET_FACTOR = 32824, const21_GL_TEXTURE_BINDING_2D = 32873, const17_GL_SAMPLE_BUFFERS = 32936, const10_GL_SAMPLES = 32937, const24_GL_SAMPLE_COVERAGE_VALUE = 32938, const25_GL_SAMPLE_COVERAGE_INVERT = 32939, const33_GL_NUM_COMPRESSED_TEXTURE_FORMATS = 34466, const29_GL_COMPRESSED_TEXTURE_FORMATS = 34467, const12_GL_DONT_CARE = 4352, const10_GL_FASTEST = 4353, const9_GL_NICEST = 4354, const23_GL_GENERATE_MIPMAP_HINT = 33170, const7_GL_BYTE = 5120, const16_GL_UNSIGNED_BYTE = 5121, const8_GL_SHORT = 5122, const17_GL_UNSIGNED_SHORT = 5123, const6_GL_INT = 5124, const15_GL_UNSIGNED_INT = 5125, const8_GL_FLOAT = 5126, const8_GL_FIXED = 5132, const18_GL_DEPTH_COMPONENT = 6402, const8_GL_ALPHA = 6406, const6_GL_RGB = 6407, const7_GL_RGBA = 6408, const12_GL_LUMINANCE = 6409, const18_GL_LUMINANCE_ALPHA = 6410, const25_GL_UNSIGNED_SHORT_4_4_4_4 = 32819, const25_GL_UNSIGNED_SHORT_5_5_5_1 = 32820, const23_GL_UNSIGNED_SHORT_5_6_5 = 33635, const18_GL_FRAGMENT_SHADER = 35632, const16_GL_VERTEX_SHADER = 35633, const21_GL_MAX_VERTEX_ATTRIBS = 34921, const29_GL_MAX_VERTEX_UNIFORM_VECTORS = 36347, const22_GL_MAX_VARYING_VECTORS = 36348, const35_GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS = 35661, const33_GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS = 35660, const26_GL_MAX_TEXTURE_IMAGE_UNITS = 34930, const31_GL_MAX_FRAGMENT_UNIFORM_VECTORS = 36349, const14_GL_SHADER_TYPE = 35663, const16_GL_DELETE_STATUS = 35712, const14_GL_LINK_STATUS = 35714, const18_GL_VALIDATE_STATUS = 35715, const19_GL_ATTACHED_SHADERS = 35717, const18_GL_ACTIVE_UNIFORMS = 35718, const28_GL_ACTIVE_UNIFORM_MAX_LENGTH = 35719, const20_GL_ACTIVE_ATTRIBUTES = 35721, const30_GL_ACTIVE_ATTRIBUTE_MAX_LENGTH = 35722, const27_GL_SHADING_LANGUAGE_VERSION = 35724, const18_GL_CURRENT_PROGRAM = 35725, const8_GL_NEVER = 512, const7_GL_LESS = 513, const8_GL_EQUAL = 514, const9_GL_LEQUAL = 515, const10_GL_GREATER = 516, const11_GL_NOTEQUAL = 517, const9_GL_GEQUAL = 518, const9_GL_ALWAYS = 519, const7_GL_KEEP = 7680, const10_GL_REPLACE = 7681, const7_GL_INCR = 7682, const7_GL_DECR = 7683, const9_GL_INVERT = 5386, const12_GL_INCR_WRAP = 34055, const12_GL_DECR_WRAP = 34056, const9_GL_VENDOR = 7936, const11_GL_RENDERER = 7937, const10_GL_VERSION = 7938, const13_GL_EXTENSIONS = 7939, const10_GL_NEAREST = 9728, const9_GL_LINEAR = 9729, const25_GL_NEAREST_MIPMAP_NEAREST = 9984, const24_GL_LINEAR_MIPMAP_NEAREST = 9985, const24_GL_NEAREST_MIPMAP_LINEAR = 9986, const23_GL_LINEAR_MIPMAP_LINEAR = 9987, const21_GL_TEXTURE_MAG_FILTER = 10240, const21_GL_TEXTURE_MIN_FILTER = 10241, const17_GL_TEXTURE_WRAP_S = 10242, const17_GL_TEXTURE_WRAP_T = 10243, const10_GL_TEXTURE = 5890, const19_GL_TEXTURE_CUBE_MAP = 34067, const27_GL_TEXTURE_BINDING_CUBE_MAP = 34068, const30_GL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069, const30_GL_TEXTURE_CUBE_MAP_NEGATIVE_X = 34070, const30_GL_TEXTURE_CUBE_MAP_POSITIVE_Y = 34071, const30_GL_TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072, const30_GL_TEXTURE_CUBE_MAP_POSITIVE_Z = 34073, const30_GL_TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074, const28_GL_MAX_CUBE_MAP_TEXTURE_SIZE = 34076, const11_GL_TEXTURE0 = 33984, const11_GL_TEXTURE1 = 33985, const11_GL_TEXTURE2 = 33986, const11_GL_TEXTURE3 = 33987, const11_GL_TEXTURE4 = 33988, const11_GL_TEXTURE5 = 33989, const11_GL_TEXTURE6 = 33990, const11_GL_TEXTURE7 = 33991, const11_GL_TEXTURE8 = 33992, const11_GL_TEXTURE9 = 33993, const12_GL_TEXTURE10 = 33994, const12_GL_TEXTURE11 = 33995, const12_GL_TEXTURE12 = 33996, const12_GL_TEXTURE13 = 33997, const12_GL_TEXTURE14 = 33998, const12_GL_TEXTURE15 = 33999, const12_GL_TEXTURE16 = 34000, const12_GL_TEXTURE17 = 34001, const12_GL_TEXTURE18 = 34002, const12_GL_TEXTURE19 = 34003, const12_GL_TEXTURE20 = 34004, const12_GL_TEXTURE21 = 34005, const12_GL_TEXTURE22 = 34006, const12_GL_TEXTURE23 = 34007, const12_GL_TEXTURE24 = 34008, const12_GL_TEXTURE25 = 34009, const12_GL_TEXTURE26 = 34010, const12_GL_TEXTURE27 = 34011, const12_GL_TEXTURE28 = 34012, const12_GL_TEXTURE29 = 34013, const12_GL_TEXTURE30 = 34014, const12_GL_TEXTURE31 = 34015, const17_GL_ACTIVE_TEXTURE = 34016, const9_GL_REPEAT = 10497, const16_GL_CLAMP_TO_EDGE = 33071, const18_GL_MIRRORED_REPEAT = 33648, const13_GL_FLOAT_VEC2 = 35664, const13_GL_FLOAT_VEC3 = 35665, const13_GL_FLOAT_VEC4 = 35666, const11_GL_INT_VEC2 = 35667, const11_GL_INT_VEC3 = 35668, const11_GL_INT_VEC4 = 35669, const7_GL_BOOL = 35670, const12_GL_BOOL_VEC2 = 35671, const12_GL_BOOL_VEC3 = 35672, const12_GL_BOOL_VEC4 = 35673, const13_GL_FLOAT_MAT2 = 35674, const13_GL_FLOAT_MAT3 = 35675, const13_GL_FLOAT_MAT4 = 35676, const13_GL_SAMPLER_2D = 35678, const15_GL_SAMPLER_CUBE = 35680, const30_GL_VERTEX_ATTRIB_ARRAY_ENABLED = 34338, const27_GL_VERTEX_ATTRIB_ARRAY_SIZE = 34339, const29_GL_VERTEX_ATTRIB_ARRAY_STRIDE = 34340, const27_GL_VERTEX_ATTRIB_ARRAY_TYPE = 34341, const33_GL_VERTEX_ATTRIB_ARRAY_NORMALIZED = 34922, const30_GL_VERTEX_ATTRIB_ARRAY_POINTER = 34373, const37_GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = 34975, const33_GL_IMPLEMENTATION_COLOR_READ_TYPE = 35738, const35_GL_IMPLEMENTATION_COLOR_READ_FORMAT = 35739, const17_GL_COMPILE_STATUS = 35713, const18_GL_INFO_LOG_LENGTH = 35716, const23_GL_SHADER_SOURCE_LENGTH = 35720, const18_GL_SHADER_COMPILER = 36346, const24_GL_SHADER_BINARY_FORMATS = 36344, const28_GL_NUM_SHADER_BINARY_FORMATS = 36345, const12_GL_LOW_FLOAT = 36336, const15_GL_MEDIUM_FLOAT = 36337, const13_GL_HIGH_FLOAT = 36338, const10_GL_LOW_INT = 36339, const13_GL_MEDIUM_INT = 36340, const11_GL_HIGH_INT = 36341, const14_GL_FRAMEBUFFER = 36160, const15_GL_RENDERBUFFER = 36161, const8_GL_RGBA4 = 32854, const10_GL_RGB5_A1 = 32855, const9_GL_RGB565 = 36194, const20_GL_DEPTH_COMPONENT16 = 33189, const16_GL_STENCIL_INDEX = 6401, const17_GL_STENCIL_INDEX8 = 36168, const21_GL_RENDERBUFFER_WIDTH = 36162, const22_GL_RENDERBUFFER_HEIGHT = 36163, const31_GL_RENDERBUFFER_INTERNAL_FORMAT = 36164, const24_GL_RENDERBUFFER_RED_SIZE = 36176, const26_GL_RENDERBUFFER_GREEN_SIZE = 36177, const25_GL_RENDERBUFFER_BLUE_SIZE = 36178, const26_GL_RENDERBUFFER_ALPHA_SIZE = 36179, const26_GL_RENDERBUFFER_DEPTH_SIZE = 36180, const28_GL_RENDERBUFFER_STENCIL_SIZE = 36181, const37_GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = 36048, const37_GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = 36049, const39_GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = 36050, const47_GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = 36051, const20_GL_COLOR_ATTACHMENT0 = 36064, const19_GL_DEPTH_ATTACHMENT = 36096, const21_GL_STENCIL_ATTACHMENT = 36128, const7_GL_NONE = 0, const23_GL_FRAMEBUFFER_COMPLETE = 36053, const36_GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 36054, const44_GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 36055, const36_GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS = 36057, const26_GL_FRAMEBUFFER_UNSUPPORTED = 36061, const22_GL_FRAMEBUFFER_BINDING = 36006, const23_GL_RENDERBUFFER_BINDING = 36007, const24_GL_MAX_RENDERBUFFER_SIZE = 34024, const32_GL_INVALID_FRAMEBUFFER_OPERATION = 1286, global10_LastExprID = 0.0, global5_Exprs_ref = [new OTTArray([new type4_Expr()])], global8_LastType = new type14_IdentifierType(), global12_voidDatatype = new type8_Datatype(), global11_intDatatype = new type8_Datatype(), global13_floatDatatype = new type8_Datatype(), global11_strDatatype = new type8_Datatype(), global9_Operators_ref = [new OTTArray([new type8_Operator()])], global10_KeywordMap = new type7_HashMap(), global8_Compiler = new type9_TCompiler(), global7_Defines = new OTTArray(new type7_TDefine()), global10_LastDefine = new type7_TDefine(), global10_Generators = new OTTArray(new type10_TGenerator()), global13_SettingIn_Str = "", global11_SHLASHF_Str = "", MaxPasses = 0, global14_Documentations = new OTTArray(new type13_Documentation()), global9_GFX_WIDTH = 0.0, global10_GFX_HEIGHT = 0.0, global10_FULLSCREEN = 0, global9_FRAMERATE = 0, global11_APPNAME_Str = "", global9_DEBUGMODE = 0, global7_CONSOLE = 0.0, global6_STRICT = 0.0, global15_USRDEF_VERS_Str = "", global14_GbapOutput_Str = "", global12_GbapPath_Str = "", global12_GbapName_Str = "", global6_Ignore = 0, global13_OptimizeLevel = 0, global12_CurrentScope = 0, global14_ForEachCounter = 0, global11_CurrentFunc = 0, global12_LabelDef_Str = "", global8_IsInGoto = 0, global11_LoopBreakID = 0, global14_LoopContinueID = 0, global11_LastDummyID = 0, global14_StaticText_Str = "", global6_Indent = 0, global9_Templates = new OTTArray(new type9_TTemplate()), global9_Libraries = new OTTArray(new type8_TLibrary()), global10_Blacklists = new OTTArray(new type10_TBlackList()), global7_Actions = new OTTArray(new type7_TAction()), global8_Mode_Str = "", global10_Target_Str = "", global13_SettingIn_Str = "", global9_Templates = new OTTArray(new type9_TTemplate()), global8_Lang_Str = "", global22_DirectoryStructure_Str = "", global5_NoRun = 0, global6_Objs3D = new OTTArray(new type6_TObj3D());
// set default statics:
window['initStatics'] = function() {
	static12_Factor_DIMASEXPRErr = 0;
static12_Keyword_SelectHelper = 0.0, static7_Keyword_GOTOErr = 0;

}
initStatics = window['initStatics'];
for (var __init = 0; __init < preInitFuncs.length; __init++) preInitFuncs[__init]();
